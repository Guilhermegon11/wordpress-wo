/* Villa Ibit Club — interações do tema (sem dependências; usa jQuery só para eventos do WooCommerce, se existir). */
(function () {
  'use strict';
  var $ = window.jQuery;
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function ready(fn) { if (document.readyState !== 'loading') { fn(); } else { document.addEventListener('DOMContentLoaded', fn); } }

  /* ---------- Banner ---------- */
  function initSlider(track) {
    if (track.dataset.viReady) { return; }
    track.dataset.viReady = '1';
    var slides = track.querySelectorAll('.vi-slide');
    if (slides.length < 2) { return; }
    var dots = track.querySelectorAll('[data-vi-dot]');
    var count = track.querySelector('[data-vi-count]');
    var index = 0, timer = null, delay = (window.VI && VI.autoplay) || 6500;

    function go(i) {
      index = (i + slides.length) % slides.length;
      slides.forEach(function (s, n) {
        var on = n === index;
        s.classList.toggle('is-active', on);
        s.setAttribute('aria-hidden', on ? 'false' : 'true');
        s.querySelectorAll('a,button').forEach(function (el) { el.tabIndex = on ? 0 : -1; });
      });
      dots.forEach(function (d, n) { if (n === index) { d.setAttribute('aria-current', 'true'); } else { d.removeAttribute('aria-current'); } });
      if (count) { count.textContent = (index < 9 ? '0' : '') + (index + 1); }
      track.classList.toggle('is-light', slides[index].classList.contains('vi-slide--dourado') || slides[index].classList.contains('vi-slide--natureza'));
    }
    function play() { if (reduceMotion) { return; } stop(); timer = setInterval(function () { go(index + 1); }, delay); }
    function stop() { if (timer) { clearInterval(timer); timer = null; } }

    var prev = track.querySelector('[data-vi-prev]'), next = track.querySelector('[data-vi-next]');
    if (prev) { prev.addEventListener('click', function () { go(index - 1); play(); }); }
    if (next) { next.addEventListener('click', function () { go(index + 1); play(); }); }
    dots.forEach(function (d) { d.addEventListener('click', function () { go(parseInt(d.getAttribute('data-vi-dot'), 10)); play(); }); });
    track.addEventListener('mouseenter', stop);
    track.addEventListener('mouseleave', play);
    track.addEventListener('focusin', stop);
    track.addEventListener('focusout', play);

    // Arrastar no celular.
    var x0 = null;
    track.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
    track.addEventListener('touchend', function (e) {
      if (x0 === null) { return; }
      var dx = e.changedTouches[0].clientX - x0;
      if (Math.abs(dx) > 50) { go(index + (dx < 0 ? 1 : -1)); play(); }
      x0 = null;
    });
    go(0);
    play();
  }

  /* ---------- Abas da vitrine ---------- */
  function initTabs(root) {
    if (root.dataset.viReady) { return; }
    root.dataset.viReady = '1';
    var tabs = Array.prototype.slice.call(root.querySelectorAll('[role="tab"]'));
    function select(tab) {
      tabs.forEach(function (t) {
        var on = t === tab;
        t.setAttribute('aria-selected', on ? 'true' : 'false');
        t.tabIndex = on ? 0 : -1;
        var panel = document.getElementById(t.getAttribute('aria-controls'));
        if (panel) { panel.hidden = !on; }
      });
    }
    tabs.forEach(function (t, i) {
      t.addEventListener('click', function () { select(t); });
      t.addEventListener('keydown', function (e) {
        var dir = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0;
        if (!dir) { return; }
        e.preventDefault();
        var n = tabs[(i + dir + tabs.length) % tabs.length];
        select(n); n.focus();
      });
    });
  }

  /* ---------- Sabores/cores como botões (produtos variáveis) ---------- */
  if ($) {
    $(document).on('show_variation hide_variation', 'form.variations_form', function (event, variation, purchasable) {
      var buyNow = this.querySelector('.vi-buy-now');
      if (buyNow) { buyNow.disabled = event.type !== 'show_variation' || !purchasable; }
    });
    $(document).on('found_variation reset_data', '.vi-product__buy form.variations_form', function (event, variation) {
      // Uma variação que aceita qualquer atributo precisa do POST completo do WooCommerce.
      var attrs = variation && variation.attributes;
      this.dataset.viFixedVariation = event.type === 'found_variation' && attrs && Object.keys(attrs).length &&
        Object.keys(attrs).every(function (key) { return attrs[key] !== ''; }) ? '1' : '0';
      var summary = this.closest('.vi-product__summary');
      var box = summary && summary.querySelector('.vi-product__pricebox');
      if (!box) { return; }
      if (typeof box.viBasePrice === 'undefined') { box.viBasePrice = box.innerHTML; }
      box.innerHTML = event.type === 'found_variation' && variation && variation.vi_price_html
        ? variation.vi_price_html : box.viBasePrice;
    });
  }
  function initVariationChips(form) {
    var selects = form.querySelectorAll('table.variations select');
    selects.forEach(function (select) {
      if (select.dataset.viChips) { return; }
      select.dataset.viChips = '1';
      var label = form.querySelector('label[for="' + select.id + '"]');
      var chosen = document.createElement('span');
      chosen.className = 'vi-chosen';
      if (label) { label.appendChild(document.createTextNode(': ')); label.appendChild(chosen); }
      var group = document.createElement('div');
      group.className = 'vi-chips';
      group.setAttribute('role', 'group');
      if (label) { group.setAttribute('aria-label', label.textContent.replace(':', '').trim()); }
      select.parentNode.insertBefore(group, select);
      select.classList.add('vi-select-hidden');
      select.setAttribute('tabindex', '-1');
      select.setAttribute('aria-hidden', 'true');

      function build() {
        group.innerHTML = '';
        Array.prototype.forEach.call(select.options, function (opt) {
          if (!opt.value) { return; }
          var b = document.createElement('button');
          b.type = 'button';
          b.textContent = opt.textContent;
          b.dataset.value = opt.value;
          b.disabled = opt.disabled;
          b.setAttribute('aria-pressed', select.value === opt.value ? 'true' : 'false');
          b.addEventListener('click', function () {
            select.value = select.value === opt.value ? '' : opt.value;
            if ($) { $(select).trigger('change'); } else { select.dispatchEvent(new Event('change', { bubbles: true })); }
            sync();
          });
          group.appendChild(b);
        });
        sync();
      }
      function sync() {
        group.querySelectorAll('button').forEach(function (b) {
          b.setAttribute('aria-pressed', b.dataset.value === select.value ? 'true' : 'false');
        });
        var opt = select.options[select.selectedIndex];
        chosen.textContent = opt && opt.value ? opt.textContent : '';
      }
      build();
      select.addEventListener('change', sync);
      if ($) {
        $(form).on('woocommerce_update_variation_values', build);
        $(form).on('reset_data', function () { setTimeout(sync, 0); });
      }
    });
  }

  /* ---------- Botões − / + da quantidade ---------- */
  function initQty(scope) {
    (scope || document).querySelectorAll('.quantity').forEach(function (q) {
      var input = q.querySelector('input.qty');
      if (!input || q.dataset.viQty || input.type === 'hidden') { return; }
      q.dataset.viQty = '1';
      function step(dir) {
        var s = parseFloat(input.step) || 1, min = parseFloat(input.min) || 0, max = parseFloat(input.max) || Infinity;
        var v = (parseFloat(input.value) || 0) + dir * s;
        v = Math.max(min, Math.min(max, v));
        input.value = v;
        if ($) { $(input).trigger('change'); } else { input.dispatchEvent(new Event('change', { bubbles: true })); }
      }
      var minus = document.createElement('button'), plus = document.createElement('button');
      minus.type = plus.type = 'button';
      minus.className = plus.className = 'vi-qty-btn';
      minus.textContent = '−'; plus.textContent = '+';
      minus.setAttribute('aria-label', 'Diminuir quantidade');
      plus.setAttribute('aria-label', 'Aumentar quantidade');
      minus.addEventListener('click', function () { step(-1); });
      plus.addEventListener('click', function () { step(1); });
      q.insertBefore(minus, input);
      q.appendChild(plus);
    });
  }

  /* ---------- Gavetas (menu mobile e filtros) ---------- */
  function drawer(panel, openers, closer) {
    var overlay = document.querySelector('.vi-nav-overlay');
    function open() {
      panel.classList.add('is-open');
      openers.forEach(function (o) { o.setAttribute('aria-expanded', 'true'); });
      if (overlay) { overlay.hidden = false; overlay.onclick = close; }
      document.body.style.overflow = 'hidden';
      scrollLock(true);
      var f = panel.querySelector('a,button'); if (f) { f.focus(); }
    }
    function close() {
      panel.classList.remove('is-open');
      openers.forEach(function (o) { o.setAttribute('aria-expanded', 'false'); });
      if (overlay) { overlay.hidden = true; }
      document.body.style.overflow = '';
      scrollLock(false);
      if (openers[0]) { openers[0].focus(); }
    }
    openers.forEach(function (o) { o.addEventListener('click', open); });
    if (closer) { closer.addEventListener('click', close); }
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && panel.classList.contains('is-open')) { close(); } });
  }

  /* Inicializa um trecho da página (usado também pelo editor do Elementor). */
  function initScope(scope) {
    scope = scope || document;
    if (scope.matches && scope.matches('[data-vi-slider]')) { initSlider(scope); }
    scope.querySelectorAll('[data-vi-slider]').forEach(initSlider);
    scope.querySelectorAll('[data-vi-tabs]').forEach(initTabs);
    scope.querySelectorAll('[data-vi-scroller]').forEach(initScroller);
    scope.querySelectorAll('form.variations_form').forEach(initVariationChips);
    initQty(scope);
  }
  window.VIinit = initScope;

  /* ---------- Carrinho lateral ---------- */
  var lastFocus = null;
  var cartCloseTimer;
  function cartDrawer() { return document.getElementById('vi-cart'); }
  function openCart(added) {
    var d = cartDrawer();
    if (!d || (window.VI && Number(VI.noDrawer) === 1)) { return false; }
    clearTimeout(cartCloseTimer);
    if (!d.contains(document.activeElement)) { lastFocus = document.activeElement; }
    d.hidden = false;
    var note = d.querySelector('[data-vi-cart-added]');
    if (note) { note.hidden = !added; }
    requestAnimationFrame(function () { d.classList.add('is-open'); });
    document.documentElement.classList.add('vi-lock');
    scrollLock(true);
    var c = d.querySelector('[data-vi-cart-close].vi-icon-btn'); if (c) { c.focus(); }
    return true;
  }
  function closeCart() {
    var d = cartDrawer();
    if (!d || d.hidden) { return; }
    d.classList.remove('is-open');
    document.documentElement.classList.remove('vi-lock');
    scrollLock(false);
    clearTimeout(cartCloseTimer);
    cartCloseTimer = setTimeout(function () { d.hidden = true; }, 280);
    if (lastFocus && lastFocus.focus) { lastFocus.focus(); }
  }
  document.addEventListener('click', function (e) {
    var btn = e.target.closest ? e.target.closest('.vi-cart-btn, [data-vi-cart-open]') : null;
    if (btn && openCart(false)) { e.preventDefault(); return; }
    if (e.target.closest && e.target.closest('[data-vi-cart-close]')) { e.preventDefault(); closeCart(); }
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { closeCart(); } });

  /* Página do produto: adiciona sem recarregar e abre a gaveta. */
  function ajaxAddToCart(form) {
    if (!$ || !window.VI || !VI.wcAjax || !cartDrawer()) { return false; }
    if (form.classList.contains('grouped_form') || form.closest('.product-type-external')) { return false; }
    // Campos de kits, atacado e personalização devem chegar intactos ao próprio plugin.
    var hasExtensionFields = Array.prototype.some.call(form.elements, function (field) {
      return field.name && !['add-to-cart', 'product_id', 'variation_id', 'quantity'].includes(field.name) &&
        !(field.matches('select') && field.name.indexOf('attribute_') === 0);
    });
    if (hasExtensionFields || form.enctype === 'multipart/form-data' && form.querySelector('input[type="file"]')) { return false; }
    var variation = form.querySelector('input[name="variation_id"]');
    if (variation && form.dataset.viFixedVariation !== '1') { return false; }
    var addInput = form.querySelector('[name="add-to-cart"]');
    var id = variation ? parseInt(variation.value, 10) : parseInt(addInput ? addInput.value : 0, 10);
    if (!id) { return false; }
    var qty = form.querySelector('input.qty');
    var button = form.querySelector('.single_add_to_cart_button');
    var $btn = $(button);
    $btn.addClass('loading').prop('disabled', true);
    $.post(VI.wcAjax.toString().replace('%%endpoint%%', 'add_to_cart'), { product_id: id, quantity: qty ? qty.value : 1 })
      .done(function (r) {
        if (!r || r.error) {
          window.location.assign((r && r.product_url) || VI.cartUrl);
          return;
        }
        if (r.fragments) { $.each(r.fragments, function (k, v) { $(k).replaceWith(v); }); }
        $(document.body).trigger('added_to_cart', [r.fragments, r.cart_hash, $btn]);
      })
      // Sem confirmação da resposta, confira o carrinho em vez de reenviar a compra.
      .fail(function () { window.location.assign(VI.cartUrl); })
      .always(function () { $btn.removeClass('loading').prop('disabled', false); });
    return true;
  }

  /* ---------- Faixa que desliza para o lado (Novidades/destaques) ---------- */
  function initScroller(box) {
    if (box.dataset.viReady) { return; }
    box.dataset.viReady = '1';
    var list = box.querySelector('ul.products');
    var bar = box.closest('.vi-featbar');
    if (!list || !bar) { return; }
    var prev = bar.querySelector('[data-vi-scroll-prev]'), next = bar.querySelector('[data-vi-scroll-next]');
    function update() {
      var max = list.scrollWidth - list.clientWidth - 2;
      if (prev) { prev.disabled = list.scrollLeft <= 2; }
      if (next) { next.disabled = list.scrollLeft >= max; }
    }
    function step(dir) {
      var card = list.querySelector('li');
      var gap = parseFloat(getComputedStyle(list).columnGap) || 14;
      var w = card ? card.getBoundingClientRect().width + gap : list.clientWidth;
      var per = Math.max(1, Math.floor((list.clientWidth + gap) / w));
      list.scrollBy({ left: dir * per * w, behavior: reduceMotion ? 'auto' : 'smooth' });
    }
    if (prev) { prev.addEventListener('click', function () { step(-1); }); }
    if (next) { next.addEventListener('click', function () { step(1); }); }
    /* Desktop: arrastar a faixa com o mouse. No celular o próprio dedo já rola. */
    var drag = null, dragEndedAt = 0;
    if (window.matchMedia && window.matchMedia('(pointer:fine)').matches) {
      box.classList.add('is-draggable');
      list.addEventListener('pointerdown', function (e) {
        if (e.pointerType !== 'mouse' || e.button !== 0) { return; }
        drag = { x: e.clientX, left: list.scrollLeft, moved: false };
      });
      window.addEventListener('pointermove', function (e) {
        if (!drag) { return; }
        var dx = e.clientX - drag.x;
        if (!drag.moved) {
          if (Math.abs(dx) < 6) { return; } // pequeno tremor não conta como arraste
          drag.moved = true;
          box.classList.add('is-dragging');
        }
        list.scrollLeft = drag.left - dx;
      });
      var endDrag = function () {
        if (!drag) { return; }
        if (drag.moved) { dragEndedAt = Date.now(); box.classList.remove('is-dragging'); }
        drag = null;
      };
      window.addEventListener('pointerup', endDrag);
      window.addEventListener('pointercancel', endDrag);
      // Depois de arrastar, o clique que sobra no card não abre o produto por engano.
      list.addEventListener('click', function (e) {
        if (Date.now() - dragEndedAt < 400) { e.preventDefault(); e.stopPropagation(); }
      }, true);
      list.addEventListener('dragstart', function (e) { e.preventDefault(); });
    }
    list.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update);
    update();
  }

  /* ---------- Rolagem suave da página (Lenis) ----------
   * Só a roda do mouse/trackpad ganha inércia; no celular o dedo continua com a rolagem nativa.
   * Menu, carrinho, filtros e faixas que rolam por dentro continuam rolando por dentro. */
  var lenis = null;
  function scrollLock(on) {
    if (!lenis) { return; }
    if (on) { lenis.stop(); } else { lenis.start(); }
  }
  function initSmoothScroll() {
    if (!window.Lenis || reduceMotion) { return; }
    // Editor do Elementor e prévias do personalizador rodam dentro de um iframe: sem rolagem suave.
    if (window.self !== window.top || document.body.classList.contains('elementor-editor-active')) { return; }
    lenis = new window.Lenis({
      lerp: 0.085,
      smoothWheel: true,
      syncTouch: false,
      allowNestedScroll: true,
      stopInertiaOnNavigate: true,
      autoRaf: true,
      prevent: function (node) {
        return node.id === 'vi-cart' || !!(node.classList && (node.classList.contains('pswp') || node.classList.contains('select2-results__options')));
      }
    });
    window.viLenis = lenis;
  }
  /* Links para um ponto da mesma página (#avaliacoes etc.) deslizam até lá, sem ficar atrás do topo.
   * Só quando nenhum outro script já tratou o clique (abas, lupa da galeria, submenus...). */
  function initAnchors() {
    document.addEventListener('click', function (e) {
      if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) { return; }
      var a = e.target.closest && e.target.closest('a[href*="#"]');
      if (!a || a.classList.contains('vi-skip') || a.target === '_blank') { return; }
      var url;
      try { url = new URL(a.href, location.href); } catch (err) { return; }
      if (url.host !== location.host || url.pathname !== location.pathname || url.search !== location.search || url.hash.length < 2) { return; }
      var target = null;
      try { target = document.getElementById(decodeURIComponent(url.hash.slice(1))) || document.querySelector(url.hash); } catch (err2) { return; }
      if (!target) { return; }
      e.preventDefault();
      if (lenis) {
        lenis.scrollTo(target); // o Lenis já desconta o scroll-padding-top (topo fixo) do CSS
      } else {
        target.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' }); // usa o scroll-padding-top do CSS
      }
      if (history.pushState) { history.pushState(null, '', url.hash); }
    });
  }

  /* ---------- Zoom suave na foto do produto (computador) ----------
   * A foto amplia devagar a partir do ponto do mouse e acompanha o movimento com atraso suave.
   * No celular o toque abre a foto em tela cheia (com pinça para ampliar). */
  function initGalleryZoom() {
    if (!window.matchMedia || !window.matchMedia('(hover:hover) and (pointer:fine)').matches) { return; }
    document.querySelectorAll('.woocommerce-product-gallery__image').forEach(function (slide) {
      var img = slide.querySelector('img');
      if (!img || slide.dataset.viZoom) { return; }
      slide.dataset.viZoom = '1';
      slide.classList.add('vi-zoomable');
      var cur = { x: 50, y: 50 }, tgt = { x: 50, y: 50 }, raf = 0, on = false;
      function paint() { img.style.transformOrigin = cur.x.toFixed(2) + '% ' + cur.y.toFixed(2) + '%'; }
      function frame() {
        cur.x += (tgt.x - cur.x) * 0.12;
        cur.y += (tgt.y - cur.y) * 0.12;
        paint();
        raf = (on || Math.abs(tgt.x - cur.x) > 0.05 || Math.abs(tgt.y - cur.y) > 0.05) ? requestAnimationFrame(frame) : 0;
      }
      function aim(e) {
        var r = slide.getBoundingClientRect();
        if (!r.width || !r.height) { return; }
        tgt.x = Math.min(100, Math.max(0, (e.clientX - r.left) / r.width * 100));
        tgt.y = Math.min(100, Math.max(0, (e.clientY - r.top) / r.height * 100));
        if (!raf) { raf = requestAnimationFrame(frame); }
      }
      function sharpen() {
        if (img.dataset.viZoomHd) { return; }
        img.dataset.viZoomHd = '1';
        if (img.getAttribute('srcset')) {
          img.setAttribute('sizes', '(max-width: 1024px) 100vw, 1600px'); // pede a versão grande do srcset
          return;
        }
        var big = img.getAttribute('data-large_image');
        if (big && big !== img.currentSrc) {
          var pre = new Image();
          pre.onload = function () { img.src = big; };
          pre.src = big;
        }
      }
      slide.addEventListener('pointerenter', function (e) {
        if (e.pointerType !== 'mouse') { return; }
        sharpen();
        on = true;
        aim(e);
        cur.x = tgt.x; cur.y = tgt.y; paint(); // começa a ampliar exatamente onde o mouse entrou
        slide.classList.add('is-zoom');
      });
      slide.addEventListener('pointermove', function (e) { if (on) { aim(e); } });
      slide.addEventListener('pointerleave', function () {
        on = false;
        slide.classList.remove('is-zoom'); // volta devagar a partir do mesmo ponto
      });
    });
  }

  /* ---------- Efeitos (visual natureza) ----------
   * Seções e cards surgem ao rolar, menu verde ganha sombra ao descer,
   * carrinho "pula" quando um item entra. Tudo desligado com "reduzir movimento". */
  function initEffects() {
    var root = document.documentElement;
    var tabs = document.querySelector('.vi-tabsnav');
    if (tabs) {
      var onScroll = function () { tabs.classList.toggle('is-stuck', window.scrollY > 140); };
      window.addEventListener('scroll', onScroll, { passive: true });
      onScroll();
    }
    if ($) {
      $(document.body).on('added_to_cart', function () {
        document.querySelectorAll('.vi-cart-btn, .vi-tabbar__cart-btn').forEach(function (el) {
          el.classList.remove('is-bump'); void el.offsetWidth; el.classList.add('is-bump');
        });
      });
    }
    if (reduceMotion || !('IntersectionObserver' in window) || !document.body.classList.contains('vi-fx')) { return; }
    var targets = document.querySelectorAll('.vi-main > section, .vi-main .elementor-widget > section, .vi-main > .vi-block, .vi-archive-hero, .vi-forest');
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (!e.isIntersecting) { return; }
        e.target.classList.add('is-in');
        e.target.querySelectorAll('ul.products > li, .vi-circle, .vi-promo, .vi-trust__item').forEach(function (el, i) {
          el.style.transitionDelay = Math.min(i, 8) * 70 + 'ms';
        });
        io.unobserve(e.target);
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    targets.forEach(function (t) {
      if (t.classList.contains('vi-hero')) { return; }
      var r = t.getBoundingClientRect();
      if (r.top < window.innerHeight * 0.92) { return; } // já visível ao abrir: sem animação
      t.classList.add('vi-reveal');
      io.observe(t);
    });
    root.classList.add('vi-fx-ready');
  }

  ready(function () {
    initSmoothScroll();
    initAnchors();
    initScope(document);
    initGalleryZoom();

    document.addEventListener('submit', function (e) {
      var form = e.target;
      if (e.defaultPrevented || !form.matches || !form.matches('form.cart')) { return; }
      if (e.submitter && (!e.submitter.matches('.single_add_to_cart_button') || e.submitter.hasAttribute('formaction'))) { return; }
      if (!form.closest('.vi-product__buy')) { return; }
      if (form.querySelector('.single_add_to_cart_button.disabled')) { return; }
      if (ajaxAddToCart(form)) { e.preventDefault(); }
    });
    if ($) {
      $(document.body).on('added_to_cart', function () { openCart(true); });
      $(document.body).on('removed_from_cart', function () {
        var note = document.querySelector('#vi-cart [data-vi-cart-added]');
        if (note) { note.hidden = true; }
      });
    }
    if (document.querySelector('[data-vi-open-cart]')) { openCart(true); }

    var nav = document.getElementById('vi-nav');
    if (nav) {
      drawer(nav, Array.prototype.slice.call(document.querySelectorAll('.vi-header__menu')), nav.querySelector('.vi-nav__close'));
      // Submenus no celular: toque abre/fecha.
      nav.querySelectorAll('li.has-children > a, li.menu-item-has-children > a').forEach(function (a) {
        a.addEventListener('click', function (e) {
          if (window.innerWidth > 1024) { return; }
          var li = a.parentNode;
          if (!li.classList.contains('is-expanded')) { e.preventDefault(); li.classList.add('is-expanded'); }
        });
      });
    }
    var filters = document.getElementById('vi-filters');
    if (filters) {
      drawer(filters, Array.prototype.slice.call(document.querySelectorAll('.vi-filters-open')), filters.querySelector('.vi-filters__close'));
    }
    /* Puffs: no computador, marcar já filtra. */
    document.querySelectorAll('form[data-vi-puffs]').forEach(function (f) {
      if (window.innerWidth > 1024) { f.setAttribute('data-vi-auto', '1'); }
      f.addEventListener('change', function () { if (window.innerWidth > 1024) { f.submit(); } });
    });

    initEffects();

    if ($) {
      $(document.body).on('updated_cart_totals updated_checkout wc_fragments_refreshed', function () { initQty(); });
      $(document).on('wc_variation_form', 'form.variations_form', function () { initVariationChips(this); });
    }
  });
})();
