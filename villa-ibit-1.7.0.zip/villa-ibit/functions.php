<?php
/**
 * Villa Ibit Club — funções do tema.
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;

define( 'VI_THEME_VER', '1.7.0' );
define( 'VI_THEME_DIR', get_template_directory() );
define( 'VI_THEME_URI', get_template_directory_uri() );

require VI_THEME_DIR . '/inc/helpers.php';
require VI_THEME_DIR . '/inc/icons.php';
require VI_THEME_DIR . '/inc/catalog.php';
require VI_THEME_DIR . '/inc/template-tags.php';

if ( class_exists( 'WooCommerce' ) ) {
	require VI_THEME_DIR . '/inc/woocommerce.php';
	require VI_THEME_DIR . '/inc/sections.php';
	require VI_THEME_DIR . '/inc/shop-sections.php';
	require VI_THEME_DIR . '/inc/elementor.php';
}

/**
 * Recursos do tema.
 */
function vi_setup() {
	load_theme_textdomain( 'villa-ibit', VI_THEME_DIR . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'custom-logo', array( 'height' => 120, 'width' => 520, 'flex-height' => true, 'flex-width' => true ) );
	add_theme_support( 'responsive-embeds' );

	add_theme_support(
		'woocommerce',
		array(
			'thumbnail_image_width' => 480,
			'single_image_width'    => 900,
			'product_grid'          => array( 'default_columns' => 4, 'min_columns' => 2, 'max_columns' => 6 ),
		)
	);
	// Zoom da foto do produto: o do WooCommerce (jQuery Zoom) pula seco para a foto grande.
	// O tema usa o próprio zoom suave (assets/js/main.js → initGalleryZoom). Por isso sem 'wc-product-gallery-zoom'.
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

	// Avisa o plugin "Villa Ibit Gestor" que o tema já exibe o preço no PIX.
	add_theme_support( 'vi-pix-display' );

	register_nav_menus(
		array(
			'principal' => __( 'Menu principal (topo e menu do celular)', 'villa-ibit' ),
			'abas'      => __( 'Abas no menu do celular (opcional: sem menu aqui, o tema mostra Início, Novidades, Promoções, Destaques, Mais vendidos, Combos e Atacado)', 'villa-ibit' ),
			'rodape'    => __( 'Rodapé — Institucional', 'villa-ibit' ),
		)
	);
}
add_action( 'after_setup_theme', 'vi_setup' );

/**
 * CSS e JS.
 */
function vi_assets() {
	wp_enqueue_style( 'vi-fonts', 'https://fonts.googleapis.com/css2?family=Sora:wght@500;600;700;800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700&display=swap', array(), null );
	wp_enqueue_style( 'vi-main', VI_THEME_URI . '/assets/css/main.css', array(), VI_THEME_VER );
	$deps = array( 'jquery' );
	/**
	 * Rolagem suave da página com a roda do mouse (Lenis). No celular a rolagem continua a nativa.
	 * Para desligar: add_filter( 'vi_smooth_scroll', '__return_false' );
	 */
	if ( apply_filters( 'vi_smooth_scroll', true ) ) {
		wp_enqueue_script( 'vi-lenis', VI_THEME_URI . '/assets/js/vendor/lenis.min.js', array(), '1.3.27', true );
		$deps[] = 'vi-lenis';
	}
	wp_enqueue_script( 'vi-main', VI_THEME_URI . '/assets/js/main.js', $deps, VI_THEME_VER, true );
	wp_localize_script(
		'vi-main',
		'VI',
		array(
			'autoplay' => 6500,
			'wcAjax'   => class_exists( 'WC_AJAX' ) ? WC_AJAX::get_endpoint( '%%endpoint%%' ) : '',
			'cartUrl'  => function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '',
			'noDrawer' => ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() ) ) ? 1 : 0,
			'i18n'     => array(
				'choose' => __( 'Escolha uma opção', 'villa-ibit' ),
			),
		)
	);
	if ( is_singular( 'post' ) && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'vi_assets' );

/**
 * Pré-conexão com o Google Fonts.
 */
function vi_resource_hints( $urls, $relation ) {
	if ( 'preconnect' === $relation ) {
		$urls[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' );
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'vi_resource_hints', 10, 2 );

/**
 * Classes no <body>.
 */
function vi_body_class( $classes ) {
	if ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() ) ) {
		$classes[] = 'vi-funnel';
	}
	return $classes;
}
add_filter( 'body_class', 'vi_body_class' );

/**
 * Resumo mais curto nos cards do blog.
 */
add_filter( 'excerpt_length', function () { return 22; } );
add_filter( 'excerpt_more', function () { return '…'; } );

/**
 * Uma atualização invalida somente o cache do tema. O conteúdo das páginas pertence à loja.
 */
add_action(
	'init',
	function () {
		if ( get_option( 'vi_theme_version' ) !== VI_THEME_VER ) {
			update_option( 'vi_theme_version', VI_THEME_VER, false );
			vi_cache_flush();
		}
	},
	5
);
