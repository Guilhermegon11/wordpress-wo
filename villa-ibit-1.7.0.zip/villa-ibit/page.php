<?php
/**
 * Páginas (inclui Carrinho, Finalizar compra e Minha conta).
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;

get_header();

// Páginas montadas no Elementor ou com as seções [villa_ibit]: largura total, sem título automático.
$vi_post = get_post();
if ( $vi_post && ( ( did_action( 'elementor/loaded' ) && 'builder' === get_post_meta( $vi_post->ID, '_elementor_edit_mode', true ) ) || has_shortcode( $vi_post->post_content, 'villa_ibit' ) ) ) {
	echo '<main id="conteudo" class="vi-main vi-elementor">';
	while ( have_posts() ) {
		the_post();
		the_content();
	}
	echo '</main>';
	get_footer();
	return;
}

$vi_is_wc   = function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() );
$vi_funnel  = function_exists( 'is_cart' ) && ( is_cart() || is_checkout() );
?>
<main id="conteudo" class="vi-main vi-page<?php echo $vi_is_wc ? ' vi-page--shop' : ''; ?>">
	<div class="vi-container<?php echo $vi_is_wc ? '' : ' vi-container--narrow'; ?>">
		<?php while ( have_posts() ) : the_post(); ?>
			<?php if ( $vi_funnel ) : ?>
				<?php vi_checkout_steps(); ?>
			<?php else : ?>
				<header class="vi-page__head"><?php the_title( '<h1 class="vi-page__title">', '</h1>' ); ?></header>
			<?php endif; ?>
			<div class="vi-content entry-content">
				<?php the_content(); ?>
				<?php wp_link_pages(); ?>
			</div>
			<?php if ( $vi_funnel ) : ?>
				<?php vi_render_trust( 'vi-trust--compact' ); ?>
			<?php endif; ?>
		<?php endwhile; ?>
	</div>
</main>
<?php
get_footer();
