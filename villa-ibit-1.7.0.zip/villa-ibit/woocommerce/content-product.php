<?php
/**
 * Card de produto (vitrines, categorias, busca, relacionados).
 *
 * @package VillaIbit
 * @version 9.4.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! is_a( $product, WC_Product::class ) || ! $product->is_visible() ) {
	return;
}

$vi_meta  = vi_card_meta( $product );
$vi_link  = $product->get_permalink();
$vi_label = $vi_meta['brand'] ? $vi_meta['brand'] : $vi_meta['cat'];
?>
<li <?php wc_product_class( 'vi-card', $product ); ?>>
	<div class="vi-card__media">
		<a href="<?php echo esc_url( $vi_link ); ?>" class="vi-card__img" tabindex="-1" aria-hidden="true">
			<?php echo $product->get_image( 'woocommerce_thumbnail', array( 'loading' => 'lazy' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</a>
		<?php $vi_badge = $GLOBALS['vi_card_badge'] ?? ''; ?>
		<?php if ( 'new' === $vi_badge ) : ?>
			<span class="vi-badge-new"><?php esc_html_e( 'Novo', 'villa-ibit' ); ?></span>
		<?php elseif ( 'hot' === $vi_badge ) : ?>
			<span class="vi-badge-hot"><?php vi_the_icon( 'fire', 12 ); ?><?php esc_html_e( 'Mais vendido', 'villa-ibit' ); ?></span>
		<?php endif; ?>
		<?php if ( $product->is_on_sale() ) : ?>
			<?php woocommerce_show_product_loop_sale_flash(); ?>
		<?php endif; ?>
		<?php if ( ! $product->is_in_stock() ) : ?>
			<span class="vi-badge-out"><?php esc_html_e( 'Esgotado', 'villa-ibit' ); ?></span>
		<?php elseif ( $vi_meta['extra'] ) : ?>
			<span class="vi-card__flavors"><?php echo esc_html( $vi_meta['extra'] ); ?></span>
		<?php endif; ?>
	</div>
	<div class="vi-card__body">
		<?php if ( $vi_label ) : ?>
			<p class="vi-card__meta"><?php echo esc_html( $vi_label ); ?></p>
		<?php endif; ?>
		<h2 class="woocommerce-loop-product__title vi-card__title"><a href="<?php echo esc_url( $vi_link ); ?>"><?php echo esc_html( $product->get_name() ); ?></a></h2>
		<?php echo vi_price_block( $product, 'card' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		<div class="vi-card__cta">
			<?php woocommerce_template_loop_add_to_cart(); ?>
		</div>
	</div>
</li>
