<?php
/**
 * Página do produto.
 * Se a página "Modelo — Página do produto" estiver montada no Elementor, o layout dela é usado.
 *
 * @package VillaIbit
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

global $product;

echo '<div class="vi-container vi-notices">';
do_action( 'woocommerce_before_single_product' );
echo '</div>';

if ( post_password_required() ) {
	echo get_the_password_form(); // phpcs:ignore WordPress.Security.EscapeOutput
	return;
}

$vi_tpl = vi_template_page( 'product' );

echo '<div id="product-' . (int) get_the_ID() . '" class="vi-single">';
if ( $vi_tpl ) {
	vi_render_elementor_page( $vi_tpl );
} else {
	vi_section_product_top();
	echo '<div class="vi-container vi-product">';
	do_action( 'woocommerce_after_single_product_summary' );
	echo '</div>';
}
echo '</div>';

do_action( 'woocommerce_after_single_product' );
