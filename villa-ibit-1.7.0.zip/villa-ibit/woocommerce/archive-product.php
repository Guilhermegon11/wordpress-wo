<?php
/**
 * Loja, categorias, marcas e busca de produtos.
 * Se a página "Todos os produtos" estiver montada no Elementor, o layout dela é usado aqui.
 *
 * @package VillaIbit
 * @version 8.6.0
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );
do_action( 'woocommerce_before_main_content' );

$vi_tpl = vi_template_page( 'catalog' );
if ( $vi_tpl ) {
	vi_render_elementor_page( $vi_tpl );
} else {
	vi_section_catalog();
}

do_action( 'woocommerce_after_main_content' );
get_footer( 'shop' );
