<?php
/**
 * Página inicial.
 * Montada no Elementor (página "Início") ou, sem Elementor, com as seções padrão da loja.
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;

$vi_front = get_queried_object();
if ( is_page() && $vi_front instanceof WP_Post && ( '' !== trim( $vi_front->post_content ) || post_password_required( $vi_front ) || ( did_action( 'elementor/loaded' ) && 'builder' === get_post_meta( $vi_front->ID, '_elementor_edit_mode', true ) ) ) ) {
	get_header();
	echo '<main id="conteudo" class="vi-main vi-elementor">';
	while ( have_posts() ) {
		the_post();
		the_content();
	}
	echo '</main>';
	get_footer();
	return;
}

get_header();

if ( ! class_exists( 'WooCommerce' ) ) {
	echo '<main id="conteudo" class="vi-main vi-container"><p>' . esc_html__( 'Ative o WooCommerce para montar a loja.', 'villa-ibit' ) . '</p></main>';
	get_footer();
	return;
}
?>
<main id="conteudo" class="vi-main vi-home">
	<?php
	vi_section_hero( array( 'h1' => true ) );
	vi_section_trust();

	// O mapa mantém a ordem original quando o Gestor ainda não tem uma preferência salva.
	$vi_sections = array(
		'categories' => array( 'vi_section_categories', array( 'title' => __( 'Compre por categoria', 'villa-ibit' ), 'link_all' => 'yes' ) ),
		'novidades'  => array( 'vi_section_products', array( 'source' => 'novidades', 'title' => __( 'Novidades', 'villa-ibit' ), 'limit' => 12, 'columns' => 5, 'style' => 'band' ) ),
		'promos'     => array( 'vi_section_promos' ),
		'duo'        => array( 'vi_section_duo' ),
		'featured'   => array( 'vi_section_featured' ),
		'tabs'       => array( 'vi_section_tabs', array( 'title' => __( 'Mais vendidos', 'villa-ibit' ) ) ),
		'spotlight'  => array( 'vi_section_spotlight' ),
		'deals'      => array( 'vi_section_products', array( 'source' => 'ofertas', 'title' => __( 'Ofertas que valem a pena', 'villa-ibit' ), 'style' => 'list' ) ),
		'brands'     => array( 'vi_section_brands', array( 'title' => __( 'Marcas originais', 'villa-ibit' ) ) ),
		'extra'      => array(
			'vi_section_products',
			array(
				'title'    => vi_opt( 'extra_title' ),
				'subtitle' => __( 'Aparelhos e kits de alta performance — e tudo para manter o seu em dia.', 'villa-ibit' ),
				'source'   => 'categoria',
				'terms'    => (array) vi_opt( 'extra_cats', array() ),
				'limit'    => 8,
				'columns'  => 4,
				'style'    => 'light',
			),
		),
		'wholesale'  => array( 'vi_section_wholesale' ),
		'reviews'    => array( 'vi_section_reviews' ),
		'blog'       => array( 'vi_section_blog' ),
		'social'     => array( 'vi_section_social' ),
	);
	$vi_preference = vi_opt( 'home_order' );
	$vi_ordered    = array();
	if ( is_array( $vi_preference ) ) {
		foreach ( $vi_preference as $vi_key ) {
			if ( is_string( $vi_key ) && isset( $vi_sections[ $vi_key ] ) ) {
				$vi_ordered[ $vi_key ] = $vi_sections[ $vi_key ];
			}
		}
	}
	foreach ( $vi_ordered + $vi_sections as $vi_key => $vi_section ) {
		if ( vi_section_on( $vi_key ) ) {
			$vi_renderer = $vi_section[0];
			$vi_renderer( $vi_section[1] ?? array() );
		}
	}
	?>
</main>
<?php
get_footer();
