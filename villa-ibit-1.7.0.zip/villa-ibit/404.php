<?php
/**
 * Página não encontrada.
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="conteudo" class="vi-main">
	<div class="vi-container vi-container--narrow vi-404">
		<p class="vi-404__code">404</p>
		<h1 class="vi-page__title"><?php esc_html_e( 'Essa página saiu para uma pausa.', 'villa-ibit' ); ?></h1>
		<p><?php esc_html_e( 'O link pode ter mudado ou o produto não está mais disponível. Tente buscar:', 'villa-ibit' ); ?></p>
		<?php get_search_form(); ?>
		<p><a class="vi-btn vi-btn--green" href="<?php echo esc_url( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ) ); ?>"><?php esc_html_e( 'Ver todos os produtos', 'villa-ibit' ); ?></a></p>
	</div>
</main>
<?php
get_footer();
