<?php
/**
 * Comentários dos posts.
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;

if ( post_password_required() ) {
	return;
}
?>
<section id="comments" class="vi-comments">
	<?php if ( have_comments() ) : ?>
		<h2 class="vi-h3"><?php echo esc_html( sprintf( _n( '%d comentário', '%d comentários', get_comments_number(), 'villa-ibit' ), get_comments_number() ) ); ?></h2>
		<ol class="vi-comments__list"><?php wp_list_comments( array( 'style' => 'ol', 'avatar_size' => 40, 'short_ping' => true ) ); ?></ol>
		<?php the_comments_navigation(); ?>
	<?php endif; ?>
	<?php comment_form(); ?>
</section>
