<?php
/**
 * Cabeçalho.
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;
$vi_topbar = array_filter( array_map( 'trim', explode( "\n", (string) vi_opt( 'topbar' ) ) ) );
$vi_icons  = array( vi_pix_percent() ? 'pix' : 'lock', 'clock', 'truck', 'shield' );
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#034D43">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="vi-skip" href="#conteudo"><?php esc_html_e( 'Pular para o conteúdo', 'villa-ibit' ); ?></a>

<div class="vi-topbar">
	<div class="vi-container vi-topbar__inner">
		<ul class="vi-topbar__list">
			<?php foreach ( array_values( $vi_topbar ) as $i => $vi_line ) : ?>
				<li><?php vi_the_icon( $vi_icons[ $i % 4 ], 14 ); ?><?php echo esc_html( vi_store_notice( $vi_line ) ); ?></li>
			<?php endforeach; ?>
		</ul>
		<div class="vi-topbar__links">
			<?php if ( function_exists( 'wc_get_account_endpoint_url' ) ) : ?>
				<a href="<?php echo esc_url( wc_get_account_endpoint_url( 'orders' ) ); ?>"><?php esc_html_e( 'Rastrear minha compra', 'villa-ibit' ); ?></a>
			<?php endif; ?>
			<?php if ( vi_wa_link() ) : ?>
			<a class="is-gold" href="<?php echo esc_url( vi_wa_link() ); ?>" target="_blank" rel="noopener"><?php echo esc_html( sprintf( __( 'WhatsApp %s', 'villa-ibit' ), vi_opt( 'whatsapp_label' ) ) ); ?></a>
			<?php endif; ?>
		</div>
	</div>
</div>

<header class="vi-header">
	<div class="vi-container vi-header__inner">
		<div class="vi-header__left">
			<button class="vi-icon-btn vi-header__menu" type="button" aria-controls="vi-nav" aria-expanded="false" aria-label="<?php esc_attr_e( 'Abrir menu', 'villa-ibit' ); ?>"><?php vi_the_icon( 'menu', 24 ); ?></button>
			<nav class="vi-hnav" aria-label="<?php esc_attr_e( 'Principal', 'villa-ibit' ); ?>">
				<?php
				if ( has_nav_menu( 'principal' ) ) {
					wp_nav_menu( array( 'theme_location' => 'principal', 'container' => false, 'menu_class' => 'vi-hnav__list', 'menu_id' => 'vi-hnav-menu', 'depth' => 2 ) );
				} elseif ( class_exists( 'WooCommerce' ) ) {
					vi_nav_fallback( 'vi-hnav__list' );
				}
				?>
			</nav>
		</div>

		<a class="vi-header__logo<?php echo vi_opt( 'hero_nature', 1 ) ? ' has-leaves' : ''; ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) . ' — ' . __( 'início', 'villa-ibit' ) ); ?>">
			<?php if ( vi_opt( 'hero_nature', 1 ) ) : ?>
				<img class="vi-leaf vi-leaf--l" src="<?php echo esc_url( VI_THEME_URI . '/assets/img/natureza/folha-esq.webp' ); ?>" alt="" width="300" height="400" aria-hidden="true">
				<img class="vi-leaf vi-leaf--r" src="<?php echo esc_url( VI_THEME_URI . '/assets/img/natureza/folha-dir.webp' ); ?>" alt="" width="300" height="400" aria-hidden="true">
			<?php endif; ?>
			<?php echo vi_logo( 'verde' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</a>

		<div class="vi-header__actions">
			<form class="vi-search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
				<label class="screen-reader-text" for="vi-search-input"><?php esc_html_e( 'Buscar produtos', 'villa-ibit' ); ?></label>
				<button type="submit" aria-label="<?php esc_attr_e( 'Buscar', 'villa-ibit' ); ?>"><?php vi_the_icon( 'search', 18 ); ?></button>
				<input id="vi-search-input" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Buscar marca ou sabor', 'villa-ibit' ); ?>">
				<?php if ( class_exists( 'WooCommerce' ) ) : ?><input type="hidden" name="post_type" value="product"><?php endif; ?>
			</form>
			<?php if ( function_exists( 'wc_get_page_permalink' ) ) : ?>
				<a class="vi-account" href="<?php echo esc_url( is_user_logged_in() ? wc_get_page_permalink( 'myaccount' ) : vi_page_url( 'entrar', wc_get_page_permalink( 'myaccount' ) ) ); ?>" aria-label="<?php echo esc_attr( is_user_logged_in() ? __( 'Minha conta', 'villa-ibit' ) : __( 'Entrar ou cadastrar', 'villa-ibit' ) ); ?>" title="<?php echo esc_attr( is_user_logged_in() ? __( 'Minha conta', 'villa-ibit' ) : __( 'Entrar / Cadastrar', 'villa-ibit' ) ); ?>">
					<?php vi_the_icon( 'user', 20 ); ?>
				</a>
				<?php echo vi_header_cart(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<?php endif; ?>
		</div>
	</div>
</header>

<?php
$vi_show_categories = is_front_page() ? vi_section_on( 'categories' ) : 'all' === vi_opt( 'nav_scope' );
if ( $vi_show_categories && class_exists( 'WooCommerce' ) && ! is_cart() && ! is_checkout() && ! is_account_page() ) : ?>
<nav class="vi-catbar" aria-label="<?php esc_attr_e( 'Categorias', 'villa-ibit' ); ?>">
	<div class="vi-catbar__track">
		<?php
		$vi_cur = is_product_category() ? (int) get_queried_object_id() : 0;
		foreach ( vi_get_categories() as $vi_c ) :
			$vi_on = $vi_cur === (int) $vi_c['id'];
			?>
			<a class="vi-catbar__item<?php echo $vi_on ? ' is-on' : ''; ?>" href="<?php echo esc_url( $vi_c['link'] ); ?>"<?php echo $vi_on ? ' aria-current="page"' : ''; ?>>
				<span class="vi-catbar__img"><img src="<?php echo esc_url( ! empty( $vi_c['thumb_lg'] ) ? $vi_c['thumb_lg'] : $vi_c['thumb'] ); ?>" alt="" loading="lazy"></span>
				<span class="vi-catbar__name"><?php echo esc_html( $vi_c['name'] ); ?></span>
			</a>
		<?php endforeach; ?>
		<a class="vi-catbar__item vi-catbar__item--deal" href="<?php echo esc_url( vi_offers_url() ); ?>"><span class="vi-catbar__img" aria-hidden="true">%</span><span class="vi-catbar__name"><?php esc_html_e( 'Ofertas', 'villa-ibit' ); ?></span></a>
	</div>
</nav>
<?php endif; ?>

<nav id="vi-nav" class="vi-nav" aria-label="<?php esc_attr_e( 'Menu', 'villa-ibit' ); ?>">
	<div class="vi-container">
		<div class="vi-nav__head">
			<?php echo vi_logo( 'verde', 'vi-logo vi-nav__logo' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<button class="vi-icon-btn vi-nav__close" type="button" aria-label="<?php esc_attr_e( 'Fechar menu', 'villa-ibit' ); ?>"><?php vi_the_icon( 'close', 24 ); ?></button>
		</div>
		<?php if ( class_exists( 'WooCommerce' ) ) { vi_tabs_nav( 'vi-nav__tabs' ); } ?>
		<?php
		if ( has_nav_menu( 'principal' ) ) {
			wp_nav_menu( array( 'theme_location' => 'principal', 'container' => false, 'menu_class' => 'vi-nav__list', 'depth' => 2 ) );
		} elseif ( class_exists( 'WooCommerce' ) ) {
			vi_nav_fallback();
		}
		?>
		<div class="vi-nav__foot">
			<?php if ( function_exists( 'wc_get_page_permalink' ) ) : ?>
				<a class="vi-nav__account" href="<?php echo esc_url( is_user_logged_in() ? wc_get_page_permalink( 'myaccount' ) : vi_page_url( 'entrar', wc_get_page_permalink( 'myaccount' ) ) ); ?>"><?php vi_the_icon( 'user', 20 ); ?><?php echo is_user_logged_in() ? esc_html__( 'Minha conta', 'villa-ibit' ) : esc_html__( 'Entrar / Cadastrar', 'villa-ibit' ); ?></a>
			<?php endif; ?>
			<?php if ( vi_wa_link() ) : ?>
			<a class="vi-nav__wa" href="<?php echo esc_url( vi_wa_link() ); ?>" target="_blank" rel="noopener"><?php vi_the_icon( 'whatsapp', 20 ); ?><?php echo esc_html( sprintf( __( 'WhatsApp %s', 'villa-ibit' ), vi_opt( 'whatsapp_label' ) ) ); ?></a>
			<?php endif; ?>
		</div>
	</div>
</nav>
<div class="vi-nav-overlay" hidden></div>
