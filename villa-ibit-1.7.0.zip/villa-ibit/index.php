<?php
/**
 * Blog, arquivos e busca de posts.
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="conteudo" class="vi-main vi-blog">
	<div class="vi-container">
		<header class="vi-page__head">
			<h1 class="vi-page__title">
				<?php
				if ( is_search() ) {
					echo esc_html( sprintf( __( 'Busca: %s', 'villa-ibit' ), get_search_query() ) );
				} elseif ( is_archive() ) {
					echo esc_html( wp_strip_all_tags( get_the_archive_title() ) );
				} elseif ( is_home() && get_option( 'page_for_posts' ) ) {
					echo esc_html( get_the_title( get_option( 'page_for_posts' ) ) );
				} else {
					esc_html_e( 'Dicas, guias e novidades', 'villa-ibit' );
				}
				?>
			</h1>
		</header>
		<?php if ( have_posts() ) : ?>
			<div class="vi-posts">
				<?php while ( have_posts() ) : the_post(); $vi_cat = get_the_category(); ?>
					<a class="vi-post" href="<?php the_permalink(); ?>">
						<div class="vi-post__media">
							<?php the_post_thumbnail( 'medium_large', array( 'loading' => 'lazy', 'alt' => '' ) ); ?>
							<?php if ( $vi_cat ) : ?><span class="vi-post__tag"><?php echo esc_html( $vi_cat[0]->name ); ?></span><?php endif; ?>
						</div>
						<div class="vi-post__body">
							<h2><?php the_title(); ?></h2>
							<p><?php echo esc_html( get_the_excerpt() ); ?></p>
							<span class="vi-post__date"><?php echo esc_html( get_the_date() ); ?></span>
						</div>
					</a>
				<?php endwhile; ?>
			</div>
			<div class="vi-pagination"><?php the_posts_pagination( array( 'mid_size' => 1, 'prev_text' => '‹', 'next_text' => '›' ) ); ?></div>
		<?php else : ?>
			<p class="vi-empty"><?php esc_html_e( 'Nada encontrado por aqui.', 'villa-ibit' ); ?></p>
			<?php get_search_form(); ?>
		<?php endif; ?>
	</div>
</main>
<?php
get_footer();
