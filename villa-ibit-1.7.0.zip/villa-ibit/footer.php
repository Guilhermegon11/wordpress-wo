<?php
/**
 * Rodapé.
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;
$vi_has_wc = class_exists( 'WooCommerce' );
?>
<?php if ( vi_opt( 'hero_nature' ) ) : ?>
<div class="vi-forest" aria-hidden="true" style="--vi-forest:url(<?php echo esc_url( VI_THEME_URI . '/assets/img/natureza/rodape-folhas.jpg?v=' . VI_THEME_VER ); ?>)"></div>
<?php endif; ?>
<footer class="vi-footer">
	<div class="vi-container vi-footer__cols">
		<div class="vi-footer__brand">
			<?php echo vi_logo( 'dark', 'vi-logo vi-footer__logo' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<p><?php echo esc_html( vi_opt( 'about' ) ); ?></p>
			<div class="vi-footer__social">
				<?php if ( vi_instagram_url() ) : ?>
				<a href="<?php echo esc_url( vi_instagram_url() ); ?>" target="_blank" rel="noopener" aria-label="Instagram"><?php vi_the_icon( 'instagram', 20 ); ?></a>
				<?php endif; ?>
				<?php if ( vi_wa_link() ) : ?>
				<a href="<?php echo esc_url( vi_wa_link() ); ?>" target="_blank" rel="noopener" aria-label="WhatsApp"><?php vi_the_icon( 'chat', 20 ); ?></a>
				<?php endif; ?>
			</div>
		</div>

		<?php if ( $vi_has_wc ) : ?>
		<nav class="vi-footer__col" aria-label="<?php esc_attr_e( 'Loja', 'villa-ibit' ); ?>">
			<h2 class="vi-footer__title"><?php esc_html_e( 'Loja', 'villa-ibit' ); ?></h2>
			<ul>
				<?php foreach ( vi_get_categories() as $vi_cat ) : ?>
					<li><a href="<?php echo esc_url( $vi_cat['link'] ); ?>"><?php echo esc_html( $vi_cat['name'] ); ?></a></li>
				<?php endforeach; ?>
				<li><a href="<?php echo esc_url( vi_offers_url() ); ?>"><?php esc_html_e( 'Ofertas', 'villa-ibit' ); ?></a></li>
			</ul>
		</nav>
		<nav class="vi-footer__col" aria-label="<?php esc_attr_e( 'Atendimento', 'villa-ibit' ); ?>">
			<h2 class="vi-footer__title"><?php esc_html_e( 'Atendimento', 'villa-ibit' ); ?></h2>
			<ul>
				<?php if ( vi_wa_link() ) : ?>
				<li><a href="<?php echo esc_url( vi_wa_link() ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Central de atendimento', 'villa-ibit' ); ?></a></li>
				<?php endif; ?>
				<li><a href="<?php echo esc_url( wc_get_account_endpoint_url( 'orders' ) ); ?>"><?php esc_html_e( 'Rastrear minha compra', 'villa-ibit' ); ?></a></li>
				<li><a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>"><?php esc_html_e( 'Minha conta', 'villa-ibit' ); ?></a></li>
				<?php if ( vi_wa_link() ) : ?>
				<li><a href="<?php echo esc_url( vi_wa_link() ); ?>" target="_blank" rel="noopener"><?php echo esc_html( sprintf( __( 'WhatsApp %s', 'villa-ibit' ), vi_opt( 'whatsapp_label' ) ) ); ?></a></li>
				<?php endif; ?>
			</ul>
		</nav>
		<?php endif; ?>

		<nav class="vi-footer__col" aria-label="<?php esc_attr_e( 'Institucional', 'villa-ibit' ); ?>">
			<h2 class="vi-footer__title"><?php esc_html_e( 'Institucional', 'villa-ibit' ); ?></h2>
			<?php
			if ( has_nav_menu( 'rodape' ) ) {
				wp_nav_menu( array( 'theme_location' => 'rodape', 'container' => false, 'depth' => 1 ) );
			} else {
				echo '<ul>';
				$vi_privacy = get_privacy_policy_url();
				if ( $vi_privacy ) {
					echo '<li><a href="' . esc_url( $vi_privacy ) . '">' . esc_html__( 'Política de privacidade', 'villa-ibit' ) . '</a></li>';
				}
				if ( $vi_has_wc && wc_terms_and_conditions_page_id() ) {
					echo '<li><a href="' . esc_url( get_permalink( wc_terms_and_conditions_page_id() ) ) . '">' . esc_html__( 'Termos de uso', 'villa-ibit' ) . '</a></li>';
				}
				if ( current_user_can( 'edit_theme_options' ) ) {
					echo '<li><a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '">' . esc_html__( '+ Montar este menu (só você vê)', 'villa-ibit' ) . '</a></li>';
				}
				echo '</ul>';
			}
			?>
		</nav>
	</div>

	<div class="vi-container vi-footer__bottom">
		<section class="vi-footer__pay" aria-labelledby="vi-footer-pay-title">
			<h2 class="vi-footer__label" id="vi-footer-pay-title"><?php esc_html_e( 'Pagamento', 'villa-ibit' ); ?></h2>
			<div class="vi-pay-row">
				<ul class="vi-pay-list vi-pay-list--cards" role="list" aria-label="<?php esc_attr_e( 'Cartões de crédito', 'villa-ibit' ); ?>">
					<?php
					$vi_card_brands = array(
						'visa'       => 'Visa',
						'mastercard' => 'Mastercard',
						'elo'        => 'Elo',
						'hipercard'  => 'Hipercard',
						'amex'       => 'American Express',
						'diners'     => 'Diners Club',
					);
					foreach ( $vi_card_brands as $vi_slug => $vi_brand ) :
						?>
						<li class="vi-pay-badge"><img src="<?php echo esc_url( VI_THEME_URI . '/assets/img/payments/' . $vi_slug . '.svg' ); ?>" alt="<?php echo esc_attr( $vi_brand ); ?>" width="52" height="28" loading="lazy"></li>
					<?php endforeach; ?>
				</ul>
				<ul class="vi-pay-list" role="list" aria-label="<?php esc_attr_e( 'Outras formas de pagamento', 'villa-ibit' ); ?>">
					<li class="vi-pay-badge"><?php vi_the_icon( 'pix', 20 ); ?><span><?php esc_html_e( 'Pix', 'villa-ibit' ); ?></span></li>
					<li class="vi-pay-badge"><?php vi_the_icon( 'cash', 21 ); ?><span><?php esc_html_e( 'Dinheiro', 'villa-ibit' ); ?></span></li>
				</ul>
			</div>
		</section>
		<p class="vi-footer__18"><span class="vi-badge-18">18+</span><?php esc_html_e( 'Venda proibida para menores de 18 anos.', 'villa-ibit' ); ?></p>
	</div>
	<div class="vi-container">
		<p class="vi-footer__copy">
			<?php
			$vi_copy = array( sprintf( '© %1$s %2$s. %3$s', gmdate( 'Y' ), get_bloginfo( 'name' ), __( 'Todos os direitos reservados.', 'villa-ibit' ) ) );
			if ( vi_opt( 'cnpj' ) ) {
				$vi_copy[] = 'CNPJ ' . vi_opt( 'cnpj' );
			}
			if ( vi_opt( 'address' ) ) {
				$vi_copy[] = vi_opt( 'address' );
			}
			echo esc_html( implode( ' · ', $vi_copy ) );
			?>
		</p>
	</div>
</footer>

<?php if ( vi_wa_link() ) : ?>
<a class="vi-wa-float" href="<?php echo esc_url( vi_wa_link() ); ?>" target="_blank" rel="noopener" aria-label="<?php esc_attr_e( 'Suporte no WhatsApp', 'villa-ibit' ); ?>"><?php vi_the_icon( 'chat', 28 ); ?></a>
<?php endif; ?>

<?php if ( $vi_has_wc ) : ?>
<nav class="vi-tabbar" aria-label="<?php esc_attr_e( 'Navegação rápida', 'villa-ibit' ); ?>">
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>"<?php echo is_front_page() ? ' aria-current="page"' : ''; ?>><?php vi_the_icon( 'home', 22 ); ?><?php esc_html_e( 'Início', 'villa-ibit' ); ?></a>
	<a href="<?php echo esc_url( vi_page_url( 'categorias', wc_get_page_permalink( 'shop' ) ) ); ?>"<?php echo ( is_shop() || is_product_taxonomy() ) ? ' aria-current="page"' : ''; ?>><?php vi_the_icon( 'grid', 22 ); ?><?php esc_html_e( 'Categorias', 'villa-ibit' ); ?></a>
	<a class="vi-tabbar__cart" data-vi-cart-open href="<?php echo esc_url( wc_get_cart_url() ); ?>" aria-controls="vi-cart" aria-label="<?php esc_attr_e( 'Carrinho', 'villa-ibit' ); ?>"<?php echo is_cart() ? ' aria-current="page"' : ''; ?>><span class="vi-tabbar__cart-btn"><?php vi_the_icon( 'cart', 22 ); ?><span class="vi-tab-count"><?php echo (int) ( WC()->cart ? WC()->cart->get_cart_contents_count() : 0 ); ?></span></span></a>
	<a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>"<?php echo is_account_page() ? ' aria-current="page"' : ''; ?>><?php vi_the_icon( 'user', 22 ); ?><?php esc_html_e( 'Conta', 'villa-ibit' ); ?></a>
	<?php if ( vi_wa_link() ) : ?>
	<a href="<?php echo esc_url( vi_wa_link() ); ?>" target="_blank" rel="noopener"><?php vi_the_icon( 'chat', 22 ); ?>WhatsApp</a>
	<?php endif; ?>
</nav>
<?php endif; ?>

<?php
if ( $vi_has_wc ) {
	vi_cart_drawer();
	if ( vi_should_open_cart() ) {
		echo '<span hidden data-vi-open-cart></span>';
	}
}
wp_footer();
?>
</body>
</html>
