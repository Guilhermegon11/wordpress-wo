<?php
/**
 * Post do blog.
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<main id="conteudo" class="vi-main vi-single">
	<?php while ( have_posts() ) : the_post(); ?>
		<article <?php post_class( 'vi-container vi-container--narrow' ); ?>>
			<header class="vi-page__head">
				<p class="vi-eyebrow vi-eyebrow--green"><?php echo esc_html( get_the_date() ); ?><?php $vi_cat = get_the_category(); echo $vi_cat ? ' · ' . esc_html( $vi_cat[0]->name ) : ''; ?></p>
				<?php the_title( '<h1 class="vi-page__title">', '</h1>' ); ?>
			</header>
			<?php if ( has_post_thumbnail() ) : ?><figure class="vi-single__media"><?php the_post_thumbnail( 'large' ); ?></figure><?php endif; ?>
			<div class="vi-content entry-content"><?php the_content(); ?><?php wp_link_pages(); ?></div>
			<?php if ( comments_open() || get_comments_number() ) { comments_template(); } ?>
		</article>
	<?php endwhile; ?>
</main>
<?php
get_footer();
