<?php
/**
 * Formulário de busca.
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;
$vi_id = 'vi-s-' . wp_unique_id();
?>
<form class="vi-search vi-search--inline" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="<?php echo esc_attr( $vi_id ); ?>"><?php esc_html_e( 'Buscar', 'villa-ibit' ); ?></label>
	<input id="<?php echo esc_attr( $vi_id ); ?>" type="search" name="s" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php esc_attr_e( 'Buscar produtos, marcas ou sabores…', 'villa-ibit' ); ?>">
	<?php if ( class_exists( 'WooCommerce' ) ) : ?><input type="hidden" name="post_type" value="product"><?php endif; ?>
	<button type="submit" aria-label="<?php esc_attr_e( 'Buscar', 'villa-ibit' ); ?>"><?php vi_the_icon( 'search', 20 ); ?></button>
</form>
