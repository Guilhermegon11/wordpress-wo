<?php
/**
 * Partes reutilizáveis de layout.
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;

/**
 * Cabeçalho de seção: título, subtítulo e link "ver todos".
 */
function vi_section_head( $title, $sub = '', $link = '', $link_label = '', $tag = 'h2', $dark = false ) {
	?>
	<div class="vi-section-head<?php echo $dark ? ' is-dark' : ''; ?>">
		<div>
			<<?php echo esc_html( $tag ); ?> class="vi-h2"><?php echo esc_html( $title ); ?></<?php echo esc_html( $tag ); ?>>
			<?php if ( $sub ) : ?><p class="vi-section-head__sub"><?php echo esc_html( $sub ); ?></p><?php endif; ?>
		</div>
		<?php if ( $link ) : ?>
			<a class="vi-link-arrow" href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( $link_label ? $link_label : __( 'Ver todos', 'villa-ibit' ) ); ?> <?php vi_the_icon( 'arrow', 16 ); ?></a>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Link da página de ofertas (loja filtrada por produtos em promoção).
 */
function vi_offers_url() {
	return add_query_arg( 'ofertas', '1', wc_get_page_permalink( 'shop' ) );
}

/**
 * Lista da loja pedida na URL: novidades | vendidos | destaques | ofertas ('' = nenhuma).
 */
function vi_shop_list() {
	if ( ! function_exists( 'is_shop' ) || ! is_shop() ) {
		return '';
	}
	$get = wp_unslash( $_GET ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! empty( $get['ofertas'] ) ) {
		return 'ofertas';
	}
	if ( ! empty( $get['destaques'] ) ) {
		return 'destaques';
	}
	$orderby = isset( $get['orderby'] ) ? sanitize_key( $get['orderby'] ) : '';
	if ( 'date' === $orderby ) {
		return 'novidades';
	}
	if ( 'popularity' === $orderby ) {
		return 'vendidos';
	}
	return '';
}

/**
 * Link de cada lista da loja.
 */
function vi_list_url( $list ) {
	$shop = wc_get_page_permalink( 'shop' );
	switch ( $list ) {
		case 'novidades':
			return add_query_arg( 'orderby', 'date', $shop );
		case 'vendidos':
			return add_query_arg( 'orderby', 'popularity', $shop );
		case 'destaques':
			return add_query_arg( 'destaques', '1', $shop );
		case 'ofertas':
			return vi_offers_url();
		case 'combos':
			$t = get_term_by( 'slug', 'combos', 'product_cat' );
			return $t ? get_term_link( $t ) : add_query_arg( array( 's' => 'combo', 'post_type' => 'product' ), home_url( '/' ) );
		case 'atacado':
			$t = get_term_by( 'slug', 'atacado', 'product_cat' );
			return ( $t && $t->count ) ? get_term_link( $t ) : home_url( '/#atacado' );
	}
	return $shop;
}

/**
 * Abas do menu verde: Início, Todos, Novidades, Promoções, Destaques, Mais vendidos, Combos e Atacado.
 *
 * @return array<int,array{key:string,label:string,icon:string,url:string,current:bool}>
 */
function vi_tab_items() {
	$list  = vi_shop_list();
	$shop  = function_exists( 'is_shop' ) && is_shop() && ! is_search();
	$cat   = function_exists( 'is_product_category' ) && is_product_category() ? get_queried_object() : null;
	$items = array(
		array( 'inicio', __( 'Início', 'villa-ibit' ), 'home', home_url( '/' ), is_front_page() ),
		array( 'todos', __( 'Todos os produtos', 'villa-ibit' ), 'grid', wc_get_page_permalink( 'shop' ), $shop && '' === $list ),
		array( 'novidades', __( 'Novidades', 'villa-ibit' ), 'sparkle', vi_list_url( 'novidades' ), 'novidades' === $list ),
		array( 'ofertas', __( 'Promoções', 'villa-ibit' ), 'tag', vi_list_url( 'ofertas' ), 'ofertas' === $list ),
		array( 'destaques', __( 'Destaques', 'villa-ibit' ), 'star', vi_list_url( 'destaques' ), 'destaques' === $list ),
		array( 'vendidos', __( 'Mais vendidos', 'villa-ibit' ), 'fire', vi_list_url( 'vendidos' ), 'vendidos' === $list ),
		array( 'combos', __( 'Combos', 'villa-ibit' ), 'layers', vi_list_url( 'combos' ), $cat && 'combos' === $cat->slug ),
		array( 'atacado', __( 'Atacado', 'villa-ibit' ), 'box', vi_list_url( 'atacado' ), $cat && 'atacado' === $cat->slug ),
	);
	$out = array();
	foreach ( $items as $i ) {
		$out[] = array( 'key' => $i[0], 'label' => $i[1], 'icon' => $i[2], 'url' => $i[3], 'current' => (bool) $i[4] );
	}
	return apply_filters( 'vi_tab_items', $out );
}

/**
 * Imprime as abas (menu verde no computador; lista no menu do celular).
 */
function vi_tabs_nav( $class = 'vi-tabsnav__list' ) {
	if ( has_nav_menu( 'abas' ) ) {
		wp_nav_menu( array( 'theme_location' => 'abas', 'container' => false, 'menu_class' => $class, 'depth' => 1 ) );
		return;
	}
	echo '<ul class="' . esc_attr( $class ) . '">';
	foreach ( vi_tab_items() as $t ) {
		echo '<li class="vi-tab-' . esc_attr( $t['key'] ) . '"><a href="' . esc_url( $t['url'] ) . '"' . ( $t['current'] ? ' aria-current="page"' : '' ) . '>' . vi_icon( $t['icon'], 18 ) . '<span>' . esc_html( $t['label'] ) . '</span></a></li>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</ul>';
}

/**
 * Menu principal sem menu cadastrado: lista as categorias automaticamente.
 */
function vi_nav_fallback( $class = 'vi-nav__list' ) {
	echo '<ul class="' . esc_attr( $class ) . '">';
	foreach ( vi_get_categories( false ) as $cat ) {
		$children = get_terms( array( 'taxonomy' => 'product_cat', 'parent' => $cat['id'], 'hide_empty' => true ) );
		$has_kids = $children && ! is_wp_error( $children );
		$thumb    = function_exists( 'vi_term_thumb_html' ) ? vi_term_thumb_html( $cat['id'] ) : '';
		echo '<li class="vi-nav__item' . ( $has_kids ? ' has-children' : '' ) . '"><a href="' . esc_url( $cat['link'] ) . '">' . $thumb . '<span>' . esc_html( $cat['name'] ) . '</span>' . ( $has_kids ? vi_icon( 'chevron', 14 ) : '' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $has_kids ) {
			echo '<ul class="sub-menu">';
			foreach ( $children as $child ) {
				echo '<li><a href="' . esc_url( get_term_link( $child ) ) . '">' . esc_html( $child->name ) . '</a></li>';
			}
			echo '</ul>';
		}
		echo '</li>';
	}
	$brands = vi_get_brands();
	if ( $brands ) {
		echo '<li class="vi-nav__item has-children"><a href="#">' . esc_html__( 'Marcas', 'villa-ibit' ) . vi_icon( 'chevron', 14 ) . '</a><ul class="sub-menu">'; // phpcs:ignore WordPress.Security.EscapeOutput
		foreach ( $brands as $b ) {
			echo '<li><a href="' . esc_url( $b['link'] ) . '">' . esc_html( $b['name'] ) . '</a></li>';
		}
		echo '</ul></li>';
	}
	echo '<li class="vi-nav__spacer" aria-hidden="true"></li>';
	echo '<li class="vi-nav__item vi-nav__item--sale"><a href="' . esc_url( vi_offers_url() ) . '">' . esc_html__( 'Ofertas', 'villa-ibit' ) . '</a></li>';
	$wholesale = get_term_by( 'slug', 'atacado', 'product_cat' );
	if ( $wholesale && $wholesale->count ) {
		echo '<li class="vi-nav__item vi-nav__item--pill"><a href="' . esc_url( get_term_link( $wholesale ) ) . '">' . esc_html( $wholesale->name ) . '</a></li>';
	}
	echo '</ul>';
}

/**
 * Etapas do funil (carrinho, pagamento, confirmação).
 */
function vi_checkout_steps() {
	if ( ! function_exists( 'is_cart' ) ) {
		return;
	}
	$current = is_cart() ? 1 : ( is_order_received_page() ? 3 : 2 );
	$steps   = array( 1 => __( 'Carrinho', 'villa-ibit' ), 2 => __( 'Identificação e pagamento', 'villa-ibit' ), 3 => __( 'Pedido confirmado', 'villa-ibit' ) );
	echo '<ol class="vi-steps" aria-label="' . esc_attr__( 'Etapas da compra', 'villa-ibit' ) . '">';
	foreach ( $steps as $n => $label ) {
		$state = $n < $current ? 'is-done' : ( $n === $current ? 'is-current' : '' );
		echo '<li class="vi-steps__item ' . esc_attr( $state ) . '"' . ( $n === $current ? ' aria-current="step"' : '' ) . '><span class="vi-steps__n">' . ( $n < $current ? vi_icon( 'check', 14 ) : (int) $n ) . '</span>' . esc_html( $label ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</ol>';
}

/**
 * Selos de confiança (usados na home e no checkout).
 */
function vi_trust_items() {
	$pix = vi_pix_percent();
	return array(
		$pix ? array( 'pix', sprintf( __( 'PIX com %s%% OFF', 'villa-ibit' ), wc_format_localized_decimal( $pix ) ), __( 'Desconto no pagamento', 'villa-ibit' ), '' ) : array( 'lock', __( 'Pagamento', 'villa-ibit' ), __( 'Veja as opções no checkout', 'villa-ibit' ), '' ),
		array( 'shield', __( '100% originais', 'villa-ibit' ), __( 'Qualidade e procedência', 'villa-ibit' ), '' ),
		array( 'truck', vi_opt( 'delivery_title' ), __( 'Somente em Governador Valadares (MG)', 'villa-ibit' ), '' ),
		array( 'box', __( 'Frete pelo CEP', 'villa-ibit' ), __( 'Consulte no carrinho', 'villa-ibit' ), '' ),
	);
}

function vi_render_trust( $class = '' ) {
	echo '<div class="vi-trust ' . esc_attr( $class ) . '">';
	foreach ( vi_trust_items() as $item ) {
		echo '<div class="vi-trust__item"><span class="vi-trust__icon ' . esc_attr( $item[3] ) . '">' . ( '18' === $item[0] ? '18+' : vi_icon( $item[0], 22 ) ) . '</span><div><strong>' . esc_html( $item[1] ) . '</strong><span>' . esc_html( $item[2] ) . '</span></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</div>';
}

/**
 * Estrelas de avaliação.
 */
function vi_stars( $rating ) {
	$rating = max( 0, min( 5, (float) $rating ) );
	$out    = '<span class="vi-stars" role="img" aria-label="' . esc_attr( sprintf( __( 'Nota %s de 5', 'villa-ibit' ), $rating ) ) . '">';
	for ( $i = 1; $i <= 5; $i++ ) {
		$out .= '<span class="' . ( $i <= round( $rating ) ? 'is-on' : '' ) . '">' . vi_icon( 'star', 16 ) . '</span>';
	}
	return $out . '</span>';
}

/**
 * O menu principal aparece duas vezes (topo no computador e gaveta no celular): evita IDs repetidos.
 */
add_filter(
	'nav_menu_item_id',
	function ( $id, $item, $args ) {
		return ( isset( $args->menu_class ) && 'vi-hnav__list' === $args->menu_class ) ? '' : $id;
	},
	10,
	3
);

/**
 * Classe "vi-fx" no <body> quando os efeitos de natureza estão ligados (folhas, névoa e animações).
 */
add_filter(
	'body_class',
	function ( $classes ) {
		if ( vi_opt( 'hero_nature', 1 ) ) {
			$classes[] = 'vi-fx';
		}
		return $classes;
	}
);
