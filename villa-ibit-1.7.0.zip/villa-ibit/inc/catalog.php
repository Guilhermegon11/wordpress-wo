<?php
/**
 * Dados dinâmicos do catálogo: categorias, marcas e listas de produtos.
 * Tudo vem do WooCommerce — cadastrou/removeu, a loja atualiza sozinha.
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;

const VI_CACHE_KEY = 'vi_catalog_v3';

/**
 * Cada consulta guarda a geração lida antes de calcular o resultado.
 * Uma visita em andamento não pode repor dados antigos depois de uma edição.
 */
function vi_cache_get( $key, &$generation = null ) {
	$generation = (string) get_option( VI_CACHE_KEY, '0' );
	$entry      = get_transient( VI_CACHE_KEY . '_' . $key );
	return is_array( $entry ) && $entry['generation'] === $generation ? $entry['value'] : null;
}

function vi_cache_set( $key, $value, $generation ) {
	set_transient( VI_CACHE_KEY . '_' . $key, array( 'generation' => $generation, 'value' => $value ), 6 * HOUR_IN_SECONDS );
	return $value;
}

function vi_cache_flush() {
	update_option( VI_CACHE_KEY, wp_generate_uuid4(), false );
}
foreach ( array( 'save_post_product', 'woocommerce_update_product', 'woocommerce_new_product', 'woocommerce_delete_product', 'woocommerce_trash_product',
	'woocommerce_update_product_variation', 'woocommerce_new_product_variation', 'woocommerce_delete_product_variation', 'woocommerce_trash_product_variation',
	'woocommerce_product_set_stock_status', 'woocommerce_variation_set_stock_status', 'update_option_woocommerce_hide_out_of_stock_items',
	'woocommerce_product_set_stock', 'woocommerce_variation_set_stock', 'created_product_cat', 'edited_product_cat', 'delete_product_cat',
	'created_product_brand', 'edited_product_brand', 'delete_product_brand', 'woocommerce_scheduled_sales', 'comment_post', 'wp_set_comment_status', 'edit_comment' ) as $vi_hook ) {
	add_action( $vi_hook, 'vi_cache_flush' );
}

// O Bling e o editor de produtos também atribuem termos depois de salvar o produto.
function vi_catalog_terms_changed( $object_id, $terms, $term_taxonomy_ids, $taxonomy ) {
	if ( in_array( $taxonomy, array( 'product_cat', 'product_brand', 'product_visibility' ), true ) ) {
		vi_cache_flush();
	}
}
add_action( 'set_object_terms', 'vi_catalog_terms_changed', 10, 4 );
add_action( 'deleted_term_relationships', function ( $id, $tt_ids, $taxonomy ) {
	vi_catalog_terms_changed( $id, array(), $tt_ids, $taxonomy );
}, 10, 3 );

// A miniatura e a ordem podem ser gravadas sem editar o nome da categoria ou marca.
function vi_catalog_term_meta_changed( $meta_id, $term_id, $key ) {
	if ( in_array( $key, array( 'thumbnail_id', 'order' ), true ) ) {
		$term = get_term( $term_id );
		if ( $term instanceof WP_Term && in_array( $term->taxonomy, array( 'product_cat', 'product_brand' ), true ) ) {
			vi_cache_flush();
		}
	}
}
foreach ( array( 'added_term_meta', 'updated_term_meta', 'deleted_term_meta' ) as $vi_hook ) {
	add_action( $vi_hook, 'vi_catalog_term_meta_changed', 10, 3 );
}

/**
 * Categorias de produto principais (nível 1) que têm produtos, na ordem definida em Produtos › Categorias.
 *
 * @param bool $include_wholesale Incluir a categoria "atacado".
 * @return array<int,array>
 */
function vi_get_categories( $include_wholesale = true ) {
	$cached = vi_cache_get( 'cats', $generation );
	if ( null === $cached ) {
		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'parent'     => 0,
				'hide_empty' => true,
				'orderby'    => 'menu_order', // ordem de Produtos › Categorias (arrastar e soltar).
				'exclude'    => array( (int) get_option( 'default_product_cat' ) ),
			)
		);
		$cached = array();
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$cached[] = array(
					'id'        => $term->term_id,
					'name'      => $term->name,
					'slug'      => $term->slug,
					'count'     => (int) $term->count,
					'desc'      => wp_strip_all_tags( term_description( $term ) ),
					'link'      => get_term_link( $term ),
					'thumb'     => vi_category_thumb( $term ),
					'has_thumb' => (bool) get_term_meta( $term->term_id, 'thumbnail_id', true ),
					'thumb_lg'  => ( $vi_t = (int) get_term_meta( $term->term_id, 'thumbnail_id', true ) ) ? wp_get_attachment_image_url( $vi_t, 'woocommerce_single' ) : '',
					'min_price' => vi_category_min_price( $term->term_id ),
					'images'    => vi_category_product_images( $term->term_id, 3 ),
				);
			}
		}
		vi_cache_set( 'cats', $cached, $generation );
	}
	if ( ! $include_wholesale ) {
		$cached = array_values( array_filter( $cached, function ( $c ) { return 'atacado' !== $c['slug']; } ) );
	}
	return $cached;
}

/**
 * Imagem da categoria (definida no admin) ou a foto de um produto dela.
 */
function vi_category_thumb( $term ) {
	$thumb_id = (int) get_term_meta( $term->term_id, 'thumbnail_id', true );
	if ( $thumb_id ) {
		return wp_get_attachment_image_url( $thumb_id, 'woocommerce_single' ); // maior: fica nítida no círculo
	}
	$images = vi_category_product_images( $term->term_id, 1 );
	return $images ? $images[0] : wc_placeholder_img_src( 'woocommerce_thumbnail' );
}

/**
 * Fotos dos produtos mais recentes da categoria.
 */
function vi_category_product_images( $term_id, $limit = 3 ) {
	$ids = wc_get_products(
		array(
			'status'     => 'publish',
			'limit'      => $limit * 2,
			'return'     => 'ids',
			'visibility' => 'catalog',
			'tax_query'  => vi_category_product_filter( $term_id ), // phpcs:ignore WordPress.DB.SlowDBQuery
		)
	);
	$urls = array();
	foreach ( $ids as $id ) {
		$img = get_post_thumbnail_id( $id );
		if ( $img ) {
			$urls[] = wp_get_attachment_image_url( $img, 'woocommerce_thumbnail' );
		}
		if ( count( $urls ) >= $limit ) {
			break;
		}
	}
	return $urls;
}

/** Use as mesmas regras de visibilidade nas fotos, no preço inicial e na vitrine. */
function vi_category_product_filter( $term_id ) {
	$excluded = array( 'exclude-from-catalog' );
	if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
		$excluded[] = 'outofstock';
	}
	return array(
		array( 'taxonomy' => 'product_cat', 'field' => 'term_id', 'terms' => $term_id ),
		array( 'taxonomy' => 'product_visibility', 'field' => 'slug', 'terms' => $excluded, 'operator' => 'NOT IN' ),
	);
}

/**
 * Menor preço da categoria ("a partir de").
 */
function vi_category_min_price( $term_id ) {
	$q = new WP_Query(
		array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => 3,
			'fields'         => 'ids',
			'meta_key'       => '_price', // phpcs:ignore WordPress.DB.SlowDBQuery
			'orderby'        => 'meta_value_num',
			'order'          => 'ASC',
			'no_found_rows'  => true,
			'tax_query'      => vi_category_product_filter( $term_id ), // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_query'     => array( array( 'key' => '_price', 'value' => 0, 'compare' => '>', 'type' => 'DECIMAL(20,6)' ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
		)
	);
	$min = 0;
	foreach ( $q->posts as $id ) {
		$p = wc_get_product( $id );
		if ( $p ) {
			$v   = vi_min_price( $p );
			$min = ( $v > 0 && ( ! $min || $v < $min ) ) ? $v : $min;
		}
	}
	return $min;
}

/**
 * Marcas com produtos (Produtos › Marcas).
 */
function vi_get_brands() {
	if ( ! taxonomy_exists( 'product_brand' ) ) {
		return array();
	}
	$cached = vi_cache_get( 'brands', $generation );
	if ( null !== $cached ) {
		return $cached;
	}
	$terms  = get_terms( array( 'taxonomy' => 'product_brand', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC' ) );
	$cached = array();
	if ( ! is_wp_error( $terms ) ) {
		foreach ( $terms as $term ) {
			$thumb_id = (int) get_term_meta( $term->term_id, 'thumbnail_id', true );
			$cached[] = array(
				'id'    => $term->term_id,
				'name'  => $term->name,
				'slug'  => $term->slug,
				'count' => (int) $term->count,
				'link'  => get_term_link( $term ),
				'logo'  => $thumb_id ? wp_get_attachment_image_url( $thumb_id, 'medium' ) : '',
			);
		}
	}
	return vi_cache_set( 'brands', $cached, $generation );
}

/**
 * Lista de produtos para as vitrines.
 *
 * @param string $type  novidades | vendidos | ofertas | destaques | marca | categoria.
 * @param int    $limit Quantidade.
 * @param mixed  $term  ID da marca/categoria (ou lista de IDs) quando aplicável.
 * @return WC_Product[]
 */
function vi_products( $type, $limit = 8, $term = null ) {
	$args = array(
		'status'     => 'publish',
		'limit'      => $limit,
		'visibility' => 'catalog',
	);
	switch ( $type ) {
		case 'vendidos':
			$args['orderby']  = 'meta_value_num';
			$args['meta_key'] = 'total_sales'; // phpcs:ignore WordPress.DB.SlowDBQuery
			$args['order']    = 'DESC';
			break;
		case 'ofertas':
			$ids = wc_get_product_ids_on_sale();
			if ( ! $ids ) {
				return array();
			}
			$args['include'] = $ids;
			break;
		case 'destaques':
			$args['featured'] = true;
			break;
		case 'marca':
			$args['tax_query'] = array( array( 'taxonomy' => 'product_brand', 'field' => 'term_id', 'terms' => (array) $term ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
			break;
		case 'categoria':
			$args['tax_query'] = array( array( 'taxonomy' => 'product_cat', 'field' => 'term_id', 'terms' => (array) $term ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
			break;
		default:
			$args['orderby'] = 'date';
			$args['order']   = 'DESC';
	}
	if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
		$args['tax_query'][] = array( 'taxonomy' => 'product_visibility', 'field' => 'slug', 'terms' => array( 'outofstock' ), 'operator' => 'NOT IN' ); // phpcs:ignore WordPress.DB.SlowDBQuery
	}
	return wc_get_products( $args );
}

/**
 * Renderiza uma lista de produtos com o mesmo card do catálogo.
 *
 * @param WC_Product[] $products Produtos.
 * @param string       $class    Classe extra da lista.
 */
function vi_render_products( $products, $class = '', $after = '' ) {
	if ( ! $products ) {
		return;
	}
	global $product, $post;
	$backup_product = $product;
	$backup_post    = $post;
	echo '<ul class="products vi-grid ' . esc_attr( $class ) . '">';
	foreach ( $products as $item ) {
		$post = get_post( $item->get_id() ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
		setup_postdata( $post );
		$product = $item; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
		wc_get_template_part( 'content', 'product' );
	}
	echo $after; // phpcs:ignore WordPress.Security.EscapeOutput -- HTML montado pelo tema (card "Ver todas").
	echo '</ul>';
	$product = $backup_product; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
	$post    = $backup_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
	wp_reset_postdata();
}

/**
 * Avaliações aprovadas mais recentes dos produtos (para a home).
 */
function vi_latest_reviews( $limit = 3 ) {
	return get_comments(
		array(
			'post_type'  => 'product',
			'status'     => 'approve',
			'type'       => 'review',
			'number'     => $limit,
			'meta_query' => array( array( 'key' => 'rating', 'value' => 4, 'compare' => '>=', 'type' => 'NUMERIC' ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
		)
	);
}

/**
 * Nota média e total de avaliações da loja.
 */
function vi_store_rating() {
	$cached = vi_cache_get( 'rating', $generation );
	if ( null !== $cached ) {
		return $cached;
	}
	global $wpdb;
	$row = $wpdb->get_row( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		"SELECT AVG(m.meta_value) AS avg, COUNT(*) AS total FROM {$wpdb->comments} c
		 INNER JOIN {$wpdb->commentmeta} m ON m.comment_id = c.comment_ID AND m.meta_key = 'rating'
		 INNER JOIN {$wpdb->posts} p ON p.ID = c.comment_post_ID AND p.post_type = 'product'
		 WHERE c.comment_approved = '1'"
	);
	$data = array( 'avg' => $row ? round( (float) $row->avg, 1 ) : 0, 'total' => $row ? (int) $row->total : 0 );
	return vi_cache_set( 'rating', $data, $generation );
}

/* ------------------------------------------------------------------ *
 * Puffs (filtro do catálogo)
 * ------------------------------------------------------------------ */

/**
 * Faixas do filtro: chave => [mínimo, máximo, rótulo].
 */
function vi_puffs_ranges() {
	return array(
		'ate-10'  => array( 1, 10000, __( 'Até 10.000', 'villa-ibit' ) ),
		'10-30'   => array( 10001, 30000, __( '10.000 a 30.000', 'villa-ibit' ) ),
		'30-45'   => array( 30001, 45000, __( '30.000 a 45.000', 'villa-ibit' ) ),
		'45-mais' => array( 45001, 10000000, __( 'Acima de 45.000', 'villa-ibit' ) ),
	);
}

/**
 * Lê a quantidade de puffs de um texto ("até 40.000", "50000 puffs", "45k", "35K 35.000 puffs").
 *
 * @param string $text   Texto.
 * @param bool   $strict Exigir a palavra "puffs" ou "k" (para nomes de produto).
 * @return int
 */
function vi_parse_puffs( $text, $strict = false ) {
	$text = strtolower( (string) $text );
	// "50000 puffs", "40.000 puffs", "5500 puffs".
	if ( preg_match( '/(\d{1,3}(?:[.\s]\d{3})+|\d{3,6})\s*(?:mil\s*)?puffs?/', $text, $m ) ) {
		return (int) preg_replace( '/\D/', '', $m[1] );
	}
	// "40k", "45 k", "30 mil".
	if ( preg_match( '/(?<![\d.])(\d{1,3})\s*(?:k|mil)\b/', $text, $m ) ) {
		return (int) $m[1] * 1000;
	}
	if ( ! $strict && preg_match( '/(\d{1,3}(?:[.\s]\d{3})+|\d{3,6})/', $text, $m ) ) {
		return (int) preg_replace( '/\D/', '', $m[1] );
	}
	return 0;
}

/**
 * Puffs de um produto: especificação "Puffs" (atributo) ou, se não houver, o nome.
 *
 * @param WC_Product $product Produto.
 * @return int
 */
function vi_product_puffs( $product ) {
	foreach ( $product->get_attributes() as $attr ) {
		$label = function_exists( 'mb_strtolower' ) ? mb_strtolower( wc_attribute_label( $attr->get_name(), $product ) ) : strtolower( wc_attribute_label( $attr->get_name(), $product ) );
		if ( false === strpos( $label, 'puff' ) || $attr->get_variation() ) {
			continue;
		}
		$vals = $attr->is_taxonomy() ? wc_get_product_terms( $product->get_id(), $attr->get_name(), array( 'fields' => 'names' ) ) : $attr->get_options();
		$n    = vi_parse_puffs( implode( ' ', (array) $vals ) );
		if ( $n ) {
			return $n;
		}
	}
	return vi_parse_puffs( $product->get_name(), true );
}

/**
 * Grava o número de puffs no produto (meta _vi_puffs).
 */
function vi_puffs_sync( $product_id ) {
	$product = wc_get_product( $product_id );
	if ( ! $product || $product->is_type( 'variation' ) ) {
		return;
	}
	update_post_meta( $product->get_id(), '_vi_puffs', vi_product_puffs( $product ) );
}
add_action( 'woocommerce_update_product', 'vi_puffs_sync', 20 );
add_action( 'woocommerce_new_product', 'vi_puffs_sync', 20 );

/**
 * Preenche _vi_puffs nos produtos que ainda não têm (em lotes, no painel).
 */
function vi_puffs_backfill( $limit = 200 ) {
	$ids = get_posts(
		array(
			'post_type'      => 'product',
			'post_status'    => array( 'publish', 'draft', 'private' ),
			'posts_per_page' => $limit,
			'fields'         => 'ids',
			'meta_query'     => array( array( 'key' => '_vi_puffs', 'compare' => 'NOT EXISTS' ) ), // phpcs:ignore WordPress.DB.SlowDBQuery
		)
	);
	foreach ( $ids as $id ) {
		vi_puffs_sync( $id );
	}
	return count( $ids );
}
// A indexação dos produtos antigos só roda quando o responsável pela loja a habilita.
// Produtos criados ou editados continuam a atualizar o próprio índice pelos hooks acima.
add_action( 'admin_init', function () {
	if ( ! apply_filters( 'vi_index_existing_puffs', false ) || ! function_exists( 'wc_get_product' ) || ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	if ( get_option( 'vi_puffs_backfill' ) !== VI_THEME_VER ) {
		if ( vi_puffs_backfill() < 200 ) {
			update_option( 'vi_puffs_backfill', VI_THEME_VER, false );
		}
		vi_cache_flush();
	}
} );

/**
 * Faixas escolhidas na URL (?puffs[]=10-30).
 */
function vi_puffs_selected() {
	$raw = isset( $_GET['puffs'] ) ? (array) wp_unslash( $_GET['puffs'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification
	return array_values( array_intersect( array_map( 'sanitize_key', $raw ), array_keys( vi_puffs_ranges() ) ) );
}

/**
 * meta_query (OR) das faixas escolhidas, ou array vazio.
 */
function vi_puffs_meta_query( $keys ) {
	$ranges = vi_puffs_ranges();
	$q      = array( 'relation' => 'OR' );
	foreach ( (array) $keys as $k ) {
		if ( isset( $ranges[ $k ] ) ) {
			$q[] = array( 'key' => '_vi_puffs', 'value' => array( $ranges[ $k ][0], $ranges[ $k ][1] ), 'compare' => 'BETWEEN', 'type' => 'NUMERIC' );
		}
	}
	return count( $q ) > 1 ? $q : array();
}

/**
 * Algum produto tem puffs identificados? (mostra o bloco do filtro).
 */
function vi_puffs_available() {
	$cached = vi_cache_get( 'puffs_any', $generation );
	if ( null !== $cached ) {
		return (bool) $cached;
	}
	$found = get_posts( array( 'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_query' => array( array( 'key' => '_vi_puffs', 'value' => 0, 'compare' => '>', 'type' => 'NUMERIC' ) ) ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
	vi_cache_set( 'puffs_any', $found ? 1 : 0, $generation );
	return (bool) $found;
}
