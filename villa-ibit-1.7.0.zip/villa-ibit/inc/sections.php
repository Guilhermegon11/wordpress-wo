<?php
/**
 * Seções da loja. Cada função é usada pela home padrão e pelos widgets "Villa Ibit" do Elementor.
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;

/**
 * Mescla argumentos com padrões.
 */
function vi_args( $args, $defaults ) {
	return array_merge( $defaults, array_filter( (array) $args, function ( $v ) { return null !== $v && '' !== $v; } ) );
}

/* ------------------------------------------------------------------ *
 * Banner
 * ------------------------------------------------------------------ */
function vi_section_hero( $args = array() ) {
	$args   = vi_args( $args, array( 'slides' => null, 'show_offers' => 'yes' ) );
	$slides = is_array( $args['slides'] ) ? array_map( 'vi_local_delivery_slide', $args['slides'] ) : (array) vi_opt( 'slides' );
	$slides = array_values( array_filter( $slides, function ( $s ) { return ! empty( $s['active'] ); } ) );
	if ( ! $slides ) {
		return;
	}
	$uid    = 'vi-hero-' . wp_unique_id();
	$fx     = (bool) vi_opt( 'hero_nature', 1 ); // Efeitos: névoa passando e zoom lento na foto.
	$first  = $slides[0]['style'] ?? 'natureza';
	?>
	<section class="vi-container vi-hero vi-hero--natureza<?php echo $fx ? ' has-fx' : ''; ?>" aria-roledescription="carrossel" aria-label="<?php esc_attr_e( 'Destaques da loja', 'villa-ibit' ); ?>">
		<div class="vi-hero__track<?php echo in_array( $first, array( 'natureza', 'dourado' ), true ) ? ' is-light' : ''; ?>" data-vi-slider id="<?php echo esc_attr( $uid ); ?>">
			<?php foreach ( $slides as $i => $s ) :
				$img = ! empty( $s['image_id'] ) ? wp_get_attachment_image_url( (int) $s['image_id'], 'full' ) : '';
				if ( ! $img && ! empty( $s['image_url'] ) ) {
					$img = $s['image_url'];
				}
				if ( ! $img && ! empty( $s['image_def'] ) ) {
					$img = VI_THEME_URI . '/assets/img/' . $s['image_def'];
				}
				$link = vi_resolve_link( $s['link'] ?? '' );
				$ext  = false === strpos( $link, home_url() );
				$tag  = ( 0 === $i && ! empty( $args['h1'] ) ) ? 'h1' : 'h2';
				?>
				<div class="vi-slide vi-slide--<?php echo esc_attr( $s['style'] ?? 'natureza' ); ?><?php echo 0 === $i ? ' is-active' : ''; ?>" role="group" aria-roledescription="slide" aria-label="<?php echo esc_attr( sprintf( __( '%1$d de %2$d', 'villa-ibit' ), $i + 1, count( $slides ) ) ); ?>"<?php echo 0 === $i ? '' : ' aria-hidden="true"'; ?>>
					<?php if ( $img ) : ?><img class="vi-slide__bg" src="<?php echo esc_url( $img ); ?>" alt="" <?php echo 0 === $i ? 'fetchpriority="high"' : 'loading="lazy"'; ?>><?php endif; ?>
					<?php if ( $fx && 'natureza' === ( $s['style'] ?? 'natureza' ) ) : ?><span class="vi-slide__mist" aria-hidden="true"></span><?php endif; ?>
					<div class="vi-slide__content">
						<?php if ( ! empty( $s['eyebrow'] ) ) : ?><span class="vi-slide__eyebrow"><?php echo esc_html( $s['eyebrow'] ); ?></span><?php endif; ?>
						<<?php echo esc_html( $tag ); ?> class="vi-slide__title">
							<?php echo esc_html( $s['title'] ?? '' ); ?>
							<?php if ( ! empty( $s['highlight'] ) ) : ?><span class="vi-slide__hl"><?php echo esc_html( $s['highlight'] ); ?></span><?php endif; ?>
							<?php echo esc_html( $s['title_after'] ?? '' ); ?>
						</<?php echo esc_html( $tag ); ?>>
						<?php if ( ! empty( $s['text'] ) ) : ?><p class="vi-slide__text"><?php echo esc_html( vi_store_notice( $s['text'] ) ); ?></p><?php endif; ?>
						<?php if ( ! empty( $s['price'] ) ) : ?>
							<p class="vi-slide__price"><?php if ( ! empty( $s['price_pre'] ) ) : ?><span><?php echo esc_html( $s['price_pre'] ); ?></span><?php endif; ?><strong><?php echo esc_html( $s['price'] ); ?></strong><span class="vi-pill vi-pill--gold"><?php esc_html_e( 'no PIX', 'villa-ibit' ); ?></span></p>
						<?php endif; ?>
						<?php if ( $link && ! empty( $s['button'] ) ) : ?>
							<div class="vi-slide__actions">
								<a class="vi-btn vi-btn--slide" href="<?php echo esc_url( $link ); ?>"<?php echo $ext ? ' target="_blank" rel="noopener"' : ''; ?> tabindex="<?php echo 0 === $i ? '0' : '-1'; ?>"><?php echo esc_html( $s['button'] ); ?><?php vi_the_icon( 'arrow', 18 ); ?></a>
								<?php if ( 'yes' === $args['show_offers'] && function_exists( 'wc_get_page_permalink' ) ) : ?>
									<a class="vi-btn vi-btn--ghost" href="<?php echo esc_url( vi_offers_url() ); ?>" tabindex="<?php echo 0 === $i ? '0' : '-1'; ?>"><?php esc_html_e( 'Ofertas da semana', 'villa-ibit' ); ?></a>
								<?php endif; ?>
							</div>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
			<?php if ( count( $slides ) > 1 ) : ?>
			<div class="vi-hero__controls">
				<button type="button" class="vi-hero__arrow" data-vi-prev aria-controls="<?php echo esc_attr( $uid ); ?>" aria-label="<?php esc_attr_e( 'Slide anterior', 'villa-ibit' ); ?>"><?php vi_the_icon( 'arrow-l', 20 ); ?></button>
				<button type="button" class="vi-hero__arrow" data-vi-next aria-controls="<?php echo esc_attr( $uid ); ?>" aria-label="<?php esc_attr_e( 'Próximo slide', 'villa-ibit' ); ?>"><?php vi_the_icon( 'arrow', 20 ); ?></button>
				<div class="vi-hero__dots">
					<?php foreach ( $slides as $i => $s ) : ?>
						<button type="button" data-vi-dot="<?php echo (int) $i; ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Ir para o slide %d', 'villa-ibit' ), $i + 1 ) ); ?>"<?php echo 0 === $i ? ' aria-current="true"' : ''; ?>><span></span></button>
					<?php endforeach; ?>
				</div>
				<span class="vi-hero__count" aria-hidden="true"><span data-vi-count>01</span> / <?php echo esc_html( str_pad( (string) count( $slides ), 2, '0', STR_PAD_LEFT ) ); ?></span>
			</div>
			<?php endif; ?>
		</div>
	</section>
	<?php
}

/* ------------------------------------------------------------------ *
 * Selos
 * ------------------------------------------------------------------ */
function vi_section_trust() {
	echo '<section class="vi-container vi-block--tight" aria-label="' . esc_attr__( 'Vantagens', 'villa-ibit' ) . '">';
	vi_render_trust();
	echo '</section>';
}

/* ------------------------------------------------------------------ *
 * Marcas
 * ------------------------------------------------------------------ */
function vi_section_brands( $args = array() ) {
	$args   = vi_args( $args, array( 'title' => __( 'Compre por marca', 'villa-ibit' ) ) );
	$brands = vi_get_brands();
	if ( ! $brands ) {
		vi_editor_notice( __( 'Cadastre marcas em Produtos › Marcas para preencher esta seção.', 'villa-ibit' ) );
		return;
	}
	?>
	<section class="vi-container vi-block">
		<div class="vi-section-head"><h2 class="vi-h2"><?php echo esc_html( $args['title'] ); ?></h2></div>
		<div class="vi-brands">
			<?php foreach ( $brands as $b ) : ?>
				<a class="vi-brand" href="<?php echo esc_url( $b['link'] ); ?>">
					<?php if ( $b['logo'] ) : ?><img src="<?php echo esc_url( $b['logo'] ); ?>" alt="<?php echo esc_attr( $b['name'] ); ?>" loading="lazy"><?php else : ?><span class="vi-brand__name"><?php echo esc_html( $b['name'] ); ?></span><?php endif; ?>
					<span class="vi-brand__count"><?php echo esc_html( sprintf( _n( '%d produto', '%d produtos', $b['count'], 'villa-ibit' ), $b['count'] ) ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>
	</section>
	<?php
}

/* ------------------------------------------------------------------ *
 * Categorias — círculos com a miniatura (home) ou grade completa (página Categorias)
 * ------------------------------------------------------------------ */
function vi_section_categories( $args = array() ) {
	$args = vi_args( $args, array( 'title' => __( 'Categorias em destaque', 'villa-ibit' ), 'layout' => 'bento', 'link_all' => 'yes' ) );
	if ( 'grid' === $args['layout'] ) {
		vi_section_category_grid( $args );
		return;
	}
	$cats = vi_get_categories();
	if ( ! $cats ) {
		vi_editor_notice( __( 'Cadastre categorias de produto para preencher esta seção.', 'villa-ibit' ) );
		return;
	}
	$deal_pct = 0;
	foreach ( vi_products( 'ofertas', 12 ) as $p ) {
		$deal_pct = max( $deal_pct, vi_sale_percent( $p ) );
	}
	?>
	<section class="vi-container vi-block vi-cats-section">
		<div class="vi-section-head vi-section-head--center">
			<h2 class="vi-h2"><?php echo esc_html( $args['title'] ); ?></h2>
			<?php if ( 'yes' === $args['link_all'] ) : ?><a class="vi-link-arrow" href="<?php echo esc_url( vi_page_url( 'categorias', wc_get_page_permalink( 'shop' ) ) ); ?>"><?php esc_html_e( 'Ver todas as categorias', 'villa-ibit' ); ?> <?php vi_the_icon( 'arrow', 16 ); ?></a><?php endif; ?>
		</div>
		<div class="vi-circles">
			<?php foreach ( $cats as $c ) : ?>
			<a class="vi-circle" href="<?php echo esc_url( $c['link'] ); ?>">
				<span class="vi-circle__img"><img src="<?php echo esc_url( ! empty( $c['thumb_lg'] ) ? $c['thumb_lg'] : $c['thumb'] ); ?>" alt="" loading="lazy"></span>
				<span class="vi-circle__name"><?php echo esc_html( $c['name'] ); ?></span>
				<span class="vi-circle__count"><?php echo esc_html( sprintf( _n( '%d produto', '%d produtos', $c['count'], 'villa-ibit' ), $c['count'] ) ); ?></span>
			</a>
			<?php endforeach; ?>
			<?php if ( $deal_pct ) : ?>
			<a class="vi-circle vi-circle--deal" href="<?php echo esc_url( vi_offers_url() ); ?>">
				<span class="vi-circle__img"><span aria-hidden="true">%</span></span>
				<span class="vi-circle__name"><?php esc_html_e( 'Ofertas', 'villa-ibit' ); ?></span>
				<span class="vi-circle__count"><?php echo esc_html( sprintf( __( 'Até %d%% off', 'villa-ibit' ), $deal_pct ) ); ?></span>
			</a>
			<?php endif; ?>
		</div>
	</section>
	<?php
}

/**
 * Grade de todas as categorias (inclui subcategorias).
 */
function vi_section_category_grid( $args = array() ) {
	$args  = vi_args( $args, array( 'title' => '' ) );
	$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => true, 'orderby' => 'menu_order', 'exclude' => array( (int) get_option( 'default_product_cat' ) ) ) );
	if ( is_wp_error( $terms ) || ! $terms ) {
		vi_editor_notice( __( 'Cadastre categorias de produto para preencher esta seção.', 'villa-ibit' ) );
		return;
	}
	$parents = array_filter( $terms, function ( $t ) { return 0 === (int) $t->parent; } );
	?>
	<section class="vi-container vi-block">
		<?php if ( $args['title'] ) : ?><div class="vi-section-head"><h2 class="vi-h2"><?php echo esc_html( $args['title'] ); ?></h2></div><?php endif; ?>
		<div class="vi-catround-grid">
			<?php foreach ( $parents as $t ) :
				$min      = vi_category_min_price( $t->term_id );
				$children = array_filter( $terms, function ( $c ) use ( $t ) { return (int) $c->parent === (int) $t->term_id; } );
				$thumb_id = (int) get_term_meta( $t->term_id, 'thumbnail_id', true );
				$srcset   = $thumb_id ? wp_get_attachment_image_srcset( $thumb_id, 'woocommerce_single' ) : '';
				?>
				<article class="vi-catround">
					<a class="vi-catround__link" href="<?php echo esc_url( get_term_link( $t ) ); ?>">
						<span class="vi-catround__img"><img src="<?php echo esc_url( vi_category_thumb( $t ) ); ?>"<?php echo $srcset ? ' srcset="' . esc_attr( $srcset ) . '" sizes="132px"' : ''; ?> alt="" loading="lazy"></span>
						<span class="vi-catround__name"><?php echo esc_html( $t->name ); ?></span>
						<span class="vi-catround__meta"><?php echo esc_html( sprintf( _n( '%d produto', '%d produtos', $t->count, 'villa-ibit' ), $t->count ) ); ?><?php if ( $min ) : ?> · <?php echo wp_kses_post( sprintf( __( 'a partir de %s', 'villa-ibit' ), wc_price( $min ) ) ); ?><?php endif; ?></span>
					</a>
					<?php if ( $children ) : ?>
						<ul class="vi-catround__subs"><?php foreach ( $children as $c ) : ?><li><a href="<?php echo esc_url( get_term_link( $c ) ); ?>"><?php echo esc_html( $c->name ); ?></a></li><?php endforeach; ?></ul>
					<?php endif; ?>
				</article>
			<?php endforeach; ?>
		</div>
	</section>
	<?php
}

/* ------------------------------------------------------------------ *
 * Vitrines de produtos
 * ------------------------------------------------------------------ */

/**
 * Lista conforme a fonte escolhida.
 */
function vi_products_by_source( $source, $limit, $term_ids = array() ) {
	switch ( $source ) {
		case 'vendidos':
		case 'ofertas':
		case 'destaques':
			return vi_products( $source, $limit );
		case 'categoria':
			return $term_ids ? vi_products( 'categoria', $limit, $term_ids ) : array();
		case 'marca':
			return $term_ids ? vi_products( 'marca', $limit, $term_ids ) : array();
		default:
			return vi_products( 'novidades', $limit );
	}
}

/**
 * Abas "Explore os produtos".
 */
function vi_section_tabs( $args = array() ) {
	$args = vi_args( $args, array( 'title' => __( 'Explore os produtos', 'villa-ibit' ), 'limit' => 8, 'brand_tabs' => 2, 'button' => __( 'Ver todos os produtos', 'villa-ibit' ) ) );
	$tabs = array(
		'novidades' => array( __( 'Novidades', 'villa-ibit' ), vi_products( 'novidades', (int) $args['limit'] ) ),
		'promocoes' => array( __( 'Promoções', 'villa-ibit' ), vi_products( 'ofertas', (int) $args['limit'] ) ),
		'vendidos'  => array( __( 'Mais vendidos', 'villa-ibit' ), vi_products( 'vendidos', (int) $args['limit'] ) ),
	);
	foreach ( array_slice( vi_get_brands(), 0, (int) $args['brand_tabs'] ) as $b ) {
		$tabs[ 'marca-' . $b['id'] ] = array( $b['name'], vi_products( 'marca', (int) $args['limit'], $b['id'] ) );
	}
	$tabs = array_filter( $tabs, function ( $t ) { return ! empty( $t[1] ); } );
	if ( __( 'Mais vendidos', 'villa-ibit' ) === $args['title'] && isset( $tabs['vendidos'] ) ) {
		$tabs = array( 'vendidos' => $tabs['vendidos'] ) + $tabs;
	}
	if ( ! $tabs ) {
		vi_editor_notice( __( 'Cadastre produtos para preencher esta vitrine.', 'villa-ibit' ) );
		return;
	}
	$uid = 'vi-t' . wp_unique_id();
	?>
	<section class="vi-container vi-block" data-vi-tabs>
		<div class="vi-section-head">
			<h2 class="vi-h2"><?php echo esc_html( $args['title'] ); ?></h2>
			<div class="vi-tabs" role="tablist">
				<?php $first = true; foreach ( $tabs as $key => $t ) : ?>
					<button type="button" role="tab" id="<?php echo esc_attr( $uid . '-' . $key ); ?>" aria-controls="<?php echo esc_attr( $uid . '-p-' . $key ); ?>" aria-selected="<?php echo $first ? 'true' : 'false'; ?>"<?php echo $first ? '' : ' tabindex="-1"'; ?>><?php echo esc_html( $t[0] ); ?></button>
				<?php $first = false; endforeach; ?>
			</div>
		</div>
		<?php $first = true; foreach ( $tabs as $key => $t ) : ?>
			<div class="woocommerce vi-tabpanel" role="tabpanel" id="<?php echo esc_attr( $uid . '-p-' . $key ); ?>" aria-labelledby="<?php echo esc_attr( $uid . '-' . $key ); ?>"<?php echo $first ? '' : ' hidden'; ?>>
				<?php vi_render_products( $t[1], 'columns-4' ); ?>
			</div>
		<?php $first = false; endforeach; ?>
		<?php if ( trim( (string) $args['button'] ) ) : ?><p class="vi-center"><a class="vi-btn vi-btn--outline" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"><?php echo esc_html( $args['button'] ); ?></a></p><?php endif; ?>
	</section>
	<?php
}

/**
 * Vitrine simples (grade) ou faixa escura de ofertas.
 */
function vi_section_products( $args = array() ) {
	$args = vi_args(
		$args,
		array(
			'title'    => __( 'Ofertas exclusivas pra você não perder', 'villa-ibit' ),
			'subtitle' => '',
			'eyebrow'  => '',
			'source'   => 'ofertas',
			'terms'    => array(),
			'limit'    => 6,
			'columns'  => 6,
			'style'    => 'dark',
			'link'     => '',
			'badge'    => '',
		)
	);
	$terms = array_filter( array_map( 'absint', (array) $args['terms'] ) );
	if ( 'categoria' === $args['source'] && ! $terms ) {
		$terms = wp_list_pluck( array_slice( vi_get_categories( false ), 1 ), 'id' );
	}
	$products = vi_products_by_source( $args['source'], (int) $args['limit'], $terms );
	if ( ! $products ) {
		vi_editor_notice( __( 'Nenhum produto encontrado para esta vitrine (ela some sozinha no site).', 'villa-ibit' ) );
		return;
	}
	$link  = $args['link'] ? vi_resolve_link( $args['link'] ) : vi_list_url( in_array( $args['source'], array( 'ofertas', 'novidades', 'vendidos', 'destaques' ), true ) ? $args['source'] : 'todos' );
	if ( in_array( $args['style'], array( 'dark', 'list' ), true ) ) {
		vi_section_deals_list( $args, $products, $link );
		return;
	}
	if ( 'band' === $args['style'] ) {
		vi_section_featured_band( $args, $products, $link );
		return;
	}
	$dark  = false;
	$cols  = max( 2, min( 6, (int) $args['columns'] ) );
	$class = 'columns-' . $cols . ( $cols >= 5 ? ' vi-grid--compact' : '' );
	if ( $dark ) {
		echo '<section class="vi-band vi-band--dark"' . ( 'ofertas' === $args['source'] ? ' id="ofertas"' : '' ) . '><div class="vi-container">';
	} else {
		echo '<section class="vi-container vi-block">';
	}
	?>
		<div class="vi-section-head<?php echo $dark ? ' is-dark' : ''; ?>">
			<div>
				<?php if ( $args['eyebrow'] ) : ?><span class="vi-eyebrow<?php echo $dark ? '' : ' vi-eyebrow--green'; ?>"><?php echo esc_html( $args['eyebrow'] ); ?></span><?php endif; ?>
				<h2 class="vi-h2"><?php echo esc_html( $args['title'] ); ?></h2>
				<?php if ( $args['subtitle'] ) : ?><p class="vi-section-head__sub"><?php echo esc_html( $args['subtitle'] ); ?></p><?php endif; ?>
			</div>
			<a class="vi-link-arrow" href="<?php echo esc_url( $link ); ?>"><?php esc_html_e( 'Ver todos', 'villa-ibit' ); ?> <?php vi_the_icon( 'arrow', 16 ); ?></a>
		</div>
		<div class="woocommerce vi-slide-mobile"><?php $GLOBALS['vi_card_badge'] = $args['badge']; vi_render_products( $products, $class ); $GLOBALS['vi_card_badge'] = ''; ?></div>
	<?php
	echo $dark ? '</div></section>' : '</section>';
}

/**
 * Faixa amarela (fundo dourado claro com folhas de palmeira): usada em Novidades e nos destaques.
 * No celular os cards deslizam para o lado.
 */
function vi_section_featured_band( $args, $products, $link ) {
	?>
	<section class="vi-container vi-block" id="<?php echo esc_attr( 'novidades' === ( $args['source'] ?? '' ) ? 'novidades' : 'destaques' ); ?>">
		<div class="vi-featbar">
			<div class="vi-section-head">
				<div>
					<?php if ( $args['eyebrow'] ) : ?><span class="vi-eyebrow vi-eyebrow--gold"><?php echo esc_html( $args['eyebrow'] ); ?></span><?php endif; ?>
					<h2 class="vi-h2"><?php echo esc_html( $args['title'] ); ?></h2>
					<?php if ( $args['subtitle'] ) : ?><p class="vi-section-head__sub"><?php echo esc_html( $args['subtitle'] ); ?></p><?php endif; ?>
				</div>
				<div class="vi-scroll__nav"<?php echo count( $products ) <= 5 ? ' data-vi-few' : ''; ?>>
					<button type="button" class="vi-scroll__btn" data-vi-scroll-prev aria-label="<?php esc_attr_e( 'Ver produtos anteriores', 'villa-ibit' ); ?>" disabled><?php vi_the_icon( 'arrow-l', 18 ); ?></button>
					<button type="button" class="vi-scroll__btn" data-vi-scroll-next aria-label="<?php esc_attr_e( 'Ver mais produtos', 'villa-ibit' ); ?>"><?php vi_the_icon( 'arrow', 18 ); ?></button>
				</div>
			</div>
			<?php
			$label = 'novidades' === ( $args['source'] ?? '' ) ? __( 'Ver todas as novidades', 'villa-ibit' ) : __( 'Ver todos os destaques', 'villa-ibit' );
			$more  = '<li class="product vi-card vi-card--more"><a href="' . esc_url( $link ) . '"><span class="vi-card--more__icon">' . vi_icon( 'arrow', 22 ) . '</span><span>' . esc_html( $label ) . '</span></a></li>';
			?>
			<div class="woocommerce vi-featbar__list" data-vi-scroller><?php vi_render_products( $products, 'columns-' . max( 3, min( 6, (int) $args['columns'] ) ) . ' vi-grid--row', $more ); ?></div>
		</div>
	</section>
	<?php
}

/**
 * Faixa de destaques da home ("Novidades"): produtos com a estrela de destaque.
 */
function vi_section_featured( $args = array() ) {
	$args = vi_args( $args, array( 'title' => vi_opt( 'featured_title', __( 'Novidades', 'villa-ibit' ) ), 'subtitle' => vi_opt( 'featured_text', '' ), 'eyebrow' => '', 'limit' => 10, 'columns' => 5 ) );
	vi_section_products(
		array(
			'title'    => $args['title'],
			'subtitle' => $args['subtitle'],
			'eyebrow'  => $args['eyebrow'],
			'source'   => 'destaques',
			'limit'    => $args['limit'],
			'columns'  => $args['columns'],
			'style'    => 'band',
		)
	);
}

/**
 * Ofertas em lista: cards horizontais (foto, desconto, preço e valor no PIX).
 */
function vi_section_deals_list( $args, $products, $link ) {
	?>
	<section class="vi-container vi-block"<?php echo 'ofertas' === $args['source'] ? ' id="ofertas"' : ''; ?>>
		<div class="vi-section-head">
			<div>
				<?php if ( $args['eyebrow'] ) : ?><span class="vi-eyebrow vi-eyebrow--green"><?php echo esc_html( $args['eyebrow'] ); ?></span><?php endif; ?>
				<h2 class="vi-h2"><?php echo esc_html( $args['title'] ); ?></h2>
				<?php if ( $args['subtitle'] ) : ?><p class="vi-section-head__sub"><?php echo esc_html( $args['subtitle'] ); ?></p><?php endif; ?>
			</div>
			<a class="vi-link-arrow" href="<?php echo esc_url( $link ); ?>"><?php esc_html_e( 'Ver todas', 'villa-ibit' ); ?> <?php vi_the_icon( 'arrow', 16 ); ?></a>
		</div>
		<div class="vi-deals">
			<?php foreach ( $products as $p ) :
				$meta  = vi_card_meta( $p );
				$pct   = vi_sale_percent( $p );
				$label = $meta['brand'] ? $meta['brand'] : $meta['cat'];
				?>
				<a class="vi-deal" href="<?php echo esc_url( $p->get_permalink() ); ?>">
					<span class="vi-deal__img">
						<?php echo $p->get_image( 'woocommerce_thumbnail', array( 'loading' => 'lazy', 'alt' => '' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
						<?php if ( $pct ) : ?><span class="vi-deal__off">-<?php echo (int) $pct; ?>%</span><?php endif; ?>
					</span>
					<span class="vi-deal__body">
						<?php if ( $label ) : ?><span class="vi-card__meta"><?php echo esc_html( $label ); ?></span><?php endif; ?>
						<strong class="vi-deal__name"><?php echo esc_html( $p->get_name() ); ?></strong>
						<?php echo vi_price_block( $p, 'card' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
					</span>
				</a>
			<?php endforeach; ?>
		</div>
	</section>
	<?php
}

/* ------------------------------------------------------------------ *
 * Destaque da semana (um produto em evidência)
 * ------------------------------------------------------------------ */

/**
 * Produto do destaque: o escolhido em Villa Ibit › Configurações › Home ou, se não houver,
 * o primeiro "em destaque" (estrela) e, por último, o mais vendido.
 *
 * @return WC_Product|null
 */
function vi_spotlight_product( $id = 0 ) {
	$id = $id ? (int) $id : (int) vi_opt( 'spotlight_product', 0 );
	if ( $id ) {
		$p = wc_get_product( $id );
		if ( $p && 'publish' === $p->get_status() && $p->is_visible() ) {
			return $p;
		}
	}
	foreach ( array( 'destaques', 'vendidos', 'novidades' ) as $source ) {
		$list = vi_products( $source, 1 );
		if ( $list ) {
			return current( $list );
		}
	}
	return null;
}

function vi_section_spotlight( $args = array() ) {
	$args    = vi_args( $args, array( 'eyebrow' => vi_opt( 'spotlight_title', __( 'Destaque da semana', 'villa-ibit' ) ), 'product' => 0, 'button' => '' ) );
	$product = vi_spotlight_product( (int) $args['product'] );
	if ( ! $product ) {
		vi_editor_notice( __( 'Cadastre produtos (ou escolha um em Villa Ibit › Configurações › Home) para mostrar o destaque.', 'villa-ibit' ) );
		return;
	}
	$meta  = vi_card_meta( $product );
	$text  = $product->get_short_description() ? wp_strip_all_tags( $product->get_short_description() ) : wp_strip_all_tags( $product->get_description() );
	$specs = array();
	foreach ( $product->get_attributes() as $attr ) {
		if ( ! $attr->get_visible() || $attr->get_variation() ) {
			continue;
		}
		$vals = $attr->is_taxonomy() ? wc_get_product_terms( $product->get_id(), $attr->get_name(), array( 'fields' => 'names' ) ) : $attr->get_options();
		if ( $vals ) {
			$specs[] = array( wc_attribute_label( $attr->get_name() ), implode( ', ', array_slice( $vals, 0, 2 ) ) );
		}
		if ( count( $specs ) >= 2 ) {
			break;
		}
	}
	if ( count( $specs ) < 2 && $meta['extra'] ) {
		$specs[] = array( __( 'Opções', 'villa-ibit' ), $meta['extra'] );
	}
	if ( count( $specs ) < 2 && $meta['brand'] ) {
		$specs[] = array( __( 'Marca', 'villa-ibit' ), $meta['brand'] );
	}
	$button = $args['button'] ? $args['button'] : ( $product->is_type( 'variable' ) ? __( 'Ver sabores', 'villa-ibit' ) : __( 'Ver produto', 'villa-ibit' ) );
	$image  = $product->get_image_id() ? wp_get_attachment_image_url( $product->get_image_id(), 'large' ) : wc_placeholder_img_src( 'large' );
	?>
	<section class="vi-container vi-block">
		<div class="vi-spot">
			<a class="vi-spot__media" href="<?php echo esc_url( $product->get_permalink() ); ?>" tabindex="-1" aria-hidden="true"><span class="vi-spot__ring"></span><img src="<?php echo esc_url( $image ); ?>" alt="" loading="lazy"></a>
			<div class="vi-spot__body">
				<?php if ( $args['eyebrow'] ) : ?><span class="vi-eyebrow vi-eyebrow--gold"><?php echo esc_html( $args['eyebrow'] ); ?></span><?php endif; ?>
				<h2 class="vi-h2 vi-h2--xl"><?php echo esc_html( $product->get_name() ); ?></h2>
				<?php if ( $text ) : ?><p class="vi-spot__text"><?php echo esc_html( wp_trim_words( $text, 28 ) ); ?></p><?php endif; ?>
				<?php if ( $specs ) : ?>
					<ul class="vi-spot__specs"><?php foreach ( $specs as $sp ) : ?><li><span><?php echo esc_html( $sp[0] ); ?></span><strong><?php echo esc_html( $sp[1] ); ?></strong></li><?php endforeach; ?></ul>
				<?php endif; ?>
				<div class="vi-spot__buy">
					<a class="vi-btn vi-btn--green" href="<?php echo esc_url( $product->get_permalink() ); ?>"><?php echo esc_html( $button ); ?></a>
					<?php echo vi_price_block( $product, 'card' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</div>
			</div>
		</div>
	</section>
	<?php
}

/* ------------------------------------------------------------------ *
 * Atacado
 * ------------------------------------------------------------------ */
/**
 * Faixa de atacado: foto da serra, texto e botão do WhatsApp.
 */
function vi_section_wholesale( $args = array() ) {
	$args  = vi_args( $args, array( 'eyebrow' => __( 'Atacado Villa Ibit', 'villa-ibit' ), 'title' => vi_opt( 'wholesale_title' ), 'text' => vi_opt( 'wholesale_text' ), 'button' => __( 'Pedir tabela no WhatsApp', 'villa-ibit' ) ) );
	$term  = get_term_by( 'slug', 'atacado', 'product_cat' );
	$img   = vi_option_image( 'wholesale_image', 'natureza/atacado-folhagem.jpg', 'full' );
	?>
	<section id="atacado" class="vi-container vi-block">
		<div class="vi-wholesale vi-wholesale--photo">
			<img class="vi-wholesale__bg" src="<?php echo esc_url( $img ); ?>" alt="" loading="lazy">
			<div class="vi-wholesale__inner">
				<div class="vi-wholesale__main">
					<span class="vi-wholesale__icon" aria-hidden="true"><?php vi_the_icon( 'box', 30 ); ?></span>
					<div class="vi-wholesale__text">
						<?php if ( $args['eyebrow'] ) : ?><span class="vi-eyebrow"><?php echo esc_html( $args['eyebrow'] ); ?></span><?php endif; ?>
						<h2 class="vi-h2 vi-h2--xl"><?php echo esc_html( $args['title'] ); ?></h2>
						<p><?php echo esc_html( $args['text'] ); ?></p>
						<div class="vi-wholesale__actions">
							<?php if ( vi_wa_link() ) : ?>
							<a class="vi-btn vi-btn--gold vi-btn--shine" href="<?php echo esc_url( vi_wa_link( __( 'Olá! Tenho interesse em comprar no atacado.', 'villa-ibit' ) ) ); ?>" target="_blank" rel="noopener"><?php vi_the_icon( 'chat', 20 ); ?><?php echo esc_html( $args['button'] ); ?></a>
							<?php endif; ?>
							<?php if ( $term && $term->count ) : ?><a class="vi-btn vi-btn--ghost" href="<?php echo esc_url( get_term_link( $term ) ); ?>"><?php esc_html_e( 'Ver produtos de atacado', 'villa-ibit' ); ?></a><?php endif; ?>
						</div>
					</div>
				</div>
				<?php echo vi_logo( 'dark', 'vi-logo vi-wholesale__logo' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>
		</div>
	</section>
	<?php
}

/**
 * Imagem escolhida no painel (ID) ou a padrão do tema.
 */
function vi_option_image( $key, $default_file, $size = 'large' ) {
	$id  = (int) vi_opt( $key, 0 );
	$url = $id ? wp_get_attachment_image_url( $id, $size ) : '';
	return $url ? $url : VI_THEME_URI . '/assets/img/' . $default_file . '?v=' . VI_THEME_VER; // ?v= evita foto antiga em cache
}

/**
 * Cartões "Ofertas da semana" e "Combos especiais", com foto.
 */
function vi_section_promos( $args = array() ) {
	$cards = array(
		'offers' => array( 'icon' => 'tag', 'class' => '', 'btn' => 'vi-btn--gold', 'img' => 'natureza/promo-ofertas.jpg', 'link' => vi_list_url( 'ofertas' ) ),
		'combos' => array( 'icon' => 'layers', 'class' => ' vi-promo--light', 'btn' => 'vi-btn--green', 'img' => 'natureza/promo-combos.jpg', 'link' => vi_list_url( 'combos' ) ),
	);
	?>
	<section class="vi-container vi-block">
		<div class="vi-promos">
			<?php foreach ( $cards as $k => $c ) :
				$link = trim( (string) vi_opt( 'promo_' . $k . '_link' ) );
				$link = $link ? vi_resolve_link( $link ) : $c['link'];
				$btn  = vi_opt( 'promo_' . $k . '_button' );
				?>
				<a class="vi-promo<?php echo esc_attr( $c['class'] ); ?>" href="<?php echo esc_url( $link ); ?>">
					<img class="vi-promo__bg" src="<?php echo esc_url( vi_option_image( 'promo_' . $k . '_image', $c['img'] ) ); ?>" alt="" loading="lazy">
					<span class="vi-promo__body">
						<span class="vi-promo__icon" aria-hidden="true"><?php vi_the_icon( $c['icon'], 22 ); ?></span>
						<span class="vi-promo__title"><?php echo esc_html( vi_opt( 'promo_' . $k . '_title' ) ); ?></span>
						<span class="vi-promo__text"><?php echo esc_html( vi_opt( 'promo_' . $k . '_text' ) ); ?></span>
						<?php if ( $btn ) : ?><span class="vi-btn <?php echo esc_attr( $c['btn'] ); ?> vi-btn--sm vi-btn--shine"><?php echo esc_html( $btn ); ?><?php vi_the_icon( 'arrow', 16 ); ?></span><?php endif; ?>
					</span>
				</a>
			<?php endforeach; ?>
		</div>
	</section>
	<?php
}

/**
 * "Mais vendidos" e "Produtos em destaque" lado a lado (3 de cada).
 */
function vi_section_duo( $args = array() ) {
	$args  = vi_args( $args, array( 'limit' => 3, 'title_sold' => __( 'Mais vendidos', 'villa-ibit' ), 'title_featured' => __( 'Produtos em destaque', 'villa-ibit' ) ) );
	$lists = array_filter(
		array(
			'vendidos'  => array( $args['title_sold'], vi_products( 'vendidos', (int) $args['limit'] ), 'hot' ),
			'destaques' => array( $args['title_featured'], vi_products( 'destaques', (int) $args['limit'] ), '' ),
		),
		function ( $l ) { return ! empty( $l[1] ); }
	);
	if ( ! $lists ) {
		vi_editor_notice( __( 'Marque produtos com a estrela (destaque) ou espere as primeiras vendas para preencher esta seção.', 'villa-ibit' ) );
		return;
	}
	?>
	<section class="vi-container vi-block">
		<div class="vi-duo<?php echo 1 === count( $lists ) ? ' vi-duo--single' : ''; ?>">
			<?php foreach ( $lists as $key => $l ) : ?>
				<div class="vi-duo__col">
					<div class="vi-section-head">
						<h2 class="vi-h2"><?php echo esc_html( $l[0] ); ?></h2>
						<a class="vi-link-arrow" href="<?php echo esc_url( vi_list_url( $key ) ); ?>"><?php esc_html_e( 'Ver todos', 'villa-ibit' ); ?> <?php vi_the_icon( 'arrow', 16 ); ?></a>
					</div>
					<div class="woocommerce vi-slide-mobile"><?php $GLOBALS['vi_card_badge'] = $l[2]; vi_render_products( $l[1], 1 === count( $lists ) ? 'columns-6 vi-grid--compact' : 'columns-3' ); $GLOBALS['vi_card_badge'] = ''; ?></div>
				</div>
			<?php endforeach; ?>
		</div>
	</section>
	<?php
}

/* ------------------------------------------------------------------ *
 * Avaliações
 * ------------------------------------------------------------------ */
function vi_section_reviews( $args = array() ) {
	$args    = vi_args( $args, array( 'title' => __( 'O que dizem os clientes', 'villa-ibit' ), 'limit' => 3 ) );
	$reviews = vi_latest_reviews( (int) $args['limit'] );
	if ( ! $reviews ) {
		vi_editor_notice( __( 'As avaliações aprovadas (4★ ou mais) aparecem aqui.', 'villa-ibit' ) );
		return;
	}
	$rating = vi_store_rating();
	?>
	<section class="vi-container vi-block">
		<?php vi_section_head( $args['title'], $rating['total'] ? sprintf( __( 'Média %1$s de 5 em %2$d avaliações', 'villa-ibit' ), wc_format_localized_decimal( $rating['avg'] ), $rating['total'] ) : '' ); ?>
		<div class="vi-reviews">
			<?php foreach ( $reviews as $r ) : $name = $r->comment_author; ?>
			<figure class="vi-review">
				<div class="vi-review__top"><?php echo vi_stars( get_comment_meta( $r->comment_ID, 'rating', true ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php if ( get_comment_meta( $r->comment_ID, 'verified', true ) ) : ?><span class="vi-review__ok"><?php esc_html_e( 'Compra verificada', 'villa-ibit' ); ?></span><?php endif; ?></div>
				<blockquote><?php echo esc_html( wp_trim_words( $r->comment_content, 40 ) ); ?></blockquote>
				<figcaption><span class="vi-review__avatar"><?php echo esc_html( function_exists( 'mb_substr' ) ? mb_strtoupper( mb_substr( $name, 0, 1 ) ) : strtoupper( substr( $name, 0, 1 ) ) ); ?></span><span><strong><?php echo esc_html( $name ); ?></strong><a href="<?php echo esc_url( get_permalink( $r->comment_post_ID ) ); ?>"><?php echo esc_html( get_the_title( $r->comment_post_ID ) ); ?></a></span></figcaption>
			</figure>
			<?php endforeach; ?>
		</div>
	</section>
	<?php
}

/* ------------------------------------------------------------------ *
 * Blog
 * ------------------------------------------------------------------ */
function vi_section_blog( $args = array() ) {
	$args  = vi_args( $args, array( 'title' => __( 'Dicas, guias e novidades', 'villa-ibit' ), 'limit' => 3 ) );
	$posts = get_posts( array( 'numberposts' => (int) $args['limit'], 'post_status' => 'publish' ) );
	if ( ! $posts ) {
		vi_editor_notice( __( 'Os últimos posts do blog aparecem aqui.', 'villa-ibit' ) );
		return;
	}
	$blog = (int) get_option( 'page_for_posts' );
	?>
	<section class="vi-container vi-block">
		<?php vi_section_head( $args['title'], '', $blog ? get_permalink( $blog ) : '', __( 'Explorar conteúdos', 'villa-ibit' ) ); ?>
		<div class="vi-posts">
			<?php foreach ( $posts as $p ) : $cat = get_the_category( $p->ID ); ?>
			<a class="vi-post" href="<?php echo esc_url( get_permalink( $p ) ); ?>">
				<div class="vi-post__media">
					<?php echo get_the_post_thumbnail( $p, 'medium_large', array( 'loading' => 'lazy', 'alt' => '' ) ); ?>
					<?php if ( $cat ) : ?><span class="vi-post__tag"><?php echo esc_html( $cat[0]->name ); ?></span><?php endif; ?>
				</div>
				<div class="vi-post__body"><h3><?php echo esc_html( get_the_title( $p ) ); ?></h3><p><?php echo esc_html( get_the_excerpt( $p ) ); ?></p></div>
			</a>
			<?php endforeach; ?>
		</div>
	</section>
	<?php
}

/* ------------------------------------------------------------------ *
 * Instagram + lista VIP
 * ------------------------------------------------------------------ */
function vi_section_social( $args = array() ) {
	$args = vi_args( $args, array( 'ig_title' => __( 'Siga no Instagram', 'villa-ibit' ), 'ig_text' => __( 'Lançamentos e promoções em primeira mão.', 'villa-ibit' ), 'news_title' => __( 'Receba ofertas em primeira mão', 'villa-ibit' ) ) );
	$newsletter = vi_opt( 'newsletter_sc' ) || vi_wa_link();
	if ( ! $newsletter && ! vi_instagram_url() ) {
		return;
	}
	?>
	<section class="vi-container vi-block vi-block--last">
		<div class="vi-social">
			<?php if ( vi_instagram_url() ) : ?><div class="vi-social__ig">
				<span class="vi-social__icon"><?php vi_the_icon( 'instagram', 30 ); ?></span>
				<div><h2 class="vi-h3"><?php echo esc_html( $args['ig_title'] ); ?></h2><p><?php echo esc_html( $args['ig_text'] ); ?></p></div>
				<a class="vi-btn vi-btn--white" href="<?php echo esc_url( vi_instagram_url() ); ?>" target="_blank" rel="noopener">@<?php echo esc_html( ltrim( vi_opt( 'instagram' ), '@' ) ); ?></a>
			</div><?php endif; ?>
			<?php if ( $newsletter ) : ?><div class="vi-social__news">
				<h2 class="vi-h3"><?php echo esc_html( $args['news_title'] ); ?></h2>
				<?php if ( vi_opt( 'newsletter_sc' ) ) : ?>
					<p><?php esc_html_e( 'Novidades e promoções exclusivas, sem spam.', 'villa-ibit' ); ?></p>
					<?php echo do_shortcode( wp_kses_post( vi_opt( 'newsletter_sc' ) ) ); ?>
				<?php else : ?>
					<p><?php esc_html_e( 'Entre na lista VIP do WhatsApp e receba lançamentos e cupons.', 'villa-ibit' ); ?></p>
					<a class="vi-btn vi-btn--green" href="<?php echo esc_url( vi_wa_link( __( 'Quero entrar na lista VIP de ofertas!', 'villa-ibit' ) ) ); ?>" target="_blank" rel="noopener"><?php vi_the_icon( 'chat', 20 ); ?><?php esc_html_e( 'Entrar na lista VIP', 'villa-ibit' ); ?></a>
				<?php endif; ?>
			</div><?php endif; ?>
		</div>
	</section>
	<?php
}

/* ------------------------------------------------------------------ *
 * Cabeçalho de página (faixa verde com título)
 * ------------------------------------------------------------------ */
function vi_section_page_hero( $args = array() ) {
	$args = vi_args( $args, array( 'title' => get_the_title(), 'text' => '', 'crumbs' => 'yes' ) );
	?>
	<section class="vi-archive-hero">
		<div class="vi-container">
			<?php if ( 'yes' === $args['crumbs'] ) : ?>
				<nav class="vi-crumbs" aria-label="<?php esc_attr_e( 'Você está em', 'villa-ibit' ); ?>"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Início', 'villa-ibit' ); ?></a><span class="vi-crumbs__sep" aria-hidden="true">/</span><span><?php echo esc_html( $args['title'] ); ?></span></nav>
			<?php endif; ?>
			<h1 class="vi-archive-hero__title"><?php echo esc_html( $args['title'] ); ?></h1>
			<?php if ( $args['text'] ) : ?><p class="vi-archive-hero__desc"><?php echo esc_html( $args['text'] ); ?></p><?php endif; ?>
		</div>
	</section>
	<?php
}

/* ------------------------------------------------------------------ *
 * Login e cadastro
 * ------------------------------------------------------------------ */
function vi_section_login( $args = array() ) {
	$args = vi_args( $args, array( 'title' => __( 'Entrar ou criar conta', 'villa-ibit' ), 'text' => __( 'Acompanhe seus pedidos, salve endereços e compre mais rápido.', 'villa-ibit' ) ) );
	echo '<section class="vi-container vi-block vi-block--last vi-login">';
	if ( is_user_logged_in() && ! vi_is_elementor_editor() ) {
		$user = wp_get_current_user();
		echo '<div class="vi-login__done"><h2 class="vi-h2">' . esc_html( sprintf( __( 'Olá, %s!', 'villa-ibit' ), $user->first_name ? $user->first_name : $user->display_name ) ) . '</h2><p>' . esc_html__( 'Você já está conectado.', 'villa-ibit' ) . '</p>';
		echo '<p class="vi-login__actions"><a class="vi-btn vi-btn--green" href="' . esc_url( wc_get_page_permalink( 'myaccount' ) ) . '">' . esc_html__( 'Ir para minha conta', 'villa-ibit' ) . '</a> <a class="vi-btn vi-btn--outline" href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '">' . esc_html__( 'Continuar comprando', 'villa-ibit' ) . '</a></p></div>';
	} else {
		echo '<div class="vi-login__intro"><h2 class="vi-h2">' . esc_html( $args['title'] ) . '</h2><p>' . esc_html( $args['text'] ) . '</p></div>';
		echo '<div class="woocommerce">';
		if ( function_exists( 'woocommerce_output_all_notices' ) && ! vi_is_elementor_editor() ) {
			woocommerce_output_all_notices();
		}
		wc_get_template( 'myaccount/form-login.php' );
		echo '</div>';
	}
	echo '</section>';
}

/* ------------------------------------------------------------------ *
 * Etapas da compra (carrinho / checkout)
 * ------------------------------------------------------------------ */
function vi_section_steps() {
	echo '<div class="vi-container vi-steps-wrap">';
	vi_checkout_steps();
	echo '</div>';
}

/* ------------------------------------------------------------------ *
 * Conteúdo do WooCommerce (carrinho, checkout, conta) dentro do layout
 * ------------------------------------------------------------------ */
function vi_section_wc_shortcode( $args = array() ) {
	$args = vi_args( $args, array( 'which' => 'cart' ) );
	$map  = array( 'cart' => 'woocommerce_cart', 'checkout' => 'woocommerce_checkout', 'account' => 'woocommerce_my_account', 'tracking' => 'woocommerce_order_tracking' );
	$sc   = isset( $map[ $args['which'] ] ) ? $map[ $args['which'] ] : 'woocommerce_cart';
	echo '<section class="vi-container vi-block--tight vi-block--last vi-wc-page vi-wc-page--' . esc_attr( $args['which'] ) . '">';
	if ( vi_is_elementor_editor() && in_array( $args['which'], array( 'checkout', 'cart' ), true ) && WC()->cart && WC()->cart->is_empty() ) {
		vi_editor_notice( __( 'Pré-visualização: adicione um produto ao carrinho e abra a página no site para ver o formulário completo.', 'villa-ibit' ), true );
	}
	echo do_shortcode( '[' . $sc . ']' );
	echo '</section>';
}

/* ------------------------------------------------------------------ *
 * Utilidades do editor
 * ------------------------------------------------------------------ */
function vi_is_elementor_editor() {
	return class_exists( '\Elementor\Plugin' ) && ( \Elementor\Plugin::$instance->editor->is_edit_mode() || \Elementor\Plugin::$instance->preview->is_preview_mode() );
}

/**
 * Aviso que só aparece dentro do Elementor (no site, a seção vazia some).
 */
function vi_editor_notice( $text, $always = false ) {
	if ( $always || vi_is_elementor_editor() ) {
		echo '<div class="vi-container"><p class="vi-editor-note">' . esc_html( $text ) . '</p></div>';
	}
}

/**
 * Link de uma página criada pela configuração automática (por slug).
 */
function vi_page_url( $slug, $fallback = '' ) {
	$page = get_page_by_path( $slug );
	return $page ? get_permalink( $page ) : ( $fallback ? $fallback : home_url( '/' ) );
}

/* ------------------------------------------------------------------ *
 * Shortcode [villa_ibit secao="..."] — usa as seções em qualquer página (também sem Elementor).
 * Ex.: [villa_ibit secao="catalogo" categoria="acessorios"]  [villa_ibit secao="categorias" layout="grid"]
 * ------------------------------------------------------------------ */
add_shortcode(
	'villa_ibit',
	function ( $atts ) {
		$atts = shortcode_atts( array( 'secao' => '', 'categoria' => '', 'layout' => '', 'titulo' => '', 'fonte' => '', 'quantidade' => '' ), $atts, 'villa_ibit' );
		$map  = array(
			'banner'     => function () { vi_section_hero(); },
			'selos'      => 'vi_section_trust',
			'marcas'     => function ( $a ) { vi_section_brands( array( 'title' => $a['titulo'] ) ); },
			'categorias' => function ( $a ) { vi_section_categories( array( 'layout' => $a['layout'] ? $a['layout'] : 'bento', 'title' => $a['titulo'] ) ); },
			'abas'       => function ( $a ) { vi_section_tabs( array( 'title' => $a['titulo'] ) ); },
			'vitrine'    => function ( $a ) { vi_section_products( array( 'title' => $a['titulo'], 'source' => $a['fonte'], 'limit' => $a['quantidade'] ) ); },
			'catalogo'   => function ( $a ) { vi_section_catalog( array( 'category' => $a['categoria'], 'title' => $a['titulo'] ) ); },
			'atacado'    => 'vi_section_wholesale',
			'cartoes'    => 'vi_section_promos',
			'vendidos-destaques' => 'vi_section_duo',
			'destaque'   => 'vi_section_spotlight',
			'destaques'  => 'vi_section_featured',
			'avaliacoes' => 'vi_section_reviews',
			'blog'       => 'vi_section_blog',
			'social'     => 'vi_section_social',
			'login'      => 'vi_section_login',
			'etapas'     => 'vi_section_steps',
		);
		if ( ! isset( $map[ $atts['secao'] ] ) ) {
			return '';
		}
		ob_start();
		call_user_func( $map[ $atts['secao'] ], $atts );
		return ob_get_clean();
	}
);
