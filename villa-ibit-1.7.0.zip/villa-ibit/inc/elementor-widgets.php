<?php
/**
 * Classes dos widgets "Villa Ibit".
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Widget_Base;

/**
 * Base comum.
 */
abstract class VI_El_Widget extends Widget_Base {

	/** @return array{name:string,title:string,icon:string,keywords?:array} */
	abstract protected function vi();

	public function get_name() {
		return 'vi-' . $this->vi()['name'];
	}

	public function get_title() {
		return 'Villa Ibit · ' . $this->vi()['title'];
	}

	public function get_icon() {
		return $this->vi()['icon'];
	}

	public function get_categories() {
		return array( 'villa-ibit' );
	}

	public function get_keywords() {
		return array_merge( array( 'villa', 'ibit', 'loja', 'woocommerce' ), $this->vi()['keywords'] ?? array() );
	}

	/** Conteúdo sempre atualizado (não guardar em cache). */
	protected function is_dynamic_content(): bool {
		return true;
	}

	public function has_widget_inner_wrapper(): bool {
		return false;
	}

	protected function register_controls() {
		$this->start_controls_section( 'vi_content', array( 'label' => __( 'Conteúdo', 'villa-ibit' ), 'tab' => Controls_Manager::TAB_CONTENT ) );
		$this->vi_controls();
		$this->end_controls_section();
	}

	protected function vi_controls() {
		$this->add_control(
			'vi_note',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => esc_html__( 'Esta seção é preenchida automaticamente com os dados da loja.', 'villa-ibit' ),
				'content_classes' => 'elementor-descriptor',
			)
		);
	}

	protected function text( $id, $label, $default = '', $textarea = false ) {
		$this->add_control( $id, array( 'label' => $label, 'type' => $textarea ? Controls_Manager::TEXTAREA : Controls_Manager::TEXT, 'default' => $default, 'label_block' => true ) );
	}

	protected function select( $id, $label, $options, $default, $extra = array() ) {
		$this->add_control( $id, array_merge( array( 'label' => $label, 'type' => Controls_Manager::SELECT, 'options' => $options, 'default' => $default ), $extra ) );
	}

	protected function switcher( $id, $label, $default = 'yes' ) {
		$this->add_control( $id, array( 'label' => $label, 'type' => Controls_Manager::SWITCHER, 'return_value' => 'yes', 'default' => $default, 'label_on' => __( 'Sim', 'villa-ibit' ), 'label_off' => __( 'Não', 'villa-ibit' ) ) );
	}

	protected function number( $id, $label, $default, $min = 1, $max = 48 ) {
		$this->add_control( $id, array( 'label' => $label, 'type' => Controls_Manager::NUMBER, 'default' => $default, 'min' => $min, 'max' => $max ) );
	}

	protected static function yn( $s, $key ) {
		return ( isset( $s[ $key ] ) && 'yes' === $s[ $key ] ) ? 'yes' : 'no';
	}

	protected function render() {
		$this->vi_render( $this->get_settings_for_display() );
	}

	abstract protected function vi_render( $s );
}

/* ------------------------------------------------------------------ */
class VI_El_Banner extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'banner', 'title' => __( 'Banner (slides)', 'villa-ibit' ), 'icon' => 'eicon-slides', 'keywords' => array( 'banner', 'slide', 'carrossel', 'hero' ) );
	}

	protected function vi_controls() {
		$this->select( 'source', __( 'Slides', 'villa-ibit' ), array( 'painel' => __( 'Usar os do painel Villa Ibit › Configurações', 'villa-ibit' ), 'elementor' => __( 'Editar aqui no Elementor', 'villa-ibit' ) ), 'painel' );
		$rep = new Repeater();
		$rep->add_control( 'style', array( 'label' => __( 'Estilo', 'villa-ibit' ), 'type' => Controls_Manager::SELECT, 'default' => 'natureza', 'options' => array( 'natureza' => __( 'Natureza (foto clara, texto verde)', 'villa-ibit' ), 'verde' => __( 'Verde', 'villa-ibit' ), 'escuro' => __( 'Escuro', 'villa-ibit' ), 'dourado' => __( 'Dourado', 'villa-ibit' ) ) ) );
		$rep->add_control( 'image', array( 'label' => __( 'Imagem de fundo (2560×1120, produtos à direita)', 'villa-ibit' ), 'type' => Controls_Manager::MEDIA ) );
		foreach ( array( 'eyebrow' => __( 'Etiqueta', 'villa-ibit' ), 'title' => __( 'Título (início)', 'villa-ibit' ), 'highlight' => __( 'Título (destaque dourado)', 'villa-ibit' ), 'title_after' => __( 'Título (final)', 'villa-ibit' ) ) as $k => $l ) {
			$rep->add_control( $k, array( 'label' => $l, 'type' => Controls_Manager::TEXT, 'label_block' => true ) );
		}
		$rep->add_control( 'text', array( 'label' => __( 'Texto', 'villa-ibit' ), 'type' => Controls_Manager::TEXTAREA ) );
		foreach ( array( 'price_pre' => __( 'Antes do preço', 'villa-ibit' ), 'price' => __( 'Preço no PIX', 'villa-ibit' ), 'button' => __( 'Texto do botão', 'villa-ibit' ), 'link' => __( 'Link do botão (URL, /caminho ou {whatsapp})', 'villa-ibit' ) ) as $k => $l ) {
			$rep->add_control( $k, array( 'label' => $l, 'type' => Controls_Manager::TEXT, 'label_block' => true ) );
		}
		$defaults = array();
		foreach ( vi_theme_defaults()['slides'] as $d ) {
			$d['image'] = array( 'url' => VI_THEME_URI . '/assets/img/' . $d['image_def'], 'id' => '' );
			unset( $d['active'], $d['image_id'], $d['image_def'] );
			$defaults[] = $d;
		}
		$this->add_control(
			'slides',
			array(
				'label'       => __( 'Slides', 'villa-ibit' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $rep->get_controls(),
				'default'     => $defaults,
				'title_field' => '{{{ eyebrow }}} — {{{ highlight }}}',
				'condition'   => array( 'source' => 'elementor' ),
			)
		);
		$this->switcher( 'show_offers', __( 'Botão "Ofertas da semana"', 'villa-ibit' ) );
	}

	/** O editor também pode gravar os três slides padrão ao salvar outra parte da página. */
	private function uses_theme_slides( $slides ) {
		$defaults = vi_theme_defaults()['slides'];
		if ( ! is_array( $slides ) || count( $slides ) !== count( $defaults ) ) {
			return false;
		}
		foreach ( array_values( $slides ) as $index => $item ) {
			$item     = vi_local_delivery_slide( $item );
			$default  = $defaults[ $index ];
			$old_file = 'banner-' . ( $index + 1 ) . '-natureza.jpg';
			$base_url = VI_THEME_URI . '/assets/img/';
			$file     = $item['image']['url'] ?? '';
			$style    = $item['style'] ?? 'natureza';
			if ( ! empty( $item['__dynamic__'] ) || ! empty( $item['image']['id'] )
				|| ! ( ( $file === $base_url . $default['image_def'] && $style === $default['style'] )
					|| ( $file === $base_url . $old_file && 'natureza' === $style ) ) ) {
				return false;
			}
			foreach ( array( 'eyebrow', 'title', 'highlight', 'title_after', 'text', 'price_pre', 'price', 'button', 'link' ) as $field ) {
				if ( ( $item[ $field ] ?? '' ) !== ( $default[ $field ] ?? '' ) ) {
					return false;
				}
			}
		}
		return true;
	}

	protected function vi_render( $s ) {
		$slides = null;
		// O layout antigo salvava "elementor" mesmo sem configurar a lista.
		// Nesse caso, os valores que o editor injeta por padrão não substituem os do painel.
		$raw = (array) $this->get_data( 'settings' );
		if ( 'elementor' === ( $raw['source'] ?? 'elementor' ) && array_key_exists( 'slides', $raw ) && ! $this->uses_theme_slides( $raw['slides'] ) ) {
			$slides = array();
			foreach ( (array) ( $s['slides'] ?? $raw['slides'] ) as $item ) {
				$item['active']    = 1;
				$item['image_id']  = ! empty( $item['image']['id'] ) ? (int) $item['image']['id'] : 0;
				$item['image_url'] = ! empty( $item['image']['url'] ) ? $item['image']['url'] : '';
				$slides[]          = $item;
			}
		}
		vi_section_hero( array( 'slides' => $slides, 'show_offers' => self::yn( $s, 'show_offers' ), 'h1' => true ) );
	}
}

class VI_El_Trust extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'selos', 'title' => __( 'Selos de confiança', 'villa-ibit' ), 'icon' => 'eicon-check-circle' );
	}
	protected function vi_render( $s ) {
		vi_section_trust();
	}
}

class VI_El_Brands extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'marcas', 'title' => __( 'Marcas', 'villa-ibit' ), 'icon' => 'eicon-logo', 'keywords' => array( 'marca', 'brand' ) );
	}
	protected function vi_controls() {
		parent::vi_controls();
		$this->text( 'title', __( 'Título', 'villa-ibit' ), __( 'Compre por marca', 'villa-ibit' ) );
	}
	protected function vi_render( $s ) {
		vi_section_brands( array( 'title' => $s['title'] ) );
	}
}

class VI_El_Categories extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'categorias', 'title' => __( 'Categorias', 'villa-ibit' ), 'icon' => 'eicon-gallery-grid', 'keywords' => array( 'categoria' ) );
	}
	protected function vi_controls() {
		parent::vi_controls();
		$this->text( 'title', __( 'Título', 'villa-ibit' ), __( 'Categorias em destaque', 'villa-ibit' ) );
		$this->select( 'layout', __( 'Layout', 'villa-ibit' ), array( 'bento' => __( 'Círculos com miniatura (home)', 'villa-ibit' ), 'grid' => __( 'Grade com todas as categorias', 'villa-ibit' ) ), 'bento' );
		$this->switcher( 'link_all', __( 'Link "Ver todas as categorias"', 'villa-ibit' ) );
	}
	protected function vi_render( $s ) {
		vi_section_categories( array( 'title' => $s['title'], 'layout' => $s['layout'], 'link_all' => self::yn( $s, 'link_all' ) ) );
	}
}

class VI_El_Tabs extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'vitrine-abas', 'title' => __( 'Vitrine com abas', 'villa-ibit' ), 'icon' => 'eicon-tabs', 'keywords' => array( 'produtos', 'vitrine', 'abas' ) );
	}
	protected function vi_controls() {
		parent::vi_controls();
		$this->text( 'title', __( 'Título', 'villa-ibit' ), __( 'Explore os produtos', 'villa-ibit' ) );
		$this->number( 'limit', __( 'Produtos por aba', 'villa-ibit' ), 8, 2, 24 );
		$this->number( 'brand_tabs', __( 'Abas de marcas (as que têm mais produtos)', 'villa-ibit' ), 2, 0, 6 );
		$this->text( 'button', __( 'Texto do botão (vazio = sem botão)', 'villa-ibit' ), __( 'Ver todos os produtos', 'villa-ibit' ) );
	}
	protected function vi_render( $s ) {
		vi_section_tabs( array( 'title' => $s['title'], 'limit' => $s['limit'], 'brand_tabs' => (string) $s['brand_tabs'], 'button' => $s['button'] ? $s['button'] : ' ' ) );
	}
}

class VI_El_Products extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'vitrine', 'title' => __( 'Vitrine de produtos', 'villa-ibit' ), 'icon' => 'eicon-products', 'keywords' => array( 'produtos', 'ofertas', 'vitrine' ) );
	}
	protected function vi_controls() {
		$this->text( 'eyebrow', __( 'Etiqueta (opcional)', 'villa-ibit' ), __( 'Promoções', 'villa-ibit' ) );
		$this->text( 'title', __( 'Título', 'villa-ibit' ), __( 'Ofertas exclusivas pra você não perder', 'villa-ibit' ) );
		$this->text( 'subtitle', __( 'Subtítulo (opcional)', 'villa-ibit' ) );
		$this->select( 'source', __( 'Quais produtos', 'villa-ibit' ), array( 'ofertas' => __( 'Em oferta', 'villa-ibit' ), 'novidades' => __( 'Mais recentes', 'villa-ibit' ), 'vendidos' => __( 'Mais vendidos', 'villa-ibit' ), 'destaques' => __( 'Em destaque (estrela)', 'villa-ibit' ), 'categoria' => __( 'De categorias', 'villa-ibit' ), 'marca' => __( 'De marcas', 'villa-ibit' ) ), 'ofertas' );
		$this->add_control( 'cats', array( 'label' => __( 'Categorias', 'villa-ibit' ), 'type' => Controls_Manager::SELECT2, 'multiple' => true, 'options' => vi_el_term_options( 'product_cat' ), 'label_block' => true, 'condition' => array( 'source' => 'categoria' ) ) );
		$this->add_control( 'brands', array( 'label' => __( 'Marcas', 'villa-ibit' ), 'type' => Controls_Manager::SELECT2, 'multiple' => true, 'options' => vi_el_term_options( 'product_brand' ), 'label_block' => true, 'condition' => array( 'source' => 'marca' ) ) );
		$this->number( 'limit', __( 'Quantidade', 'villa-ibit' ), 6, 1, 24 );
		$this->select( 'columns', __( 'Colunas', 'villa-ibit' ), array( '3' => '3', '4' => '4', '5' => '5', '6' => '6' ), '6' );
		$this->select( 'style', __( 'Formato', 'villa-ibit' ), array( 'light' => __( 'Grade de cards', 'villa-ibit' ), 'dark' => __( 'Lista de ofertas (cards na horizontal)', 'villa-ibit' ), 'band' => __( 'Faixa de destaques (dourada)', 'villa-ibit' ) ), 'dark' );
		$this->text( 'link', __( 'Link "Ver todos" (opcional)', 'villa-ibit' ) );
		$this->select( 'badge', __( 'Selo nos produtos', 'villa-ibit' ), array( '' => __( 'Nenhum', 'villa-ibit' ), 'new' => __( '"Novo"', 'villa-ibit' ), 'hot' => __( '"Mais vendido"', 'villa-ibit' ) ), '' );
	}
	protected function vi_render( $s ) {
		$raw = (array) $this->get_data( 'settings' );
		if ( is_front_page() && 'categoria' === $s['source'] ) {
			if ( empty( $raw['cats'] ) ) {
				$s['cats'] = (array) vi_opt( 'extra_cats' );
			}
			if ( empty( $raw['title'] ) || 'Pod System, coils e líquidos' === $raw['title'] ) {
				$s['title'] = vi_opt( 'extra_title' );
			}
		}
		if ( is_front_page() && 'destaques' === $s['source'] && 'band' === $s['style'] ) {
			if ( empty( $raw['title'] ) || in_array( $raw['title'], array( 'Destaques do mês', 'Novidades' ), true ) ) {
				$s['title'] = vi_opt( 'featured_title' );
			}
			if ( empty( $raw['subtitle'] ) ) {
				$s['subtitle'] = vi_opt( 'featured_text' );
			}
		}
		vi_section_products(
			array(
				'eyebrow'  => $s['eyebrow'],
				'title'    => $s['title'],
				'subtitle' => $s['subtitle'],
				'source'   => $s['source'],
				'terms'    => 'marca' === $s['source'] ? (array) ( $s['brands'] ?? array() ) : (array) ( $s['cats'] ?? array() ),
				'limit'    => $s['limit'],
				'columns'  => $s['columns'],
				'style'    => $s['style'],
				'link'     => $s['link'],
				'badge'    => $s['badge'] ?? '',
			)
		);
	}
}

class VI_El_Spotlight extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'destaque', 'title' => __( 'Destaque da semana', 'villa-ibit' ), 'icon' => 'eicon-single-product', 'keywords' => array( 'destaque', 'produto', 'semana' ) );
	}
	protected function vi_controls() {
		$this->add_control(
			'vi_note',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => esc_html__( 'Mostra o produto escolhido em Villa Ibit › Configurações › Home (ou o primeiro produto em destaque). Foto, preço e especificações se atualizam sozinhos.', 'villa-ibit' ),
				'content_classes' => 'elementor-descriptor',
			)
		);
		$this->text( 'eyebrow', __( 'Etiqueta (em branco, usa a do painel)', 'villa-ibit' ) );
		$this->add_control( 'product', array( 'label' => __( 'Produto (opcional)', 'villa-ibit' ), 'type' => Controls_Manager::SELECT2, 'options' => vi_el_product_options(), 'label_block' => true ) );
		$this->text( 'button', __( 'Texto do botão (opcional)', 'villa-ibit' ) );
	}
	protected function vi_render( $s ) {
		$label = $s['eyebrow'] ?? '';
		if ( 'Destaque da semana' === $label ) {
			$label = '';
		}
		vi_section_spotlight( array( 'eyebrow' => $label, 'product' => (int) ( $s['product'] ?? 0 ), 'button' => $s['button'] ?? '' ) );
	}
}

class VI_El_Wholesale extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'atacado', 'title' => __( 'Faixa Atacado', 'villa-ibit' ), 'icon' => 'eicon-call-to-action' );
	}
	protected function vi_controls() {
		$this->text( 'eyebrow', __( 'Etiqueta', 'villa-ibit' ), __( 'Para lojistas', 'villa-ibit' ) );
		$this->text( 'title', __( 'Título (em branco, usa o do painel)', 'villa-ibit' ) );
		$this->text( 'text', __( 'Texto (em branco, usa o do painel)', 'villa-ibit' ), '', true );
		$this->text( 'button', __( 'Botão (abre o WhatsApp)', 'villa-ibit' ), __( 'Falar com o atacado', 'villa-ibit' ) );
	}
	protected function vi_render( $s ) {
		// O instalador anterior gravava este texto no widget de todas as lojas.
		if ( 'Compre no atacado' === ( $s['title'] ?? '' ) ) {
			unset( $s['title'] );
		}
		$original = 'Misture marcas e sabores com condições especiais para lojistas e revendedores.';
		if ( in_array( $s['text'] ?? '', array( $original, $original . ' Fale com a gente e receba a tabela atualizada.' ), true ) && function_exists( 'vi_gestor_get' ) && null !== vi_gestor_get( 'wholesale_text' ) ) {
			unset( $s['text'] );
		}
		vi_section_wholesale( $s );
	}
}

class VI_El_Reviews extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'avaliacoes', 'title' => __( 'Avaliações', 'villa-ibit' ), 'icon' => 'eicon-review' );
	}
	protected function vi_controls() {
		parent::vi_controls();
		$this->text( 'title', __( 'Título', 'villa-ibit' ), __( 'O que dizem os clientes', 'villa-ibit' ) );
		$this->number( 'limit', __( 'Quantidade', 'villa-ibit' ), 3, 1, 12 );
	}
	protected function vi_render( $s ) {
		vi_section_reviews( $s );
	}
}

class VI_El_Blog extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'blog', 'title' => __( 'Posts do blog', 'villa-ibit' ), 'icon' => 'eicon-posts-grid' );
	}
	protected function vi_controls() {
		parent::vi_controls();
		$this->text( 'title', __( 'Título', 'villa-ibit' ), __( 'Dicas, guias e novidades', 'villa-ibit' ) );
		$this->number( 'limit', __( 'Quantidade', 'villa-ibit' ), 3, 1, 12 );
	}
	protected function vi_render( $s ) {
		vi_section_blog( $s );
	}
}

class VI_El_Social extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'instagram-vip', 'title' => __( 'Instagram + lista VIP', 'villa-ibit' ), 'icon' => 'eicon-instagram-post' );
	}
	protected function vi_controls() {
		$this->text( 'ig_title', __( 'Título do Instagram', 'villa-ibit' ), __( 'Siga no Instagram', 'villa-ibit' ) );
		$this->text( 'ig_text', __( 'Texto do Instagram', 'villa-ibit' ), __( 'Lançamentos e promoções em primeira mão.', 'villa-ibit' ) );
		$this->text( 'news_title', __( 'Título da lista VIP', 'villa-ibit' ), __( 'Receba ofertas em primeira mão', 'villa-ibit' ) );
	}
	protected function vi_render( $s ) {
		vi_section_social( $s );
	}
}

class VI_El_Page_Hero extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'cabecalho', 'title' => __( 'Cabeçalho de página', 'villa-ibit' ), 'icon' => 'eicon-header', 'keywords' => array( 'titulo', 'header' ) );
	}
	protected function vi_controls() {
		$this->text( 'title', __( 'Título (vazio = título da página)', 'villa-ibit' ) );
		$this->text( 'text', __( 'Texto', 'villa-ibit' ), '', true );
		$this->switcher( 'crumbs', __( 'Mostrar "Início / página"', 'villa-ibit' ) );
	}
	protected function vi_render( $s ) {
		vi_section_page_hero( array( 'title' => $s['title'] ? $s['title'] : get_the_title(), 'text' => $s['text'], 'crumbs' => self::yn( $s, 'crumbs' ) ) );
	}
}

class VI_El_Catalog extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'catalogo', 'title' => __( 'Catálogo com filtros', 'villa-ibit' ), 'icon' => 'eicon-archive-posts', 'keywords' => array( 'loja', 'produtos', 'categoria', 'filtro' ) );
	}
	protected function vi_controls() {
		$this->add_control(
			'vi_note',
			array(
				'type' => Controls_Manager::RAW_HTML,
				'raw'  => esc_html__( 'Na página "Todos os produtos", este catálogo também é usado nas páginas de cada categoria e marca (mostra os produtos delas automaticamente).', 'villa-ibit' ),
			)
		);
		$this->text( 'title', __( 'Título (vazio = automático)', 'villa-ibit' ) );
		$this->text( 'text', __( 'Texto abaixo do título', 'villa-ibit' ), '', true );
		$this->select( 'category', __( 'Mostrar só a categoria', 'villa-ibit' ), vi_el_cat_slug_options(), '' );
		$this->switcher( 'hero', __( 'Faixa verde com título', 'villa-ibit' ) );
		$this->switcher( 'filters', __( 'Barra de filtros', 'villa-ibit' ) );
		$this->number( 'per_page', __( 'Produtos por página', 'villa-ibit' ), 24, 3, 96 );
	}
	protected function vi_render( $s ) {
		vi_section_catalog( array( 'title' => $s['title'], 'text' => $s['text'], 'category' => $s['category'], 'hero' => self::yn( $s, 'hero' ), 'filters' => self::yn( $s, 'filters' ), 'per_page' => $s['per_page'] ) );
	}
}

class VI_El_Login extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'login', 'title' => __( 'Login e cadastro', 'villa-ibit' ), 'icon' => 'eicon-lock-user', 'keywords' => array( 'login', 'entrar', 'cadastro', 'registro' ) );
	}
	protected function vi_controls() {
		$this->text( 'title', __( 'Título', 'villa-ibit' ), __( 'Entrar ou criar conta', 'villa-ibit' ) );
		$this->text( 'text', __( 'Texto', 'villa-ibit' ), __( 'Acompanhe seus pedidos, salve endereços e compre mais rápido.', 'villa-ibit' ), true );
	}
	protected function vi_render( $s ) {
		vi_section_login( $s );
	}
}

class VI_El_Steps extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'etapas', 'title' => __( 'Etapas da compra', 'villa-ibit' ), 'icon' => 'eicon-progress-tracker' );
	}
	protected function vi_render( $s ) {
		vi_section_steps();
	}
}

class VI_El_Woo extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'woo', 'title' => __( 'Carrinho / Checkout / Minha conta', 'villa-ibit' ), 'icon' => 'eicon-checkout', 'keywords' => array( 'carrinho', 'checkout', 'conta', 'pedido' ) );
	}
	protected function vi_controls() {
		$this->select( 'which', __( 'Conteúdo', 'villa-ibit' ), array( 'cart' => __( 'Carrinho', 'villa-ibit' ), 'checkout' => __( 'Finalizar compra (checkout)', 'villa-ibit' ), 'account' => __( 'Minha conta', 'villa-ibit' ), 'tracking' => __( 'Rastrear pedido', 'villa-ibit' ) ), 'cart' );
	}
	protected function vi_render( $s ) {
		vi_section_wc_shortcode( $s );
	}
}

class VI_El_Product_Top extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'produto-compra', 'title' => __( 'Produto: fotos e compra', 'villa-ibit' ), 'icon' => 'eicon-product-images', 'keywords' => array( 'produto' ) );
	}
	protected function vi_controls() {
		$this->add_control( 'vi_note', array( 'type' => Controls_Manager::RAW_HTML, 'raw' => esc_html__( 'Use na página "Modelo — Página do produto". No editor aparece um produto de exemplo; no site, o produto que o cliente abriu.', 'villa-ibit' ) ) );
		$this->switcher( 'crumbs', __( 'Mostrar caminho (Início / categoria)', 'villa-ibit' ) );
		$this->switcher( 'details', __( 'Descrição e especificações dentro do quadro de compra', 'villa-ibit' ) );
		$this->switcher( 'delivery', __( 'Entrega e trocas', 'villa-ibit' ) );
		$this->switcher( 'trust', __( 'Selos (original, seguro, 18+)', 'villa-ibit' ) );
	}
	protected function vi_render( $s ) {
		vi_section_product_top( array( 'crumbs' => self::yn( $s, 'crumbs' ), 'delivery' => self::yn( $s, 'delivery' ), 'trust' => self::yn( $s, 'trust' ), 'details' => isset( $s['details'] ) ? self::yn( $s, 'details' ) : 'yes' ) );
	}
}

class VI_El_Product_Tabs extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'produto-abas', 'title' => __( 'Produto: descrição e avaliações', 'villa-ibit' ), 'icon' => 'eicon-product-tabs', 'keywords' => array( 'produto' ) );
	}
	protected function vi_render( $s ) {
		vi_section_product_tabs();
	}
}

class VI_El_Product_Related extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'produto-relacionados', 'title' => __( 'Produto: relacionados', 'villa-ibit' ), 'icon' => 'eicon-product-related', 'keywords' => array( 'produto' ) );
	}
	protected function vi_render( $s ) {
		vi_section_product_related();
	}
}

/**
 * Lista de widgets registrados.
 */
class VI_El_Promos extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'cartoes', 'title' => __( 'Cartões Ofertas e Combos', 'villa-ibit' ), 'icon' => 'eicon-image-box', 'keywords' => array( 'ofertas', 'combos', 'cartão', 'promoção' ) );
	}
	protected function vi_controls() {
		$this->add_control(
			'vi_note',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => esc_html__( 'Textos, links e fotos dos dois cartões ficam em Villa Ibit › Configurações › Home.', 'villa-ibit' ),
				'content_classes' => 'elementor-descriptor',
			)
		);
	}
	protected function vi_render( $s ) {
		vi_section_promos();
	}
}

class VI_El_Duo extends VI_El_Widget {
	protected function vi() {
		return array( 'name' => 'vendidos-destaques', 'title' => __( 'Mais vendidos + Destaques', 'villa-ibit' ), 'icon' => 'eicon-columns', 'keywords' => array( 'mais vendidos', 'destaques', 'produtos' ) );
	}
	protected function vi_controls() {
		parent::vi_controls();
		$this->text( 'title_sold', __( 'Título da esquerda', 'villa-ibit' ), __( 'Mais vendidos', 'villa-ibit' ) );
		$this->text( 'title_featured', __( 'Título da direita (produtos com estrela)', 'villa-ibit' ), __( 'Produtos em destaque', 'villa-ibit' ) );
		$this->number( 'limit', __( 'Produtos de cada lado', 'villa-ibit' ), 3, 1, 6 );
	}
	protected function vi_render( $s ) {
		vi_section_duo( array( 'title_sold' => $s['title_sold'], 'title_featured' => $s['title_featured'], 'limit' => $s['limit'] ) );
	}
}

function vi_elementor_widget_classes() {
	return array( 'VI_El_Banner', 'VI_El_Trust', 'VI_El_Brands', 'VI_El_Categories', 'VI_El_Tabs', 'VI_El_Spotlight', 'VI_El_Products', 'VI_El_Promos', 'VI_El_Duo', 'VI_El_Wholesale', 'VI_El_Reviews', 'VI_El_Blog', 'VI_El_Social', 'VI_El_Page_Hero', 'VI_El_Catalog', 'VI_El_Login', 'VI_El_Steps', 'VI_El_Woo', 'VI_El_Product_Top', 'VI_El_Product_Tabs', 'VI_El_Product_Related' );
}
