<?php
/**
 * Integração com o WooCommerce.
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;

/* ------------------------------------------------------------------ *
 * Estrutura das páginas da loja
 * ------------------------------------------------------------------ */
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
remove_action( 'woocommerce_shop_loop_header', 'woocommerce_product_taxonomy_archive_header', 10 );

add_action( 'woocommerce_before_main_content', function () { echo '<main id="conteudo" class="vi-main">'; }, 10 );
add_action( 'woocommerce_after_main_content', function () { echo '</main>'; }, 10 );

/**
 * Breadcrumb no padrão do tema.
 */
add_filter(
	'woocommerce_breadcrumb_defaults',
	function ( $args ) {
		$args['delimiter']   = '<span class="vi-crumbs__sep" aria-hidden="true">/</span>';
		$args['wrap_before'] = '<nav class="vi-crumbs" aria-label="' . esc_attr__( 'Você está em', 'villa-ibit' ) . '">';
		$args['wrap_after']  = '</nav>';
		$args['home']        = __( 'Início', 'villa-ibit' );
		return $args;
	}
);

/* ------------------------------------------------------------------ *
 * Catálogo
 * ------------------------------------------------------------------ */
add_filter( 'loop_shop_columns', function () { return 3; } );
add_filter( 'loop_shop_per_page', function () { return 24; } );
add_filter( 'woocommerce_catalog_orderby', function ( $options ) {
	$options['menu_order'] = __( 'Relevância', 'villa-ibit' );
	$options['date']       = __( 'Novidades', 'villa-ibit' );
	$options['popularity'] = __( 'Mais vendidos', 'villa-ibit' );
	$options['price']      = __( 'Menor preço', 'villa-ibit' );
	$options['price-desc'] = __( 'Maior preço', 'villa-ibit' );
	unset( $options['rating'] );
	return $options;
} );

/**
 * Página de ofertas: /loja/?ofertas=1 mostra só produtos em promoção.
 */
add_action(
	'woocommerce_product_query',
	function ( $q ) {
		$puffs = vi_puffs_meta_query( vi_puffs_selected() );
		if ( $puffs ) {
			$mq   = (array) $q->get( 'meta_query' );
			$mq[] = $puffs;
			$q->set( 'meta_query', $mq );
		}
		if ( ! empty( $_GET['destaques'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			// Produtos em destaque: os marcados com a estrela.
			$tq   = (array) $q->get( 'tax_query' );
			$tq[] = array( 'taxonomy' => 'product_visibility', 'field' => 'name', 'terms' => array( 'featured' ), 'operator' => 'IN' );
			$q->set( 'tax_query', $tq );
		}
		if ( empty( $_GET['ofertas'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$ids = wc_get_product_ids_on_sale();
		$q->set( 'post__in', $ids ? array_map( 'absint', $ids ) : array( 0 ) );
	}
);
add_filter(
	'woocommerce_page_title',
	function ( $title ) {
		$titles = array(
			'ofertas'   => __( 'Promoções', 'villa-ibit' ),
			'novidades' => __( 'Novidades', 'villa-ibit' ),
			'vendidos'  => __( 'Mais vendidos', 'villa-ibit' ),
			'destaques' => __( 'Produtos em destaque', 'villa-ibit' ),
		);
		$list   = function_exists( 'vi_shop_list' ) ? vi_shop_list() : '';
		return ( $list && isset( $titles[ $list ] ) ) ? $titles[ $list ] : $title;
	}
);

/**
 * Selo "Oferta -X%".
 */
add_filter(
	'woocommerce_sale_flash',
	function ( $html, $post, $product ) {
		$pct = vi_sale_percent( $product );
		return '<span class="onsale vi-badge-sale">' . ( $pct ? '<span class="screen-reader-text">' . esc_html__( 'Oferta', 'villa-ibit' ) . ' </span>' . esc_html( sprintf( '-%d%%', $pct ) ) : esc_html__( 'Oferta', 'villa-ibit' ) ) . '</span>';
	},
	10,
	3
);

/**
 * Texto do botão nos cards.
 */
add_filter(
	'woocommerce_product_add_to_cart_text',
	function ( $text, $product ) {
		if ( ! $product->is_in_stock() ) {
			return __( 'Esgotado', 'villa-ibit' );
		}
		if ( $product->is_type( 'variable' ) ) {
			return __( 'Escolher sabor', 'villa-ibit' );
		}
		if ( $product->is_type( 'simple' ) ) {
			return __( 'Comprar agora', 'villa-ibit' );
		}
		return $text;
	},
	10,
	2
);

/* ------------------------------------------------------------------ *
 * Carrinho no header (atualiza sem recarregar)
 * ------------------------------------------------------------------ */
function vi_header_cart() {
	$cart  = WC()->cart;
	$count = $cart ? $cart->get_cart_contents_count() : 0;
	$total = $cart ? $cart->get_cart_subtotal() : wc_price( 0 );
	return '<a class="vi-cart-btn" href="' . esc_url( wc_get_cart_url() ) . '" aria-controls="vi-cart" aria-haspopup="dialog" aria-label="' . esc_attr( sprintf( _n( 'Carrinho, %d item', 'Carrinho, %d itens', $count, 'villa-ibit' ), $count ) ) . '">'
		. vi_icon( 'cart', 20 ) . '<span class="vi-cart-btn__label">' . esc_html__( 'Carrinho', 'villa-ibit' ) . '</span><span class="vi-cart-btn__total screen-reader-text">' . wp_kses_post( $total ) . '</span><span class="vi-cart-btn__count">' . (int) $count . '</span></a>';
}
add_filter(
	'woocommerce_add_to_cart_fragments',
	function ( $fragments ) {
		$fragments['a.vi-cart-btn']     = vi_header_cart();
		$fragments['span.vi-tab-count'] = '<span class="vi-tab-count">' . (int) WC()->cart->get_cart_contents_count() . '</span>';
		return $fragments;
	}
);

/* ------------------------------------------------------------------ *
 * Página do produto
 * ------------------------------------------------------------------ */
// Tanto as opções carregadas com a página quanto as buscadas por AJAX usam este filtro.
add_filter( 'woocommerce_available_variation', function ( $data, $parent, $variation ) {
	$data['vi_price_html'] = vi_price_block( $variation, 'single' );
	return $data;
}, 10, 3 );

add_filter( 'woocommerce_product_thumbnails_columns', function () { return 5; } );
add_filter( 'woocommerce_output_related_products_args', function ( $args ) {
	$args['posts_per_page'] = 4;
	$args['columns']        = 4;
	return $args;
} );
add_filter( 'woocommerce_upsell_display_args', function ( $args ) {
	$args['posts_per_page'] = 4;
	$args['columns']        = 4;
	return $args;
} );

add_filter(
	'woocommerce_product_tabs',
	function ( $tabs ) {
		if ( isset( $tabs['description'] ) ) {
			$tabs['description']['title'] = __( 'Descrição', 'villa-ibit' );
		}
		if ( isset( $tabs['additional_information'] ) ) {
			$tabs['additional_information']['title'] = __( 'Especificações', 'villa-ibit' );
		}
		return $tabs;
	},
	20
);
add_filter( 'woocommerce_product_description_heading', '__return_empty_string' );
add_filter( 'woocommerce_product_additional_information_heading', '__return_empty_string' );

/**
 * O segundo botão envia o mesmo formulário, incluindo os campos das extensões.
 */
add_action(
	'woocommerce_after_add_to_cart_button',
	function () {
		global $product;
		if ( ! $product || ! $product->is_type( array( 'simple', 'variable', 'grouped' ) ) ) {
			return;
		}
		$action = apply_filters( 'woocommerce_add_to_cart_form_action', $product->get_permalink() );
		?>
		<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $product->get_id() ); ?>" formaction="<?php echo esc_url( add_query_arg( 'vi_buy_now', $product->get_id(), $action ) ); ?>" class="vi-btn vi-btn--green vi-btn--block vi-buy-now"><?php esc_html_e( 'Compre Agora', 'villa-ibit' ); ?></button>
		<?php
	}
);

/** O marcador só pertence ao botão de compra imediata deste produto. */
function vi_is_buy_now_request() {
	return isset( $_GET['vi_buy_now'], $_POST['add-to-cart'] ) // phpcs:ignore WordPress.Security.NonceVerification
		&& is_string( $_GET['vi_buy_now'] ) && is_numeric( $_GET['vi_buy_now'] )
		&& $_GET['vi_buy_now'] === $_POST['add-to-cart'];
}

add_filter(
	'woocommerce_add_to_cart_redirect',
	function ( $url, $product = null ) {
		return $product && vi_is_buy_now_request() ? wc_get_checkout_url() : $url;
	},
	99,
	2
);

/* ------------------------------------------------------------------ *
 * Carrinho e checkout (funciona com o carrinho/checkout clássico e em blocos)
 * ------------------------------------------------------------------ */
add_action(
	'woocommerce_review_order_after_payment',
	function () {
		echo '<div class="vi-checkout-trust">';
		echo '<p>' . vi_icon( 'lock', 16 ) . esc_html__( 'Compra 100% segura — seus dados protegidos.', 'villa-ibit' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<p>' . vi_icon( 'shield', 16 ) . esc_html__( 'Produtos originais com procedência.', 'villa-ibit' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( vi_wa_link() ) {
			echo '<p>' . vi_icon( 'chat', 16 ) . sprintf( esc_html__( 'Dúvidas? Fale no WhatsApp %s', 'villa-ibit' ), '<a href="' . esc_url( vi_wa_link() ) . '" target="_blank" rel="noopener">' . esc_html( vi_opt( 'whatsapp_label' ) ) . '</a>' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div>';
	}
);

/**
 * Aviso de PIX no carrinho clássico.
 */
add_action(
	'woocommerce_proceed_to_checkout',
	function () {
		$pix = vi_pix_percent();
		if ( $pix > 0 && WC()->cart ) {
			$total = (float) WC()->cart->get_subtotal() + (float) WC()->cart->get_subtotal_tax();
			echo '<p class="vi-cart-pix">' . vi_icon( 'pix', 16 ) . wp_kses_post( sprintf( __( 'No PIX você paga %1$s (%2$s%% OFF)', 'villa-ibit' ), '<strong>' . wc_price( vi_pix_amount( $total ) ) . '</strong>', wc_format_localized_decimal( $pix ) ) ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
	},
	5
);

/**
 * Minha conta: rótulos mais diretos.
 */
add_filter(
	'woocommerce_account_menu_items',
	function ( $items ) {
		if ( isset( $items['dashboard'] ) ) {
			$items['dashboard'] = __( 'Início', 'villa-ibit' );
		}
		if ( isset( $items['orders'] ) ) {
			$items['orders'] = __( 'Meus pedidos', 'villa-ibit' );
		}
		if ( isset( $items['edit-address'] ) ) {
			$items['edit-address'] = __( 'Endereços', 'villa-ibit' );
		}
		if ( isset( $items['edit-account'] ) ) {
			$items['edit-account'] = __( 'Meus dados', 'villa-ibit' );
		}
		return $items;
	}
);

/* ------------------------------------------------------------------ *
 * O tema monta o resumo do produto (content-single-product.php).
 * O hook continua rodando para dados estruturados e outros plugins.
 * ------------------------------------------------------------------ */
add_action(
	'wp',
	function () {
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 50 );
	}
);

/**
 * Usa só o CSS base do WooCommerce (formulários, avisos); o layout é do tema.
 */
add_filter(
	'woocommerce_enqueue_styles',
	function ( $styles ) {
		unset( $styles['woocommerce-layout'], $styles['woocommerce-smallscreen'] );
		return $styles;
	}
);

/**
 * No editor do Elementor, o checkout não redireciona para o carrinho quando ele está vazio.
 */
add_filter(
	'woocommerce_checkout_redirect_empty_cart',
	function ( $redirect ) {
		return current_user_can( 'edit_post', get_queried_object_id() ) && vi_is_elementor_editor() ? false : $redirect;
	}
);

/* ------------------------------------------------------------------ *
 * Carrinho lateral (gaveta)
 * ------------------------------------------------------------------ */

/**
 * Scripts do WooCommerce para atualizar o carrinho sem recarregar (em todas as páginas).
 */
add_action(
	'wp_enqueue_scripts',
	function () {
		foreach ( array( 'wc-add-to-cart', 'wc-cart-fragments' ) as $handle ) {
			if ( wp_script_is( $handle, 'registered' ) ) {
				wp_enqueue_script( $handle );
			}
		}
	},
	20
);

/**
 * Conteúdo da gaveta.
 */
function vi_cart_drawer() {
	if ( is_cart() || is_checkout() ) {
		return;
	}
	$count = WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
	?>
	<div class="vi-drawer" id="vi-cart" role="dialog" aria-modal="true" aria-labelledby="vi-cart-title" hidden>
		<div class="vi-drawer__backdrop" data-vi-cart-close></div>
		<aside class="vi-drawer__panel">
			<header class="vi-drawer__head">
				<div>
					<h2 id="vi-cart-title" class="vi-h3"><?php esc_html_e( 'Seu carrinho', 'villa-ibit' ); ?></h2>
					<?php echo vi_drawer_count( $count ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</div>
				<button type="button" class="vi-icon-btn" data-vi-cart-close aria-label="<?php esc_attr_e( 'Fechar carrinho', 'villa-ibit' ); ?>"><?php vi_the_icon( 'close', 22 ); ?></button>
			</header>
			<div class="vi-drawer__added" data-vi-cart-added hidden><?php vi_the_icon( 'check', 16 ); ?><span><?php esc_html_e( 'Produto adicionado ao carrinho!', 'villa-ibit' ); ?></span></div>
			<div class="vi-drawer__body" data-lenis-prevent>
				<div class="widget_shopping_cart_content"><?php woocommerce_mini_cart(); ?></div>
			</div>
		</aside>
	</div>
	<?php
}

function vi_drawer_count( $count ) {
	return '<p class="vi-drawer__count">' . esc_html( sprintf( _n( '%d item', '%d itens', $count, 'villa-ibit' ), $count ) ) . '</p>';
}

add_filter(
	'woocommerce_add_to_cart_fragments',
	function ( $fragments ) {
		$fragments['p.vi-drawer__count'] = vi_drawer_count( WC()->cart->get_cart_contents_count() );
		return $fragments;
	},
	20
);

/**
 * Valor no PIX e frete dentro da gaveta.
 */
add_action(
	'woocommerce_widget_shopping_cart_before_buttons',
	function () {
		$pix = vi_pix_percent();
		if ( $pix > 0 && WC()->cart && ! WC()->cart->is_empty() ) {
			$total = (float) WC()->cart->get_subtotal() + (float) WC()->cart->get_subtotal_tax();
			echo '<p class="vi-mini-pix">' . vi_icon( 'pix', 16 ) . wp_kses_post( sprintf( __( 'No PIX: %1$s <small>(%2$s%% OFF)</small>', 'villa-ibit' ), '<strong>' . wc_price( vi_pix_amount( $total ) ) . '</strong>', wc_format_localized_decimal( $pix ) ) ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '<p class="vi-mini-note">' . esc_html__( 'Frete calculado na finalização da compra.', 'villa-ibit' ) . '</p>';
	}
);

/**
 * Carrinho vazio: botão para continuar comprando.
 */
add_action(
	'woocommerce_after_mini_cart',
	function () {
		if ( WC()->cart && WC()->cart->is_empty() ) {
			echo '<div class="vi-mini-empty">' . vi_icon( 'cart', 40 ) . '<a class="vi-btn vi-btn--green vi-btn--sm" href="' . esc_url( wc_get_page_permalink( 'shop' ) ) . '">' . esc_html__( 'Ver produtos', 'villa-ibit' ) . '</a></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}
);
add_filter( 'woocommerce_widget_cart_is_hidden', '__return_false' );

/**
 * Ao adicionar sem AJAX (ex.: página do produto sem JavaScript), em vez da faixa de aviso a gaveta abre na página seguinte.
 */
add_filter(
	'wc_add_to_cart_message_html',
	function ( $message ) {
		if ( vi_is_buy_now_request() ) {
			return '';
		}
		if ( wp_doing_ajax() || ( function_exists( 'is_cart' ) && is_cart() ) || 'yes' === get_option( 'woocommerce_cart_redirect_after_add' ) ) {
			return $message;
		}
		if ( WC()->session ) {
			WC()->session->set( 'vi_open_cart', 1 );
		}
		return '';
	}
);

function vi_should_open_cart() {
	if ( WC()->session && WC()->session->get( 'vi_open_cart' ) ) {
		WC()->session->set( 'vi_open_cart', null );
		return true;
	}
	return false;
}

/* ------------------------------------------------------------------ *
 * Miniatura da categoria no menu principal
 * ------------------------------------------------------------------ */
function vi_term_thumb_html( $term_id, $class = 'vi-nav__thumb' ) {
	$thumb = (int) get_term_meta( $term_id, 'thumbnail_id', true );
	if ( ! $thumb ) {
		return '';
	}
	$src = wp_get_attachment_image_url( $thumb, 'thumbnail' );
	return $src ? '<img class="' . esc_attr( $class ) . '" src="' . esc_url( $src ) . '" alt="" width="32" height="32" loading="lazy">' : '';
}

add_filter(
	'nav_menu_item_title',
	function ( $title, $item, $args, $depth ) {
		if ( isset( $args->theme_location ) && 'principal' === $args->theme_location && 'product_cat' === $item->object ) {
			$img = vi_term_thumb_html( (int) $item->object_id );
			if ( $img ) {
				return $img . '<span>' . $title . '</span>';
			}
		}
		return $title;
	},
	10,
	4
);

/* ------------------------------------------------------------------ *
 * Galeria do produto: movimento suave (1.5.9)
 * ------------------------------------------------------------------ */

/**
 * Tela cheia da foto (PhotoSwipe): o WooCommerce abre e fecha sem animação (0 ms).
 * Aqui ela surge e some com um esmaecer suave.
 */
add_filter(
	'woocommerce_single_product_photoswipe_options',
	function ( $options ) {
		$options['showAnimationDuration'] = 420;
		$options['hideAnimationDuration'] = 320;
		$options['showHideOpacity']       = true;
		$options['bgOpacity']             = 0.94;
		return $options;
	}
);

/** Troca de foto da galeria (miniaturas) um pouco mais lenta e macia. */
add_filter(
	'woocommerce_single_product_carousel_options',
	function ( $options ) {
		$options['animationSpeed'] = 650;
		return $options;
	}
);
