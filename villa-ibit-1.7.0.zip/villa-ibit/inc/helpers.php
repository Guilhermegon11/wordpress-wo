<?php
/**
 * Configurações e utilidades.
 *
 * As configurações vêm do plugin "Villa Ibit Gestor" (Villa Ibit › Configurações).
 * Sem o plugin, o tema usa os valores padrão abaixo.
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;

/**
 * Valores padrão da loja.
 */
function vi_theme_defaults() {
	return array(
		'whatsapp'        => '5533991347344',
		'whatsapp_label'  => '(33) 99134-7344',
		'instagram'       => 'villaibit',
		'pix_percent'     => function_exists( 'vi_gestor_get' ) && vi_gestor_get( 'pix_apply' ) && vi_gestor_get( 'pix_gateways' ) ? 5 : 0,
		'delivery_title'  => 'Entrega local',
		'delivery_text'   => 'Entregamos somente em Governador Valadares (MG). Consulte o frete pelo CEP no carrinho.',
		'topbar'          => "PIX com 5% de desconto\nEntrega somente em Governador Valadares (MG)",
		'cnpj'            => '',
		'address'         => '',
		'about'           => 'Os melhores produtos importados com qualidade de procedência. Vapes, pods, líquidos e acessórios 100% originais.',
		'wholesale_title' => 'Compre no atacado',
		'wholesale_text'  => 'Misture marcas e sabores com condições especiais para lojistas e revendedores.',
		'newsletter_sc'   => '',
		'extra_cats'      => array(),
		'extra_title'     => 'Pod System, coils e líquidos',
		'nav_scope'       => 'home',
		'spotlight_product' => 0,
		'spotlight_title' => 'Destaque da semana',
		'hero_nature'     => 0,
		'featured_title'  => 'Novidades',
		'featured_text'   => '',
		'sections'        => array(
			'categories' => 1,
			'tabs'       => 1,
			'spotlight'  => 1,
			'deals'      => 1,
			'brands'     => 1,
			'wholesale'  => 1,
			'social'     => 1,
			'novidades'  => 0,
			'promos'     => 0,
			'duo'        => 0,
			'featured'   => 0,
			'extra'      => 0,
			'reviews'    => 0,
			'blog'       => 0,
		),
		// Cartões "Ofertas da semana" e "Combos especiais".
		'promo_offers_title'  => 'Ofertas da semana',
		'promo_offers_text'   => 'Produtos selecionados com descontos especiais.',
		'promo_offers_button' => 'Aproveite agora',
		'promo_offers_link'   => '',
		'promo_offers_image'  => 0,
		'promo_combos_title'  => 'Combos especiais',
		'promo_combos_text'   => 'Mais economia na sua compra.',
		'promo_combos_button' => 'Confira os combos',
		'promo_combos_link'   => '',
		'promo_combos_image'  => 0,
		'wholesale_image'     => 0,
		'slides'          => array(
			array(
				'active'    => 1,
				'style'     => 'verde',
				'eyebrow'   => 'Lançamentos Elf Bar',
				'title'     => 'Sabor do primeiro ao',
				'highlight' => 'último puff.',
				'text'      => 'Ice King 40k, BC Pro 45k e TE 30K: até 45.000 puffs e mais de 60 sabores gelados.',
				'price_pre' => 'a partir de',
				'price'     => 'R$ 79,80',
				'button'    => 'Ver linha Elf Bar',
				'link'      => '/?s=elf+bar&post_type=product',
				'image_id'  => 0,
				'image_def' => 'banner-1-elfbar.jpg',
			),
			array(
				'active'    => 1,
				'style'     => 'escuro',
				'eyebrow'   => 'Ignite V500',
				'title'     => '',
				'highlight' => '50.000 puffs.',
				'text'      => '15 sabores, modos Boost e Eco e a assinatura Ignite que você já conhece.',
				'price_pre' => '',
				'price'     => 'R$ 154,85',
				'button'    => 'Comprar Ignite V500',
				'link'      => '/?s=ignite+v500&post_type=product',
				'image_id'  => 0,
				'image_def' => 'banner-2-ignite.jpg',
				'title_after' => 'Sem pressa de trocar.',
			),
			array(
				'active'    => 1,
				'style'     => 'dourado',
				'eyebrow'   => 'Entrega local',
				'title'     => 'Entrega em',
				'highlight' => 'Governador Valadares',
				'text'      => 'Entregamos somente em Governador Valadares (MG). Consulte o frete pelo CEP no carrinho.',
				'price_pre' => '',
				'price'     => '',
				'button'    => 'Pedir pelo WhatsApp',
				'link'      => '{whatsapp}',
				'image_id'  => 0,
				'image_def' => 'banner-3-delivery.jpg',
			),
		),
	);
}

/**
 * Lê uma configuração.
 *
 * @param string $key     Chave.
 * @param mixed  $default Valor se não existir.
 * @return mixed
 */
function vi_opt( $key, $default = null ) {
	if ( function_exists( 'vi_gestor_get' ) ) {
		$value = vi_gestor_get( $key );
		if ( null !== $value ) {
			return vi_local_delivery_setting( $key, $value );
		}
	}
	$defaults = vi_theme_defaults();
	return array_key_exists( $key, $defaults ) ? $defaults[ $key ] : $default;
}

/** Atualiza apenas cópias literais dos padrões antigos, sem alterar o conteúdo salvo. */
function vi_local_delivery_setting( $key, $value ) {
	if ( 'slides' === $key && is_array( $value ) ) {
		return array_map( 'vi_local_delivery_slide', $value );
	}
	$previous = array(
		'delivery_title' => 'Delivery GV em até 50 min',
		'delivery_text'  => 'Peça agora e receba hoje. Envio rápido e seguro para todo o Brasil.',
		'topbar'         => "PIX com 5% de desconto\nDelivery GV em até 50 min\nEntrega para todo o Brasil",
	);
	if ( isset( $previous[ $key ] ) && $previous[ $key ] === $value ) {
		return vi_theme_defaults()[ $key ];
	}
	return $value;
}

/** O Elementor também pode gravar as cópias dos slides padrão no próprio widget. */
function vi_local_delivery_slide( $slide ) {
	if ( ! is_array( $slide ) ) {
		return $slide;
	}
	if ( 'Delivery GV' === ( $slide['eyebrow'] ?? '' ) && 'Pediu, chegou.' === ( $slide['title'] ?? '' ) && 'Em até 50 min.' === ( $slide['highlight'] ?? '' ) ) {
		$slide['eyebrow']   = 'Entrega local';
		$slide['title']     = 'Entrega em';
		$slide['highlight'] = 'Governador Valadares';
	}
	if ( 'Entrega expressa em GV e envio rápido para todo o Brasil. No PIX, você ainda ganha 5% de desconto.' === ( $slide['text'] ?? '' ) ) {
		$slide['text'] = vi_theme_defaults()['delivery_text'];
	}
	return $slide;
}

/**
 * Seção da home está ligada?
 */
function vi_section_on( $name ) {
	$sections = array_merge( vi_theme_defaults()['sections'], (array) vi_opt( 'sections', array() ) );
	return ! isset( $sections[ $name ] ) || ! empty( $sections[ $name ] );
}

/** Chave do painel para um widget da página inicial, inclusive layouts antigos. */
function vi_home_section_key( $type, $settings ) {
	$widgets = array(
		'vi-categorias' => 'categories', 'vi-cartoes' => 'promos', 'vi-vendidos-destaques' => 'duo',
		'vi-vitrine-abas' => 'tabs', 'vi-destaque' => 'spotlight', 'vi-marcas' => 'brands',
		'vi-atacado' => 'wholesale', 'vi-avaliacoes' => 'reviews', 'vi-blog' => 'blog', 'vi-instagram-vip' => 'social',
	);
	if ( 'vi-vitrine' === $type ) {
		$sources = array( 'ofertas' => 'deals', 'novidades' => 'novidades', 'destaques' => 'featured', 'categoria' => 'extra' );
		return $sources[ $settings['source'] ?? 'ofertas' ] ?? '';
	}
	return $widgets[ $type ] ?? '';
}

/**
 * Link do WhatsApp com mensagem opcional.
 */
function vi_wa_link( $message = '' ) {
	$number = preg_replace( '/\D+/', '', (string) vi_opt( 'whatsapp' ) );
	if ( '' === $number ) {
		return '';
	}
	$url    = 'https://wa.me/' . $number;
	if ( $message ) {
		$url .= '?text=' . rawurlencode( $message );
	}
	return $url;
}

/**
 * Link do Instagram.
 */
function vi_instagram_url() {
	$handle = ltrim( (string) vi_opt( 'instagram' ), '@' );
	return $handle ? 'https://instagram.com/' . $handle : '';
}

/**
 * Resolve links digitados nas configurações (aceita caminhos relativos e {whatsapp}).
 */
function vi_resolve_link( $link ) {
	$link = trim( (string) $link );
	if ( '' === $link ) {
		return function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
	}
	if ( '{whatsapp}' === $link ) {
		return vi_wa_link( 'Olá! Quero fazer um pedido.' );
	}
	if ( 0 === strpos( $link, '/' ) ) {
		return home_url( $link );
	}
	return $link;
}

/**
 * Percentual de desconto no PIX (ex.: 5).
 */
function vi_pix_percent() {
	return max( 0, min( 90, (float) vi_opt( 'pix_percent', 0 ) ) );
}

/**
 * Os textos padrão acompanham o desconto e o delivery configurados no Gestor.
 * Uma mensagem escrita pela loja continua sendo exibida como foi cadastrada.
 */
function vi_store_notice( $text ) {
	if ( 'Delivery GV em até 50 min' === $text ) {
		return (string) vi_opt( 'delivery_title' );
	}
	if ( 'Entrega para todo o Brasil' === $text ) {
		return __( 'Entrega somente em Governador Valadares (MG)', 'villa-ibit' );
	}
	$is_pix = 'PIX com 5% de desconto' === $text;
	$delivery = vi_theme_defaults()['delivery_text'];
	$is_delivery_slide = $delivery === $text;
	if ( ! $is_pix && ! $is_delivery_slide ) {
		return $text;
	}
	$percent = vi_pix_percent();
	$label = number_format_i18n( $percent, $percent == (int) $percent ? 0 : 1 );
	if ( $is_pix ) {
		return $percent ? sprintf( __( 'PIX com %s%% de desconto', 'villa-ibit' ), $label ) : __( 'Consulte as formas de pagamento no checkout', 'villa-ibit' );
	}
	return $percent ? $delivery . ' ' . sprintf( __( 'No PIX, você ainda ganha %s%% de desconto.', 'villa-ibit' ), $label ) : $delivery;
}

/**
 * Menor preço exibível de um produto (variáveis: menor variação).
 *
 * @param WC_Product $product Produto.
 * @return float
 */
function vi_min_price( $product ) {
	if ( $product->is_type( 'variable' ) ) {
		return (float) $product->get_variation_price( 'min', true );
	}
	if ( $product->is_type( 'grouped' ) ) {
		$prices = array();
		foreach ( $product->get_children() as $child_id ) {
			$child = wc_get_product( $child_id );
			if ( $child && '' !== $child->get_price() ) {
				$prices[] = (float) wc_get_price_to_display( $child );
			}
		}
		return $prices ? min( $prices ) : 0;
	}
	return (float) wc_get_price_to_display( $product );
}

/**
 * Preço com desconto do PIX.
 */
function vi_pix_amount( $amount ) {
	return (float) $amount * ( 1 - vi_pix_percent() / 100 );
}

/**
 * Bloco de preço do tema.
 *
 * - card:   preço (com "de" riscado quando em oferta) e, embaixo, o valor no PIX com o símbolo do PIX.
 * - single: valor no PIX em destaque, valor no cartão ao lado e quanto se economiza no PIX.
 *
 * @param WC_Product $product Produto.
 * @param string     $size    card | single.
 */
function vi_price_block( $product, $size = 'card' ) {
	if ( '' === $product->get_price() && ! $product->is_type( array( 'variable', 'grouped' ) ) ) {
		return '';
	}
	$min = vi_min_price( $product );
	if ( $min <= 0 ) {
		return '<div class="vi-price vi-price--' . esc_attr( $size ) . '">' . wp_kses_post( $product->get_price_html() ) . '</div>';
	}

	$from    = $product->is_type( 'variable' ) && (float) $product->get_variation_price( 'max', true ) > $min;
	$regular = 0;
	if ( $product->is_on_sale() ) {
		$regular = $product->is_type( 'variable' ) ? (float) $product->get_variation_regular_price( 'min', true ) : (float) wc_get_price_to_display( $product, array( 'price' => $product->get_regular_price() ) );
	}
	$percent = vi_pix_percent();
	$pix     = $percent > 0 ? vi_pix_amount( $min ) : $min;

	ob_start();
	if ( 'single' === $size ) :
		?>
		<div class="vi-price vi-price--single">
			<div class="vi-price__row">
				<?php if ( $percent > 0 ) : ?>
				<div class="vi-price__pixbox">
					<span class="vi-price__label"><?php vi_the_icon( 'pix', 16 ); ?><?php echo $from ? esc_html__( 'No PIX, a partir de', 'villa-ibit' ) : esc_html__( 'No PIX', 'villa-ibit' ); ?></span>
					<strong class="vi-price__big"><?php echo wp_kses_post( wc_price( $pix ) ); ?></strong>
				</div>
				<?php endif; ?>
				<div class="vi-price__cardbox">
					<span class="vi-price__label"><?php echo $percent > 0 ? esc_html__( 'No cartão', 'villa-ibit' ) : ( $from ? esc_html__( 'A partir de', 'villa-ibit' ) : esc_html__( 'Preço', 'villa-ibit' ) ); ?></span>
					<span class="vi-price__cardline">
						<?php if ( $regular > $min ) : ?><del class="vi-price__old"><?php echo wp_kses_post( wc_price( $regular ) ); ?></del><?php endif; ?>
						<strong<?php echo $percent > 0 ? '' : ' class="vi-price__big"'; ?>><?php echo wp_kses_post( wc_price( $min ) ); ?></strong>
					</span>
				</div>
			</div>
			<?php if ( $percent > 0 && $min - $pix >= 0.01 ) : ?>
				<span class="vi-price__save"><?php echo wp_kses_post( sprintf( __( 'Economize %1$s no PIX (%2$s%% OFF)', 'villa-ibit' ), wc_price( $min - $pix ), wc_format_localized_decimal( $percent ) ) ); ?></span>
			<?php endif; ?>
		</div>
		<?php
	else :
		?>
		<div class="vi-price vi-price--<?php echo esc_attr( $size ); ?>">
			<?php if ( $from ) : ?><span class="vi-price__from"><?php esc_html_e( 'a partir de', 'villa-ibit' ); ?></span><?php endif; ?>
			<div class="vi-price__main">
				<strong><?php echo wp_kses_post( wc_price( $min ) ); ?></strong>
				<?php if ( $regular > $min ) : ?><del class="vi-price__old"><?php echo wp_kses_post( wc_price( $regular ) ); ?></del><?php endif; ?>
			</div>
			<?php if ( $percent > 0 ) : ?>
				<div class="vi-price__pix"><?php vi_the_icon( 'pix', 14 ); ?><span><?php echo wp_kses_post( sprintf( __( '%s no PIX', 'villa-ibit' ), '<strong>' . wc_price( $pix ) . '</strong>' ) ); ?></span></div>
			<?php endif; ?>
		</div>
		<?php
	endif;
	return ob_get_clean();
}

/**
 * Percentual de desconto da oferta (0 quando não está em oferta).
 */
function vi_sale_percent( $product ) {
	if ( ! $product->is_on_sale() ) {
		return 0;
	}
	if ( $product->is_type( 'variable' ) ) {
		$max    = 0;
		$prices = $product->get_variation_prices( true );
		foreach ( $prices['regular_price'] as $id => $regular ) {
			$sale = isset( $prices['price'][ $id ] ) ? (float) $prices['price'][ $id ] : (float) $regular;
			if ( $regular > 0 && $sale < $regular ) {
				$max = max( $max, round( ( 1 - $sale / $regular ) * 100 ) );
			}
		}
		return (int) $max;
	}
	$regular = (float) $product->get_regular_price();
	$sale    = (float) $product->get_price();
	return $regular > 0 ? (int) round( ( 1 - $sale / $regular ) * 100 ) : 0;
}

/**
 * Linha curta de detalhes do card: categoria · N sabores/opções.
 *
 * @param WC_Product $product Produto.
 * @return array{cat:string,extra:string}
 */
function vi_card_meta( $product ) {
	$cat   = '';
	$terms = get_the_terms( $product->get_id(), 'product_cat' );
	if ( $terms && ! is_wp_error( $terms ) ) {
		$default = (int) get_option( 'default_product_cat' );
		foreach ( $terms as $term ) {
			if ( (int) $term->term_id !== $default && 'atacado' !== $term->slug ) {
				$cat = $term->name;
				break;
			}
		}
	}
	$extra = '';
	if ( $product->is_type( 'variable' ) ) {
		$attributes = $product->get_variation_attributes();
		if ( $attributes ) {
			$name    = array_key_first( $attributes );
			$options = array_filter( (array) $attributes[ $name ] );
			$label   = wc_attribute_label( $name, $product );
			$n       = count( $options );
			if ( $n ) {
				$lower = function_exists( 'mb_strtolower' ) ? mb_strtolower( $label ) : strtolower( $label );
				$word  = ( false !== strpos( $lower, 'sabor' ) ) ? _n( 'sabor', 'sabores', $n, 'villa-ibit' ) : ( ( false !== strpos( $lower, 'cor' ) ) ? _n( 'cor', 'cores', $n, 'villa-ibit' ) : _n( 'opção', 'opções', $n, 'villa-ibit' ) );
				$extra = $n . ' ' . $word;
			}
		}
	}
	$brand = vi_product_brand( $product->get_id() );
	return array( 'cat' => $cat, 'extra' => $extra, 'brand' => $brand ? $brand->name : '' );
}

/**
 * Marca do produto (taxonomia nativa de Marcas do WooCommerce).
 */
function vi_product_brand( $product_id ) {
	if ( ! taxonomy_exists( 'product_brand' ) ) {
		return null;
	}
	$terms = get_the_terms( $product_id, 'product_brand' );
	return ( $terms && ! is_wp_error( $terms ) ) ? $terms[0] : null;
}

/**
 * Logo (personalizado ou o da marca que vem no tema).
 *
 * @param string $variant light (topo branco — usa o logo personalizado, se houver) | dark (rodapé verde).
 */
function vi_logo( $variant = 'dark', $class = 'vi-logo' ) {
	if ( in_array( $variant, array( 'light', 'verde' ), true ) && has_custom_logo() ) {
		$id = get_theme_mod( 'custom_logo' );
		return wp_get_attachment_image( $id, 'full', false, array( 'class' => $class, 'alt' => get_bloginfo( 'name' ) ) );
	}
	$files = array( 'dark' => 'logo-dark.png', 'verde' => 'logo-verde.png' ); // verde: logo toda no verde escuro (topo)
	$file  = $files[ $variant ] ?? 'logo-light.png';
	return '<img class="' . esc_attr( $class ) . '" src="' . esc_url( VI_THEME_URI . '/assets/img/' . $file ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" width="330" height="74">';
}
