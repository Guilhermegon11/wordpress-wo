<?php
/**
 * Catálogo (loja, categorias, marcas, páginas como "Acessórios") e partes da página do produto.
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;

/* ================================================================== *
 * Catálogo
 * ================================================================== */

/**
 * Está numa listagem nativa do WooCommerce?
 */
function vi_is_product_archive() {
	return function_exists( 'is_shop' ) && ( is_shop() || is_product_taxonomy() || ( is_search() && 'product' === get_query_var( 'post_type' ) ) );
}

/**
 * Catálogo com filtros, ordenação e paginação.
 *
 * - Na loja/categoria/marca: usa a listagem do próprio WooCommerce.
 * - Numa página comum (ex.: "Acessórios"): faz a própria consulta, opcionalmente presa a uma categoria.
 *
 * @param array $args title, text, category (slug), hero (yes/no), per_page, filters (yes/no).
 */
function vi_section_catalog( $args = array() ) {
	$args    = vi_args( $args, array( 'title' => '', 'text' => '', 'category' => '', 'hero' => 'yes', 'per_page' => 24, 'filters' => 'yes' ) );
	$fixed   = $args['category'] ? get_term_by( 'slug', $args['category'], 'product_cat' ) : null;
	$archive = vi_is_product_archive() && ! $fixed && ! vi_is_elementor_editor();
	$term    = $archive && is_product_taxonomy() ? get_queried_object() : $fixed;
	$current = $term instanceof WP_Term ? (int) $term->term_id : 0;
	$get     = wp_unslash( $_GET ); // phpcs:ignore WordPress.Security.NonceVerification
	$orderby = isset( $get['orderby'] ) ? sanitize_key( $get['orderby'] ) : '';
	$min     = isset( $get['min_price'] ) ? wc_clean( $get['min_price'] ) : '';
	$max     = isset( $get['max_price'] ) ? wc_clean( $get['max_price'] ) : '';
	$offers  = ! empty( $get['ofertas'] );

	// Título e descrição.
	if ( $archive ) {
		$title = woocommerce_page_title( false );
		$desc  = $term instanceof WP_Term ? term_description( $term ) : ( $args['text'] ? wpautop( esc_html( $args['text'] ) ) : '' );
		if ( is_shop() && $args['title'] && ! $offers && ! vi_shop_list() && ! is_search() ) {
			$title = $args['title'];
		}
		if ( is_search() ) {
			$desc = '<p>' . esc_html( sprintf( __( 'Resultados para “%s”', 'villa-ibit' ), get_search_query() ) ) . '</p>';
		}
	} else {
		$title = $args['title'] ? $args['title'] : ( $fixed ? $fixed->name : __( 'Todos os produtos', 'villa-ibit' ) );
		$desc  = $args['text'] ? wpautop( esc_html( $args['text'] ) ) : ( $fixed ? term_description( $fixed ) : '' );
	}

	if ( 'yes' === $args['hero'] ) :
		?>
		<section class="vi-archive-hero">
			<div class="vi-container">
				<?php if ( $archive ) { woocommerce_breadcrumb(); } else { ?>
					<nav class="vi-crumbs" aria-label="<?php esc_attr_e( 'Você está em', 'villa-ibit' ); ?>"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Início', 'villa-ibit' ); ?></a><span class="vi-crumbs__sep" aria-hidden="true">/</span><span><?php echo esc_html( $title ); ?></span></nav>
				<?php } ?>
				<div class="vi-archive-hero__row">
					<div class="vi-archive-hero__text">
						<h1 class="vi-archive-hero__title"><?php echo esc_html( $title ); ?></h1>
						<?php if ( $desc ) : ?><div class="vi-archive-hero__desc"><?php echo wp_kses_post( $desc ); ?></div><?php endif; ?>
					</div>
					<?php vi_archive_circles( $current ); ?>
				</div>
			</div>
		</section>
		<?php
	endif;

	// Produtos.
	$query = null;
	if ( ! $archive ) {
		$paged = max( 1, isset( $get['pagina'] ) ? absint( $get['pagina'] ) : 1 );
		$qa    = array(
			'post_type'      => 'product',
			'post_status'    => 'publish',
			'posts_per_page' => max( 1, (int) $args['per_page'] ),
			'paged'          => $paged,
			'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery
				array( 'taxonomy' => 'product_visibility', 'field' => 'name', 'terms' => array( 'exclude-from-catalog' ), 'operator' => 'NOT IN' ),
			),
			'meta_query'     => array(), // phpcs:ignore WordPress.DB.SlowDBQuery
		);
		if ( $fixed ) {
			$qa['tax_query'][] = array( 'taxonomy' => 'product_cat', 'field' => 'term_id', 'terms' => $fixed->term_id );
		}
		if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
			$qa['tax_query'][] = array( 'taxonomy' => 'product_visibility', 'field' => 'name', 'terms' => array( 'outofstock' ), 'operator' => 'NOT IN' );
		}
		if ( '' !== $min || '' !== $max ) {
			$qa['meta_query'][] = array( 'key' => '_price', 'value' => array( (float) ( '' === $min ? 0 : $min ), (float) ( '' === $max ? 999999 : $max ) ), 'compare' => 'BETWEEN', 'type' => 'DECIMAL(10,2)' );
		}
		$puffs_q = vi_puffs_meta_query( vi_puffs_selected() );
		if ( $puffs_q ) {
			$qa['meta_query'][] = $puffs_q;
		}
		if ( $offers ) {
			$ids            = wc_get_product_ids_on_sale();
			$qa['post__in'] = $ids ? array_map( 'absint', $ids ) : array( 0 );
		}
		switch ( $orderby ) {
			case 'date':
				$qa['orderby'] = 'date';
				$qa['order']   = 'DESC';
				break;
			case 'price':
			case 'price-desc':
				$qa['meta_key'] = '_price'; // phpcs:ignore WordPress.DB.SlowDBQuery
				$qa['orderby']  = 'meta_value_num';
				$qa['order']    = 'price' === $orderby ? 'ASC' : 'DESC';
				break;
			case 'popularity':
				$qa['meta_key'] = 'total_sales'; // phpcs:ignore WordPress.DB.SlowDBQuery
				$qa['orderby']  = 'meta_value_num';
				$qa['order']    = 'DESC';
				break;
			default:
				$qa['orderby'] = array( 'menu_order' => 'ASC', 'title' => 'ASC' );
		}
		$query = new WP_Query( $qa );
	}

	$base_url = $archive ? ( $term instanceof WP_Term ? get_term_link( $term ) : wc_get_page_permalink( 'shop' ) ) : get_permalink();
	?>
	<div class="vi-container vi-archive">
		<?php if ( 'yes' === $args['filters'] ) { vi_catalog_filters( $current, $base_url, $orderby, $min, $max, $offers, $fixed ); } ?>
		<section class="vi-archive__list" aria-label="<?php esc_attr_e( 'Produtos', 'villa-ibit' ); ?>">
			<?php
			$total = $archive ? (int) wc_get_loop_prop( 'total' ) : (int) $query->found_posts;
			$has   = $archive ? woocommerce_product_loop() : $query->have_posts();
			if ( $has ) :
				?>
				<div class="vi-toolbar">
					<?php if ( $archive ) { woocommerce_output_all_notices(); } ?>
					<?php if ( 'yes' === $args['filters'] ) : ?><button type="button" class="vi-btn vi-btn--outline vi-btn--sm vi-filters-open" aria-controls="vi-filters" aria-expanded="false"><?php vi_the_icon( 'filter', 16 ); ?><?php esc_html_e( 'Filtros', 'villa-ibit' ); ?></button><?php endif; ?>
					<p class="woocommerce-result-count"><?php echo esc_html( sprintf( _n( '%d produto', '%d produtos', $total, 'villa-ibit' ), $total ) ); ?></p>
					<nav class="vi-sort" aria-label="<?php esc_attr_e( 'Ordenar por', 'villa-ibit' ); ?>">
						<?php
						$clean = function ( $url ) { return preg_replace( '#/page/\d+/?#', '/', remove_query_arg( array( 'paged', 'pagina' ), $url ) ); };
						$sorts = array(
							array( __( 'Relevância', 'villa-ibit' ), $clean( remove_query_arg( array( 'orderby', 'ofertas' ) ) ), '' === $orderby && ! $offers ),
							array( __( 'Ofertas', 'villa-ibit' ), $offers ? $clean( remove_query_arg( 'ofertas' ) ) : $clean( add_query_arg( 'ofertas', '1', $archive ? vi_offers_url() : remove_query_arg( 'orderby' ) ) ), $offers ),
							array( __( 'Menor preço', 'villa-ibit' ), $clean( add_query_arg( 'orderby', 'price' ) ), 'price' === $orderby ),
							array( __( 'Maior preço', 'villa-ibit' ), $clean( add_query_arg( 'orderby', 'price-desc' ) ), 'price-desc' === $orderby ),
						);
						foreach ( $sorts as $so ) :
							?>
							<a href="<?php echo esc_url( $so[1] ); ?>" class="<?php echo $so[2] ? 'is-on' : ''; ?>"<?php echo $so[2] ? ' aria-current="true"' : ''; ?>><?php echo esc_html( $so[0] ); ?></a>
						<?php endforeach; ?>
					</nav>
				</div>
				<div class="woocommerce">
				<?php
				if ( $archive ) {
					woocommerce_product_loop_start();
					while ( have_posts() ) {
						the_post();
						do_action( 'woocommerce_shop_loop' );
						wc_get_template_part( 'content', 'product' );
					}
					woocommerce_product_loop_end();
					do_action( 'woocommerce_after_shop_loop' );
				} else {
					vi_render_products( array_filter( array_map( 'wc_get_product', wp_list_pluck( $query->posts, 'ID' ) ) ), 'columns-3' );
					if ( $query->max_num_pages > 1 ) {
						echo '<nav class="woocommerce-pagination"><ul class="page-numbers">';
						$links = paginate_links( array( 'base' => add_query_arg( 'pagina', '%#%' ), 'format' => '', 'current' => max( 1, (int) $query->get( 'paged' ) ), 'total' => $query->max_num_pages, 'type' => 'array', 'prev_text' => '‹', 'next_text' => '›' ) );
						foreach ( (array) $links as $l ) {
							echo '<li>' . wp_kses_post( $l ) . '</li>';
						}
						echo '</ul></nav>';
					}
				}
				?>
				</div>
			<?php else : ?>
				<div class="vi-empty-box">
					<p><?php esc_html_e( 'Nenhum produto encontrado com esses filtros.', 'villa-ibit' ); ?></p>
					<a class="vi-btn vi-btn--green vi-btn--sm" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"><?php esc_html_e( 'Ver todos os produtos', 'villa-ibit' ); ?></a>
				</div>
			<?php endif; ?>
		</section>
	</div>
	<?php
	if ( $query ) {
		wp_reset_postdata();
	}
}

/**
 * Atalhos em círculo no topo do catálogo: marcas com mais produtos e Ofertas.
 */
function vi_archive_circles( $current = 0 ) {
	$items = array();
	foreach ( array_slice( vi_get_brands(), 0, 4 ) as $b ) {
		$img = $b['logo'];
		if ( ! $img ) {
			$first = vi_products( 'marca', 1, $b['id'] );
			$first = $first ? current( $first ) : null;
			$img   = ( $first && $first->get_image_id() ) ? wp_get_attachment_image_url( $first->get_image_id(), 'woocommerce_thumbnail' ) : '';
		}
		$items[] = array( 'name' => $b['name'], 'link' => $b['link'], 'img' => $img, 'on' => (int) $b['id'] === (int) $current );
	}
	if ( ! $items ) {
		return;
	}
	echo '<nav class="vi-archive-hero__circles" aria-label="' . esc_attr__( 'Marcas', 'villa-ibit' ) . '">';
	foreach ( $items as $it ) {
		echo '<a class="vi-mini-circle' . ( $it['on'] ? ' is-on' : '' ) . '" href="' . esc_url( $it['link'] ) . '"><span>' . ( $it['img'] ? '<img src="' . esc_url( $it['img'] ) . '" alt="" loading="lazy">' : esc_html( function_exists( 'mb_substr' ) ? mb_substr( $it['name'], 0, 1 ) : substr( $it['name'], 0, 1 ) ) ) . '</span>' . esc_html( $it['name'] ) . '</a>';
	}
	if ( wc_get_product_ids_on_sale() ) {
		echo '<a class="vi-mini-circle vi-mini-circle--deal" href="' . esc_url( vi_offers_url() ) . '"><span aria-hidden="true">%</span>' . esc_html__( 'Ofertas', 'villa-ibit' ) . '</a>';
	}
	echo '</nav>';
}

/**
 * Coluna de filtros: marca, preço, puffs e atacado (vira gaveta no celular).
 */
function vi_catalog_filters( $current, $base_url, $orderby, $min, $max, $offers, $fixed = null ) {
	$shop   = wc_get_page_permalink( 'shop' );
	$action = is_wp_error( $base_url ) ? $shop : $base_url;
	$brands = vi_get_brands();
	$picked = vi_puffs_selected();
	$keep   = function ( $skip ) use ( $orderby, $offers, $min, $max, $picked ) {
		if ( $orderby && 'orderby' !== $skip ) {
			echo '<input type="hidden" name="orderby" value="' . esc_attr( $orderby ) . '">';
		}
		if ( $offers ) {
			echo '<input type="hidden" name="ofertas" value="1">';
		}
		if ( is_search() ) {
			echo '<input type="hidden" name="s" value="' . esc_attr( get_search_query() ) . '"><input type="hidden" name="post_type" value="product">';
		}
		if ( 'price' !== $skip ) {
			if ( '' !== $min ) {
				echo '<input type="hidden" name="min_price" value="' . esc_attr( $min ) . '">';
			}
			if ( '' !== $max ) {
				echo '<input type="hidden" name="max_price" value="' . esc_attr( $max ) . '">';
			}
		}
		if ( 'puffs' !== $skip ) {
			foreach ( $picked as $k ) {
				echo '<input type="hidden" name="puffs[]" value="' . esc_attr( $k ) . '">';
			}
		}
	};
	$all_count = (int) wp_count_posts( 'product' )->publish;
	?>
	<aside class="vi-filters" id="vi-filters" aria-label="<?php esc_attr_e( 'Filtros', 'villa-ibit' ); ?>">
		<div class="vi-filters__head">
			<h2 class="vi-h3"><?php esc_html_e( 'Filtrar', 'villa-ibit' ); ?></h2>
			<button type="button" class="vi-icon-btn vi-filters__close" aria-label="<?php esc_attr_e( 'Fechar filtros', 'villa-ibit' ); ?>"><?php vi_the_icon( 'close', 22 ); ?></button>
		</div>

		<?php
		if ( $fixed ) :
			$subs = get_terms( array( 'taxonomy' => 'product_cat', 'parent' => $fixed->term_id, 'hide_empty' => true ) );
			if ( $subs && ! is_wp_error( $subs ) ) :
				?>
			<div class="vi-filter">
				<h3 class="vi-filter__title"><?php echo esc_html( $fixed->name ); ?></h3>
				<?php foreach ( $subs as $sub ) : ?><a class="vi-filter__opt" href="<?php echo esc_url( get_term_link( $sub ) ); ?>"><span><?php echo esc_html( $sub->name ); ?></span><span class="vi-filter__n"><?php echo (int) $sub->count; ?></span></a><?php endforeach; ?>
			</div>
				<?php
			endif;
		endif;
		?>

		<?php if ( $brands ) :
			$brand_on = false;
			foreach ( $brands as $b ) {
				$brand_on = $brand_on || $current === (int) $b['id'];
			}
			?>
		<div class="vi-filter">
			<h3 class="vi-filter__title"><?php esc_html_e( 'Marca', 'villa-ibit' ); ?></h3>
			<a class="vi-filter__opt<?php echo $brand_on ? '' : ' is-on'; ?>" href="<?php echo esc_url( $fixed ? get_term_link( $fixed ) : $shop ); ?>"><span><?php esc_html_e( 'Todas', 'villa-ibit' ); ?></span><?php if ( ! $fixed ) : ?><span class="vi-filter__n"><?php echo (int) $all_count; ?></span><?php endif; ?></a>
			<?php foreach ( $brands as $b ) : ?>
				<a class="vi-filter__opt<?php echo $current === (int) $b['id'] ? ' is-on' : ''; ?>" href="<?php echo esc_url( $b['link'] ); ?>"<?php echo $current === (int) $b['id'] ? ' aria-current="page"' : ''; ?>><span><?php echo esc_html( $b['name'] ); ?></span><span class="vi-filter__n"><?php echo (int) $b['count']; ?></span></a>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>

		<form class="vi-filter" method="get" action="<?php echo esc_url( $action ); ?>">
			<h3 class="vi-filter__title"><?php esc_html_e( 'Preço', 'villa-ibit' ); ?></h3>
			<div class="vi-filter__price">
				<label><?php esc_html_e( 'Mínimo', 'villa-ibit' ); ?><input type="number" inputmode="numeric" min="0" name="min_price" value="<?php echo esc_attr( $min ); ?>" placeholder="R$ 0"></label>
				<label><?php esc_html_e( 'Máximo', 'villa-ibit' ); ?><input type="number" inputmode="numeric" min="0" name="max_price" value="<?php echo esc_attr( $max ); ?>" placeholder="R$ 500"></label>
			</div>
			<?php $keep( 'price' ); ?>
			<button type="submit" class="vi-btn vi-btn--green vi-btn--block vi-btn--sm"><?php esc_html_e( 'Aplicar', 'villa-ibit' ); ?></button>
		</form>

		<?php if ( vi_puffs_available() ) : ?>
		<form class="vi-filter vi-filter--puffs" method="get" action="<?php echo esc_url( $action ); ?>" data-vi-puffs>
			<h3 class="vi-filter__title"><?php esc_html_e( 'Puffs', 'villa-ibit' ); ?></h3>
			<?php foreach ( vi_puffs_ranges() as $key => $r ) : ?>
				<label class="vi-filter__check"><input type="checkbox" name="puffs[]" value="<?php echo esc_attr( $key ); ?>"<?php checked( in_array( $key, $picked, true ) ); ?>><span><?php echo esc_html( $r[2] ); ?></span></label>
			<?php endforeach; ?>
			<?php $keep( 'puffs' ); ?>
			<div class="vi-filter__row">
				<button type="submit" class="vi-btn vi-btn--green vi-btn--sm vi-filter__apply"><?php esc_html_e( 'Aplicar', 'villa-ibit' ); ?></button>
				<?php if ( $picked ) : ?><a class="vi-filter__clear" href="<?php echo esc_url( remove_query_arg( 'puffs' ) ); ?>"><?php esc_html_e( 'Limpar', 'villa-ibit' ); ?></a><?php endif; ?>
			</div>
		</form>
		<?php endif; ?>

		<?php $ws = get_term_by( 'slug', 'atacado', 'product_cat' ); ?>
		<div class="vi-filter vi-filter--gold">
			<strong><?php esc_html_e( 'Compra para revenda?', 'villa-ibit' ); ?></strong>
			<p><?php echo esc_html( vi_opt( 'wholesale_text' ) ); ?></p>
			<?php if ( ( $ws && $ws->count ) || vi_wa_link() ) : ?>
			<a href="<?php echo esc_url( ( $ws && $ws->count ) ? get_term_link( $ws ) : vi_wa_link( __( 'Olá! Tenho interesse em comprar no atacado.', 'villa-ibit' ) ) ); ?>"><?php esc_html_e( 'Falar com o atacado', 'villa-ibit' ); ?> <?php vi_the_icon( 'arrow', 14 ); ?></a>
			<?php endif; ?>
		</div>
	</aside>
	<?php
}

/* ================================================================== *
 * Página do produto
 * ================================================================== */

/**
 * Produto do contexto: o da página atual ou, no editor do Elementor, um produto de exemplo.
 *
 * @return WC_Product|null
 */
function vi_context_product() {
	global $product, $post;
	if ( $product instanceof WC_Product ) {
		return $product;
	}
	if ( is_singular( 'product' ) ) {
		$product = wc_get_product( get_the_ID() ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
		return $product;
	}
	if ( vi_is_elementor_editor() ) {
		$ids = wc_get_products( array( 'status' => 'publish', 'limit' => 1, 'type' => 'variable', 'return' => 'ids' ) );
		$ids = $ids ? $ids : wc_get_products( array( 'status' => 'publish', 'limit' => 1, 'return' => 'ids' ) );
		if ( $ids ) {
			$post    = get_post( $ids[0] ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
			$product = wc_get_product( $ids[0] ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
			setup_postdata( $post );
			return $product;
		}
	}
	return null;
}

/**
 * Galeria + compra.
 */
function vi_section_product_top( $args = array() ) {
	$args    = vi_args( $args, array( 'crumbs' => 'yes', 'delivery' => 'yes', 'trust' => 'yes', 'details' => 'yes' ) );
	$product = vi_context_product();
	if ( ! $product ) {
		vi_editor_notice( __( 'Cadastre um produto para ver a pré-visualização desta seção.', 'villa-ibit' ), true );
		return;
	}
	$brand = vi_product_brand( $product->get_id() );
	$meta  = vi_card_meta( $product );

	$highlights = array();
	foreach ( $product->get_attributes() as $attr ) {
		if ( ! $attr->get_visible() || $attr->get_variation() ) {
			continue;
		}
		$vals = $attr->is_taxonomy() ? wc_get_product_terms( $product->get_id(), $attr->get_name(), array( 'fields' => 'names' ) ) : $attr->get_options();
		if ( $vals ) {
			$highlights[] = wc_attribute_label( $attr->get_name() ) . ': ' . implode( ', ', array_slice( $vals, 0, 2 ) );
		}
		if ( count( $highlights ) >= 3 ) {
			break;
		}
	}
	if ( $meta['extra'] ) {
		$highlights[] = $meta['extra'];
	}
	?>
	<?php if ( 'yes' === $args['crumbs'] ) : ?><div class="vi-container"><?php woocommerce_breadcrumb(); ?></div><?php endif; ?>
	<div class="vi-container vi-product product <?php echo esc_attr( implode( ' ', wc_get_product_class( '', $product ) ) ); ?>">
		<div class="vi-product__top">
			<div class="vi-product__gallery">
				<?php do_action( 'woocommerce_before_single_product_summary' ); ?>
			</div>
			<div class="summary entry-summary vi-product__summary">
				<p class="vi-product__eyebrow"><?php echo esc_html( implode( ' · ', array_filter( array( $brand ? $brand->name : '', $meta['cat'] ) ) ) ); ?></p>
				<h1 class="product_title entry-title vi-product__title"><?php echo esc_html( $product->get_name() ); ?></h1>
				<?php if ( wc_review_ratings_enabled() && $product->get_review_count() ) : ?>
					<a class="vi-product__rating" href="#reviews"><?php echo vi_stars( $product->get_average_rating() ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( sprintf( _n( '%d avaliação', '%d avaliações', $product->get_review_count(), 'villa-ibit' ), $product->get_review_count() ) ); ?></span></a>
				<?php endif; ?>
				<?php if ( $highlights ) : ?>
					<ul class="vi-product__chips"><?php foreach ( $highlights as $h ) : ?><li><?php echo esc_html( $h ); ?></li><?php endforeach; ?></ul>
				<?php endif; ?>
				<div class="vi-product__pricebox"><?php echo vi_price_block( $product, 'single' ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
				<?php if ( $product->get_short_description() ) : ?>
					<div class="vi-product__short"><?php echo wp_kses_post( apply_filters( 'woocommerce_short_description', $product->get_short_description() ) ); ?></div>
				<?php endif; ?>
				<div class="vi-product__buy"><?php woocommerce_template_single_add_to_cart(); ?></div>
				<?php if ( 'yes' === $args['trust'] ) : ?>
				<ul class="vi-product__trust">
					<li><?php vi_the_icon( 'shield', 18 ); ?><?php esc_html_e( '100% original', 'villa-ibit' ); ?></li>
					<li><?php vi_the_icon( 'clock', 18 ); ?><?php echo esc_html( vi_opt( 'delivery_title' ) ); ?></li>
					<li><?php vi_the_icon( 'lock', 18 ); ?><?php esc_html_e( 'Compra segura', 'villa-ibit' ); ?></li>
					<li><span class="vi-badge-18 vi-badge-18--sm">18+</span><?php esc_html_e( 'Só para maiores', 'villa-ibit' ); ?></li>
				</ul>
				<?php endif; ?>
				<?php
				if ( 'yes' === $args['details'] ) {
					vi_product_details( $product, 'yes' === $args['delivery'] );
				} elseif ( 'yes' === $args['delivery'] ) {
					?>
					<div class="vi-product__delivery">
						<span class="vi-product__delivery-icon"><?php vi_the_icon( 'clock', 22 ); ?></span>
						<div><strong><?php echo esc_html( vi_opt( 'delivery_title' ) ); ?></strong><p><?php echo esc_html( vi_opt( 'delivery_text' ) ); ?></p></div>
					</div>
					<?php
				}
				?>
				<?php do_action( 'woocommerce_single_product_summary' ); ?>
			</div>
		</div>
	</div>
	<?php
}

/**
 * Descrição, especificações e entrega em blocos que abrem e fecham, dentro do quadro de compra.
 * Quando aparecem aqui, as abas de baixo mostram só as avaliações.
 *
 * @param WC_Product $product  Produto.
 * @param bool       $delivery Mostrar "Entrega e trocas".
 */
function vi_product_details( $product, $delivery = true ) {
	$GLOBALS['vi_details_shown'] = true;
	$desc = $product->get_description();
	ob_start();
	if ( function_exists( 'wc_display_product_attributes' ) ) {
		wc_display_product_attributes( $product );
	}
	$specs = trim( (string) ob_get_clean() );
	if ( ! $desc && ! $specs && ! $delivery ) {
		return;
	}
	echo '<div class="vi-details">';
	if ( $desc ) {
		echo '<details class="vi-details__item" open><summary>' . esc_html__( 'Descrição', 'villa-ibit' ) . vi_icon( 'chevron', 18 ) . '</summary><div class="vi-details__body">' . wp_kses_post( wc_format_content( $desc ) ) . '</div></details>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	if ( $specs ) {
		echo '<details class="vi-details__item"' . ( $desc ? '' : ' open' ) . '><summary>' . esc_html__( 'Especificações', 'villa-ibit' ) . vi_icon( 'chevron', 18 ) . '</summary><div class="vi-details__body">' . $specs . '</div></details>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	if ( $delivery ) {
		echo '<details class="vi-details__item"><summary>' . esc_html__( 'Entrega e trocas', 'villa-ibit' ) . vi_icon( 'chevron', 18 ) . '</summary><div class="vi-details__body"><p><strong>' . esc_html( vi_opt( 'delivery_title' ) ) . '</strong></p><p>' . esc_html( vi_opt( 'delivery_text' ) ) . '</p></div></details>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
	echo '</div>';
}

add_filter(
	'woocommerce_product_tabs',
	function ( $tabs ) {
		if ( ! empty( $GLOBALS['vi_details_shown'] ) ) {
			unset( $tabs['description'], $tabs['additional_information'] );
		}
		return $tabs;
	},
	30
);

/**
 * Abas: descrição, especificações e avaliações.
 */
function vi_section_product_tabs() {
	if ( ! vi_context_product() ) {
		return;
	}
	echo '<div class="vi-container vi-product product">';
	woocommerce_output_product_data_tabs();
	echo '</div>';
}

/**
 * Produtos relacionados e "você também pode gostar".
 */
function vi_section_product_related() {
	if ( ! vi_context_product() ) {
		return;
	}
	echo '<div class="vi-container vi-product vi-product--related">';
	woocommerce_upsell_display();
	woocommerce_output_related_products();
	echo '</div>';
}

/* ================================================================== *
 * Modelos montados no Elementor
 * ================================================================== */

/**
 * ID da página modelo (produto) ou da página "Todos os produtos" (catálogo), se estiver montada no Elementor.
 *
 * @param string $type product | catalog.
 */
function vi_template_page( $type ) {
	if ( ! did_action( 'elementor/loaded' ) ) {
		return 0;
	}
	if ( 'catalog' === $type ) {
		$id = function_exists( 'wc_get_page_id' ) ? (int) get_option( 'woocommerce_shop_page_id' ) : 0;
	} else {
		$id   = (int) vi_opt( 'tpl_product', 0 );
		$page = $id ? get_post( $id ) : get_page_by_path( 'modelo-produto', OBJECT, 'page' );
		$id   = $page ? (int) $page->ID : 0;
	}
	if ( ! $id || 'builder' !== get_post_meta( $id, '_elementor_edit_mode', true ) ) {
		return 0;
	}
	return $id;
}

/**
 * Imprime o conteúdo de uma página do Elementor.
 */
function vi_render_elementor_page( $id ) {
	echo \Elementor\Plugin::$instance->frontend->get_builder_content_for_display( $id, true ); // phpcs:ignore WordPress.Security.EscapeOutput
}

/**
 * Ao editar "Todos os produtos" (página da loja) no Elementor, mostra a página normal
 * em vez da listagem do WooCommerce — assim o editor consegue carregar.
 */
add_filter(
	'woocommerce_get_shop_page_id',
	function ( $id ) {
		$preview = isset( $_GET['elementor-preview'] ) ? absint( $_GET['elementor-preview'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		return ( $preview && $preview === (int) $id ) ? -1 : $id;
	}
);

/**
 * Páginas modelo não aparecem em buscadores.
 */
add_filter(
	'wp_robots',
	function ( $robots ) {
		if ( is_page() && 0 === strpos( (string) get_post_field( 'post_name', get_queried_object_id() ), 'modelo-' ) ) {
			$robots['noindex'] = true;
		}
		return $robots;
	}
);
