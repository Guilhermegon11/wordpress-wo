<?php
/**
 * Widgets "Villa Ibit" para o Elementor.
 * Cada widget usa as mesmas seções do tema, então tudo continua dinâmico (produtos, categorias, marcas…)
 * e ainda pode ser arrastado, removido, duplicado e editado no Elementor.
 *
 * @package VillaIbit
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'elementor/elements/categories_registered',
	function ( $manager ) {
		$manager->add_category( 'villa-ibit', array( 'title' => 'Villa Ibit', 'icon' => 'eicon-woocommerce' ) );
	}
);

add_action(
	'elementor/widgets/register',
	function ( $widgets ) {
		require_once VI_THEME_DIR . '/inc/elementor-widgets.php';
		foreach ( vi_elementor_widget_classes() as $class ) {
			$widgets->register( new $class() );
		}
	}
);

// As escolhas de visibilidade da home não interferem nas páginas de categoria ou produto.
add_filter(
	'elementor/frontend/widget/should_render',
	function ( $show, $widget ) {
		if ( ! $show || ! is_front_page() || ! function_exists( 'vi_gestor_get' ) || vi_is_elementor_editor() ) {
			return $show;
		}
		$sections = (array) vi_gestor_get( 'sections' );
		$key      = vi_home_section_key( $widget->get_name(), (array) $widget->get_data( 'settings' ) );
		return isset( $sections[ $key ] ) ? ! empty( $sections[ $key ] ) : $show;
	},
	10,
	2
);

/**
 * Inicializa banner, abas e sabores também dentro do editor.
 */
add_action(
	'elementor/frontend/after_enqueue_scripts',
	function () {
		wp_add_inline_script( 'vi-main', '(function(){function h(){if(window.elementorFrontend&&elementorFrontend.hooks&&window.VIinit){elementorFrontend.hooks.addAction("frontend/element_ready/global",function($s){window.VIinit($s[0]);});}}if(window.jQuery){jQuery(window).on("elementor/frontend/init",h);}})();', 'after' );
	}
);

/**
 * Lista de opções de categorias/marcas para os controles.
 */
function vi_el_term_options( $taxonomy ) {
	if ( ! taxonomy_exists( $taxonomy ) ) {
		return array();
	}
	$terms = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false ) );
	$out   = array();
	if ( ! is_wp_error( $terms ) ) {
		foreach ( $terms as $t ) {
			$out[ $t->term_id ] = $t->name;
		}
	}
	return $out;
}

function vi_el_cat_slug_options() {
	$out   = array( '' => __( '— Todas (catálogo completo) —', 'villa-ibit' ) );
	$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
	if ( ! is_wp_error( $terms ) ) {
		foreach ( $terms as $t ) {
			$out[ $t->slug ] = $t->name;
		}
	}
	return $out;
}

/**
 * Lista de produtos publicados para o widget "Destaque da semana".
 */
function vi_el_product_options() {
	$out = array( '' => __( '— Automático —', 'villa-ibit' ) );
	if ( ! function_exists( 'wc_get_products' ) ) {
		return $out;
	}
	foreach ( wc_get_products( array( 'status' => 'publish', 'limit' => 200, 'orderby' => 'title', 'order' => 'ASC' ) ) as $p ) {
		$out[ $p->get_id() ] = $p->get_name();
	}
	return $out;
}
