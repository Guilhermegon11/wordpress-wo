=== Villa Ibit | Combos e Atacado ===
Stable tag: 1.1.0
Requires at least: 6.4
Requires PHP: 7.4
Requires Plugins: woocommerce
License: GPL-2.0-or-later

== Instalação ==

Com o WooCommerce ativo, envie o ZIP em Plugins > Adicionar plugin > Enviar plugin e ative Villa Ibit | Combos e Atacado. O plugin funciona com o tema atual da loja.

== Criar um combo ==

1. No painel Villa Ibit, abra Catálogo > Combos promocionais. Para alterar um combo existente, clique em Editar ao lado do nome dele. Se o Gestor estiver desativado, abra WooCommerce > Combos promocionais.
2. Dê um nome ao kit. Busque dois ou mais itens do catálogo por nome ou SKU e defina a quantidade de cada um. Em produtos com sabor ou tamanho, escolha a variação exata.
3. Escolha desconto percentual ou valor fixo. O painel calcula o preço com os valores atuais dos itens. Você também pode escolher uma foto para o combo.
4. Selecione Publicado na loja e clique em Criar produto do combo. Para preparar o kit antes de vender, escolha Rascunho.

O produto aparece na categoria Combo. Na página do produto, o cliente vê “O que vem no combo” antes dos botões de compra. Quando o WooCommerce baixa o estoque, ele movimenta cada componente na quantidade prevista. Por exemplo, duas vendas de um kit com duas unidades de A e uma de B dão baixa em quatro unidades de A e duas de B.

O editor aceita produtos simples e variações com atributos definidos. Para calcular o imposto do kit, os componentes precisam ter a mesma condição e classe de imposto. No reembolso parcial, informe as quantidades devolvidas nas linhas dos componentes e marque a reposição de estoque quando quiser devolver essas unidades ao catálogo.

== Configurar o atacado ==

1. Entre em Villa Ibit > Atacado ou WooCommerce > Atacado.
2. Em Banner da página, escolha a imagem, ajuste o título e o texto e clique em Salvar banner.
3. Em Produtos do atacado, busque o produto e clique em Adicionar ao atacado. Você pode informar um preço por unidade exclusivo da página. Em branco, vale o preço cadastrado do produto ou do sabor escolhido.
4. Clique em Abrir página de atacado. A vitrine fica em /atacado no próprio site. Por exemplo, uma loja em https://exemplo.com.br usa https://exemplo.com.br/atacado.

A vitrine usa os produtos da categoria Atacado. O mínimo é de 10 unidades adicionadas pelo atacado, somando produtos e sabores. Um pedido com seis unidades de A e quatro de B já atinge o mínimo. Unidades colocadas no carrinho pela vitrine de varejo seguem o preço normal e ficam fora dessa contagem.

Em /atacado, escolha o sabor no card, ajuste a quantidade com os botões ou digite o número e clique em Adicionar. A confirmação aparece no próprio card. Você pode escolher o próximo sabor em seguida. O resumo da página mostra quantas unidades faltam para atingir o mínimo.

Para inserir a vitrine em um layout do Elementor, use o widget Shortcode com [villa_ibit_atacado].

== Atualização da versão 1.0.0 ==

Envie o novo ZIP na tela de plugins do WordPress e escolha substituir a versão instalada. Os combos já cadastrados passam a usar a categoria Combo na vitrine.

Se /atacado já tiver uma página editorial publicada, o catálogo aparece junto com o conteúdo dela. Se a página estiver em rascunho ou se esse endereço estiver reservado ao carrinho, ao checkout ou a outra página essencial, confira a orientação em Villa Ibit > Atacado.
