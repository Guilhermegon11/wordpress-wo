<?php
/**
 * Plugin Name:       Villa Ibit | Combos e Atacado
 * Description:       Monte combos com produtos da loja e ofereça uma página de compras no atacado.
 * Version:           1.1.0
 * Author:            Villa Ibit
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * WC requires at least: 9.6
 * Text Domain:       villa-ibit-combos
 * License:           GPL-2.0-or-later
 */

defined( 'ABSPATH' ) || exit;
define( 'VIC_FILE', __FILE__ );
define( 'VIC_VERSION', '1.1.0' );

add_action( 'before_woocommerce_init', function () {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', VIC_FILE, true );
	}
} );

register_activation_hook( VIC_FILE, function () {
	if ( class_exists( 'WooCommerce' ) ) {
		require_once __DIR__ . '/includes/wholesale.php';
		VIC_Wholesale::install_page();
		require_once __DIR__ . '/includes/class-vic-combos.php';
		VIC_Combos::resume();
	}
} );

register_deactivation_hook( VIC_FILE, function () {
	if ( class_exists( 'WooCommerce' ) ) {
		require_once __DIR__ . '/includes/class-vic-combos.php';
		VIC_Combos::suspend();
	}
} );

add_action( 'plugins_loaded', function () {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', function () {
			echo '<div class="notice notice-error"><p>Ative o WooCommerce para usar o Villa Ibit Combos e Atacado.</p></div>';
		} );
		return;
	}
	require_once __DIR__ . '/includes/class-vic-combos.php';
	require_once __DIR__ . '/includes/combo-category.php';
	require_once __DIR__ . '/includes/class-vic-cart.php';
	require_once __DIR__ . '/includes/class-vic-editor.php';
	require_once __DIR__ . '/includes/wholesale.php';
	require_once __DIR__ . '/includes/store-links.php';
	VIC_Combo_Category::init();
	VIC_Combos::init();
	VIC_Cart::init();
	VIC_Editor::init();
	VIC_Wholesale::init();
}, 15 );
