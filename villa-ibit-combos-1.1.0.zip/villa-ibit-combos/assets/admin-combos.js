/* global jQuery, ajaxurl, vicComboEditor, wp */
jQuery(function ($) {
	'use strict';

	var form = document.getElementById('vic-form');
	if (!form) {
		return;
	}

	var rows = document.getElementById('vic-rows');
	var price = document.getElementById('vic-price');
	var timer;
	var request;
	var sequence = 0;
	var frame;

	function updateRows() {
		var lines = rows.querySelectorAll('.vic-row');
		lines.forEach(function (line, i) {
			line.querySelector('select').setAttribute('aria-label', 'Produto ou variação ' + (i + 1));
			var remove = line.querySelector('.vic-remove');
			remove.hidden = lines.length <= 2;
			remove.setAttribute('aria-label', 'Remover produto ' + (i + 1));
		});
	}

	function quote() {
		var current = ++sequence;
		clearTimeout(timer);
		if (request) {
			request.abort();
		}
		var products = [];
		var quantities = [];
		rows.querySelectorAll('.vic-row').forEach(function (line) {
			products.push(line.querySelector('select').value);
			quantities.push(line.querySelector('input').value);
		});
		var discount = form.elements['vic[discount]'].value;
		var type = form.elements['vic[type]'].value;
		if (products.indexOf('') !== -1 || !discount || quantities.some(function (q) { return !q || Number(q) < 1; })) {
			price.textContent = 'Preencha os produtos e o desconto.';
			return;
		}
		price.textContent = 'Calculando…';
		timer = setTimeout(function () {
			request = $.post(ajaxurl, {
				action: 'vic_combo_quote',
				nonce: vicComboEditor.nonce,
				vic: { products: products, qty: quantities, discount: discount, type: type }
			}).done(function (response) {
				if (current === sequence && response.success) {
					price.textContent = response.data.price;
				}
			}).fail(function (_, reason) {
				if (current === sequence && reason !== 'abort') {
					price.textContent = 'Confira os produtos, as quantidades e o desconto.';
				}
			});
		}, 250);
	}

	$('#vic-add').on('click', function () {
		var clone = document.getElementById('vic-row-template').content.cloneNode(true);
		rows.appendChild(clone);
		updateRows();
		$(document.body).trigger('wc-enhanced-select-init');
		$(rows.lastElementChild).find('select').selectWoo('open');
		quote();
	});

	$(rows).on('click', '.vic-remove', function () {
		if (rows.children.length <= 2) {
			return;
		}
		var line = this.closest('.vic-row');
		var select = $(line).find('.wc-product-search');
		if (select.hasClass('enhanced')) {
			select.selectWoo('destroy');
		}
		line.remove();
		updateRows();
		document.getElementById('vic-add').focus();
		quote();
	});
	$(rows).on('change', 'select', quote);
	$(form).on('input', '[name="vic[qty][]"], [name="vic[discount]"]', quote);
	function updateDiscount() {
		var fixed = form.elements['vic[type]'].value === 'fixed';
		var amount = form.elements['vic[discount]'];
		amount.step = fixed ? form.querySelector('.vic-pricing').dataset.fixedStep : '0.01';
		amount.min = amount.step;
		if (fixed) {
			amount.removeAttribute('max');
		} else {
			amount.max = '100';
		}
	}
	$(form.elements['vic[type]']).on('change', function () {
		updateDiscount();
		quote();
	});
	updateDiscount();
	updateRows();
	if (form.hasAttribute('data-refresh-price')) {
		quote();
	}

	var imageField = document.getElementById('vic-image-id');
	var imagePreview = document.getElementById('vic-image-preview');
	var clearImage = document.getElementById('vic-clear');
	$('#vic-pick').on('click', function () {
		if (!frame) {
			frame = wp.media({ title: 'Foto do combo', button: { text: 'Usar esta foto' }, library: { type: 'image' }, multiple: false });
			frame.on('select', function () {
				var picked = frame.state().get('selection').first().toJSON();
				var img = document.createElement('img');
				img.src = picked.sizes && picked.sizes.thumbnail ? picked.sizes.thumbnail.url : picked.url;
				img.alt = '';
				imageField.value = picked.id;
				imagePreview.replaceChildren(img);
				clearImage.hidden = false;
			});
		}
		frame.open();
	});
	clearImage.addEventListener('click', function () {
		imageField.value = '';
		imagePreview.replaceChildren();
		clearImage.hidden = true;
		document.getElementById('vic-pick').focus();
	});

	form.addEventListener('submit', function (event) {
		var empty = Array.prototype.find.call(rows.querySelectorAll('select'), function (select) { return !select.value; });
		if (empty) {
			event.preventDefault();
			$(empty).selectWoo('open');
			return;
		}
		form.querySelector('button[type="submit"]').disabled = true;
	});
});
