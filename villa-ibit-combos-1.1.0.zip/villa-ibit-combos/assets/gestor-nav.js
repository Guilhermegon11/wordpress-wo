(function () {
	'use strict';

	// O Gestor 1.14 usa dois menus próprios: a lateral e a folha “Mais” do celular.
	document.querySelectorAll('.vig-nav, .vig-sheet__grid').forEach(function (menu) {
		var products = menu.querySelector('a[href$="page=vi-gestor-produtos"]');
		if (!products) {
			return;
		}
		var previous = products;
		Object.entries(window.vicGestorLinks || {}).forEach(function (entry) {
			if (menu.querySelector('a[href="' + entry[1] + '"]')) {
				return;
			}
			var link = document.createElement('a');
			link.className = menu.classList.contains('vig-nav') ? 'vig-nav__item' : 'vig-sheet__item';
			link.href = entry[1];
			if (new URL(link.href).searchParams.get('page') === new URL(window.location.href).searchParams.get('page')) {
				link.classList.add('is-on');
				link.setAttribute('aria-current', 'page');
			}
			var icon = products.querySelector('svg');
			if (icon) {
				link.appendChild(icon.cloneNode(true));
			}
			var label = document.createElement('span');
			label.textContent = entry[0];
			link.appendChild(label);
			previous.after(link);
			previous = link;
		});
	});
}());
