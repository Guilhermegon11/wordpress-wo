(function () {
	'use strict';

	function init() {
		const forms = document.querySelectorAll('.vic-atacado__form');
		const settings = window.vicWholesaleCart;
		// Cada envio aguarda a gravação anterior na sessão do WooCommerce.
		let queue = Promise.resolve();

		function setFeedback(form, message, state) {
			const feedback = form.querySelector('[data-vic-feedback]');
			feedback.textContent = message;
			feedback.dataset.state = state;
		}

		function appendCartLink(form, container) {
			const cart = form.closest('.vic-atacado').querySelector('.vic-atacado__resumo a');
			if (cart) {
				const link = document.createElement('a');
				link.href = cart.href;
				link.textContent = 'Ver carrinho';
				container.append(' ', link);
			}
		}

		function showUnconfirmed(form) {
			setFeedback(form, 'Não foi possível confirmar a inclusão. Confira o carrinho antes de tentar de novo.', 'error');
			appendCartLink(form, form.querySelector('[data-vic-feedback]'));
		}

		function clearPreviousProgress() {
			document.querySelectorAll('[data-vic-cart-progress]').forEach(function (previous) {
				previous.remove();
			});
		}
		if (window.jQuery) {
			window.jQuery(document.body).on('removed_from_cart', clearPreviousProgress);
		}

		function showSuccess(form, data) {
			clearPreviousProgress();
			setFeedback(form, data.message, 'success');
			const progress = document.createElement('span');
			progress.dataset.vicCartProgress = '';
			progress.textContent = ' ' + data.summaryDetail;
			if (data.remaining === 0) {
				appendCartLink(form, progress);
			}
			form.querySelector('[data-vic-feedback]').appendChild(progress);
		}

		function updateSummary(data) {
			document.querySelectorAll('[data-vic-summary-title]').forEach(function (title) {
				title.textContent = data.summaryTitle;
			});
			document.querySelectorAll('[data-vic-summary-detail]').forEach(function (detail) {
				detail.textContent = data.summaryDetail;
			});
		}

		function updateMiniCart(data) {
			const $ = window.jQuery;
			if (!$ || !data.fragments) {
				return;
			}
			Object.entries(data.fragments).forEach(function ([selector, html]) {
				// Um seletor de extensão incompatível não deve impedir a atualização dos outros.
				try { $(selector).replaceWith(html); } catch (error) { /* Fragmento inválido. */ }
			});
			const cache = window.wc_cart_fragments_params;
			if (cache) {
				try {
					sessionStorage.setItem(cache.fragment_name, JSON.stringify(data.fragments));
					sessionStorage.setItem('wc_cart_created', String(Date.now()));
					sessionStorage.setItem(cache.cart_hash_key, data.cart_hash);
					localStorage.setItem(cache.cart_hash_key, data.cart_hash);
				} catch (error) { /* O navegador pode bloquear o armazenamento. */ }
			}
			// O tema abre a gaveta em added_to_cart. Aqui o cliente continua montando o pedido.
			$(document.body).trigger('wc_fragments_refreshed');
		}

		async function add(form, fields) {
			let result;
			try {
				const response = await fetch(settings.endpoint, {
					method: 'POST',
					body: fields,
					credentials: 'same-origin',
					headers: { Accept: 'application/json' }
				});
				result = await response.json();
				if (result && result.success === false && result.data && typeof result.data.message === 'string') {
					setFeedback(form, result.data.message, 'error');
					return;
				}
				if (!response.ok || !result || result.success !== true || !result.data) {
					showUnconfirmed(form);
					return;
				}
			} catch (error) {
				// A requisição pode ter chegado à loja mesmo quando a resposta se perde.
				showUnconfirmed(form);
				return;
			}
			showSuccess(form, result.data);
			updateSummary(result.data);
			updateMiniCart(result.data);
		}

		forms.forEach(function (form) {
			const field = form.elements.vic_quantity;
			const steps = form.querySelectorAll('[data-vic-step]');
			const submit = form.querySelector('.vic-atacado__adicionar');
			if (!field || !submit) {
				return;
			}

			function updateSteps() {
				steps.forEach(function (button) {
					const minus = button.dataset.vicStep === '-1';
					button.disabled = minus ? field.valueAsNumber <= Number(field.min) :
						(field.max !== '' && field.valueAsNumber >= Number(field.max));
				});
			}
			steps.forEach(function (button) {
				button.hidden = false;
				button.addEventListener('click', function () {
					if (!field.value) {
						field.value = field.min;
					} else if (button.dataset.vicStep === '-1') {
						field.stepDown();
					} else {
						field.stepUp();
					}
					field.dispatchEvent(new Event('input', { bubbles: true }));
				});
			});
			updateSteps();
			field.addEventListener('input', updateSteps);

			const supportsAjax = settings && settings.endpoint && window.fetch && window.FormData &&
				window.crypto && window.crypto.getRandomValues;
			if (!supportsAjax || !form.querySelector('[data-vic-feedback]')) {
				return;
			}
			let pending = false;
			submit.addEventListener('click', function (event) {
				if (event.detail > 1) {
					event.preventDefault();
				}
			});
			form.addEventListener('submit', function (event) {
				if (event.defaultPrevented) {
					return;
				}
				event.preventDefault();
				if (pending || !form.reportValidity()) {
					return;
				}
				// Captura as escolhas no clique, mesmo se outro card ainda estiver sendo enviado.
				const fields = new FormData(form);
				const id = crypto.getRandomValues(new Uint8Array(16));
				fields.set('vic_request_id', Array.from(id, function (byte) {
					return byte.toString(16).padStart(2, '0');
				}).join(''));
				pending = true;
				submit.setAttribute('aria-disabled', 'true');
				setFeedback(form, 'Adicionando ao carrinho…', 'loading');
				async function send() {
					try {
						await add(form, fields);
					} finally {
						pending = false;
						submit.removeAttribute('aria-disabled');
					}
				}
				queue = queue.then(send, send);
			});
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
