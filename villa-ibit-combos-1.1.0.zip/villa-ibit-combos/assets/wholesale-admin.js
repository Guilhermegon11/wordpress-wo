(function ($) {
	'use strict';
	$(function () {
		var frame;
		var input = $('#vic-wh-image');
		var preview = $('#vic-wh-preview');
		$('#vic-wh-pick').on('click', function () {
			if (!frame) {
				frame = wp.media({title: 'Imagem do banner de atacado', library: {type: 'image'}, multiple: false, button: {text: 'Usar no banner'}});
				frame.on('select', function () {
					var item = frame.state().get('selection').first().toJSON();
					input.val(item.id);
					preview.attr('src', item.url);
					$('#vic-wh-default').prop('disabled', false);
				});
			}
			frame.open();
		});
		$('#vic-wh-default').on('click', function () {
			input.val('0');
			preview.attr('src', preview.data('fallback'));
			$(this).prop('disabled', true);
		});
	});
})(jQuery);
