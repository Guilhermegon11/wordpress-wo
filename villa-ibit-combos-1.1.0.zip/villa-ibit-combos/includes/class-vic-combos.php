<?php
/** Criação e manutenção do produto que representa o combo no catálogo. */

defined( 'ABSPATH' ) || exit;

class VIC_Combos {
	public static function init() {
		add_action( 'woocommerce_before_product_object_save', array( __CLASS__, 'keep_catalog_data' ) );
		add_action( 'woocommerce_after_product_object_save', array( __CLASS__, 'on_product_save' ) );
		add_action( 'woocommerce_product_set_stock', array( __CLASS__, 'on_product_save' ) );
		add_action( 'woocommerce_variation_set_stock', array( __CLASS__, 'on_product_save' ) );
		add_action( 'transition_post_status', array( __CLASS__, 'on_status_change' ), 15, 3 );
		add_action( 'deleted_post', array( __CLASS__, 'on_deleted_post' ), 15, 2 );
		// O tema e o widget do Elementor chamam o formulário antes do resumo padrão do WooCommerce.
		add_action( 'woocommerce_before_template_part', array( __CLASS__, 'show_contents' ) );
		add_filter( 'render_block_woocommerce/add-to-cart-with-options', array( __CLASS__, 'before_purchase_block' ), 10, 3 );
		add_filter( 'woocommerce_product_get_image_id', array( __CLASS__, 'fallback_image' ), 10, 2 );
	}

	private static function product( $value ) {
		return $value instanceof WC_Product ? $value : ( is_numeric( $value ) && $value > 0 ? wc_get_product( $value ) : false );
	}

	public static function is_combo( $item ) {
		$product = self::product( $item );
		return $product && 'yes' === $product->get_meta( '_vic_combo', true, 'edit' );
	}

	public static function components( $item ) {
		$product = self::product( $item );
		return $product ? (array) ( $product->get_meta( '_vic_components', true, 'edit' ) ?: array() ) : array();
	}

	/** Valida também o produto pai de uma variação. Não vende um sabor indefinido. */
	public static function catalog_component( $id ) {
		$item = wc_get_product( $id );
		if ( ! $item || self::is_combo( $item ) || ! $item->is_type( array( 'simple', 'variation' ) ) || 'publish' !== $item->get_status( 'edit' ) || '' === $item->get_price( 'edit' ) ) {
			return false;
		}
		if ( $item->is_type( 'variation' ) ) {
			$parent = wc_get_product( $item->get_parent_id() );
			if ( ! $parent || 'publish' !== $parent->get_status( 'edit' ) || ! $parent->is_type( 'variable' ) || ! $item->variation_is_active() ) {
				return false;
			}
			$chosen = $item->get_attributes();
			foreach ( array_keys( $parent->get_variation_attributes() ) as $attribute ) {
				$key = sanitize_title( $attribute );
				if ( ! isset( $chosen[ $key ] ) || '' === (string) $chosen[ $key ] ) {
					return false;
				}
			}
		}
		return $item;
	}

	/** Dados para o preço indexado do Woo e disponibilidade de um combo inteiro. */
	private static function calculate( $components, $discount, $type ) {
		if ( ! is_array( $components ) || count( $components ) < 2 ) {
			return new WP_Error( 'vic_definition', 'Selecione pelo menos dois produtos diferentes para criar o kit.' );
		}
		if ( ! in_array( $type, array( 'percent', 'fixed' ), true ) || ! is_numeric( $discount ) || $discount <= 0 || ( 'percent' === $type && $discount > 100 ) ) {
			return new WP_Error( 'vic_discount', 'Informe um desconto maior que zero. Para descontos em percentual, o limite é 100%.' );
		}
		$total = 0.0;
		$virtual = true;
		$stock_status = 'instock';
		$stock_needed = array();
		$stock_owners = array();
		$related = array();
		$tax = null;
		foreach ( $components as $id => $quantity ) {
			if ( ! ctype_digit( (string) $id ) || ! is_scalar( $quantity ) || ! ctype_digit( (string) $quantity ) || (int) $quantity < 1 || (float) $quantity > PHP_INT_MAX ) {
				return new WP_Error( 'vic_quantity', 'Informe uma quantidade inteira positiva para cada produto.' );
			}
			$item = self::catalog_component( $id );
			if ( ! $item ) {
				return new WP_Error( 'vic_component', 'Escolha produtos simples publicados ou variações publicadas com todos os atributos definidos e preço cadastrado. Um combo não pode conter outro combo.' );
			}
			$quantity = (int) $quantity;
			if ( $item->is_sold_individually() && $quantity > 1 ) {
				return new WP_Error( 'vic_individual', sprintf( '“%s” permite apenas uma unidade por pedido.', $item->get_name() ) );
			}
			$item_tax = array( $item->get_tax_status(), $item->get_tax_class() );
			if ( $tax && $tax !== $item_tax ) {
				return new WP_Error( 'vic_tax', 'Use produtos com a mesma condição e classe de imposto para cobrar o tributo correto no combo.' );
			}
			$tax = $item_tax;
			$total += (float) $item->get_price( 'edit' ) * $quantity;
			$virtual = $virtual && $item->is_virtual();
			$related[] = $item->get_id();
			if ( $item->get_parent_id() ) {
				$related[] = $item->get_parent_id();
			}
			if ( ! $item->is_in_stock() ) {
				$stock_status = 'outofstock';
			} elseif ( 'instock' === $stock_status && $item->is_on_backorder( $quantity ) ) {
				$stock_status = 'onbackorder';
			}
			if ( $item->managing_stock() ) {
				$owner_id = $item->get_stock_managed_by_id();
				$stock_needed[ $owner_id ] = ( $stock_needed[ $owner_id ] ?? 0 ) + $quantity;
				if ( ! isset( $stock_owners[ $owner_id ] ) ) {
					// Variações podem estar em cache com a quantidade anterior do pai.
					$stock_owners[ $owner_id ] = $owner_id === $item->get_id() ? $item : wc_get_product( $owner_id );
				}
			}
		}
		foreach ( $stock_needed as $owner_id => $needed ) {
			$owner = $stock_owners[ $owner_id ];
			if ( ! $owner || ! $owner->has_enough_stock( $needed ) ) {
				$stock_status = 'outofstock';
			} elseif ( 'instock' === $stock_status && $owner->is_on_backorder( $needed ) ) {
				$stock_status = 'onbackorder';
			}
		}
		$final = 'fixed' === $type ? max( 0, $total - $discount ) : $total * ( 1 - $discount / 100 );
		return array(
			'regular' => wc_format_decimal( $total, wc_get_price_decimals() ),
			'price'   => wc_format_decimal( $final, wc_get_price_decimals() ),
			'virtual' => $virtual,
			'tax'     => $tax,
			'stock'   => $stock_status,
			'related' => array_unique( $related ),
		);
	}

	public static function price( $product ) {
		$product = self::product( $product );
		if ( ! self::is_combo( $product ) ) {
			return false;
		}
		$data = self::calculate_product( $product );
		return is_wp_error( $data ) ? false : $data['price'];
	}

	private static function calculate_product( $product ) {
		return self::calculate(
			self::components( $product ),
			$product->get_meta( '_vic_discount', true, 'edit' ),
			$product->get_meta( '_vic_discount_type', true, 'edit' ) ?: 'percent'
		);
	}

	public static function keep_catalog_data( $product ) {
		if ( ! self::is_combo( $product ) ) {
			return;
		}
		$data = self::calculate_product( $product );
		$product->set_manage_stock( false );
		if ( is_wp_error( $data ) ) {
			$product->set_stock_status( 'outofstock' );
			$product->set_regular_price( '' );
			$product->set_sale_price( '' );
			$product->set_price( '' );
			return;
		}
		$product->set_stock_status( $data['stock'] );
		$product->set_virtual( $data['virtual'] );
		$product->set_tax_status( $data['tax'][0] );
		$product->set_tax_class( $data['tax'][1] );
		$product->set_regular_price( $data['regular'] );
		$product->set_sale_price( $data['price'] );
		$product->set_price( $data['price'] );
		$product->set_date_on_sale_from( null );
		$product->set_date_on_sale_to( null );
	}

	/** A criação altera somente o novo produto. A edição exige que o alvo já seja um combo nosso. */
	public static function save_combo( $id, $name, $components, $discount, $status, $image_id, $discount_type = 'percent' ) {
		$name = sanitize_text_field( $name );
		if ( '' === trim( $name ) || ! in_array( $status, array( 'publish', 'draft' ), true ) ) {
			return new WP_Error( 'vic_name', 'Informe o nome do combo e escolha se deseja publicar ou salvar como rascunho.' );
		}
		$digits = 'fixed' === $discount_type ? wc_get_price_decimals() : 2;
		$pattern = $digits ? '/^\d+(?:[,.]\d{1,' . $digits . '})?$/D' : '/^\d+$/D';
		if ( ! is_scalar( $discount ) || ! preg_match( $pattern, (string) $discount ) || ! is_finite( (float) $discount ) ) {
			return new WP_Error( 'vic_discount', 'Informe um valor de desconto válido, usando o número de casas decimais permitido.' );
		}
		$discount = str_replace( ',', '.', (string) $discount );
		$data = self::calculate( $components, $discount, $discount_type );
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		$product = $id ? wc_get_product( $id ) : new WC_Product_Simple();
		if ( ! $product || ( $id && ( ! self::is_combo( $product ) || ! $product->is_type( 'simple' ) ) ) ) {
			return new WP_Error( 'vic_id', 'Este produto não é um combo editável.' );
		}
		if ( $image_id && ! wp_attachment_is_image( $image_id ) ) {
			return new WP_Error( 'vic_image', 'Escolha uma imagem da biblioteca de mídia.' );
		}
		$categories = VIC_Combo_Category::for_product( $product->get_category_ids( 'edit' ) );
		if ( is_wp_error( $categories ) ) {
			return $categories;
		}
		$product->set_category_ids( $categories );
		$product->set_name( $name );
		$product->set_status( $status );
		$product->set_image_id( absint( $image_id ) );
		$product->update_meta_data( '_vic_combo', 'yes' );
		$product->update_meta_data( '_vic_components', array_map( 'intval', $components ) );
		$product->update_meta_data( '_vic_discount', $discount );
		$product->update_meta_data( '_vic_discount_type', $discount_type );
		$product->delete_meta_data( '_vic_member' );
		foreach ( $data['related'] as $related_id ) {
			$product->add_meta_data( '_vic_member', $related_id );
		}
		try {
			return $product->save();
		} catch ( Exception $e ) {
			return new WP_Error( 'vic_save', $e->getMessage() );
		}
	}

	public static function on_product_save( $product ) {
		if ( ! self::is_combo( $product ) ) {
			self::refresh_dependents( $product->get_id() );
		}
	}

	public static function on_status_change( $new, $old, $post ) {
		if ( $new !== $old && in_array( $post->post_type, array( 'product', 'product_variation' ), true ) ) {
			self::refresh_dependents( $post->ID );
		}
	}

	public static function on_deleted_post( $id, $post ) {
		if ( in_array( $post->post_type, array( 'product', 'product_variation' ), true ) ) {
			self::refresh_dependents( $id );
		}
	}

	private static function refresh_dependents( $id ) {
		$ids = get_posts( array(
			'post_type' => 'product', 'post_status' => array( 'publish', 'draft', 'private', 'pending', 'future' ),
			'fields' => 'ids', 'numberposts' => -1, 'meta_key' => '_vic_member', 'meta_value' => (string) $id,
		) );
		foreach ( $ids as $combo_id ) {
			$combo = wc_get_product( $combo_id );
			if ( $combo && self::is_combo( $combo ) ) {
				self::keep_catalog_data( $combo );
				if ( $combo->get_changes() ) {
					$combo->save();
				}
			}
		}
	}

	private static function published_combos() {
		return get_posts( array(
			'post_type' => 'product', 'post_status' => 'publish', 'fields' => 'ids', 'numberposts' => -1,
			'meta_key' => '_vic_combo', 'meta_value' => 'yes',
		) );
	}

	/** Sem o plugin, uma venda do produto simples deixaria de baixar seus componentes. */
	public static function suspend() {
		update_option( 'vic_combos_suspended', 1, false );
		$removed = remove_action( 'woocommerce_before_product_object_save', array( __CLASS__, 'keep_catalog_data' ) );
		try {
			foreach ( self::published_combos() as $id ) {
				$product = wc_get_product( $id );
				if ( $product && 'outofstock' !== $product->get_stock_status( 'edit' ) ) {
					$product->set_stock_status( 'outofstock' );
					$product->save();
				}
			}
		} finally {
			if ( $removed ) {
				add_action( 'woocommerce_before_product_object_save', array( __CLASS__, 'keep_catalog_data' ) );
			}
		}
	}

	public static function resume() {
		if ( ! get_option( 'vic_combos_suspended' ) ) {
			return;
		}
		foreach ( self::published_combos() as $id ) {
			$product = wc_get_product( $id );
			if ( $product ) {
				self::keep_catalog_data( $product );
				if ( $product->get_changes() ) {
					$product->save();
				}
			}
		}
		delete_option( 'vic_combos_suspended' );
	}

	public static function fallback_image( $image_id, $product ) {
		if ( ! $image_id && self::is_combo( $product ) ) {
			foreach ( array_keys( self::components( $product ) ) as $id ) {
				$item = wc_get_product( $id );
				if ( $item && ! self::is_combo( $item ) && $item->get_image_id() ) {
					return $item->get_image_id();
				}
			}
		}
		return $image_id;
	}

	public static function show_contents( $template_name = 'single-product/add-to-cart/simple.php' ) {
		if ( 'single-product/add-to-cart/simple.php' !== $template_name ) {
			return;
		}
		global $product;
		echo self::contents_html( $product ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- itens escapados em contents_html.
	}

	public static function before_purchase_block( $html, $parsed, $block ) {
		// Temas de blocos podem usar um formulário próprio ou recorrer ao formulário clássico.
		if ( '' === $html || empty( $block->context['postId'] ) || false !== strpos( $html, 'class="vic-composition"' ) ) {
			return $html;
		}
		$product = wc_get_product( $block->context['postId'] );
		return self::contents_html( $product ) . $html;
	}

	private static function contents_html( $product ) {
		if ( ! self::is_combo( $product ) ) {
			return '';
		}
		$html = '<section class="vic-composition"><h3>O que vem no combo</h3><ul>';
		foreach ( self::components( $product ) as $id => $quantity ) {
			$item = wc_get_product( $id );
			if ( $item ) {
				$html .= '<li>' . esc_html( sprintf( '%1$d × %2$s', $quantity, $item->get_name() ) ) . '</li>';
			}
		}
		return $html . '</ul></section>';
	}
}
