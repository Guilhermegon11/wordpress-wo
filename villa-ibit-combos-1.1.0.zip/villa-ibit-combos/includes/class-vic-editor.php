<?php
/** Editor de produtos promocionais no painel da loja. */
defined( 'ABSPATH' ) || exit;

final class VIC_Editor {
	const PAGE = 'vic-combos';
	const GESTOR_PAGE = 'vi-gestor-combos';
	const CAP  = 'manage_woocommerce';

	private static $screen;
	private static $posted  = null;
	private static $error   = '';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 60 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ), 30 );
		add_action( 'wp_ajax_vic_search_components', array( __CLASS__, 'search' ) );
		add_action( 'wp_ajax_vic_combo_quote', array( __CLASS__, 'quote' ) );
		add_filter( 'plugin_action_links_villa-ibit-combos/villa-ibit-combos.php', array( __CLASS__, 'links' ) );
		add_filter( 'post_row_actions', array( __CLASS__, 'row_actions' ), 15, 2 );
	}

	private static function has_gestor() {
		return is_callable( array( 'VIG_Admin', 'header' ) ) && is_callable( array( 'VIG_Admin', 'footer' ) );
	}

	public static function url( $id = 0 ) {
		$args = array( 'page' => self::has_gestor() ? self::GESTOR_PAGE : self::PAGE );
		if ( $id ) {
			$args['combo'] = $id;
		}
		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}

	public static function menu() {
		$gestor = self::has_gestor();
		$parent = $gestor ? 'vi-gestor' : 'woocommerce';
		$page   = $gestor ? self::GESTOR_PAGE : self::PAGE;
		self::$screen = add_submenu_page( $parent, 'Combos promocionais', 'Combos promocionais', self::CAP, $page, array( __CLASS__, 'render' ) );
		if ( self::$screen ) {
			add_action( 'load-' . self::$screen, array( __CLASS__, 'submit' ) );
		}
		if ( $gestor ) {
			add_action( 'load-' . get_plugin_page_hookname( 'vi-gestor-produto', 'vi-gestor' ), array( __CLASS__, 'open_catalog_combo' ) );
		}

		// Um favorito ou formulário aberto continua funcionando após a atualização ou troca de painel.
		$alias = $gestor ? self::PAGE : self::GESTOR_PAGE;
		if ( $alias === ( $_GET['page'] ?? '' ) ) {
			$old = add_submenu_page( $parent, 'Combos promocionais', 'Combos promocionais', self::CAP, $alias, '__return_null' );
			if ( $old ) {
				add_action( 'load-' . $old, array( __CLASS__, 'redirect_alias' ) );
			}
		}
	}

	public static function open_catalog_combo() {
		if ( 'GET' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || ! empty( $_GET['do'] ) ) {
			return;
		}
		$id = absint( $_GET['id'] ?? 0 );
		if ( $id && current_user_can( self::CAP ) && current_user_can( 'edit_products' ) && current_user_can( 'edit_post', $id ) && VIC_Combos::is_combo( $id ) ) {
			wp_safe_redirect( self::url( $id ) );
			exit;
		}
	}

	public static function redirect_alias() {
		$url = self::url( absint( $_GET['combo'] ?? 0 ) );
		if ( isset( $_GET['lista'] ) ) {
			$url = add_query_arg( 'lista', max( 1, absint( $_GET['lista'] ) ), $url );
		}
		wp_safe_redirect( $url, 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) ? 307 : 302 );
		exit;
	}

	public static function links( $links ) {
		if ( current_user_can( self::CAP ) ) {
			array_unshift( $links, '<a href="' . esc_url( self::url() ) . '">Combos promocionais</a>' );
		}
		return $links;
	}

	public static function row_actions( $actions, $post ) {
		if ( 'product' === $post->post_type && current_user_can( self::CAP ) && current_user_can( 'edit_post', $post->ID ) && 'yes' === get_post_meta( $post->ID, '_vic_combo', true ) ) {
			$actions['vic_combo'] = '<a href="' . esc_url( self::url( $post->ID ) ) . '">Editar combo</a>';
		}
		return $actions;
	}

	public static function assets( $screen ) {
		if ( $screen !== self::$screen ) {
			return;
		}

		wp_enqueue_style( 'woocommerce_admin_styles' );
		wp_enqueue_style( 'vic-combos-editor', plugins_url( 'assets/admin-combos.css', VIC_FILE ), array( 'woocommerce_admin_styles' ), VIC_VERSION );
		wp_enqueue_media();
		wp_enqueue_script( 'vic-combos-editor', plugins_url( 'assets/admin-combos.js', VIC_FILE ), array( 'jquery', 'wc-enhanced-select' ), VIC_VERSION, true );
		wp_localize_script( 'vic-combos-editor', 'vicComboEditor', array( 'nonce' => wp_create_nonce( 'vic_combo_quote' ) ) );
	}

	public static function search() {
		if ( ! current_user_can( self::CAP ) || ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( null, 403 );
		}
		// Usa busca por nome, ID ou SKU, nonce e regras de leitura do WooCommerce.
		add_filter( 'woocommerce_json_search_found_products', array( __CLASS__, 'filter_search' ) );
		WC_AJAX::json_search_products_and_variations();
	}

	public static function filter_search( $found ) {
		foreach ( $found as $id => $label ) {
			if ( ! VIC_Combos::catalog_component( $id ) ) {
				unset( $found[ $id ] );
				continue;
			}
			// SelectWoo recebe HTML de opções pelo contrato da busca nativa.
			$found[ $id ] = esc_html( wp_strip_all_tags( html_entity_decode( $label, ENT_QUOTES, 'UTF-8' ) ) );
		}
		return $found;
	}

	private static function posted_form() {
		$in = isset( $_POST['vic'] ) && is_array( $_POST['vic'] ) ? wp_unslash( $_POST['vic'] ) : array();
		return array(
			'id'       => isset( $in['id'] ) && is_scalar( $in['id'] ) ? absint( $in['id'] ) : 0,
			'name'     => sanitize_text_field( $in['name'] ?? '' ),
			'discount' => str_replace( ',', '.', sanitize_text_field( $in['discount'] ?? '' ) ),
			'type'     => sanitize_key( $in['type'] ?? 'percent' ),
			'status'   => sanitize_key( $in['status'] ?? '' ),
			'image'    => ! empty( $in['image'] ) && is_scalar( $in['image'] ) ? absint( $in['image'] ) : 0,
			'products' => array_map( 'sanitize_text_field', array_values( (array) ( $in['products'] ?? array() ) ) ),
			'qty'      => array_map( 'sanitize_text_field', array_values( (array) ( $in['qty'] ?? array() ) ) ),
		);
	}

	private static function component_map( $form ) {
		$components = array();
		if ( count( $form['products'] ) !== count( $form['qty'] ) ) {
			return new WP_Error( 'invalid_row', 'Confira o produto e a quantidade em cada linha.' );
		}
		foreach ( $form['products'] as $i => $value ) {
			$id  = filter_var( $value, FILTER_VALIDATE_INT, array( 'options' => array( 'min_range' => 1 ) ) );
			$qty = filter_var( $form['qty'][ $i ], FILTER_VALIDATE_INT, array( 'options' => array( 'min_range' => 1 ) ) );
			if ( ! $id || ! $qty ) {
				return new WP_Error( 'invalid_row', 'Escolha um produto e informe uma quantidade inteira, a partir de 1, em cada linha.' );
			}
			if ( isset( $components[ $id ] ) ) {
				return new WP_Error( 'duplicate', 'O mesmo produto aparece duas vezes. Ajuste a quantidade em uma única linha.' );
			}
			$components[ $id ] = $qty;
		}
		return count( $components ) >= 2 ? $components : new WP_Error( 'few', 'Escolha pelo menos dois produtos ou variações diferentes.' );
	}

	public static function quote() {
		check_ajax_referer( 'vic_combo_quote', 'nonce' );
		if ( ! current_user_can( self::CAP ) || ! current_user_can( 'edit_products' ) ) {
			wp_send_json_error( null, 403 );
		}
		$form = self::posted_form();
		$rows = self::component_map( $form );
		if ( is_wp_error( $rows ) || ! in_array( $form['type'], array( 'percent', 'fixed' ), true ) || ! is_numeric( $form['discount'] ) || $form['discount'] <= 0 || ( 'percent' === $form['type'] && $form['discount'] > 100 ) ) {
			wp_send_json_error( null, 400 );
		}
		$preview = new WC_Product_Simple();
		$preview->update_meta_data( '_vic_combo', 'yes' );
		$preview->update_meta_data( '_vic_components', $rows );
		$preview->update_meta_data( '_vic_discount', $form['discount'] );
		$preview->update_meta_data( '_vic_discount_type', $form['type'] );
		$price = VIC_Combos::price( $preview );
		if ( false === $price || '' === $price ) {
			wp_send_json_error( null, 400 );
		}
		wp_send_json_success( array( 'price' => wp_strip_all_tags( html_entity_decode( wc_price( (float) $price ), ENT_QUOTES, 'UTF-8' ) ) ) );
	}

	private static function check_access( $id ) {
		if ( ! current_user_can( self::CAP ) || ! current_user_can( 'edit_products' ) || ( $id && ! current_user_can( 'edit_post', $id ) ) ) {
			wp_die( esc_html( 'Você não pode editar este combo.' ), '', array( 'response' => 403 ) );
		}
		if ( $id && ( ! VIC_Combos::is_combo( $id ) || 'trash' === get_post_status( $id ) ) ) {
			wp_die( esc_html( 'Este combo não está disponível para edição.' ), '', array( 'response' => 404 ) );
		}
	}

	public static function submit() {
		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || ! isset( $_POST['vic'] ) ) {
			return;
		}
		$form = self::posted_form();
		check_admin_referer( 'vic_save_combo_' . $form['id'] );
		self::check_access( $form['id'] );
		if ( 'publish' === $form['status'] && ! current_user_can( 'publish_products' ) ) {
			wp_die( esc_html( 'Você não pode publicar produtos.' ), '', array( 'response' => 403 ) );
		}
		$rows   = self::component_map( $form );
		$result = is_wp_error( $rows ) ? $rows : VIC_Combos::save_combo( $form['id'], $form['name'], $rows, $form['discount'], $form['status'], $form['image'], $form['type'] );
		if ( is_wp_error( $result ) ) {
			self::$posted = $form;
			self::$error  = $result->get_error_message();
			return;
		}
		wp_safe_redirect( add_query_arg( 'salvo', '1', self::url( $result ) ) );
		exit;
	}

	private static function form( $product ) {
		if ( null !== self::$posted ) {
			return self::$posted;
		}
		$components = $product ? VIC_Combos::components( $product ) : array();
		return array(
			'id'       => $product ? $product->get_id() : 0,
			'name'     => $product ? $product->get_name( 'edit' ) : '',
			'status'   => $product ? $product->get_status( 'edit' ) : 'draft',
			'image'    => $product ? $product->get_image_id( 'edit' ) : 0,
			'discount' => $product ? $product->get_meta( '_vic_discount' ) : '',
			'type'     => $product && 'fixed' === $product->get_meta( '_vic_discount_type' ) ? 'fixed' : 'percent',
			'products' => array_keys( $components ),
			'qty'      => array_values( $components ),
		);
	}

	private static function row( $id, $qty, $index = 1 ) {
		$product = $id ? wc_get_product( $id ) : false;
		$name    = $product ? wp_strip_all_tags( $product->get_formatted_name() ) : sprintf( 'Produto indisponível (#%d)', $id );
		?>
		<div class="vic-row">
			<label><span>Produto ou variação</span>
				<select class="wc-product-search" name="vic[products][]" data-action="vic_search_components" data-minimum_input_length="2" data-placeholder="Buscar por nome ou SKU" aria-label="<?php echo esc_attr( 'Produto ou variação ' . $index ); ?>">
					<option value=""></option>
					<?php if ( $id ) : ?><option value="<?php echo esc_attr( $id ); ?>" selected><?php echo esc_html( $name ); ?></option><?php endif; ?>
				</select>
			</label>
			<div class="vic-row-controls">
				<label><span>Quantidade</span><input type="number" name="vic[qty][]" value="<?php echo esc_attr( $qty ); ?>" min="1" step="1" required></label>
				<button type="button" class="vic-button vic-remove">Remover</button>
			</div>
		</div>
		<?php
	}

	public static function render() {
		$id = null !== self::$posted ? self::$posted['id'] : absint( $_GET['combo'] ?? 0 );
		self::check_access( $id );
		$product = $id ? wc_get_product( $id ) : false;
		$form    = self::form( $product );
		$gestor  = self::has_gestor();
		if ( $gestor ) {
			VIG_Admin::header( self::GESTOR_PAGE, 'Combos promocionais', '<a class="vig-btn vic-list-shortcut" href="#vic-list">Ver combos cadastrados</a>' );
		}
		?>
		<div class="<?php echo $gestor ? 'vic-combos' : 'wrap vic-combos'; ?>">
			<?php if ( ! $gestor ) : ?><h1>Combos promocionais</h1><?php endif; ?>
			<?php if ( self::$error ) : ?>
				<p class="vic-message is-error" role="alert"><?php echo esc_html( self::$error ); ?></p>
			<?php elseif ( $product && isset( $_GET['salvo'] ) ) : ?>
				<p class="vic-message" role="status">Combo salvo. <?php if ( 'publish' === $product->get_status() ) : ?><a href="<?php echo esc_url( $product->get_permalink() ); ?>">Ver produto na loja</a><?php endif; ?></p>
			<?php endif; ?>
			<div class="vic-layout">
			<form method="post" id="vic-form" class="vic-card" action="<?php echo esc_url( self::url( $id ) ); ?>" <?php if ( null !== self::$posted ) { echo 'data-refresh-price'; } ?>>
				<?php wp_nonce_field( 'vic_save_combo_' . $id ); ?>
				<input type="hidden" name="vic[id]" value="<?php echo esc_attr( $id ); ?>">
				<div class="vic-title"><h2><?php echo $id ? 'Editar combo' : 'Criar combo'; ?></h2><?php if ( $id ) : ?><a class="vic-button" href="<?php echo esc_url( self::url() ); ?>">Criar outro combo</a><?php endif; ?></div>
				<label class="vic-field"><span>Nome do combo</span><input type="text" name="vic[name]" value="<?php echo esc_attr( $form['name'] ); ?>" required></label>
				<h3>Produtos do combo</h3><p class="description">Escolha pelo menos dois itens diferentes. Se o produto tiver sabores, selecione a variação exata.</p>
				<div id="vic-rows"><?php
					for ( $i = 0, $n = max( 2, count( $form['products'] ) ); $i < $n; $i++ ) {
						self::row( absint( $form['products'][ $i ] ?? 0 ), $form['qty'][ $i ] ?? 1, $i + 1 );
					}
				?></div>
				<template id="vic-row-template"><?php self::row( 0, 1 ); ?></template>
				<button type="button" id="vic-add" class="vic-button">Adicionar produto</button>
				<div class="vic-pricing" data-fixed-step="<?php echo esc_attr( wc_format_decimal( pow( 10, -wc_get_price_decimals() ), wc_get_price_decimals() ) ); ?>">
					<label class="vic-field"><span>Tipo de desconto</span><select name="vic[type]"><option value="percent" <?php selected( $form['type'], 'percent' ); ?>>Percentual (%)</option><option value="fixed" <?php selected( $form['type'], 'fixed' ); ?>>Valor fixo (<?php echo esc_html( get_woocommerce_currency_symbol() ); ?>)</option></select></label>
					<label class="vic-field"><span>Desconto no combo</span><input type="number" step="any" min="0" name="vic[discount]" required value="<?php echo esc_attr( $form['discount'] ); ?>"></label>
					<div class="vic-field vic-total"><span>Preço do combo</span><output id="vic-price" aria-live="polite"><?php echo $product && '' !== $product->get_price() ? wp_kses_post( wc_price( $product->get_price() ) ) : 'Preencha os produtos e o desconto.'; ?></output></div>
				</div>
				<div class="vic-field vic-image"><span>Foto do combo</span>
					<input type="hidden" name="vic[image]" id="vic-image-id" value="<?php echo esc_attr( $form['image'] ); ?>">
					<div id="vic-image-preview"><?php echo wp_get_attachment_image( $form['image'], 'thumbnail', false, array( 'alt' => '' ) ); ?></div>
					<div><button type="button" class="vic-button" id="vic-pick">Escolher foto</button> <button type="button" class="vic-button" id="vic-clear" <?php echo $form['image'] ? '' : 'hidden'; ?>>Remover foto</button></div>
				</div>
				<div class="vic-footer">
					<label class="vic-field"><span>Status do produto</span><select name="vic[status]">
						<option value="draft" <?php selected( 'draft', $form['status'] ); ?>>Rascunho</option>
						<?php if ( current_user_can( 'publish_products' ) ) : ?><option value="publish" <?php selected( 'publish', $form['status'] ); ?>>Publicado na loja</option><?php endif; ?>
					</select></label>
					<button type="submit" class="vic-button is-primary"><?php echo $id ? 'Salvar combo' : 'Criar produto do combo'; ?></button>
				</div>
			</form>
			<?php self::listing(); ?>
			</div>
		</div>
		<?php
		if ( $gestor ) {
			VIG_Admin::footer();
		}
	}

	private static function listing() {
		$page  = max( 1, absint( $_GET['lista'] ?? 1 ) );
		$query = new WP_Query( array(
			'post_type'      => 'product',
			'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
			'posts_per_page' => 20,
			'paged'          => $page,
			'meta_key'       => '_vic_combo',
			'meta_value'     => 'yes',
			'orderby'        => 'modified',
		) );
		?>
		<section class="vic-card" id="vic-list" tabindex="-1" aria-labelledby="vic-list-heading"><h2 id="vic-list-heading">Combos cadastrados</h2>
		<?php if ( ! $query->have_posts() ) : ?><p>Os combos que você criar aparecem aqui.</p>
		<?php else : ?>
			<ul class="vic-saved">
			<?php foreach ( $query->posts as $post ) :
				$product = wc_get_product( $post->ID );
				if ( ! $product || ! current_user_can( 'edit_post', $post->ID ) ) {
					continue;
				}
				$status = get_post_status_object( $product->get_status() );
				?>
				<li><a href="<?php echo esc_url( self::url( $post->ID ) ); ?>" aria-label="<?php echo esc_attr( sprintf( 'Editar combo %s', $product->get_name() ) ); ?>">
					<strong><?php echo esc_html( $product->get_name() ); ?></strong><span class="vic-edit-link">Editar</span>
					<span class="vic-saved-meta"><span><?php echo '' === $product->get_price() ? 'Indisponível' : wp_kses_post( wc_price( $product->get_price() ) ); ?></span><span class="vic-status"><?php echo esc_html( $status ? $status->label : $product->get_status() ); ?></span></span>
				</a></li>
			<?php endforeach; ?>
			</ul>
			<?php if ( $query->max_num_pages > 1 ) : ?>
				<nav aria-label="Páginas de combos"><?php echo wp_kses_post( paginate_links( array( 'base' => self::url() . '&lista=%#%#vic-list', 'format' => '', 'current' => $page, 'total' => $query->max_num_pages ) ) ); ?></nav>
			<?php endif; ?>
		<?php endif; ?></section>
		<?php
	}
}
