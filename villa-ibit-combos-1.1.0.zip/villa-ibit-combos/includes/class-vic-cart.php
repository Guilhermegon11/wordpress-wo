<?php
/**
 * O cliente compra uma linha de combo. O frete e a reserva de estoque trabalham
 * com os produtos reais que serão separados no pedido.
 */
defined( 'ABSPATH' ) || exit;

class VIC_Cart {
	public static function init() {
		add_filter( 'woocommerce_add_cart_item_data', array( __CLASS__, 'check_addition' ), 20, 4 );
		add_filter( 'woocommerce_update_cart_validation', array( __CLASS__, 'check_update' ), 10, 4 );
		add_filter( 'woocommerce_store_api_cart_item_quantity_validation', array( __CLASS__, 'check_api_update' ), 10, 4 );
		add_action( 'woocommerce_check_cart_items', array( __CLASS__, 'validate_cart' ) );
		add_action( 'woocommerce_store_api_cart_errors', array( __CLASS__, 'validate_api_cart' ), 10, 2 );
		add_action( 'woocommerce_before_calculate_totals', array( __CLASS__, 'update_prices' ), 5 );
		add_filter( 'woocommerce_get_cart_item_from_session', array( __CLASS__, 'restore_price' ), 5 );
		add_filter( 'woocommerce_cart_item_data_to_validate', array( __CLASS__, 'composition_hash' ), 10, 2 );
		add_filter( 'woocommerce_get_item_data', array( __CLASS__, 'describe_item' ), 10, 2 );
		add_filter( 'woocommerce_cart_shipping_packages', array( __CLASS__, 'shipping_packages' ), 5 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( __CLASS__, 'add_components_to_order' ), 10, 4 );
		add_filter( 'woocommerce_order_item_visible', array( __CLASS__, 'customer_item_visible' ), 10, 2 );
		add_filter( 'woocommerce_order_again_cart_item_data', array( __CLASS__, 'reorder_data' ), 10, 2 );
		add_filter( 'woocommerce_add_to_cart_validation', array( __CLASS__, 'skip_reordered_component' ), 10, 6 );
	}

	public static function composition_hash( $data, $product ) {
		if ( VIC_Combos::is_combo( $product ) ) {
			$data['vic_composition'] = VIC_Combos::components( $product );
		}
		return $data;
	}

	public static function update_prices( $cart ) {
		foreach ( $cart->get_cart() as $key => $row ) {
			$product = $row['data'];
			if ( VIC_Combos::is_combo( $product ) ) {
				$price = VIC_Combos::price( $product );
				if ( false !== $price ) {
					$product->set_price( $price );
					$cart->cart_contents[ $key ]['vic_combo_price'] = $price;
				}
			}
		}
	}

	public static function restore_price( $row ) {
		if ( VIC_Combos::is_combo( $row['data'] ) ) {
			$price = VIC_Combos::price( $row['data'] );
			if ( false !== $price ) {
				$row['data']->set_price( $price );
				if ( $price !== ( $row['vic_combo_price'] ?? null ) ) {
					WC()->session->set( 'cart_totals', null );
				}
				$row['vic_combo_price'] = $price;
			}
		}
		return $row;
	}

	/** Confere toda a demanda pelo mesmo estoque, inclusive avulsos e variações com estoque no pai. */
	private static function stock_error( $rows ) {
		$units         = array();
		$component_ids = array();
		foreach ( $rows as $row ) {
			$product = $row['data'];
			if ( ! VIC_Combos::is_combo( $product ) ) {
				$id           = $product->get_id();
				$units[ $id ] = ( $units[ $id ] ?? 0 ) + $row['quantity'];
				continue;
			}
			$components = VIC_Combos::components( $product );
			if ( count( $components ) < 2 || false === VIC_Combos::price( $product ) ) {
				return sprintf( 'O combo “%s” está indisponível. Retire-o do carrinho para continuar.', $product->get_name() );
			}
			if ( $row['quantity'] < 1 || (float) (int) $row['quantity'] !== (float) $row['quantity'] ) {
				return 'Escolha uma quantidade inteira de combos.';
			}
			foreach ( $components as $id => $quantity ) {
				$component_ids[ $id ] = true;
				$units[ $id ]         = ( $units[ $id ] ?? 0 ) + $quantity * $row['quantity'];
			}
		}
		if ( ! $component_ids ) {
			return '';
		}

		$stock_units = array();
		$limited     = array();
		foreach ( $units as $id => $quantity ) {
			$product  = wc_get_product( $id );
			$included = isset( $component_ids[ $id ] );
			if ( $included && ( ! $product || 'publish' !== $product->get_status() || ! $product->is_purchasable() || ! $product->is_in_stock() ) ) {
				return 'Um dos produtos do combo ficou indisponível. Revise seu carrinho para continuar.';
			}
			if ( ! $product ) {
				continue;
			}
			if ( $included && $product->is_sold_individually() && $quantity > 1 ) {
				return sprintf( 'O produto “%s” permite apenas uma unidade por pedido, contando combos e avulsos.', $product->get_name() );
			}
			if ( ! $product->managing_stock() ) {
				continue;
			}
			$source                 = $product->get_stock_managed_by_id();
			$stock_units[ $source ] = ( $stock_units[ $source ] ?? 0 ) + $quantity;
			if ( $included ) {
				$limited[ $source ] = $product;
			}
		}
		$order_id = WC()->session ? ( WC()->session->get( 'order_awaiting_payment' ) ?: WC()->session->get( 'store_api_draft_order', 0 ) ) : 0;
		foreach ( $limited as $source => $product ) {
			// Variações podem ter uma cópia anterior da quantidade do pai no objeto carregado.
			$owner = $product->get_id() === $source ? $product : wc_get_product( $source );
			if ( ! $owner ) {
				return 'O estoque de um produto do combo está indisponível. Revise seu carrinho.';
			}
			if ( $owner->backorders_allowed() ) {
				continue;
			}
			$held = wc_get_held_stock_quantity( $owner, absint( $order_id ) );
			if ( $stock_units[ $source ] > $owner->get_stock_quantity() - $held ) {
				return sprintf( 'Estoque insuficiente de “%s” para essa quantidade. Conte também as unidades dentro dos combos.', $product->get_name() );
			}
		}
		return '';
	}

	public static function check_addition( $data, $product_id, $variation_id, $qty = 1 ) {
		$product = wc_get_product( $variation_id ?: $product_id );
		if ( ! $product || ! WC()->cart ) {
			return $data;
		}
		$rows   = WC()->cart->get_cart();
		$rows[] = array( 'data' => $product, 'quantity' => $qty ?? 1 );
		$error  = self::stock_error( $rows );
		if ( $error ) {
			// Esta exceção também é tratada por WC_Cart::add_to_cart (formulário e AJAX clássicos).
			throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException( 'vic_combo_stock', esc_html( $error ), 400 );
		}
		return $data;
	}

	private static function update_error( $key, $row, $qty ) {
		if ( $qty <= $row['quantity'] ) {
			return '';
		}
		$rows = WC()->cart->get_cart();
		$rows[ $key ]['quantity'] = $qty;
		return self::stock_error( $rows );
	}

	public static function check_update( $valid, $key, $row, $qty ) {
		$error = $valid ? self::update_error( $key, $row, $qty ) : '';
		if ( $error ) {
			wc_add_notice( esc_html( $error ), 'error' );
			return false;
		}
		return $valid;
	}

	public static function check_api_update( $valid, $qty, $product, $row ) {
		$error = true === $valid ? self::update_error( $row['key'], $row, $qty ) : '';
		return $error ? new WP_Error( 'vic_combo_stock', esc_html( $error ) ) : $valid;
	}

	public static function validate_cart() {
		$error = self::stock_error( WC()->cart->get_cart() );
		if ( $error && ! wc_has_notice( esc_html( $error ), 'error' ) ) {
			wc_add_notice( esc_html( $error ), 'error' );
		}
	}

	public static function validate_api_cart( $errors, $cart ) {
		$error = self::stock_error( $cart->get_cart() );
		if ( $error ) {
			$errors->add( 'vic_combo_stock', esc_html( $error ) );
		}
	}

	private static function composition_text( $product ) {
		$names = array();
		foreach ( VIC_Combos::components( $product ) as $id => $units ) {
			$part = wc_get_product( $id );
			if ( $part ) {
				$names[] = sprintf( '%d × %s', $units, wp_strip_all_tags( $part->get_name() ) );
			}
		}
		return implode( ', ', $names );
	}

	public static function describe_item( $details, $row ) {
		if ( VIC_Combos::is_combo( $row['data'] ) ) {
			$details[] = array( 'key' => 'Itens do combo', 'value' => self::composition_text( $row['data'] ) );
		}
		return $details;
	}

	/** Substitui a embalagem genérica pelos pesos, medidas, classes e quantidades reais. */
	public static function shipping_packages( $packages ) {
		foreach ( $packages as &$package ) {
			$changed = false;
			foreach ( $package['contents'] as $key => $row ) {
				if ( ! VIC_Combos::is_combo( $row['data'] ) ) {
					continue;
				}
				$changed = true;
				unset( $package['contents'][ $key ] );
				$products = array();
				$sum      = 0;
				foreach ( VIC_Combos::components( $row['data'] ) as $id => $units ) {
					$product = wc_get_product( $id );
					if ( $product ) {
						$part_cost       = (float) $product->get_price() * $units;
						$sum            += $part_cost;
						$products[ $id ] = array( $product, $units, $part_cost );
					}
				}
				foreach ( $products as $id => list( $product, $units, $part_cost ) ) {
					if ( ! $product->needs_shipping() ) {
						continue;
					}
					$share  = $sum > 0 ? $part_cost / $sum : 0;
					$part   = $row;
					$is_var = $product->is_type( 'variation' );
					$part['key']          = $key . ':' . $id;
					$part['product_id']   = $is_var ? $product->get_parent_id() : $id;
					$part['variation_id'] = $is_var ? $id : 0;
					$part['variation']    = $is_var ? $product->get_variation_attributes() : array();
					$part['quantity']     = $units * $row['quantity'];
					// Alguns métodos de frete leem o preço unitário para o valor declarado.
					$part['data']         = clone $product;
					$part['data']->set_price( (float) $row['data']->get_price() * $share / $units );
					foreach ( array( 'line_total', 'line_subtotal', 'line_tax', 'line_subtotal_tax' ) as $field ) {
						$part[ $field ] = ( $row[ $field ] ?? 0 ) * $share;
					}
					foreach ( $row['line_tax_data'] ?? array() as $field => $rates ) {
						foreach ( $rates as $rate_id => $amount ) {
							$part['line_tax_data'][ $field ][ $rate_id ] = $amount * $share;
						}
					}
					$package['contents'][ $part['key'] ] = $part;
				}
			}
			if ( $changed ) {
				$package['contents_cost'] = array_sum( wp_list_pluck( $package['contents'], 'line_total' ) );
			}
		}
		return $packages;
	}

	/** Usado tanto no checkout clássico quanto na criação/atualização dos pedidos em blocos. */
	public static function add_components_to_order( $item, $cart_key, $row, $order ) {
		if ( ! VIC_Combos::is_combo( $row['data'] ) ) {
			return;
		}
		$components = VIC_Combos::components( $row['data'] );
		if ( count( $components ) < 2 ) {
			throw new Exception( 'A composição do combo foi alterada. Revise o carrinho.' );
		}
		$item->add_meta_data( 'Itens do combo', self::composition_text( $row['data'] ), true );
		foreach ( $components as $id => $units ) {
			$product = wc_get_product( $id );
			if ( ! $product || ! $product->is_purchasable() || ! $product->is_in_stock() ) {
				throw new Exception( 'Um produto do combo está indisponível. Revise o carrinho.' );
			}
			$part = new WC_Order_Item_Product();
			$part->set_product( $product );
			$part->set_quantity( $units * $row['quantity'] );
			$part->set_subtotal( 0 );
			$part->set_total( 0 );
			$part->add_meta_data( '_vic_component_of', $cart_key, true );
			$part->add_meta_data( 'Incluído no combo', $row['data']->get_name(), true );
			$order->add_item( $part );
		}
	}

	public static function customer_item_visible( $visible, $item ) {
		return $item->get_meta( '_vic_component_of' ) ? false : $visible;
	}

	public static function reorder_data( $data, $item ) {
		if ( $item->get_meta( '_vic_component_of' ) ) {
			$data['vic_skip_reorder_component'] = true;
		}
		return $data;
	}

	public static function skip_reordered_component( $valid, $product_id, $qty, $variation_id = 0, $variation = array(), $data = array() ) {
		return empty( $data['vic_skip_reorder_component'] ) && $valid;
	}
}
