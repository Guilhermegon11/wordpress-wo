<?php
/** Configuração da página de atacado no WordPress. */
defined( 'ABSPATH' ) || exit;

final class VIC_Wholesale_Admin {
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 30 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ), 40 );
		add_action( 'admin_post_vic_wholesale_save', array( __CLASS__, 'save' ) );
	}

	public static function menu() {
		add_submenu_page( 'woocommerce', 'Atacado', 'Atacado', 'manage_woocommerce', 'vic-atacado', array( __CLASS__, 'render' ) );
		if ( class_exists( 'VIG_Admin' ) ) {
			add_submenu_page( 'vi-gestor', 'Atacado', 'Atacado', 'manage_woocommerce', 'vic-atacado', array( __CLASS__, 'render' ) );
		}
	}

	public static function assets( $hook ) {
		if ( false === strpos( $hook, '_page_vic-atacado' ) ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_style( 'woocommerce_admin_styles' );
		wp_enqueue_script( 'wc-enhanced-select' );
		wp_enqueue_script( 'vic-wholesale-admin', VIC_Wholesale::asset( 'wholesale-admin.js' ), array( 'jquery', 'media-editor' ), VIC_VERSION, true );
		wp_enqueue_style( 'vic-wholesale-admin', VIC_Wholesale::asset( 'wholesale-admin.css' ), array(), VIC_VERSION );
	}

	private static function fields( $operation ) {
		echo '<input type="hidden" name="action" value="vic_wholesale_save"><input type="hidden" name="vic_operation" value="' . esc_attr( $operation ) . '">';
		wp_nonce_field( 'vic_wholesale_save', 'vic_nonce', false );
	}

	public static function render() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$banner = VIC_Wholesale::banner();
		$url = VIC_Wholesale::page_url();
		$id  = absint( get_option( VIC_Wholesale::PAGE_OPTION ) );
		$list_page = isset( $_GET['vic_pg'] ) ? max( 1, absint( $_GET['vic_pg'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification
		$list = VIC_Wholesale::products( $list_page, 20, true );
		$post_url = admin_url( 'admin-post.php' );
		?>
		<div class="wrap vic-wh-admin">
		<h1>Atacado</h1>
		<?php if ( isset( $_GET['vic_saved'] ) ) : ?><div class="notice notice-success is-dismissible"><p>Alterações salvas.</p></div><?php endif; ?>
		<?php if ( get_option( VIC_Wholesale_Route::BLOCKED_OPTION ) ) : ?>
			<div class="notice notice-warning inline"><p>O endereço /atacado pertence a uma página essencial da loja. Depois de liberar esse endereço em Páginas, clique em configurar.</p>
			<form method="post" action="<?php echo esc_url( $post_url ); ?>"><?php self::fields( 'create_page' ); ?><button class="button">Configurar /atacado</button></form></div>
		<?php endif; ?>
		<?php if ( $url ) : ?><p><a class="button" href="<?php echo esc_url( $url ); ?>">Abrir página de atacado</a> <code><?php echo esc_html( $url ); ?></code></p>
		<?php elseif ( $id && 'page' === get_post_type( $id ) && 'trash' !== get_post_status( $id ) ) : ?>
			<p>A página de atacado está em <?php echo esc_html( get_post_status_object( get_post_status( $id ) )->label ); ?>. <a href="<?php echo esc_url( get_edit_post_link( $id ) ); ?>">Editar página</a></p>
		<?php else : ?>
			<form method="post" action="<?php echo esc_url( $post_url ); ?>"><?php self::fields( 'create_page' ); ?><button class="button">Criar página de atacado</button></form>
		<?php endif; ?>
		<section class="vic-wh-box">
			<h2>Banner da página</h2>
			<form method="post" action="<?php echo esc_url( $post_url ); ?>">
				<?php self::fields( 'banner' ); ?>
				<div class="vic-wh-banner-form"><div>
				<p><label for="vic-wh-title">Título do banner</label><input type="text" id="vic-wh-title" name="vic_title" value="<?php echo esc_attr( $banner['title'] ); ?>" required></p>
				<p><label for="vic-wh-text">Texto abaixo do título</label><textarea id="vic-wh-text" name="vic_text" rows="3"><?php echo esc_textarea( $banner['text'] ); ?></textarea></p></div>
				<div><img id="vic-wh-preview" src="<?php echo esc_url( VIC_Wholesale::banner_url( $banner ) ); ?>" data-fallback="<?php echo esc_url( VIC_Wholesale::banner_url( array( 'image' => 0 ) ) ); ?>" alt="Imagem atual do banner de atacado">
				<input type="hidden" id="vic-wh-image" name="vic_image" value="<?php echo esc_attr( $banner['image'] ); ?>">
				<button type="button" id="vic-wh-pick" class="button">Escolher imagem</button>
				<button type="button" id="vic-wh-default" class="button-link" <?php disabled( ! $banner['image'] ); ?>>Usar imagem padrão</button>
				</div></div>
				<?php submit_button( 'Salvar banner', 'primary', '', false ); ?>
			</form>
		</section>
		<section class="vic-wh-box">
			<h2>Produtos do atacado</h2>
			<p>Selecione os produtos da categoria Atacado. As variações participam com o estoque de cada sabor. Deixe o preço em branco para usar o valor atual do produto ou da variação.</p>
			<form class="vic-wh-add" method="post" action="<?php echo esc_url( $post_url ); ?>">
				<?php self::fields( 'product' ); ?>
				<label>Produto <select class="wc-product-search" name="vic_product" required data-placeholder="Buscar por nome ou SKU" data-action="woocommerce_json_search_products"></select></label>
				<label>Preço de atacado por unidade (<?php echo esc_html( get_woocommerce_currency_symbol() ); ?>)
				<input name="vic_price" type="text" inputmode="decimal" placeholder="Usar preço cadastrado"></label>
				<button type="submit" class="button button-primary">Adicionar ao atacado</button>
			</form>
			<?php if ( $list->posts ) : ?>
			<table class="widefat striped"><thead><tr><th scope="col">Produto</th><th scope="col">Preço por unidade e ações</th></tr></thead><tbody>
			<?php foreach ( $list->posts as $product_id ) :
				$product = wc_get_product( $product_id );
				if ( ! $product ) { continue; }
				?>
				<tr><td><?php echo esc_html( $product->get_name() ); ?></td><td>
					<form class="vic-wh-row" method="post" action="<?php echo esc_url( $post_url ); ?>">
						<?php self::fields( 'product' ); ?>
						<input name="vic_product" type="hidden" value="<?php echo esc_attr( $product_id ); ?>">
						<input name="vic_pg" type="hidden" value="<?php echo esc_attr( $list_page ); ?>">
						<label class="screen-reader-text" for="vic-wh-price-<?php echo esc_attr( $product_id ); ?>">Preço de atacado de <?php echo esc_html( $product->get_name() ); ?></label>
						<input name="vic_price" id="vic-wh-price-<?php echo esc_attr( $product_id ); ?>" type="text" inputmode="decimal" placeholder="Preço cadastrado" value="<?php echo esc_attr( wc_format_localized_price( $product->get_meta( VIC_Wholesale::PRICE_META, true ) ) ); ?>">
						<button class="button">Salvar preço</button> <button type="submit" class="button-link-delete" name="vic_remove" value="1">Tirar do atacado</button>
					</form>
				</td></tr>
			<?php endforeach; ?></tbody></table>
			<?php if ( $list->max_num_pages > 1 ) : ?>
				<p><?php echo wp_kses_post( paginate_links( array( 'base' => admin_url( 'admin.php?page=vic-atacado&vic_pg=%#%' ), 'current' => $list_page, 'total' => $list->max_num_pages, 'prev_text' => 'Anterior', 'next_text' => 'Próxima' ) ) ); ?></p>
			<?php endif; ?>
			<?php else : ?><p>Nenhum produto nesta lista.</p><?php endif; ?>
		</section></div>
		<?php
	}

	public static function save() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'Sem permissão.', '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'vic_wholesale_save', 'vic_nonce' );
		$op = sanitize_key( wp_unslash( $_POST['vic_operation'] ?? '' ) );
		switch ( $op ) {
			case 'create_page':
				$id = VIC_Wholesale::install_page();
				if ( ! $id || is_wp_error( $id ) ) {
					wp_die( esc_html( is_wp_error( $id ) ? $id->get_error_message() : 'Não foi possível criar a página de atacado.' ) );
				}
				break;
			case 'banner':
				$image = absint( $_POST['vic_image'] ?? 0 );
				$title = sanitize_text_field( wp_unslash( $_POST['vic_title'] ?? '' ) );
				$text = sanitize_textarea_field( wp_unslash( $_POST['vic_text'] ?? '' ) );
				if ( '' === $title || ( $image && ! wp_attachment_is_image( $image ) ) ) {
					wp_die( 'Informe o título e escolha uma imagem válida.' );
				}
				update_option( VIC_Wholesale::SETTINGS_OPTION, array( 'title' => $title, 'text' => $text, 'image' => $image ), false );
				break;
			case 'product':
				self::save_product();
				break;
			default:
				wp_die( 'Ação desconhecida.' );
		}
		$url = add_query_arg( array( 'page' => 'vic-atacado', 'vic_saved' => 1, 'vic_pg' => max( 1, absint( $_POST['vic_pg'] ?? 1 ) ) ), admin_url( 'admin.php' ) );
		wp_safe_redirect( $url, 303 );
		exit;
	}

	private static function save_product() {
		$id = filter_var( $_POST['vic_product'] ?? 0, FILTER_VALIDATE_INT, array( 'options' => array( 'min_range' => 1 ) ) );
		$product = $id ? wc_get_product( $id ) : false;
		if ( ! $product || ! current_user_can( 'edit_post', $id ) ) {
			wp_die( 'Selecione um produto que você possa editar.', '', array( 'response' => 403 ) );
		}
		$term = get_term_by( 'slug', VIC_Wholesale::TERM_SLUG, 'product_cat' );
		if ( ! empty( $_POST['vic_remove'] ) ) {
			if ( $term && is_wp_error( wp_remove_object_terms( $id, (int) $term->term_id, 'product_cat' ) ) ) {
				wp_die( 'Não foi possível retirar o produto da categoria Atacado.' );
			}
			$product->delete_meta_data( VIC_Wholesale::PRICE_META );
			$product->save_meta_data();
			wc_delete_product_transients( $id );
			return;
		}
		if ( ! VIC_Wholesale::supported( $product ) ) {
			wp_die( 'Escolha um produto simples ou variável. Combos são vendidos separadamente na loja.' );
		}
		$price = isset( $_POST['vic_price'] ) && is_string( $_POST['vic_price'] ) ? trim( wp_unslash( $_POST['vic_price'] ) ) : '';
		if ( '' !== $price && ! preg_match( '/^\d+(?:[,.]\d+)?$/D', $price ) ) {
			wp_die( 'Informe um preço válido, por exemplo 49,90, ou deixe em branco.' );
		}
		if ( ! $term ) {
			$new = wp_insert_term( 'Atacado', 'product_cat', array( 'slug' => VIC_Wholesale::TERM_SLUG ) );
			$term_id = is_wp_error( $new ) ? (int) $new->get_error_data( 'term_exists' ) : (int) $new['term_id'];
			if ( ! $term_id ) {
				wp_die( 'Não foi possível criar a categoria Atacado.' );
			}
		} else {
			$term_id = $term->term_id;
		}
		if ( is_wp_error( wp_add_object_terms( $id, (int) $term_id, 'product_cat' ) ) ) {
			wp_die( 'Não foi possível incluir o produto na categoria Atacado.' );
		}
		if ( '' === $price ) {
			$product->delete_meta_data( VIC_Wholesale::PRICE_META );
		} else {
			$product->update_meta_data( VIC_Wholesale::PRICE_META, wc_format_decimal( str_replace( ',', '.', $price ), wc_get_price_decimals() ) );
		}
		$product->save_meta_data();
		wc_delete_product_transients( $id );
	}
}
