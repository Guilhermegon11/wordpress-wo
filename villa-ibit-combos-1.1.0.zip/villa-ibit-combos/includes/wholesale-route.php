<?php
/** Página canônica de atacado, inclusive em lojas atualizadas a partir da versão 1.0.0. */
defined( 'ABSPATH' ) || exit;

final class VIC_Wholesale_Route {
	const VERSION_OPTION = 'vic_wholesale_route_version';
	const LEGACY_OPTION  = 'vic_wholesale_old_page';
	const BLOCKED_OPTION = 'vic_wholesale_reserved_page';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'upgrade' ), 25 );
		add_filter( 'request', array( __CLASS__, 'resolve' ) );
		add_filter( 'page_link', array( __CLASS__, 'permalink' ), 10, 3 );
		add_action( 'template_redirect', array( __CLASS__, 'redirect' ), 3 );
		add_filter( 'redirect_canonical', array( __CLASS__, 'keep_url' ) );
		add_filter( 'the_content', array( __CLASS__, 'include_catalog' ), 99 );
	}

	public static function upgrade() {
		if ( '1' !== get_option( self::VERSION_OPTION ) ) {
			self::install();
		}
	}

	/** A restrição evita que o atacado ocupe acidentalmente a home, carrinho ou checkout. */
	private static function reserved( $id ) {
		foreach ( array( 'page_on_front', 'page_for_posts', 'woocommerce_shop_page_id', 'woocommerce_cart_page_id', 'woocommerce_checkout_page_id', 'woocommerce_myaccount_page_id', 'wp_page_for_privacy_policy' ) as $option ) {
			if ( (int) get_option( $option ) === $id ) {
				return true;
			}
		}
		return false;
	}

	private static function has_catalog( $page ) {
		// Durante a ativação o shortcode ainda pode não ter sido registrado no WordPress.
		$pattern = '/(?<!\[)\[villa_ibit_atacado\b[^\]]*\]/';
		return preg_match( $pattern, $page->post_content ) || preg_match( $pattern, (string) get_post_meta( $page->ID, '_elementor_data', true ) );
	}

	public static function install() {
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		if ( ! WP_Upgrader::create_lock( 'vic_wholesale_install', 60 ) ) {
			return new WP_Error( 'vic_locked', 'A página de atacado já está sendo configurada.' );
		}
		try {
			$old_id = (int) get_option( VIC_Wholesale::PAGE_OPTION );
			$old    = $old_id ? get_post( $old_id ) : null;
			if ( ! $old || 'page' !== $old->post_type || 'trash' === $old->post_status || self::reserved( $old_id ) || ( 'atacado' !== get_page_uri( $old ) && ! self::has_catalog( $old ) ) ) {
				$old = null;
			}
			$page = get_page_by_path( 'atacado', OBJECT, array( 'page' ) );
			if ( $page && self::reserved( $page->ID ) ) {
				update_option( self::BLOCKED_OPTION, $page->ID, false );
				update_option( self::VERSION_OPTION, '1', false );
				return new WP_Error( 'vic_reserved', 'O endereço /atacado já pertence a uma página essencial da loja. Altere o endereço dessa página antes de configurar o atacado.' );
			}
			// Salve o endereço anterior antes de mudar o slug, inclusive para instalações com permalinks simples.
			if ( $old && 'atacado' !== get_page_uri( $old ) ) {
				update_option( self::LEGACY_OPTION, array( 'id' => $old->ID, 'path' => get_page_uri( $old ) ), false );
			}
			if ( $page && 'trash' !== $page->post_status ) {
				$id = $page->ID;
			} elseif ( $old ) {
				$id = wp_update_post( array( 'ID' => $old->ID, 'post_name' => 'atacado', 'post_parent' => 0 ), true );
			} else {
				$id = wp_insert_post( array(
					'post_type' => 'page', 'post_status' => 'publish',
					'post_name' => 'atacado', 'post_title' => 'Atacado',
					'post_content' => '[villa_ibit_atacado]',
				), true );
			}
			if ( $id && ! is_wp_error( $id ) ) {
				update_option( VIC_Wholesale::PAGE_OPTION, (int) $id, false );
				delete_option( self::BLOCKED_OPTION );
				update_option( self::VERSION_OPTION, '1', false );
			}
			return $id;
		} finally {
			WP_Upgrader::release_lock( 'vic_wholesale_install' );
		}
	}

	public static function url() {
		$id = (int) get_option( VIC_Wholesale::PAGE_OPTION );
		if ( ! $id || 'page' !== get_post_type( $id ) || 'publish' !== get_post_status( $id ) ) {
			return '';
		}
		if ( get_option( self::BLOCKED_OPTION ) ) {
			return self::reserved( $id ) ? '' : (string) get_permalink( $id );
		}
		return home_url( '/atacado' );
	}

	public static function permalink( $url, $id, $sample ) {
		if ( ! $sample && (int) get_option( VIC_Wholesale::PAGE_OPTION ) === $id && ! get_option( self::BLOCKED_OPTION ) && 'publish' === get_post_status( $id ) ) {
			return home_url( '/atacado' );
		}
		return $url;
	}

	private static function path() {
		return wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH );
	}

	private static function matches( $relative ) {
		return untrailingslashit( (string) self::path() ) === untrailingslashit( (string) wp_parse_url( home_url( '/' . $relative ), PHP_URL_PATH ) );
	}

	private static function old_path( $legacy ) {
		if ( empty( $legacy['path'] ) || ! self::matches( $legacy['path'] ) ) {
			return false;
		}
		// Um novo proprietário pode reaproveitar o slug depois que a página é movida.
		$owner = get_page_by_path( $legacy['path'], OBJECT, array( 'page' ) );
		return ! $owner || ( (int) $legacy['id'] === $owner->ID && self::has_catalog( $owner ) && ! self::reserved( $owner->ID ) );
	}

	private static function old_id( $id, $legacy ) {
		if ( ! $id || $id !== (int) ( $legacy['id'] ?? 0 ) ) {
			return false;
		}
		$page = get_post( $id );
		return $page && 'page' === $page->post_type && (string) get_page_uri( $page ) === ( $legacy['path'] ?? '' ) && self::has_catalog( $page ) && ! self::reserved( $id );
	}

	public static function resolve( $vars ) {
		$id = (int) get_option( VIC_Wholesale::PAGE_OPTION );
		if ( ! $id || is_admin() || isset( $vars['rest_route'] ) || isset( $_GET['elementor-preview'] ) || ! empty( $vars['preview'] ) || get_option( self::BLOCKED_OPTION ) ) {
			return $vars;
		}
		$legacy = (array) get_option( self::LEGACY_OPTION, array() );
		$requested_id = $vars['page_id'] ?? $vars['p'] ?? 0;
		if ( self::matches( 'atacado' ) || self::old_path( $legacy ) || ( is_scalar( $requested_id ) && self::old_id( absint( $requested_id ), $legacy ) ) ) {
			unset( $vars['error'], $vars['pagename'], $vars['name'], $vars['p'], $vars['post_type'], $vars['attachment'], $vars['attachment_id'], $vars['product'], $vars['product_cat'] );
			$vars['page_id'] = $id;
		}
		return $vars;
	}

	public static function redirect() {
		$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
		if ( ! in_array( $method, array( 'GET', 'HEAD' ), true ) || ! is_page() || is_preview() || is_feed() || isset( $_GET['elementor-preview'] ) || get_option( self::BLOCKED_OPTION ) ) {
			return;
		}
		$id     = get_queried_object_id();
		$active = (int) get_option( VIC_Wholesale::PAGE_OPTION );
		$legacy = (array) get_option( self::LEGACY_OPTION, array() );
		if ( $id !== $active && ! self::old_id( $id, $legacy ) ) {
			return;
		}
		$url = self::url();
		if ( ! $url || ( self::path() === wp_parse_url( $url, PHP_URL_PATH ) && ! isset( $_GET['page_id'] ) && ! isset( $_GET['p'] ) ) ) {
			return;
		}
		// O WooCommerce já pode ter executado add-to-cart ou remove_item em wp_loaded.
		// Leve somente paginação e atribuição para que o navegador não repita nenhuma ação.
		$query = array();
		foreach ( $_GET as $key => $value ) {
			if ( is_string( $value ) && is_string( $key ) && ( preg_match( '/^utm_[a-z0-9_]+$/D', $key ) || in_array( $key, array( 'gclid', 'fbclid', 'msclkid', 'gbraid', 'wbraid' ), true ) ) ) {
				$query[ $key ] = sanitize_text_field( wp_unslash( $value ) );
			}
		}
		if ( isset( $_GET['vic_pg'] ) && is_string( $_GET['vic_pg'] ) ) {
			$query['vic_pg'] = max( 1, absint( $_GET['vic_pg'] ) );
		}
		$url = add_query_arg( $query, $url );
		wp_safe_redirect( $url, 301, 'Villa Ibit' );
		exit;
	}

	public static function keep_url( $redirect ) {
		$id = (int) get_option( VIC_Wholesale::PAGE_OPTION );
		return $id && self::matches( 'atacado' ) && ! get_option( self::BLOCKED_OPTION ) && is_page( $id ) ? false : $redirect;
	}

	/** Reaproveite uma página editorial sem gravar sobre seu texto, blocos ou dados do Elementor. */
	public static function include_catalog( $content ) {
		$id = (int) get_option( VIC_Wholesale::PAGE_OPTION );
		if ( ! $id || ! is_page( $id ) || get_the_ID() !== $id || ! in_the_loop() || ! is_main_query() || post_password_required( $id ) || is_feed() || get_option( self::BLOCKED_OPTION ) || false !== strpos( $content, 'class="vic-atacado"' ) ) {
			return $content;
		}
		return $content . VIC_Wholesale::render();
	}
}
