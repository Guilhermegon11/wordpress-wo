<?php
/** Links da vitrine para a página de compra no atacado. */
defined( 'ABSPATH' ) || exit;

function vic_kits_url() {
	return VIC_Combo_Category::url();
}

add_filter( 'vi_tab_items', function ( $items ) {
	foreach ( $items as $index => $item ) {
		if ( 'atacado' === $item['key'] && ( $url = VIC_Wholesale::page_url() ) ) {
			$items[ $index ]['url']     = $url;
			$items[ $index ]['current'] = $item['current'] || ( is_page() && get_permalink( get_queried_object_id() ) === $url );
		} elseif ( 'combos' === $item['key'] && ( $url = vic_kits_url() ) ) {
			$items[ $index ]['label']   = 'Combo';
			$items[ $index ]['url']     = $url;
			$items[ $index ]['current'] = is_product_category( VIC_Combo_Category::SLUG );
		}
	}
	return $items;
} );

// A faixa da home e o menu automático usam o link da categoria de atacado.
add_filter( 'term_link', function ( $link, $term, $taxonomy ) {
	if ( 'product_cat' !== $taxonomy || 'atacado' !== $term->slug || is_admin() || ! did_action( 'wp' ) || is_feed() || wp_is_json_request() ) {
		return $link;
	}
	return VIC_Wholesale::page_url() ?: $link;
}, 10, 3 );

// Os menus personalizados do tema também dão acesso às duas vitrines.
add_filter( 'wp_nav_menu_objects', function ( $items, $args ) {
	if ( ! defined( 'VI_THEME_VER' ) || ! in_array( $args->theme_location, array( 'principal', 'abas' ), true ) ) {
		return $items;
	}
	$state = VIC_Combo_Category::state();
	$url = VIC_Combo_Category::url();
	if ( empty( $state['id'] ) || ! $url ) {
		return $items;
	}
	$term_ids = array_merge( array( $state['id'] ), $state['aliases'] );
	$urls = array( untrailingslashit( $url ) );
	foreach ( $state['old_slugs'] as $slug ) {
		// O termo antigo pode ter sido renomeado, ou pode continuar registrado para widgets.
		$urls[] = untrailingslashit( preg_replace( '~(?<=[/=])combos(?=[/&#?]|$)~', $slug, $url ) );
		$term = get_term_by( 'slug', $slug, 'product_cat' );
		if ( $term ) {
			$old_link = get_term_link( $term );
			if ( ! is_wp_error( $old_link ) ) {
				$urls[] = untrailingslashit( $old_link );
			}
		}
	}
	$first = 0;
	$duplicates = array();
	foreach ( $items as $key => $item ) {
		$is_combo = 'product_cat' === $item->object && in_array( (int) $item->object_id, $term_ids, true );
		if ( ! $is_combo && ! in_array( untrailingslashit( $item->url ), $urls, true ) ) {
			continue;
		}
		if ( ! $first ) {
			$first = (int) $item->ID;
			$items[ $key ] = clone $item;
			$items[ $key ]->title = 'Combo';
			$items[ $key ]->url = $url;
		} else {
			$duplicates[] = (int) $item->ID;
			unset( $items[ $key ] );
		}
	}
	foreach ( $items as $key => $item ) {
		if ( in_array( (int) $item->menu_item_parent, $duplicates, true ) && $first !== (int) $item->ID ) {
			$items[ $key ] = clone $item;
			$items[ $key ]->menu_item_parent = $first;
		}
	}
	return $items;
}, 10, 2 );

add_filter( 'wp_nav_menu_items', function ( $html, $args ) {
	if ( ! defined( 'VI_THEME_VER' ) || ! in_array( $args->theme_location, array( 'principal', 'abas' ), true ) ) {
		return $html;
	}
	$links = array( 'Atacado' => VIC_Wholesale::page_url(), 'Combo' => vic_kits_url() );
	$tags  = new WP_HTML_Tag_Processor( $html );
	while ( $tags->next_tag( 'a' ) ) {
		$href = $tags->get_attribute( 'href' );
		foreach ( $links as $label => $url ) {
			if ( $url && untrailingslashit( (string) $href ) === untrailingslashit( $url ) ) {
				unset( $links[ $label ] );
			}
		}
	}
	foreach ( $links as $label => $url ) {
		if ( $url ) {
			$html .= '<li class="menu-item"><a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a></li>';
		}
	}
	return $html;
}, 10, 2 );

add_action( 'admin_enqueue_scripts', function () {
	if ( ! class_exists( 'VIG_Admin' ) || ! VIG_Admin::is_screen() || ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	wp_enqueue_script( 'vic-gestor-nav', plugins_url( 'assets/gestor-nav.js', VIC_FILE ), array(), VIC_VERSION, true );
	wp_localize_script( 'vic-gestor-nav', 'vicGestorLinks', array(
		'Combos promocionais' => VIC_Editor::url(),
		'Atacado'             => admin_url( 'admin.php?page=vic-atacado' ),
	) );
} );
