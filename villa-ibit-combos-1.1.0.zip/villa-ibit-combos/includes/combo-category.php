<?php
/** Categoria única da vitrine e compatibilidade com os cadastros do plugin 1.0.0. */
defined( 'ABSPATH' ) || exit;

final class VIC_Combo_Category {
	const TAX = 'product_cat';
	const SLUG = 'combos'; // O tema Villa Ibit também usa este slug no cartão da home.
	const OPTION = 'vic_combo_category_101';
	const BATCH_HOOK = 'vic_combo_copy_category';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'upgrade' ), 25 );
		add_action( self::BATCH_HOOK, array( __CLASS__, 'copy_memberships' ) );
		add_action( 'set_object_terms', array( __CLASS__, 'sync_legacy_assignment' ), 12, 5 );
		add_filter( 'get_terms_args', array( __CLASS__, 'list_args' ), 20, 2 );
		add_filter( 'get_the_terms', array( __CLASS__, 'product_terms' ), 20, 3 );
		add_action( 'template_redirect', array( __CLASS__, 'redirect_old_archive' ), 1 );
	}

	public static function state() {
		return (array) get_option( self::OPTION, array() );
	}

	/** Prioriza o ID histórico da loja e conserva a descrição, miniatura, ordem e filhos. */
	public static function upgrade() {
		$state = self::state();
		if ( ! empty( $state['id'] ) ) {
			return (int) $state['id'];
		}
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		if ( ! WP_Upgrader::create_lock( 'vic_combo_category_install', 120 ) ) {
			return new WP_Error( 'vic_category_updating', 'A categoria Combo está sendo preparada. Tente salvar novamente em instantes.' );
		}
		try {
			wp_cache_delete( self::OPTION, 'options' );
			wp_cache_delete( 'notoptions', 'options' );
			$state = self::state();
			return ! empty( $state['id'] ) ? (int) $state['id'] : self::prepare( $state );
		} finally {
			WP_Upgrader::release_lock( 'vic_combo_category_install' );
		}
	}

	private static function prepare( $state ) {
		$known = array();
		foreach ( array( self::SLUG, 'combo', 'kits-promocionais' ) as $slug ) {
			$term = get_term_by( 'slug', $slug, self::TAX );
			if ( $term ) {
				$known[ $slug ] = (int) $term->term_id;
			}
		}
		$id = reset( $known );
		$slugs = array_unique( array_merge( $state['old_slugs'] ?? array(), array_keys( array_diff_key( $known, array( self::SLUG => true ) ) ) ) );
		// Guarda o slug antes da troca: uma interrupção entre a renomeação e a conclusão é recuperável.
		if ( $slugs && $slugs !== ( $state['old_slugs'] ?? array() ) ) {
			update_option( self::OPTION, array( 'old_slugs' => $slugs ), false );
		}
		$result = $id ? wp_update_term( $id, self::TAX, array( 'name' => 'Combo', 'slug' => self::SLUG ) )
			: wp_insert_term( 'Combo', self::TAX, array( 'slug' => self::SLUG ) );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$id    = (int) $result['term_id'];
		$state = array( 'id' => $id, 'aliases' => array_values( array_diff( $known, array( $id ) ) ), 'old_slugs' => $slugs );
		if ( $state['aliases'] && ! wp_next_scheduled( self::BATCH_HOOK ) ) {
			wp_schedule_single_event( time() + 60, self::BATCH_HOOK );
		}
		update_option( self::OPTION, $state, false );
		self::clear_home_cache();
		if ( $state['aliases'] ) {
			self::copy_memberships();
		}
		return $id;
	}

	public static function for_product( $categories ) {
		$id = self::upgrade();
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		if ( ! term_exists( $id, self::TAX ) ) {
			delete_option( self::OPTION );
			$id = self::upgrade();
			if ( is_wp_error( $id ) ) {
				return $id;
			}
		}
		$categories[] = $id;
		return array_values( array_unique( $categories ) );
	}

	private static function clear_home_cache() {
		if ( function_exists( 'vi_cache_flush' ) ) {
			vi_cache_flush();
		}
		$home = (int) get_option( 'page_on_front' );
		if ( $home ) {
			delete_post_meta( $home, '_elementor_element_cache' );
			clean_post_cache( $home );
		}
	}

	public static function copy_memberships() {
		$state = self::state();
		if ( empty( $state['aliases'] ) || ! term_exists( (int) $state['id'], self::TAX ) ) {
			return;
		}
		// A busca exclui os produtos já migrados. Pode ser retomada após falha ou concorrência.
		$products = get_posts( array(
			'post_type' => 'product', 'post_status' => array_values( get_post_stati() ),
			'fields' => 'ids', 'numberposts' => 75, 'orderby' => 'ID', 'order' => 'ASC',
			'tax_query' => array(
				array( 'taxonomy' => self::TAX, 'terms' => $state['aliases'], 'include_children' => true ),
				array( 'taxonomy' => self::TAX, 'terms' => array( $state['id'] ), 'operator' => 'NOT IN', 'include_children' => false ),
			),
		) );
		$retry = count( $products ) === 75;
		foreach ( $products as $product_id ) {
			// A relação antiga pode estar em um widget, cupom ou integração. Preservamos essa referência.
			if ( is_wp_error( wp_add_object_terms( $product_id, (int) $state['id'], self::TAX ) ) ) {
				$retry = true;
			}
		}
		if ( $retry && ! wp_next_scheduled( self::BATCH_HOOK ) ) {
			wp_schedule_single_event( time() + 30, self::BATCH_HOOK );
		}
		if ( $products ) {
			self::clear_home_cache();
		}
	}

	public static function sync_legacy_assignment( $object_id, $terms, $tt_ids, $taxonomy, $append ) {
		if ( self::TAX !== $taxonomy ) {
			return;
		}
		$state = self::state();
		if ( empty( $state['aliases'] ) || 'product' !== get_post_type( $object_id ) || has_term( (int) $state['id'], self::TAX, $object_id ) ) {
			return;
		}
		$related = $state['aliases'];
		foreach ( $state['aliases'] as $alias_id ) {
			$children = get_term_children( $alias_id, self::TAX );
			if ( ! is_wp_error( $children ) ) {
				$related = array_merge( $related, $children );
			}
		}
		if ( has_term( $related, self::TAX, $object_id ) ) {
			wp_add_object_terms( $object_id, (int) $state['id'], self::TAX );
		}
	}

	/** Não esconder referências pedidas por ID, slug ou relação nos editores e integrações. */
	public static function list_args( $args, $taxonomies ) {
		if ( array( self::TAX ) !== array_values( $taxonomies ) || is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ! empty( $args['slug'] ) || ! empty( $args['name'] ) || ! empty( $args['object_ids'] ) || ! empty( $args['include'] ) || ! empty( $args['search'] ) ) {
			return $args;
		}
		// A árvore interna usa id=>parent, mesmo quando um widget pede exibição de categorias vazias.
		if ( empty( $args['hide_empty'] ) && ! in_array( $args['fields'], array( 'all', 'names' ), true ) ) {
			return $args;
		}
		$state = self::state();
		if ( ! empty( $state['aliases'] ) ) {
			$args['exclude'] = array_unique( array_merge( wp_parse_id_list( $args['exclude'] ), $state['aliases'] ) );
		}
		return $args;
	}

	public static function product_terms( $terms, $post_id, $taxonomy ) {
		if ( self::TAX !== $taxonomy || ! is_array( $terms ) || is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return $terms;
		}
		$state = self::state();
		if ( empty( $state['aliases'] ) || ! in_array( $state['id'], wp_list_pluck( $terms, 'term_id' ), true ) ) {
			return $terms;
		}
		return array_values( array_filter( $terms, function ( $term ) use ( $state ) {
			return ! in_array( $term->term_id, $state['aliases'], true );
		} ) );
	}

	public static function url() {
		$term = get_term_by( 'slug', self::SLUG, self::TAX );
		$link = $term ? get_term_link( $term ) : '';
		return is_wp_error( $link ) ? '' : $link;
	}

	public static function redirect_old_archive() {
		global $wp;
		if ( ! isset( $wp->query_vars ) || is_feed() || ! in_array( $_SERVER['REQUEST_METHOD'] ?? 'GET', array( 'GET', 'HEAD' ), true ) ) {
			return;
		}
		$vars = $wp->query_vars;
		$slug = $vars[ self::TAX ] ?? ( ( $vars['taxonomy'] ?? '' ) === self::TAX ? $vars['term'] ?? '' : '' );
		if ( ! is_string( $slug ) || '' === $slug || isset( $vars['product'] ) || isset( $vars['name'] ) || ( ! is_tax( self::TAX ) && ! is_404() ) ) {
			return;
		}
		$state = self::state();
		if ( in_array( basename( $slug ), $state['old_slugs'] ?? array(), true ) && ( $url = self::url() ) ) {
			if ( ! empty( $vars['paged'] ) ) {
				$url = add_query_arg( 'paged', absint( $vars['paged'] ), $url );
			}
			wp_safe_redirect( $url, 301 );
			exit;
		}
	}
}
