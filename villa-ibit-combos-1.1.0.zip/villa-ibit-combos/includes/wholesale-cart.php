<?php
defined( 'ABSPATH' ) || exit;

final class VIC_Wholesale_Cart {
	public static function init() {
		add_filter( 'woocommerce_get_cart_item_from_session', array( __CLASS__, 'restore_price' ), 20 );
		add_action( 'woocommerce_before_calculate_totals', array( __CLASS__, 'set_prices' ), 20 );
		add_action( 'woocommerce_check_cart_items', array( __CLASS__, 'classic_errors' ) );
		add_action( 'woocommerce_store_api_cart_errors', array( __CLASS__, 'store_errors' ), 10, 2 );
		add_filter( 'woocommerce_get_item_data', array( __CLASS__, 'display_item' ), 10, 2 );
		add_action( 'woocommerce_checkout_create_order_line_item', array( __CLASS__, 'order_item' ), 10, 3 );
		add_filter( 'woocommerce_order_again_cart_item_data', array( __CLASS__, 'order_again' ), 10, 2 );
	}

	private static function marked( $row ) {
		return isset( $row['vic_wholesale'] ) && in_array( $row['vic_wholesale'], array( 1, '1' ), true );
	}

	/** Trabalha com o produto do catálogo, nunca com um preço enviado pelo navegador. */
	private static function priced_row( $row ) {
		$product = wc_get_product( $row['data']->get_id() );
		if ( ! $product ) {
			return $row;
		}

		$price = VIC_Wholesale::price( $product );
		// Duas linhas do mesmo produto podem compartilhar o objeto que o WooCommerce carrega.
		$row['data'] = clone $row['data'];
		$row['data']->set_price( null === $price ? $product->get_price() : $price );
		$row['vic_wholesale_price'] = null === $price ? null : (string) $price;
		return $row;
	}

	public static function restore_price( $row ) {
		if ( ! self::marked( $row ) ) {
			return $row;
		}
		$old_price = $row['vic_wholesale_price'] ?? null;
		$row       = self::priced_row( $row );
		if ( $old_price !== ( $row['vic_wholesale_price'] ?? null ) ) {
			// O núcleo recalcula os totais após restaurar a sessão quando este valor é nulo.
			WC()->session->set( 'cart_totals', null );
		}
		return $row;
	}

	public static function set_prices( $cart ) {
		foreach ( $cart->get_cart() as $key => $row ) {
			if ( self::marked( $row ) ) {
				$cart->cart_contents[ $key ] = self::priced_row( $row );
			}
		}
	}

	private static function errors( $cart ) {
		$errors = new WP_Error();
		$count  = 0;
		foreach ( $cart->get_cart() as $row ) {
			if ( ! self::marked( $row ) ) {
				continue;
			}
			$product = wc_get_product( $row['data']->get_id() );
			if ( ! $product || null === VIC_Wholesale::price( $product ) ) {
				$errors->add( 'vic_wholesale_unavailable', sprintf( __( '“%s” saiu do atacado. Remova esse item do carrinho para continuar.', 'villa-ibit-combos' ), wp_strip_all_tags( $row['data']->get_name() ) ) );
				continue;
			}
			if ( $product->is_sold_individually() && self::units_in_cart( $cart, $product->get_id() ) > 1 ) {
				$errors->add( 'vic_wholesale_individual', sprintf( __( '“%s” aceita apenas uma unidade por pedido. Confira as quantidades no varejo e no atacado.', 'villa-ibit-combos' ), wp_strip_all_tags( $product->get_name() ) ) );
				continue;
			}
			$quantity = (int) $row['quantity'];
			if ( $quantity < 1 || (float) $quantity !== (float) $row['quantity'] ) {
				$errors->add( 'vic_wholesale_quantity', __( 'Use quantidades inteiras para os produtos de atacado.', 'villa-ibit-combos' ) );
				continue;
			}
			$count += $quantity;
		}
		if ( ! $errors->has_errors() && $count > 0 && $count < VIC_Wholesale::MIN_QTY ) {
			$missing = VIC_Wholesale::MIN_QTY - $count;
			$errors->add(
				'vic_wholesale_minimum',
				sprintf(
					_n( 'O mínimo no atacado é de %1$d unidades. Adicione mais %2$d unidade de atacado para finalizar.', 'O mínimo no atacado é de %1$d unidades. Adicione mais %2$d unidades de atacado para finalizar.', $missing, 'villa-ibit-combos' ),
					VIC_Wholesale::MIN_QTY,
					$missing
				)
			);
		}
		return $errors;
	}

	public static function units_in_cart( $cart, $product_id ) {
		$total = 0;
		foreach ( $cart->get_cart() as $row ) {
			if ( $product_id === $row['data']->get_id() ) {
				$total += $row['quantity'];
			}
		}
		return $total;
	}

	public static function classic_errors() {
		if ( ! WC()->cart ) {
			return;
		}
		foreach ( self::errors( WC()->cart )->get_error_messages() as $error ) {
			$message = esc_html( $error );
			if ( ! wc_has_notice( $message, 'error' ) ) {
				wc_add_notice( $message, 'error' );
			}
		}
	}

	public static function store_errors( $errors, $cart ) {
		$errors->merge_from( self::errors( $cart ) );
	}

	public static function display_item( $data, $row ) {
		if ( self::marked( $row ) ) {
			$data[] = array(
				'key'     => __( 'Modalidade', 'villa-ibit-combos' ),
				'value'   => __( 'Atacado', 'villa-ibit-combos' ),
				'raw_key' => 'vic_wholesale',
			);
		}
		return $data;
	}

	public static function order_item( $item, $cart_item_key, $row ) {
		if ( self::marked( $row ) ) {
			$item->add_meta_data( '_vic_wholesale', 1, true );
			$item->add_meta_data( __( 'Modalidade', 'villa-ibit-combos' ), __( 'Atacado', 'villa-ibit-combos' ), true );
		}
	}

	public static function order_again( $data, $item ) {
		if ( $item->get_meta( '_vic_wholesale' ) ) {
			$data['vic_wholesale'] = 1;
		}
		return $data;
	}
}
