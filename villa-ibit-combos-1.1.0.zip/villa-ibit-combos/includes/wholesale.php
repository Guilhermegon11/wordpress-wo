<?php
/** Catálogo de atacado e inclusão de produtos pelo preço dessa modalidade. */
defined( 'ABSPATH' ) || exit;
require_once __DIR__ . '/wholesale-route.php';
require_once __DIR__ . '/wholesale-cart.php';
require_once __DIR__ . '/wholesale-admin.php';

class VIC_Wholesale {
	const MIN_QTY = 10;
	const TERM_SLUG = 'atacado';
	const PAGE_OPTION = 'vic_wholesale_page';
	const SETTINGS_OPTION = 'vic_wholesale_banner';
	const PRICE_META = '_vic_wholesale_price';

	public static function init() {
		add_shortcode( 'villa_ibit_atacado', array( __CLASS__, 'render' ) );
		add_action( 'template_redirect', array( __CLASS__, 'protect_page_cache' ), 0 );
		add_action( 'template_redirect', array( __CLASS__, 'add_to_cart' ) );
		add_action( 'init', array( __CLASS__, 'lock_ajax_submission' ), -1 );
		add_action( 'wc_ajax_vic_wholesale_add', array( __CLASS__, 'ajax_add_to_cart' ) );
		add_filter( 'woocommerce_add_to_cart_fragments', array( __CLASS__, 'summary_fragments' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		VIC_Wholesale_Route::init();
		VIC_Wholesale_Admin::init();
		VIC_Wholesale_Cart::init();
	}

	public static function install_page() {
		return VIC_Wholesale_Route::install();
	}

	public static function page_url() {
		return VIC_Wholesale_Route::url();
	}

	public static function asset( $name ) {
		return plugins_url( 'assets/' . $name, VIC_FILE );
	}

	private static function is_catalog_page() {
		if ( ! is_page() ) {
			return false;
		}
		$page = get_queried_object();
		if ( ! $page instanceof WP_Post ) {
			return false;
		}
		return (int) get_option( self::PAGE_OPTION ) === $page->ID || has_shortcode( $page->post_content, 'villa_ibit_atacado' ) || false !== strpos( (string) get_post_meta( $page->ID, '_elementor_data', true ), 'villa_ibit_atacado' );
	}

	public static function protect_page_cache() {
		if ( self::is_catalog_page() ) {
			wc_nocache_headers();
			// A primeira inclusão e uma eventual retransmissão devem usar o mesmo carrinho.
			if ( WC()->session && is_callable( array( WC()->session, 'set_customer_session_cookie' ) ) ) {
				WC()->session->set_customer_session_cookie( true );
			}
		}
	}

	public static function enqueue() {
		if ( self::is_catalog_page() ) {
			wp_enqueue_style( 'vic-wholesale', self::asset( 'wholesale.css' ), array(), VIC_VERSION );
			wp_enqueue_script( 'vic-wholesale-cart', self::asset( 'wholesale-cart.js' ), array( 'jquery' ), VIC_VERSION, true );
			wp_localize_script( 'vic-wholesale-cart', 'vicWholesaleCart', array( 'endpoint' => WC_AJAX::get_endpoint( 'vic_wholesale_add' ) ) );
		}
	}

	public static function banner() {
		$value = (array) get_option( self::SETTINGS_OPTION, array() );
		return wp_parse_args( $value, array( 'image' => 0, 'title' => 'Atacado', 'text' => 'Para lojistas e revendedores.' ) );
	}

	public static function banner_url( $settings ) {
		$src = wp_get_attachment_image_url( absint( $settings['image'] ), 'full' );
		if ( ! $src && function_exists( 'vi_option_image' ) ) {
			$src = vi_option_image( 'wholesale_image', 'natureza/atacado-folhagem.jpg', 'full' );
		}
		return $src ?: self::asset( 'wholesale-banner.jpg' );
	}

	public static function supported( $product ) {
		return $product instanceof WC_Product && $product->is_type( array( 'simple', 'variable' ) ) && ! ( class_exists( 'VIC_Combos' ) && VIC_Combos::is_combo( $product ) );
	}

	private static function eligible_parent( $product ) {
		return self::supported( $product ) && 'publish' === $product->get_status() && ! post_password_required( $product->get_id() ) && has_term( self::TERM_SLUG, 'product_cat', $product->get_id() );
	}

	/** Obtém o preço atual pelo cadastro, inclusive após reabrir uma sessão de carrinho. */
	public static function price( $product ) {
		if ( ! $product instanceof WC_Product ) {
			return null;
		}
		$parent = $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;
		if ( ! self::eligible_parent( $parent ) || $product->is_type( 'variable' ) || 'publish' !== $product->get_status() || ! $product->is_purchasable() ) {
			return null;
		}
		if ( $product->is_type( 'variation' ) && ! $product->variation_is_active() ) {
			return null;
		}
		$special = $parent->get_meta( self::PRICE_META, true );
		$price   = '' === $special ? $product->get_price() : $special;
		return is_numeric( $price ) && $price >= 0 ? (string) $price : null;
	}

	public static function products( $page, $limit, $admin = false ) {
		$tax = array(
			array( 'taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => self::TERM_SLUG, 'include_children' => false ),
		);
		if ( ! $admin ) {
			// WooCommerce pode gerar produto simples sem termo product_type. Exclua apenas tipos não atendidos.
			$types = array_diff( array_keys( wc_get_product_types() ), array( 'simple', 'variable' ) );
			if ( $types ) {
				$tax[] = array( 'taxonomy' => 'product_type', 'field' => 'slug', 'terms' => $types, 'operator' => 'NOT IN' );
			}
			if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
				$tax[] = array( 'taxonomy' => 'product_visibility', 'field' => 'name', 'terms' => 'outofstock', 'operator' => 'NOT IN' );
			}
		}
		$args = array(
			'post_type' => 'product', 'post_status' => $admin ? array( 'publish', 'draft', 'pending', 'private' ) : 'publish',
			'fields' => 'ids', 'posts_per_page' => $limit, 'paged' => $page,
			'orderby' => array( 'menu_order' => 'ASC', 'title' => 'ASC', 'ID' => 'ASC' ),
			'tax_query' => $tax, // phpcs:ignore WordPress.DB.SlowDBQuery
		);
		if ( ! $admin ) {
			$args['has_password'] = false;
		}
		return new WP_Query( $args );
	}

	public static function render() {
		if ( ! WC()->cart ) {
			return '';
		}
		$banner = self::banner();
		$current = isset( $_GET['vic_pg'] ) ? max( 1, absint( $_GET['vic_pg'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification
		$query = self::products( $current, 12 );
		$page_url = get_permalink( get_queried_object_id() ) ?: self::page_url();
		$summary = self::cart_summary();
		ob_start();
		?>
		<section class="vic-atacado" aria-label="Compra no atacado">
			<header class="vic-atacado__banner">
				<img src="<?php echo esc_url( self::banner_url( $banner ) ); ?>" alt="" fetchpriority="high">
				<div><h2><?php echo esc_html( $banner['title'] ); ?></h2><p><?php echo esc_html( $banner['text'] ); ?></p></div>
			</header>
			<?php wc_print_notices(); ?>
			<div class="vic-atacado__resumo">
				<div>
					<strong data-vic-summary-title><?php echo esc_html( $summary['summaryTitle'] ); ?></strong>
					<p data-vic-summary-detail><?php echo esc_html( $summary['summaryDetail'] ); ?></p>
				</div>
				<a href="<?php echo esc_url( wc_get_cart_url() ); ?>">Ver carrinho</a>
			</div>
			<div class="vic-atacado__grid">
			<?php
			$count = 0;
			foreach ( $query->posts as $id ) {
				$product = wc_get_product( $id );
				if ( self::eligible_parent( $product ) ) {
					self::card( $product, $page_url, $current );
					++$count;
				}
			}
			if ( ! $count ) {
				echo '<p>Nenhum produto de atacado disponível nesta página.</p>';
			}
			?>
			</div>
			<?php if ( $query->max_num_pages > 1 ) : ?>
				<nav aria-label="Páginas do atacado"><?php echo wp_kses_post( paginate_links( array( 'base' => add_query_arg( 'vic_pg', '%#%', $page_url ), 'format' => '', 'current' => $current, 'total' => $query->max_num_pages, 'prev_text' => 'Anterior', 'next_text' => 'Próxima' ) ) ); ?></nav>
			<?php endif; ?>
		</section>
		<?php
		return ob_get_clean();
	}

	private static function card( $product, $page_url, $page ) {
		$id = $product->get_id();
		$special = $product->get_meta( self::PRICE_META, true );
		$variable = $product->is_type( 'variable' );
		$qty_id = wp_unique_id( 'vic-qty-' . $id . '-' );
		// O estoque de um produto variável pode ser controlado individualmente por sabor.
		$max_qty = $variable && ! $product->is_sold_individually() ? -1 : $product->get_max_purchase_quantity();
		if ( $variable && '' === $special ) {
			$min = $product->get_variation_price( 'min', true );
			$max = $product->get_variation_price( 'max', true );
			$price = '' === $min ? '' : ( $min === $max ? wc_price( $min ) : wc_format_price_range( $min, $max ) );
		} else {
			$raw = '' === $special ? $product->get_price() : $special;
			$price = is_numeric( $raw ) ? wc_price( wc_get_price_to_display( $product, array( 'price' => $raw ) ) ) : '';
		}
		?>
		<article class="vic-atacado__card">
			<div class="vic-atacado__foto"><?php echo wp_kses_post( $product->get_image( 'woocommerce_thumbnail' ) ); ?></div>
			<div class="vic-atacado__info"><h3><?php echo esc_html( $product->get_name() ); ?></h3>
			<?php if ( $price ) : ?><div class="vic-atacado__preco"><?php echo wp_kses_post( $price ); ?> <small>/ unidade</small></div><?php endif; ?>
			<?php if ( $price && $product->is_purchasable() && $product->is_in_stock() ) : ?>
			<form class="vic-atacado__form" method="post" action="<?php echo esc_url( $page > 1 ? add_query_arg( 'vic_pg', $page, $page_url ) : $page_url ); ?>">
				<input type="hidden" name="vic_wholesale_product" value="<?php echo esc_attr( $id ); ?>">
				<input type="hidden" name="vic_wholesale_nonce" value="<?php echo esc_attr( wp_create_nonce( 'vic_wholesale_add' ) ); ?>">
				<?php if ( $variable ) : foreach ( $product->get_variation_attributes() as $key => $options ) :
					$field = wp_unique_id( 'vic-' . $id . '-' . sanitize_title( $key ) . '-' );
					$label = wc_attribute_label( $key, $product );
					?>
					<div class="vic-atacado__campo">
						<label for="<?php echo esc_attr( $field ); ?>"><?php echo esc_html( $label ); ?></label>
						<?php
						wc_dropdown_variation_attribute_options( array(
							'id'               => $field,
							'options'          => $options,
							'attribute'        => $key,
							'product'          => $product,
							'required'         => true,
							'show_option_none' => 0 === strcasecmp( $label, 'Sabor' ) ? 'Escolha o sabor' : 'Escolha uma opção',
						) );
						?>
					</div>
				<?php endforeach; endif; ?>
				<div class="vic-atacado__acoes">
					<div class="vic-atacado__campo">
						<label for="<?php echo esc_attr( $qty_id ); ?>">Quantidade</label>
						<div class="vic-atacado__quantidade">
							<button type="button" data-vic-step="-1" aria-label="Diminuir quantidade" aria-controls="<?php echo esc_attr( $qty_id ); ?>" hidden>−</button>
							<input id="<?php echo esc_attr( $qty_id ); ?>" type="number" min="1" step="1" inputmode="numeric" name="vic_quantity" required value="1"<?php if ( $max_qty > 0 ) : ?> max="<?php echo esc_attr( $max_qty ); ?>"<?php endif; ?>>
							<button type="button" data-vic-step="1" aria-label="Aumentar quantidade" aria-controls="<?php echo esc_attr( $qty_id ); ?>" hidden>+</button>
						</div>
					</div>
					<button class="vic-atacado__adicionar" type="submit" aria-label="<?php echo esc_attr( 'Adicionar ' . $product->get_name() . ' ao carrinho de atacado' ); ?>">Adicionar</button>
				</div>
				<p class="vic-atacado__feedback" data-vic-feedback role="status" aria-live="polite" aria-atomic="true"></p>
			</form>
			<?php else : ?><p>Indisponível no momento</p><?php endif; ?>
			</div>
		</article>
		<?php
	}

	private static function cart_summary() {
		$quantity = 0;
		foreach ( WC()->cart->get_cart() as $row ) {
			if ( ! empty( $row['vic_wholesale'] ) ) {
				$quantity += (int) $row['quantity'];
			}
		}
		$remaining = max( 0, self::MIN_QTY - $quantity );
		$title  = sprintf( __( 'Mínimo de %d unidades', 'villa-ibit-combos' ), self::MIN_QTY );
		$detail = __( 'Você pode misturar produtos e sabores.', 'villa-ibit-combos' );
		if ( $quantity ) {
			$title  = sprintf( _n( '%d unidade de atacado no carrinho', '%d unidades de atacado no carrinho', $quantity, 'villa-ibit-combos' ), $quantity );
			$detail = $remaining ? sprintf( _n( 'Falta %d unidade para finalizar.', 'Faltam %d unidades para finalizar.', $remaining, 'villa-ibit-combos' ), $remaining ) : __( 'Você já atingiu o mínimo do atacado.', 'villa-ibit-combos' );
		}
		return array(
			'quantity' => $quantity,
			'minimum' => self::MIN_QTY,
			'remaining' => $remaining,
			'summaryTitle' => $title,
			'summaryDetail' => $detail,
		);
	}

	/** Remover um sabor pela gaveta também altera o mínimo mostrado no catálogo. */
	public static function summary_fragments( $fragments ) {
		if ( ! WC()->cart ) {
			return $fragments;
		}
		$summary = self::cart_summary();
		$fragments['[data-vic-summary-title]'] = '<strong data-vic-summary-title>' . esc_html( $summary['summaryTitle'] ) . '</strong>';
		$fragments['[data-vic-summary-detail]'] = '<p data-vic-summary-detail>' . esc_html( $summary['summaryDetail'] ) . '</p>';
		return $fragments;
	}

	private static function request_id() {
		$id = $_POST['vic_request_id'] ?? '';
		return is_string( $id ) && preg_match( '/^[a-f0-9]{32}$/D', $id ) ? $id : '';
	}

	/** Trave antes que o WooCommerce leia a sessão, inclusive entre abas ou workers. */
	public static function lock_ajax_submission() {
		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || 'vic_wholesale_add' !== ( $_GET['wc-ajax'] ?? '' ) || ! self::request_id() ) {
			return;
		}
		$nonce = $_POST['vic_wholesale_nonce'] ?? '';
		if ( ! is_string( $nonce ) || ! wp_verify_nonce( $nonce, 'vic_wholesale_add' ) ) {
			return;
		}
		$cookie = (string) apply_filters( 'woocommerce_cookie', 'wp_woocommerce_session_' . COOKIEHASH );
		$owner = get_current_user_id() ?: ( $_COOKIE[ $cookie ] ?? self::request_id() );
		$lock = 'vic_wh_cart_' . md5( is_scalar( $owner ) ? (string) $owner : self::request_id() );
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		if ( ! WP_Upgrader::create_lock( $lock, MINUTE_IN_SECONDS ) ) {
			wp_send_json_error( array( 'message' => 'Há uma inclusão em andamento. Confira o carrinho antes de adicionar novamente.' ), 409 );
		}
		add_action( 'shutdown', static function () use ( $lock ) {
			WP_Upgrader::release_lock( $lock );
		}, PHP_INT_MAX );
	}

	/** POST clássico e AJAX passam pelas mesmas verificações e filtros da loja. */
	private static function add_requested_item( $request_id = '' ) {
		try {
			if ( ! isset( $_POST['vic_wholesale_nonce'] ) || ! is_string( $_POST['vic_wholesale_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vic_wholesale_nonce'] ) ), 'vic_wholesale_add' ) ) {
				throw new Exception( 'A página de atacado expirou. Atualize e tente novamente.' );
			}
			$receipts = (array) WC()->session->get( 'vic_wholesale_receipts', array() );
			if ( $request_id && isset( $receipts[ $request_id ] ) ) {
				return $receipts[ $request_id ];
			}
			$id = filter_var( $_POST['vic_wholesale_product'] ?? 0, FILTER_VALIDATE_INT, array( 'options' => array( 'min_range' => 1 ) ) );
			$product = $id ? wc_get_product( $id ) : false;
			$qty = filter_var( $_POST['vic_quantity'] ?? 0, FILTER_VALIDATE_INT, array( 'options' => array( 'min_range' => 1 ) ) );
			if ( ! self::eligible_parent( $product ) || ! $qty ) {
				throw new Exception( 'Confira o produto e informe uma quantidade inteira a partir de 1.' );
			}
			$attributes = array();
			$variation_id = 0;
			if ( $product->is_type( 'variable' ) ) {
				foreach ( $product->get_variation_attributes() as $name => $options ) {
					$key = wc_variation_attribute_name( $name );
					$value = isset( $_POST[ $key ] ) && is_string( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : '';
					if ( '' === $value ) {
						throw new Exception( 'Escolha todas as opções do produto.' );
					}
					$attributes[ $key ] = taxonomy_exists( $name ) ? sanitize_title( $value ) : html_entity_decode( wc_clean( $value ), ENT_QUOTES, get_bloginfo( 'charset' ) );
				}
				$variation_id = WC_Data_Store::load( 'product' )->find_matching_product_variation( $product, $attributes );
				if ( ! $variation_id ) {
					throw new Exception( 'Essa combinação está indisponível. Escolha outra opção.' );
				}
			}
			$selected = $variation_id ? wc_get_product( $variation_id ) : $product;
			if ( null === self::price( $selected ) || ! $selected->is_in_stock() ) {
				throw new Exception( 'Este produto está indisponível para atacado.' );
			}
			if ( $selected->is_sold_individually() && ( $qty > 1 || VIC_Wholesale_Cart::units_in_cart( WC()->cart, $selected->get_id() ) > 0 ) ) {
				throw new Exception( 'Este produto permite apenas uma unidade por pedido.' );
			}
			$existing = WC()->cart->get_cart();
			$errors_before = wc_notice_count( 'error' );
			$line = array( 'vic_wholesale' => 1 );
			$allowed = apply_filters( 'woocommerce_add_to_cart_validation', true, $product->get_id(), $qty, $variation_id, $attributes, $line );
			$key = $allowed ? WC()->cart->add_to_cart( $product->get_id(), $qty, $variation_id, $attributes, $line ) : false;
			if ( ! $key ) {
				if ( wc_notice_count( 'error' ) <= $errors_before ) {
					throw new Exception( 'Não foi possível adicionar este produto. Confira a quantidade e as opções.' );
				}
				return false;
			}

			$row = WC()->cart->get_cart_item( $key );
			$added = $row['quantity'] - ( $existing[ $key ]['quantity'] ?? 0 );
			$name = $product->get_name();
			if ( $attributes ) {
				$name .= ' (' . wc_get_formatted_variation( $row['variation'], true, false ) . ')';
			}
			$name = wp_strip_all_tags( wp_specialchars_decode( $name, ENT_QUOTES ) );
			$message = sprintf( _n( '%1$d unidade de %2$s adicionada ao carrinho.', '%1$d unidades de %2$s adicionadas ao carrinho.', $added, 'villa-ibit-combos' ), $added, $name );
			if ( $request_id ) {
				$receipts[ $request_id ] = $message;
				WC()->session->set( 'vic_wholesale_receipts', array_slice( $receipts, -32, null, true ) );
			}
			if ( wp_doing_ajax() ) {
				do_action( 'woocommerce_ajax_added_to_cart', $product->get_id() );
			}
			return $message;
		} catch ( Exception $error ) {
			wc_add_notice( $error->getMessage(), 'error' );
			return false;
		}
	}

	public static function add_to_cart() {
		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || ! isset( $_POST['vic_wholesale_product'] ) || ! WC()->cart ) {
			return;
		}
		$message = self::add_requested_item();
		if ( false !== $message ) {
			wc_add_notice( esc_html( $message ), 'success' );
		}
		$target = self::page_url() ?: home_url( '/' );
		$page = isset( $_GET['vic_pg'] ) ? absint( $_GET['vic_pg'] ) : 0;
		if ( $page > 1 ) {
			$target = add_query_arg( 'vic_pg', $page, $target );
		}
		wp_safe_redirect( $target, 303 );
		exit;
	}

	public static function ajax_add_to_cart() {
		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
			header( 'Allow: POST' );
			wp_send_json_error( array( 'message' => 'Envie o produto pelo formulário de atacado.' ), 405 );
		}
		if ( ! WC()->cart || ! WC()->session ) {
			wp_send_json_error( array( 'message' => 'O carrinho está indisponível. Atualize a página para continuar.' ), 503 );
		}

		// Separe os avisos deste envio daqueles que o cliente ainda verá no carrinho ou checkout.
		$previous = wc_get_notices();
		wc_clear_notices();
		$message = self::add_requested_item( self::request_id() );
		if ( false === $message ) {
			$errors = wp_list_pluck( wc_get_notices( 'error' ), 'notice' );
			$error = html_entity_decode( wp_strip_all_tags( implode( ' ', $errors ) ), ENT_QUOTES, get_bloginfo( 'charset' ) );
			wc_set_notices( $previous );
			wp_send_json_error( array( 'message' => $error ?: 'Não foi possível adicionar este produto.' ), 422 );
		}

		ob_start();
		woocommerce_mini_cart();
		$mini_cart = ob_get_clean();
		$data = self::cart_summary();
		$data['message'] = $message;
		$data['fragments'] = apply_filters( 'woocommerce_add_to_cart_fragments', array( 'div.widget_shopping_cart_content' => '<div class="widget_shopping_cart_content">' . $mini_cart . '</div>' ) );
		$data['cart_hash'] = WC()->cart->get_cart_hash();
		wc_set_notices( $previous );
		if ( is_callable( array( WC()->session, 'save_data' ) ) ) {
			WC()->session->save_data();
		}
		wp_send_json_success( $data );
	}
}
