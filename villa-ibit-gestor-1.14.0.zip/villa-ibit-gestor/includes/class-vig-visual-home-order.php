<?php
/** Ordem das seções que o Visual Villa Ibit publica como blocos de shortcode. */
defined( 'ABSPATH' ) || exit;

final class VIG_Visual_Home_Order {
	public static function init() {
		add_filter( 'the_content', array( __CLASS__, 'order_front_page' ), 8 );
	}

	/** Equivalências entre as seções do Visual e as opções do Gestor. */
	public static function section_key( $section ) {
		$keys = array(
			'categories' => 'categories',
			'products'   => 'tabs',
			'spotlight'  => 'spotlight',
			'offers'     => 'deals',
			'brands'     => 'brands',
			'wholesale'  => 'wholesale',
			'social'     => 'social',
		);
		return is_string( $section ) ? ( $keys[ sanitize_key( $section ) ] ?? '' ) : '';
	}

	/** O Visual gera um bloco independente por seção, no primeiro nível. */
	private static function slots( array $blocks ) {
		$slots   = array();
		$pattern = '/^' . get_shortcode_regex( array( 'viv_section' ) ) . '$/D';
		foreach ( $blocks as $index => $block ) {
			if ( 'core/shortcode' !== $block['blockName'] || ! preg_match( $pattern, trim( $block['innerHTML'] ), $match ) ) {
				continue;
			}
			if ( '' !== $match[1] || '' !== ( $match[5] ?? '' ) || '' !== $match[6] ) {
				continue;
			}
			$attributes = shortcode_parse_atts( $match[3] );
			$key        = self::section_key( $attributes['section'] ?? '' );
			if ( $key ) {
				$slots[ $index ] = $key;
			}
		}
		return $slots;
	}

	public static function current_order( $post_content ) {
		if ( ! is_string( $post_content ) || false === strpos( $post_content, '[viv_section' ) ) {
			return array();
		}
		return array_values( array_unique( self::slots( parse_blocks( $post_content ) ) ) );
	}

	public static function order_front_page( $content ) {
		if ( ! class_exists( 'VIV_Layouts' ) || false === strpos( $content, '[viv_section' ) || ! is_front_page() || ! is_main_query() || ! in_the_loop() || get_the_ID() !== get_queried_object_id() ) {
			return $content;
		}
		$order = vi_gestor_get( 'home_order' );
		if ( ! is_array( $order ) || ! $order ) {
			return $content;
		}

		$blocks = parse_blocks( $content );
		$slots  = self::slots( $blocks );
		if ( count( $slots ) < 2 ) {
			return $content;
		}

		// Troca somente blocos reconhecidos entre si, inclusive suas personalizações.
		$sorted = array();
		foreach ( VIG_Settings::home_section_order( $order ) as $key ) {
			foreach ( array_keys( $slots, $key, true ) as $index ) {
				$sorted[] = $index;
			}
		}
		$positions = array_keys( $slots );
		if ( $positions === $sorted ) {
			return $content;
		}
		$output = $blocks;
		foreach ( $positions as $i => $position ) {
			$output[ $position ] = $blocks[ $sorted[ $i ] ];
		}
		return serialize_blocks( $output );
	}
}
