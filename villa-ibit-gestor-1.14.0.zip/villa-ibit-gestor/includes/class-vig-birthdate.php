<?php
/**
 * Data de nascimento no cadastro e no checkout (bloqueia menores de 18 anos).
 *
 * Funciona no checkout clássico e no checkout em blocos. A data declarada fica salva
 * no cliente e em cada pedido, e aparece na tela do pedido.
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;

class VIG_Birthdate {

	const MIN_AGE  = 18;
	const KEY      = 'billing_birthdate';
	const BLOCK_ID = 'villa-ibit/birthdate';

	/* ================================================================ *
	 * Regras (funções puras, sem depender do WordPress)
	 * ================================================================ */

	/**
	 * Converte "DD/MM/AAAA" (ou "AAAA-MM-DD") em data. Retorna null se a data não existir.
	 *
	 * @param string $str Texto digitado.
	 * @return DateTimeImmutable|null
	 */
	public static function parse( $str ) {
		$str = trim( (string) $str );
		if ( preg_match( '#^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{4})$#', $str, $m ) ) {
			list( , $d, $mo, $y ) = $m;
		} elseif ( preg_match( '#^(\d{4})-(\d{2})-(\d{2})$#', $str, $m ) ) {
			list( , $y, $mo, $d ) = $m;
		} elseif ( preg_match( '#^(\d{2})(\d{2})(\d{4})$#', $str, $m ) ) {
			list( , $d, $mo, $y ) = $m;
		} else {
			return null;
		}
		$d  = (int) $d;
		$mo = (int) $mo;
		$y  = (int) $y;
		if ( ! checkdate( $mo, $d, $y ) ) {
			return null;
		}
		return new DateTimeImmutable( sprintf( '%04d-%02d-%02d', $y, $mo, $d ) );
	}

	/**
	 * Idade completa em anos numa data de referência (padrão: hoje).
	 */
	public static function age( DateTimeImmutable $birth, $today = null ) {
		$today = $today instanceof DateTimeImmutable ? $today : new DateTimeImmutable( 'today' );
		return (int) $birth->diff( $today )->y * ( $birth <= $today ? 1 : -1 );
	}

	/**
	 * Valida a data e a idade mínima.
	 *
	 * @return string '' quando está tudo certo; 'invalid' | 'future' | 'minor' | 'empty'.
	 */
	public static function check( $str, $min = self::MIN_AGE, $today = null ) {
		if ( '' === trim( (string) $str ) ) {
			return 'empty';
		}
		$birth = self::parse( $str );
		if ( ! $birth ) {
			return 'invalid';
		}
		$today = $today instanceof DateTimeImmutable ? $today : new DateTimeImmutable( 'today' );
		if ( $birth > $today ) {
			return 'future';
		}
		$age = self::age( $birth, $today );
		if ( $age > 120 ) {
			return 'invalid';
		}
		return $age < $min ? 'minor' : '';
	}

	/**
	 * Data no formato de exibição (DD/MM/AAAA) ou '' se inválida.
	 */
	public static function format( $str ) {
		$birth = self::parse( $str );
		return $birth ? $birth->format( 'd/m/Y' ) : '';
	}

	/**
	 * Deixa no formato DD/MM/AAAA; se não der para entender, mantém o texto (para a validação avisar).
	 */
	public static function normalize( $str ) {
		$formatted = self::format( $str );
		return $formatted ? $formatted : trim( (string) $str );
	}

	/**
	 * Mensagem de erro para o cliente.
	 */
	public static function message( $code ) {
		switch ( $code ) {
			case 'empty':
				return __( 'Informe sua data de nascimento.', 'villa-ibit-gestor' );
			case 'minor':
				return sprintf( __( 'Você precisa ter %d anos ou mais para comprar nesta loja.', 'villa-ibit-gestor' ), self::MIN_AGE );
			case 'future':
			case 'invalid':
				return __( 'Data de nascimento inválida. Use o formato DD/MM/AAAA.', 'villa-ibit-gestor' );
		}
		return '';
	}

	/* ================================================================ *
	 * Integração com o WooCommerce
	 * ================================================================ */

	public static function enabled() {
		return function_exists( 'vig_value' ) ? (bool) vig_value( 'birth_required', 0 ) : true;
	}

	public static function init() {
		// Painel: mostra a data no pedido nativo do WooCommerce (mesmo se a regra estiver desligada).
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( __CLASS__, 'admin_order' ) );

		if ( ! self::enabled() ) {
			return;
		}

		// Checkout clássico.
		add_filter( 'woocommerce_billing_fields', array( __CLASS__, 'billing_field' ), 30 );
		add_action( 'woocommerce_after_checkout_validation', array( __CLASS__, 'validate_checkout' ), 10, 2 );
		add_filter( 'woocommerce_process_checkout_field_' . self::KEY, array( __CLASS__, 'normalize' ) );

		// Checkout em blocos.
		add_action( 'woocommerce_init', array( __CLASS__, 'register_block_field' ) );

		// Cadastro (Minha conta e página Entrar / Cadastrar).
		add_action( 'woocommerce_register_form', array( __CLASS__, 'register_form' ) );
		add_filter( 'woocommerce_registration_errors', array( __CLASS__, 'validate_register' ), 10, 3 );
		add_action( 'woocommerce_created_customer', array( __CLASS__, 'save_register' ) );

		// Minha conta › Detalhes da conta.
		add_action( 'woocommerce_edit_account_form', array( __CLASS__, 'account_form' ) );
		add_action( 'woocommerce_save_account_details_errors', array( __CLASS__, 'validate_account' ), 10, 2 );
		add_action( 'woocommerce_save_account_details', array( __CLASS__, 'save_account' ) );

		// Máscara DD/MM/AAAA.
		add_action( 'wp_footer', array( __CLASS__, 'mask_script' ), 30 );
	}

	/**
	 * Atributos comuns do campo.
	 */
	private static function attrs() {
		return array(
			'inputmode'    => 'numeric',
			'autocomplete' => 'bday',
			'maxlength'    => '10',
			'data-vig-bday' => '1',
		);
	}

	public static function billing_field( $fields ) {
		$fields[ self::KEY ] = array(
			'type'              => 'text',
			'label'             => __( 'Data de nascimento', 'villa-ibit-gestor' ),
			'placeholder'       => __( 'DD/MM/AAAA', 'villa-ibit-gestor' ),
			'required'          => true,
			'class'             => array( 'form-row-first', 'vig-bday-row' ),
			'priority'          => 120,
			'custom_attributes' => self::attrs(),
			'description'       => sprintf( __( 'Venda só para maiores de %d anos.', 'villa-ibit-gestor' ), self::MIN_AGE ),
		);
		return $fields;
	}

	public static function validate_checkout( $data, $errors ) {
		$code = self::check( isset( $data[ self::KEY ] ) ? $data[ self::KEY ] : '' );
		if ( $code && 'empty' !== $code ) { // "vazio" o próprio WooCommerce já avisa (campo obrigatório).
			$errors->add( 'vig_birthdate', self::message( $code ), array( 'id' => self::KEY ) );
		}
	}

	public static function register_block_field() {
		if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
			return;
		}
		woocommerce_register_additional_checkout_field(
			array(
				'id'                => self::BLOCK_ID,
				'label'             => __( 'Data de nascimento (DD/MM/AAAA)', 'villa-ibit-gestor' ),
				'location'          => 'contact',
				'type'              => 'text',
				'required'          => true,
				'attributes'        => array(
					'autocomplete' => 'bday',
					'inputmode'    => 'numeric',
					'maxLength'    => 10,
				),
				'sanitize_callback' => function ( $value ) {
					return sanitize_text_field( self::normalize( $value ) );
				},
				'validate_callback' => function ( $value ) {
					$code = self::check( $value );
					return $code ? new WP_Error( 'vig_birthdate', self::message( $code ) ) : true;
				},
			)
		);
	}

	/**
	 * Campo HTML reutilizado no cadastro e na conta.
	 */
	private static function input_html( $value ) {
		$attrs = '';
		foreach ( self::attrs() as $k => $v ) {
			$attrs .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
		}
		echo '<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide vig-bday-row">';
		echo '<label for="reg_' . esc_attr( self::KEY ) . '">' . esc_html__( 'Data de nascimento', 'villa-ibit-gestor' ) . '&nbsp;<span class="required" aria-hidden="true">*</span></label>';
		echo '<input type="text" class="woocommerce-Input input-text" name="' . esc_attr( self::KEY ) . '" id="reg_' . esc_attr( self::KEY ) . '" value="' . esc_attr( $value ) . '" placeholder="' . esc_attr__( 'DD/MM/AAAA', 'villa-ibit-gestor' ) . '" required' . $attrs . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<span class="description">' . esc_html( sprintf( __( 'Venda só para maiores de %d anos.', 'villa-ibit-gestor' ), self::MIN_AGE ) ) . '</span>';
		echo '</p>';
	}

	private static function posted() {
		return isset( $_POST[ self::KEY ] ) ? sanitize_text_field( wp_unslash( $_POST[ self::KEY ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	}

	public static function register_form() {
		self::input_html( self::posted() );
	}

	public static function validate_register( $errors, $username, $email ) {
		$code = self::check( self::posted() );
		if ( $code ) {
			$errors->add( 'vig_birthdate', self::message( $code ) );
		}
		return $errors;
	}

	public static function save_register( $customer_id ) {
		$value = self::format( self::posted() );
		if ( $value ) {
			update_user_meta( $customer_id, self::KEY, $value );
		}
	}

	public static function account_form() {
		$value = self::posted();
		if ( '' === $value ) {
			$value = (string) get_user_meta( get_current_user_id(), self::KEY, true );
		}
		self::input_html( $value );
	}

	public static function validate_account( $errors, $user ) {
		$code = self::check( self::posted() );
		if ( $code ) {
			$errors->add( 'vig_birthdate', self::message( $code ) );
		}
	}

	public static function save_account( $user_id ) {
		$value = self::format( self::posted() );
		if ( $value ) {
			update_user_meta( $user_id, self::KEY, $value );
		}
	}

	/**
	 * Data e idade de um pedido (checkout clássico ou em blocos).
	 *
	 * @param WC_Order $order Pedido.
	 * @return array{date:string,age:int}|null
	 */
	public static function from_order( $order ) {
		$raw = (string) $order->get_meta( '_' . self::KEY );
		if ( '' === $raw ) {
			$raw = (string) $order->get_meta( '_wc_other/' . self::BLOCK_ID );
		}
		$birth = self::parse( $raw );
		if ( ! $birth ) {
			return null;
		}
		return array( 'date' => $birth->format( 'd/m/Y' ), 'age' => self::age( $birth ) );
	}

	public static function admin_order( $order ) {
		$b = self::from_order( $order );
		if ( $b ) {
			echo '<p><strong>' . esc_html__( 'Data de nascimento:', 'villa-ibit-gestor' ) . '</strong> ' . esc_html( $b['date'] ) . ' (' . esc_html( sprintf( _n( '%d ano', '%d anos', $b['age'], 'villa-ibit-gestor' ), $b['age'] ) ) . ')</p>';
		}
	}

	/**
	 * Insere as barras enquanto o cliente digita (só nas páginas com o campo).
	 */
	public static function mask_script() {
		if ( ! function_exists( 'is_checkout' ) || ! ( is_checkout() || is_account_page() || is_page( 'entrar' ) ) ) {
			return;
		}
		?>
		<script>
		(function () {
			function mask(el) {
				var v = el.value.replace(/\D/g, '').slice(0, 8), out = v;
				if (v.length > 4) { out = v.slice(0, 2) + '/' + v.slice(2, 4) + '/' + v.slice(4); }
				else if (v.length > 2) { out = v.slice(0, 2) + '/' + v.slice(2); }
				el.value = out;
			}
			document.addEventListener('input', function (e) {
				var el = e.target;
				if (el && el.matches && (el.matches('[data-vig-bday]') || el.id === 'contact-villa-ibit-birthdate' || el.name === 'villa-ibit/birthdate')) {
					if (e.inputType && e.inputType.indexOf('delete') === 0) { return; }
					mask(el);
				}
			});
		})();
		</script>
		<?php
	}
}
