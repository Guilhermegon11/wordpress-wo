<?php
/**
 * Configurações da loja (lidas pelo tema Villa Ibit).
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;

class VIG_Settings {

	const MAX_SLIDES = 5;

	public static function init() {
		add_action( 'admin_post_vig_save_settings', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_vig_enable_gateway', array( __CLASS__, 'enable_gateway' ) );
		add_action( 'admin_post_vig_classic_checkout', array( __CLASS__, 'classic_checkout' ) );
	}

	private static function tabs() {
		return array(
			'loja'   => __( 'Loja e contato', 'villa-ibit-gestor' ),
			'banner' => __( 'Banner da home', 'villa-ibit-gestor' ),
			'home'   => __( 'Seções da home', 'villa-ibit-gestor' ),
			'pix'    => __( 'PIX e checkout', 'villa-ibit-gestor' ),
			'idade'  => __( 'Verificação 18+', 'villa-ibit-gestor' ),
			'avisos' => __( 'Avisos de venda', 'villa-ibit-gestor' ),
			'painel' => __( 'Painel', 'villa-ibit-gestor' ),
		);
	}

	/* ---------- campos ---------- */
	private static function text( $key, $label, $help = '', $type = 'text' ) {
		$id = 'vig-' . $key;
		echo '<div class="vig-field"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label><input id="' . esc_attr( $id ) . '" type="' . esc_attr( $type ) . '" name="vig[' . esc_attr( $key ) . ']" value="' . esc_attr( (string) vig_value( $key, '' ) ) . '"' . ( 'number' === $type ? ' step="0.5" min="0" max="90"' : '' ) . '>' . ( $help ? '<p class="vig-help">' . esc_html( $help ) . '</p>' : '' ) . '</div>';
	}

	private static function textarea( $key, $label, $help = '' ) {
		$id = 'vig-' . $key;
		echo '<div class="vig-field"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label><textarea id="' . esc_attr( $id ) . '" rows="3" name="vig[' . esc_attr( $key ) . ']">' . esc_textarea( (string) vig_value( $key, '' ) ) . '</textarea>' . ( $help ? '<p class="vig-help">' . esc_html( $help ) . '</p>' : '' ) . '</div>';
	}

	/** Foto escolhida na biblioteca (guarda o ID); sem foto, mostra a padrão do tema. */
	private static function image( $key, $default_file ) {
		$id  = (int) vig_value( $key, 0 );
		$def = defined( 'VI_THEME_URI' ) ? VI_THEME_URI . '/assets/img/' . $default_file : '';
		$img = $id ? wp_get_attachment_image_url( $id, 'medium' ) : $def;
		echo '<div class="vig-media" data-vig-media data-vig-default="' . esc_url( $def ) . '"><img src="' . esc_url( (string) $img ) . '" alt=""' . ( $img ? '' : ' hidden' ) . '><input type="hidden" data-vig-id name="vig[' . esc_attr( $key ) . ']" value="' . esc_attr( (string) $id ) . '"><button type="button" class="button" data-vig-pick>' . esc_html__( 'Escolher imagem', 'villa-ibit-gestor' ) . '</button> <button type="button" class="button-link" data-vig-clear>' . esc_html__( 'Usar a padrão', 'villa-ibit-gestor' ) . '</button></div>';
	}

	private static function toggle( $name, $label, $on, $help = '', $described_by = '' ) {
		$description = $described_by ? ' aria-describedby="' . esc_attr( $described_by ) . '"' : '';
		echo '<label class="vig-toggle"><input type="hidden" name="' . esc_attr( $name ) . '" value="0"><input type="checkbox" name="' . esc_attr( $name ) . '" value="1"' . $description . checked( (bool) $on, true, false ) . '><span class="vig-toggle__ui" aria-hidden="true"></span><span><strong>' . esc_html( $label ) . '</strong>' . ( $help ? '<em>' . esc_html( $help ) . '</em>' : '' ) . '</span></label>';
	}

	public static function render() {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'loja'; // phpcs:ignore WordPress.Security.NonceVerification
		$tab = array_key_exists( $tab, self::tabs() ) ? $tab : 'loja';

		VIG_Admin::header( 'vi-gestor-config', __( 'Configurações da loja', 'villa-ibit-gestor' ) );
		if ( ! empty( $_GET['home_unmanaged'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'A página Início usa um layout próprio. Para aplicar a ordem pelo Gestor, adicione uma seção da loja à página ou organize o conteúdo diretamente no editor.', 'villa-ibit-gestor' ) . '</p></div>';
		} elseif ( ! empty( $_GET['home_order_conflict'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'A ordem da página Início mudou enquanto esta aba estava aberta. Confira a lista atual, ajuste a posição desejada e salve de novo.', 'villa-ibit-gestor' ) . '</p></div>';
		} elseif ( ! empty( $_GET['home_sync_error'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-warning"><p>' . esc_html__( 'As configurações foram salvas, mas o Gestor não conseguiu aplicar todas as seções à página Início. Confira a organização da página no Elementor e salve esta aba de novo.', 'villa-ibit-gestor' ) . '</p></div>';
		} elseif ( ! empty( $_GET['saved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Configurações salvas.', 'villa-ibit-gestor' ) . '</p></div>';
		}
		if ( ! empty( $_GET['classic'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Carrinho e checkout agora usam o modelo clássico.', 'villa-ibit-gestor' ) . '</p></div>';
		}
		echo '<nav class="vig-pills vig-pills--tabs">';
		foreach ( self::tabs() as $k => $l ) {
			echo '<a class="' . ( $k === $tab ? 'is-on' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=vi-gestor-config&tab=' . $k ) ) . '">' . ( 'pix' === $k ? VIG_Admin::icon( 'pix', 16 ) . ' ' : ( 'avisos' === $k ? VIG_Admin::icon( 'bell', 16 ) . ' ' : '' ) ) . esc_html( $l ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</nav>';

		if ( 'pix' === $tab ) {
			if ( isset( $_GET['gateway_enabled'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Método de pagamento habilitado no WooCommerce.', 'villa-ibit-gestor' ) . '</p></div>';
			}
			self::checkout_payments( WC()->payment_gateways()->payment_gateways() );
		}

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="vig-card vig-form">';
		wp_nonce_field( 'vig_save_settings' );
		echo '<input type="hidden" name="action" value="vig_save_settings"><input type="hidden" name="tab" value="' . esc_attr( $tab ) . '">';

		switch ( $tab ) {
			case 'banner':
				self::tab_banner();
				break;
			case 'home':
				self::tab_home();
				break;
			case 'pix':
				self::tab_pix();
				break;
			case 'idade':
				self::tab_age();
				break;
			case 'painel':
				self::tab_panel();
				break;
			case 'avisos':
				self::tab_notify();
				break;
			default:
				self::tab_store();
		}
		echo '<p class="vig-submit"><button class="button button-primary button-hero">' . esc_html__( 'Salvar alterações', 'villa-ibit-gestor' ) . '</button></p></form>';

		if ( 'pix' === $tab ) {
			self::classic_box();
		}
		if ( 'avisos' === $tab && class_exists( 'VIG_Notify' ) ) {
			VIG_Notify::test_box();
			VIG_WaScript::retry_box();
		}
		VIG_Admin::footer();
	}

	private static function tab_store() {
		echo '<div class="vig-grid2">';
		self::text( 'whatsapp', __( 'WhatsApp (com DDD, só números)', 'villa-ibit-gestor' ), __( 'Ex.: 5533991347344 — usado em todos os botões de WhatsApp.', 'villa-ibit-gestor' ) );
		self::text( 'whatsapp_label', __( 'WhatsApp como aparece no site', 'villa-ibit-gestor' ), __( 'Ex.: (33) 99134-7344', 'villa-ibit-gestor' ) );
		self::text( 'instagram', __( 'Instagram (sem @)', 'villa-ibit-gestor' ) );
		self::text( 'cnpj', __( 'CNPJ', 'villa-ibit-gestor' ), __( 'Aparece no rodapé.', 'villa-ibit-gestor' ) );
		self::text( 'address', __( 'Endereço', 'villa-ibit-gestor' ), __( 'Aparece no rodapé.', 'villa-ibit-gestor' ) );
		self::text( 'delivery_title', __( 'Título da entrega', 'villa-ibit-gestor' ), __( 'Ex.: Entrega em Governador Valadares', 'villa-ibit-gestor' ) );
		echo '</div>';
		self::textarea( 'delivery_text', __( 'Texto da entrega (página do produto)', 'villa-ibit-gestor' ) );
		self::textarea( 'topbar', __( 'Avisos da barra do topo (um por linha, até 3)', 'villa-ibit-gestor' ) );
		self::textarea( 'about', __( 'Texto sobre a loja (rodapé)', 'villa-ibit-gestor' ) );
		VIG_Local_Delivery::settings();
	}

	private static function tab_banner() {
		$slides = (array) vig_value( 'slides', array() );
		echo '<p class="vig-help">' . esc_html__( 'O banner padrão usa estes slides. Se você criou slides próprios no Elementor, abra o widget Banner e escolha “Usar os do painel Villa Ibit” para passar a editá-los aqui.', 'villa-ibit-gestor' ) . '</p>';
		echo '<p class="vig-help">' . esc_html__( 'Imagem recomendada: 2560 × 1120 px, uma foto (montanha, mata) com os produtos do lado direito e o lado esquerdo livre para o texto. No estilo Natureza, o lado esquerdo ganha um véu claro e o texto fica verde.', 'villa-ibit-gestor' ) . '</p>';
		echo '<div class="vig-toggles">';
		self::toggle( 'vig[hero_nature]', __( 'Efeitos de natureza no site', 'villa-ibit-gestor' ), (bool) vig_value( 'hero_nature', 1 ), __( 'Folhas balançando ao lado do logo, névoa passando e zoom lento na foto do banner, seções e produtos surgindo ao rolar a página. Quem usa "reduzir movimento" no aparelho vê tudo parado.', 'villa-ibit-gestor' ) );
		echo '</div>';
		for ( $i = 0; $i < self::MAX_SLIDES; $i++ ) {
			$s    = isset( $slides[ $i ] ) && is_array( $slides[ $i ] ) ? $slides[ $i ] : array( 'active' => 0 );
			$base = 'vig[slides][' . $i . ']';
			$img  = ! empty( $s['image_id'] ) ? wp_get_attachment_image_url( (int) $s['image_id'], 'medium' ) : '';
			if ( ! $img && ! empty( $s['image_def'] ) && defined( 'VI_THEME_URI' ) ) {
				$img = VI_THEME_URI . '/assets/img/' . $s['image_def'];
			}
			echo '<details class="vig-slide"' . ( ! empty( $s['active'] ) || 0 === $i ? ' open' : '' ) . '><summary><strong>' . esc_html( sprintf( __( 'Slide %d', 'villa-ibit-gestor' ), $i + 1 ) ) . '</strong> <span class="vig-muted">' . esc_html( trim( ( $s['title'] ?? '' ) . ' ' . ( $s['highlight'] ?? '' ) ) ) . '</span>' . ( empty( $s['active'] ) ? ' <span class="vig-badge">' . esc_html__( 'desligado', 'villa-ibit-gestor' ) . '</span>' : '' ) . '</summary>';
			echo '<div class="vig-slide__body"><div class="vig-slide__img">';
			echo '<div class="vig-media" data-vig-media><img src="' . esc_url( $img ) . '" alt=""' . ( $img ? '' : ' hidden' ) . '><input type="hidden" name="' . esc_attr( $base ) . '[image_id]" value="' . esc_attr( (string) ( $s['image_id'] ?? 0 ) ) . '"><input type="hidden" name="' . esc_attr( $base ) . '[image_def]" value="' . esc_attr( (string) ( $s['image_def'] ?? '' ) ) . '"><button type="button" class="button" data-vig-pick>' . esc_html__( 'Escolher imagem', 'villa-ibit-gestor' ) . '</button> <button type="button" class="button-link" data-vig-clear>' . esc_html__( 'Remover', 'villa-ibit-gestor' ) . '</button></div>';
			self::toggle( $base . '[active]', __( 'Mostrar este slide', 'villa-ibit-gestor' ), ! empty( $s['active'] ) );
			echo '<div class="vig-field"><label>' . esc_html__( 'Estilo', 'villa-ibit-gestor' ) . '<select name="' . esc_attr( $base ) . '[style]">';
			foreach ( array( 'natureza' => __( 'Natureza (foto clara, texto verde)', 'villa-ibit-gestor' ), 'verde' => __( 'Verde (texto claro)', 'villa-ibit-gestor' ), 'escuro' => __( 'Escuro (texto claro)', 'villa-ibit-gestor' ), 'dourado' => __( 'Dourado (texto escuro)', 'villa-ibit-gestor' ) ) as $k => $l ) {
				echo '<option value="' . esc_attr( $k ) . '"' . selected( $s['style'] ?? 'natureza', $k, false ) . '>' . esc_html( $l ) . '</option>';
			}
			echo '</select></label></div></div><div class="vig-grid2">';
			$fields = array(
				'eyebrow'     => __( 'Etiqueta (ex.: Lançamentos Elf Bar)', 'villa-ibit-gestor' ),
				'title'       => __( 'Título — início', 'villa-ibit-gestor' ),
				'highlight'   => __( 'Título — parte em destaque (outra cor)', 'villa-ibit-gestor' ),
				'title_after' => __( 'Título — final (opcional)', 'villa-ibit-gestor' ),
				'price_pre'   => __( 'Antes do preço (ex.: a partir de)', 'villa-ibit-gestor' ),
				'price'       => __( 'Preço no PIX (ex.: R$ 79,80)', 'villa-ibit-gestor' ),
				'button'      => __( 'Texto do botão', 'villa-ibit-gestor' ),
				'link'        => __( 'Link do botão', 'villa-ibit-gestor' ),
			);
			foreach ( $fields as $k => $l ) {
				echo '<div class="vig-field"><label>' . esc_html( $l ) . '<input type="text" name="' . esc_attr( $base . '[' . $k . ']' ) . '" value="' . esc_attr( (string) ( $s[ $k ] ?? '' ) ) . '"></label></div>';
			}
			echo '</div><div class="vig-field"><label>' . esc_html__( 'Texto', 'villa-ibit-gestor' ) . '<textarea rows="2" name="' . esc_attr( $base ) . '[text]">' . esc_textarea( (string) ( $s['text'] ?? '' ) ) . '</textarea></label></div>';
			echo '<p class="vig-help">' . esc_html__( 'Link: cole um endereço completo, um caminho do site (ex.: /categorias/pods-descartaveis/) ou {whatsapp} para abrir o WhatsApp da loja.', 'villa-ibit-gestor' ) . '</p>';
			echo '</div></details>';
		}
	}

	private static function home_section_labels() {
		return array(
			'categories' => array( __( 'Categorias em destaque', 'villa-ibit-gestor' ), __( 'Cartões com a miniatura de cada categoria, na ordem de Produtos › Categorias, e o atalho de Promoções. No celular fica a barra de categorias do topo.', 'villa-ibit-gestor' ) ),
			'novidades'  => array( __( 'Novidades', 'villa-ibit-gestor' ), __( 'Os produtos cadastrados por último, com o selo "Novo". Atualiza sozinho.', 'villa-ibit-gestor' ) ),
			'promos'     => array( __( 'Cartões Ofertas da semana e Combos especiais', 'villa-ibit-gestor' ), __( 'Dois cartões com foto. Textos, links e fotos logo abaixo.', 'villa-ibit-gestor' ) ),
			'duo'        => array( __( 'Mais vendidos + Produtos em destaque', 'villa-ibit-gestor' ), __( 'Lado a lado: os 3 que mais venderam e 3 produtos marcados com a estrela (☆).', 'villa-ibit-gestor' ) ),
			'featured'   => array( __( 'Faixa dourada de destaques (antiga)', 'villa-ibit-gestor' ), __( 'Faixa com os produtos marcados com estrela.', 'villa-ibit-gestor' ) ),
			'tabs'       => array( __( 'Vitrine com abas (antiga)', 'villa-ibit-gestor' ), __( 'Abas Novidades, Promoções, Mais vendidos e as 2 marcas com mais produtos.', 'villa-ibit-gestor' ) ),
			'spotlight'  => array( __( 'Destaque da semana', 'villa-ibit-gestor' ), __( 'Um produto em evidência, com foto grande, especificações e preço. Escolha qual logo abaixo.', 'villa-ibit-gestor' ) ),
			'deals'      => array( __( 'Ofertas que valem a pena', 'villa-ibit-gestor' ), __( 'Produtos com preço promocional, em cards na horizontal (some sozinha se não houver).', 'villa-ibit-gestor' ) ),
			'brands'     => array( __( 'Marcas originais', 'villa-ibit-gestor' ), __( 'Mostra as marcas cadastradas em Produtos › Marcas.', 'villa-ibit-gestor' ) ),
			'extra'      => array( __( 'Vitrine de categorias escolhidas', 'villa-ibit-gestor' ), __( 'Produtos das categorias marcadas abaixo.', 'villa-ibit-gestor' ) ),
			'wholesale'  => array( __( 'Atacado', 'villa-ibit-gestor' ), __( 'Faixa com foto da serra, texto e botão para o WhatsApp.', 'villa-ibit-gestor' ) ),
			'reviews'    => array( __( 'Avaliações', 'villa-ibit-gestor' ), __( 'Últimas avaliações aprovadas com 4 ou 5 estrelas.', 'villa-ibit-gestor' ) ),
			'blog'       => array( __( 'Dicas e guias', 'villa-ibit-gestor' ), __( 'Últimos 3 posts do blog (some se não houver posts).', 'villa-ibit-gestor' ) ),
			'social'     => array( __( 'Instagram e lista VIP', 'villa-ibit-gestor' ), '' ),
		);
	}

	/** Completa listas antigas ou parciais com as seções conhecidas, na ordem padrão. */
	public static function home_section_order( $order ) {
		$sections = self::home_section_labels();
		$ordered  = array();
		foreach ( is_array( $order ) ? $order : array() as $key ) {
			if ( is_string( $key ) && isset( $sections[ $key ] ) ) {
				$ordered[ $key ] = true;
			}
		}
		return array_keys( $ordered + $sections );
	}

	public static function effective_home_section_order( array $actual, $saved ) {
		if ( ! is_array( $saved ) || ! $saved ) {
			return self::home_section_order( $actual );
		}
		$order   = self::home_section_order( $saved );
		$present = array_values( array_intersect( array_unique( $actual ), $order ) );
		$slots   = array_flip( $present );
		$next    = 0;
		// Respeita a ordem atual do Elementor e conserva as posições das seções ausentes.
		foreach ( $order as $index => $key ) {
			if ( isset( $slots[ $key ] ) ) {
				$order[ $index ] = $present[ $next++ ];
			}
		}
		return $order;
	}

	private static function tab_home() {
		$defaults = vig_defaults();
		$sections = array_merge( (array) ( $defaults['sections'] ?? array() ), (array) vig_value( 'sections', array() ) );
		$labels   = self::home_section_labels();
		$order    = self::effective_home_section_order( VIG_Layouts::current_home_section_order(), vi_gestor_get( 'home_order' ) );
		?>
		<div class="vig-home-order-head">
			<h2 class="vig-h2" id="vig-home-order-title"><?php esc_html_e( 'O que aparece na home', 'villa-ibit-gestor' ); ?></h2>
			<button type="submit" class="vig-btn is-primary"><?php esc_html_e( 'Salvar alterações da home', 'villa-ibit-gestor' ); ?></button>
		</div>
		<p class="vig-help"><?php esc_html_e( 'Ative as seções que deseja exibir e use Subir ou Descer para escolher a ordem. O banner e os selos do topo têm posição própria.', 'villa-ibit-gestor' ); ?></p>
		<input type="hidden" name="vig[home_order_start]" value="<?php echo esc_attr( wp_hash( implode( ',', $order ) ) ); ?>">
		<ol class="vig-home-order" aria-labelledby="vig-home-order-title" data-vig-home-order data-vig-position-message="<?php esc_attr_e( '%1$s, posição %2$d de %3$d.', 'villa-ibit-gestor' ); ?>">
			<?php foreach ( $order as $index => $key ) : ?>
				<li class="vig-home-order__row">
					<span class="vig-home-order__position" aria-hidden="true"><?php echo (int) $index + 1; ?></span>
					<?php self::toggle( 'vig[sections][' . $key . ']', $labels[ $key ][0], ! isset( $sections[ $key ] ) || ! empty( $sections[ $key ] ), '', $labels[ $key ][1] ? 'vig-home-desc-' . $key : '' ); ?>
					<input type="hidden" name="vig[home_order][]" value="<?php echo esc_attr( $key ); ?>" disabled>
					<span class="vig-home-order__controls">
						<?php foreach ( array( 'up' => __( 'Subir', 'villa-ibit-gestor' ), 'down' => __( 'Descer', 'villa-ibit-gestor' ) ) as $direction => $verb ) : ?>
							<button type="button" class="vig-btn vig-home-order__move" data-vig-move="<?php echo esc_attr( $direction ); ?>" aria-label="<?php echo esc_attr( $verb . ' ' . $labels[ $key ][0] ); ?>" <?php disabled( 'up' === $direction ? 0 === $index : count( $order ) - 1 === $index ); ?>>
								<?php echo VIG_Admin::icon( 'arrow', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
								<span><?php echo esc_html( $verb ); ?></span>
							</button>
						<?php endforeach; ?>
					</span>
					<?php if ( $labels[ $key ][1] ) : ?>
						<p class="vig-home-order__description" id="vig-home-desc-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $labels[ $key ][1] ); ?></p>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ol>
		<p class="screen-reader-text" role="status" data-vig-order-status></p>
		<?php
		echo '<h2 class="vig-h2">' . esc_html__( 'Cartões da home', 'villa-ibit-gestor' ) . '</h2><p class="vig-help">' . esc_html__( 'Link em branco: Ofertas abre a página de promoções e Combos abre a categoria "Combos". Sem foto escolhida, fica a foto padrão do tema (1200 × 560 px, produtos à direita).', 'villa-ibit-gestor' ) . '</p>';
		foreach ( array( 'offers' => array( __( 'Ofertas da semana', 'villa-ibit-gestor' ), 'promo-ofertas.jpg' ), 'combos' => array( __( 'Combos especiais', 'villa-ibit-gestor' ), 'promo-combos.jpg' ) ) as $k => $c ) {
			echo '<details class="vig-slide" open><summary><strong>' . esc_html( $c[0] ) . '</strong></summary><div class="vig-slide__body"><div class="vig-slide__img">';
			self::image( 'promo_' . $k . '_image', 'natureza/' . $c[1] );
			echo '</div><div class="vig-grid2">';
			self::text( 'promo_' . $k . '_title', __( 'Título', 'villa-ibit-gestor' ) );
			self::text( 'promo_' . $k . '_button', __( 'Texto do botão', 'villa-ibit-gestor' ) );
			self::text( 'promo_' . $k . '_text', __( 'Texto', 'villa-ibit-gestor' ) );
			self::text( 'promo_' . $k . '_link', __( 'Link (opcional)', 'villa-ibit-gestor' ), __( 'Endereço completo ou caminho do site, ex.: /categorias/combos/', 'villa-ibit-gestor' ) );
			echo '</div></div></details>';
		}
		echo '<h2 class="vig-h2">' . esc_html__( 'Faixa dourada de destaques (produtos com ★)', 'villa-ibit-gestor' ) . '</h2><div class="vig-grid2">';
		self::text( 'featured_title', __( 'Título da faixa', 'villa-ibit-gestor' ), __( 'Ex.: Novidades, Queima de estoque.', 'villa-ibit-gestor' ) );
		self::text( 'featured_text', __( 'Texto abaixo do título', 'villa-ibit-gestor' ) );
		echo '</div><p class="vig-help">' . esc_html__( 'Os produtos da faixa são os marcados com a estrela na lista de produtos (ou "Destaque na home" no editor do produto).', 'villa-ibit-gestor' ) . '</p>';
		echo '<h2 class="vig-h2">' . esc_html__( 'Destaque da semana', 'villa-ibit-gestor' ) . '</h2><div class="vig-grid2">';
		$spot  = (int) vig_value( 'spotlight_product', 0 );
		$items = wc_get_products( array( 'status' => 'publish', 'limit' => 300, 'orderby' => 'title', 'order' => 'ASC' ) );
		echo '<div class="vig-field"><label for="vig-spot">' . esc_html__( 'Produto em destaque', 'villa-ibit-gestor' ) . '</label><select id="vig-spot" name="vig[spotlight_product]"><option value="0">' . esc_html__( 'Automático (primeiro produto com estrela de destaque)', 'villa-ibit-gestor' ) . '</option>';
		foreach ( $items as $it ) {
			echo '<option value="' . (int) $it->get_id() . '"' . selected( $spot, $it->get_id(), false ) . '>' . esc_html( $it->get_name() ) . '</option>';
		}
		echo '</select><p class="vig-help">' . esc_html__( 'Aparece na home com foto grande, especificações e preço no PIX. Troque quando quiser.', 'villa-ibit-gestor' ) . '</p></div>';
		self::text( 'spotlight_title', __( 'Etiqueta acima do nome', 'villa-ibit-gestor' ), __( 'Ex.: Destaque da semana, Lançamento, Mais pedido.', 'villa-ibit-gestor' ) );
		echo '</div>';
		echo '<h2 class="vig-h2">' . esc_html__( 'Vitrine de categorias escolhidas', 'villa-ibit-gestor' ) . '</h2>';
		self::text( 'extra_title', __( 'Título da vitrine', 'villa-ibit-gestor' ) );
		$chosen = array_map( 'absint', (array) vig_value( 'extra_cats', array() ) );
		$terms  = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'parent' => 0 ) );
		echo '<fieldset class="vig-field"><legend>' . esc_html__( 'Categorias (nenhuma marcada = todas, menos a primeira e o atacado)', 'villa-ibit-gestor' ) . '</legend><input type="hidden" name="vig[extra_cats][]" value="0"><div class="vig-checks">';
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				echo '<label class="vig-check"><input type="checkbox" name="vig[extra_cats][]" value="' . (int) $t->term_id . '"' . checked( in_array( (int) $t->term_id, $chosen, true ), true, false ) . '> ' . esc_html( $t->name ) . ' <span class="vig-muted">(' . (int) $t->count . ')</span></label>';
			}
		}
		echo '</div></fieldset><h2 class="vig-h2">' . esc_html__( 'Atacado e newsletter', 'villa-ibit-gestor' ) . '</h2><div class="vig-grid2">';
		self::text( 'wholesale_title', __( 'Título do atacado', 'villa-ibit-gestor' ) );
		self::text( 'wholesale_text', __( 'Texto do atacado', 'villa-ibit-gestor' ) );
		echo '</div>';
		echo '<div class="vig-field"><label>' . esc_html__( 'Foto do atacado (1920 × 570 px)', 'villa-ibit-gestor' ) . '</label>';
		self::image( 'wholesale_image', 'natureza/atacado-folhagem.jpg' );
		echo '</div>';
		self::text( 'newsletter_sc', __( 'Shortcode da newsletter (opcional)', 'villa-ibit-gestor' ), __( 'Ex.: [mc4wp_form id="12"]. Em branco, a home mostra o botão “Entrar na lista VIP” do WhatsApp.', 'villa-ibit-gestor' ) );
	}

	/** Somente controles de habilitação padrão, de meios prontos para ativação. */
	private static function can_enable_gateway( $gateway ) {
		try {
			$fields = $gateway->get_form_fields();
			if ( 'checkbox' !== ( $fields['enabled']['type'] ?? '' ) || wc_string_to_bool( $gateway->needs_setup() ) ) {
				return false;
			}
			foreach ( array( 'is_account_connected', 'is_connected' ) as $connection_check ) {
				if ( method_exists( $gateway, $connection_check ) && is_callable( array( $gateway, $connection_check ) ) ) {
					return wc_string_to_bool( $gateway->$connection_check() );
				}
			}
			return true;
		} catch ( Throwable $e ) {
			return false;
		}
	}

	public static function enable_gateway() {
		if ( ! current_user_can( VIG_Admin::CAP ) || 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
			wp_die( esc_html__( 'Ação não permitida.', 'villa-ibit-gestor' ), '', array( 'response' => 403 ) );
		}
		$id       = isset( $_POST['gateway_id'] ) && is_string( $_POST['gateway_id'] ) ? wp_unslash( $_POST['gateway_id'] ) : '';
		$gateways = WC()->payment_gateways()->payment_gateways();
		if ( ! isset( $gateways[ $id ] ) ) {
			wp_die( esc_html__( 'Método de pagamento indisponível.', 'villa-ibit-gestor' ), '', array( 'response' => 400 ) );
		}
		check_admin_referer( 'vig_enable_gateway_' . $id, 'vig_gateway_nonce' );

		$gateway = $gateways[ $id ];
		$gateway->init_settings();
		if ( 'yes' !== $gateway->get_option( 'enabled', 'no' ) ) {
			if ( ! self::can_enable_gateway( $gateway ) ) {
				wp_safe_redirect( add_query_arg( 'section', $id, admin_url( 'admin.php?page=wc-settings&tab=checkout' ) ) );
				exit;
			}
			if ( $gateway instanceof WC_Gateway_COD && 'cod' === $id ) {
				$fields = $gateway->get_form_fields();
				$title  = $gateway->get_option( 'title' );
				if ( '' === $title || $title === ( $fields['title']['default'] ?? '' ) ) {
					$gateway->settings['title'] = __( 'Dinheiro', 'villa-ibit-gestor' );
				}
			}
			do_action( 'woocommerce_update_option', array( 'id' => $gateway->get_option_key() ) );
			$gateway->update_option( 'enabled', 'yes' );
			$gateway->init_settings();
			if ( 'yes' !== $gateway->get_option( 'enabled', 'no' ) ) {
				wp_die( esc_html__( 'O provedor não habilitou este método. Abra Configurar para verificar a conexão.', 'villa-ibit-gestor' ) );
			}
			do_action( 'woocommerce_update_options' );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=vi-gestor-config&tab=pix&gateway_enabled=1' ) );
		exit;
	}

	private static function checkout_payments( $gateways ) {
		$payments_url = admin_url( 'admin.php?page=wc-settings&tab=checkout' );
		?>
		<section class="vig-card">
		<h2 class="vig-h2"><?php esc_html_e( 'Pagamentos do checkout', 'villa-ibit-gestor' ); ?></h2>
		<p><strong><?php esc_html_e( 'Dinheiro', 'villa-ibit-gestor' ); ?></strong> · <?php esc_html_e( 'Use o pagamento na entrega (cod) ou o método de dinheiro que já atende a loja. Em Configurar, escolha as modalidades de entrega aceitas.', 'villa-ibit-gestor' ); ?><br>
		<strong><?php esc_html_e( 'Pix', 'villa-ibit-gestor' ); ?></strong> · <?php esc_html_e( 'Conecte sua conta ao provedor de Pix e habilite o método que gera o QR Code e o código copia e cola.', 'villa-ibit-gestor' ); ?><br>
		<strong><?php esc_html_e( 'Cartão de crédito', 'villa-ibit-gestor' ); ?></strong> · <?php esc_html_e( 'Conecte sua conta ao provedor de cartão e configure o parcelamento nele. Os campos do cartão são exibidos pelo próprio provedor.', 'villa-ibit-gestor' ); ?></p>
		<?php if ( $gateways ) : ?>
			<div class="vig-table-wrap"><table class="vig-table">
				<thead><tr><th scope="col"><?php esc_html_e( 'Método instalado', 'villa-ibit-gestor' ); ?></th><th scope="col"><?php esc_html_e( 'Habilitado no WooCommerce', 'villa-ibit-gestor' ); ?></th><th scope="col"><?php esc_html_e( 'Configuração', 'villa-ibit-gestor' ); ?></th></tr></thead>
				<tbody>
				<?php foreach ( $gateways as $id => $gateway ) : ?>
					<tr>
						<td><?php echo esc_html( wp_strip_all_tags( $gateway->get_method_title() ?: $gateway->get_title() ) ); ?> <small>(<?php echo esc_html( $id ); ?>)</small></td>
						<td><?php echo 'yes' === $gateway->enabled ? esc_html__( 'Sim', 'villa-ibit-gestor' ) : esc_html__( 'Não', 'villa-ibit-gestor' ); ?></td>
						<td>
							<?php if ( 'yes' !== $gateway->enabled && self::can_enable_gateway( $gateway ) ) : ?>
								<form method="post" class="vig-inline" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
									<input type="hidden" name="action" value="vig_enable_gateway">
									<input type="hidden" name="gateway_id" value="<?php echo esc_attr( $id ); ?>">
									<input type="hidden" name="vig_gateway_nonce" value="<?php echo esc_attr( wp_create_nonce( 'vig_enable_gateway_' . $id ) ); ?>">
									<button type="submit" class="button"><?php esc_html_e( 'Habilitar', 'villa-ibit-gestor' ); ?></button>
								</form>
							<?php endif; ?>
							<a href="<?php echo esc_url( add_query_arg( 'section', $id, $payments_url ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Configurar', 'villa-ibit-gestor' ); ?></a>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table></div>
		<?php endif; ?>
		<p class="vig-help"><?php esc_html_e( 'Se o provedor de Pix ou cartão ainda não aparece, instale e conecte o plugin de pagamento usado pela loja. Quando só houver “Configurar”, conclua a ativação no provedor. Moeda, frete e regras do provedor podem limitar as opções de cada pedido.', 'villa-ibit-gestor' ); ?>
			<a href="<?php echo esc_url( $payments_url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Abrir pagamentos do WooCommerce', 'villa-ibit-gestor' ); ?></a></p>
		</section>
		<?php
	}

	private static function tab_pix() {
		$gateways = WC()->payment_gateways()->payment_gateways();
		$cash = (string) vig_value( 'cash_gateway', 'cod' );
		?>
		<h2 class="vig-h2"><?php esc_html_e( 'Troco em dinheiro', 'villa-ibit-gestor' ); ?></h2>
		<div class="vig-field">
			<label for="vig-cash-gateway"><?php esc_html_e( 'Dinheiro · Em qual opção mostrar o campo de troco?', 'villa-ibit-gestor' ); ?></label>
			<select id="vig-cash-gateway" name="vig[cash_gateway]" aria-describedby="vig-cash-help">
				<option value="" <?php selected( $cash, '' ); ?>><?php esc_html_e( 'Desligar o campo de troco', 'villa-ibit-gestor' ); ?></option>
				<?php if ( '' !== $cash && ! isset( $gateways[ $cash ] ) ) : ?>
					<option value="<?php echo esc_attr( $cash ); ?>" selected><?php echo esc_html( sprintf( __( '%s (indisponível)', 'villa-ibit-gestor' ), $cash ) ); ?></option>
				<?php endif; ?>
				<?php foreach ( $gateways as $id => $gateway ) : ?>
					<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $cash, $id ); ?>><?php echo esc_html( wp_strip_all_tags( $gateway->get_title() ?: $gateway->get_method_title() ) . ' (' . $id . ')' ); ?></option>
				<?php endforeach; ?>
			</select>
			<p id="vig-cash-help" class="vig-help"><?php esc_html_e( 'Marque o método que a loja usa para receber dinheiro na entrega e salve a alteração. Ao escolher essa opção, o cliente pode informar o valor que vai entregar.', 'villa-ibit-gestor' ); ?></p>
		</div>
		<?php
		$pct = (float) vig_value( 'pix_percent', 5 );
		echo '<div class="vig-pix-preview">' . VIG_Admin::icon( 'pix', 28 ) . '<div><strong>' . esc_html__( 'Como aparece na loja', 'villa-ibit-gestor' ) . '</strong><span>' . wp_kses_post( sprintf( __( 'R$ 163,00 no cartão · <b>%s no PIX</b>', 'villa-ibit-gestor' ), wc_price( 163 * ( 1 - $pct / 100 ) ) ) ) . '</span></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<div class="vig-grid2">';
		self::text( 'pix_percent', __( 'Desconto no PIX (%)', 'villa-ibit-gestor' ), __( 'Mostrado em todos os preços como “R$ X no PIX”. Use 0 para esconder.', 'villa-ibit-gestor' ), 'number' );
		self::text( 'low_stock', __( 'Avisar estoque baixo a partir de (unidades)', 'villa-ibit-gestor' ), '', 'number' );
		echo '</div>';
		self::toggle( 'vig[pix_apply]', __( 'Aplicar o desconto de verdade no checkout', 'villa-ibit-gestor' ), (bool) vig_value( 'pix_apply', 0 ), __( 'Adiciona a linha “Desconto PIX” no total quando o cliente escolhe uma das formas de pagamento marcadas abaixo. Deixe desligado se o seu gateway já dá o desconto.', 'villa-ibit-gestor' ) );
		$chosen   = (array) vig_value( 'pix_gateways', array() );
		echo '<fieldset class="vig-field"><legend>' . esc_html__( 'Formas de pagamento que recebem o desconto', 'villa-ibit-gestor' ) . '</legend><input type="hidden" name="vig[pix_gateways][]" value=""><div class="vig-checks">';
		foreach ( $gateways as $id => $gw ) {
			echo '<label class="vig-check"><input type="checkbox" name="vig[pix_gateways][]" value="' . esc_attr( $id ) . '"' . checked( in_array( $id, $chosen, true ), true, false ) . '> ' . esc_html( wp_strip_all_tags( $gw->get_method_title() ? $gw->get_method_title() : $gw->get_title() ) ) . ( 'yes' === $gw->enabled ? '' : ' <span class="vig-muted">(' . esc_html__( 'desativada', 'villa-ibit-gestor' ) . ')</span>' ) . '</label>';
		}
		if ( ! $gateways ) {
			echo '<p class="vig-help">' . esc_html__( 'Nenhuma forma de pagamento instalada ainda.', 'villa-ibit-gestor' ) . '</p>';
		}
		echo '</div></fieldset>';
	}

	private static function tab_panel() {
		VIG_Admin::app_card( false );
		self::toggle( 'vig[login_panel]', __( 'Abrir o Villa Ibit ao entrar no painel', 'villa-ibit-gestor' ), (bool) vig_value( 'login_panel', 0 ), __( 'Depois do login, você cai direto no resumo da loja.', 'villa-ibit-gestor' ) );
		self::toggle( 'vig[simple_menu]', __( 'Esconder os menus nativos de Produtos, WooCommerce e Comentários', 'villa-ibit-gestor' ), (bool) vig_value( 'simple_menu', 0 ), __( 'Deixa o menu lateral mais limpo para quem usa só o Villa Ibit. As telas continuam acessíveis pelo endereço e você pode desligar aqui a qualquer momento.', 'villa-ibit-gestor' ) );
	}

	private static function tab_notify() {
		echo '<p class="vig-lead">' . esc_html__( 'A cada nova venda, o plugin avisa você na hora. Conta como venda o pedido pago (Processando) ou o que aguarda você conferir o PIX/transferência (Aguardando). Cada pedido é avisado uma vez só.', 'villa-ibit-gestor' ) . '</p>';

		echo '<h2 class="vig-h2">' . VIG_Admin::icon( 'phone', 18 ) . esc_html__( 'Notificação no celular e no computador', 'villa-ibit-gestor' ) . '</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput
		self::toggle( 'vig[notify_push]', __( 'Mandar notificação para os aparelhos ativados', 'villa-ibit-gestor' ), (bool) vig_value( 'notify_push', 1 ), __( 'Aparece como a mensagem de um app, com o valor, o cliente e os produtos, mesmo com o painel fechado. Tocando nela, abre o pedido. Não usa serviço pago nem de terceiros.', 'villa-ibit-gestor' ) );
		if ( class_exists( 'VIG_Notify' ) ) {
			VIG_Notify::devices_box();
		}

		echo '<h2 class="vig-h2">' . VIG_Admin::icon( 'bell', 18 ) . esc_html__( 'Com o painel aberto', 'villa-ibit-gestor' ) . '</h2><div class="vig-toggles">'; // phpcs:ignore WordPress.Security.EscapeOutput
		self::toggle( 'vig[notify_panel]', __( 'Mostrar o aviso na tela do painel', 'villa-ibit-gestor' ), (bool) vig_value( 'notify_panel', 1 ), __( 'Um cartão aparece no canto com a venda e o botão "Abrir pedido". O número de pedidos para enviar se atualiza sozinho.', 'villa-ibit-gestor' ) );
		self::toggle( 'vig[notify_sound]', __( 'Tocar um som', 'villa-ibit-gestor' ), (bool) vig_value( 'notify_sound', 1 ), __( 'Um "plim" curto. O navegador só deixa tocar depois do primeiro clique ou toque na tela.', 'villa-ibit-gestor' ) );
		echo '</div>';

		echo '<h2 class="vig-h2">' . VIG_Admin::icon( 'bag', 18 ) . esc_html__( 'Por e-mail', 'villa-ibit-gestor' ) . '</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput
		self::toggle( 'vig[notify_email]', __( 'Mandar um e-mail a cada venda', 'villa-ibit-gestor' ), (bool) vig_value( 'notify_email', 0 ), __( 'E-mail com o valor, os produtos e sabores, o cliente, a entrega e os botões "Abrir o pedido" e "Chamar no WhatsApp".', 'villa-ibit-gestor' ) );
		echo '<div class="vig-field"><label for="vig-notify_emails">' . esc_html__( 'Quem recebe (um ou mais e-mails, separados por vírgula)', 'villa-ibit-gestor' ) . '</label><input id="vig-notify_emails" type="text" inputmode="email" name="vig[notify_emails]" value="' . esc_attr( (string) vig_value( 'notify_emails', '' ) ) . '" placeholder="' . esc_attr( (string) get_option( 'admin_email' ) ) . '"><p class="vig-help">' . esc_html__( 'Em branco, vai para o e-mail do administrador do site.', 'villa-ibit-gestor' ) . '</p></div>';
		self::toggle( 'vig[notify_wc_off]', __( 'Desligar o e-mail "Novo pedido" do WooCommerce', 'villa-ibit-gestor' ), (bool) vig_value( 'notify_wc_off', 0 ), __( 'Para não chegarem dois e-mails da mesma venda. Os e-mails que o cliente recebe não mudam.', 'villa-ibit-gestor' ) );

		echo '<h2 class="vig-h2">' . VIG_Admin::icon( 'chat', 18 ) . esc_html__( 'Por WhatsApp (opcional)', 'villa-ibit-gestor' ) . '</h2>'; // phpcs:ignore WordPress.Security.EscapeOutput
		self::toggle( 'vig[notify_wa]', __( 'Mandar uma mensagem no WhatsApp a cada venda', 'villa-ibit-gestor' ), (bool) vig_value( 'notify_wa', 0 ), __( 'Os avisos vão para o número da loja escolhido abaixo.', 'villa-ibit-gestor' ) );
		VIG_WaScript::fields();

		echo '<h2 class="vig-h2">' . esc_html__( 'Pedidos que ainda não foram pagos', 'villa-ibit-gestor' ) . '</h2>';
		self::toggle( 'vig[notify_pending]', __( 'Avisar também quando o pedido é feito e o pagamento ainda está pendente', 'villa-ibit-gestor' ), (bool) vig_value( 'notify_pending', 0 ), __( 'Útil com PIX do Mercado Pago, PagBank etc.: chega um aviso "aguardando pagamento" e, quando pagar, outro de "Nova venda". Deixe desligado para receber só as vendas.', 'villa-ibit-gestor' ) );
	}

	private static function tab_age() {
		self::toggle( 'vig[age_gate]', __( 'Pedir confirmação de idade (18+) ao entrar na loja', 'villa-ibit-gestor' ), (bool) vig_value( 'age_gate', 1 ), __( 'O visitante confirma se tem 18 anos ou mais. Quem informa ser menor de idade fica com o acesso bloqueado nesta sessão.', 'villa-ibit-gestor' ) );
		$remember_days = VIG_Age_Gate::remember_days( vig_value( 'age_remember_days', 0 ) );
		?>
		<div class="vig-field">
			<label for="vig-age-remember-days"><?php esc_html_e( 'Quando pedir a confirmação', 'villa-ibit-gestor' ); ?></label>
			<select id="vig-age-remember-days" name="vig[age_remember_days]" aria-describedby="vig-age-remember-help">
				<option value="0" <?php selected( $remember_days, 0 ); ?>><?php esc_html_e( 'Sempre que abrir uma página', 'villa-ibit-gestor' ); ?></option>
				<?php for ( $days = 1; $days <= 30; $days++ ) : ?>
					<option value="<?php echo esc_attr( $days ); ?>" <?php selected( $remember_days, $days ); ?>><?php echo esc_html( sprintf( _n( 'A cada %d dia', 'A cada %d dias', $days, 'villa-ibit-gestor' ), $days ) ); ?></option>
				<?php endfor; ?>
			</select>
			<p id="vig-age-remember-help" class="vig-help"><?php esc_html_e( 'Em “Sempre”, o aviso volta ao abrir outra página ou recarregar a atual. Com um prazo em dias, a loja lembra a confirmação neste navegador até o prazo terminar.', 'villa-ibit-gestor' ); ?></p>
		</div>
		<?php
		self::text( 'age_title', __( 'Título', 'villa-ibit-gestor' ) );
		self::textarea( 'age_text', __( 'Texto', 'villa-ibit-gestor' ) );
		echo '<h2 class="vig-h2">' . esc_html__( 'Data de nascimento', 'villa-ibit-gestor' ) . '</h2>';
		self::toggle( 'vig[birth_required]', __( 'Pedir data de nascimento no cadastro e no checkout', 'villa-ibit-gestor' ), (bool) vig_value( 'birth_required', 0 ), __( 'Quem tiver menos de 18 anos não consegue criar conta nem finalizar a compra. A data declarada fica salva no cliente e em cada pedido (aparece na tela do pedido, com a idade). Funciona no checkout clássico e no checkout em blocos.', 'villa-ibit-gestor' ) );
	}

	private static function classic_box() {
		echo '<section class="vig-card"><h2 class="vig-h2">Carrinho e checkout</h2><p>Os blocos, campos adicionais, extensões de frete e pagamentos são administrados pela loja. O Gestor não substitui essas páginas.</p></section>';
	}

	/* ---------- salvar ---------- */
	public static function save() {
		if ( ! current_user_can( VIG_Admin::CAP ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'villa-ibit-gestor' ) );
		}
		check_admin_referer( 'vig_save_settings' );
		$tab  = isset( $_POST['tab'] ) ? sanitize_key( wp_unslash( $_POST['tab'] ) ) : 'loja';
		$in   = isset( $_POST['vig'] ) && is_array( $_POST['vig'] ) ? wp_unslash( $_POST['vig'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitizado campo a campo abaixo.
		$opts = get_option( VIG_OPTION, array() );
		$opts = is_array( $opts ) ? $opts : array();
		if ( 'loja' === $tab && isset( $in['local_delivery_zone'] ) ) {
			VIG_Local_Delivery::save_choice( $opts, $in['local_delivery_zone'] );
		}
		if ( 'idade' === $tab && isset( $in['age_remember_days'] ) ) {
			$opts['age_remember_days'] = VIG_Age_Gate::remember_days( $in['age_remember_days'] );
		}

		$text_keys = array( 'whatsapp_label', 'instagram', 'cnpj', 'address', 'delivery_title', 'extra_title', 'wholesale_title', 'wholesale_text', 'age_title', 'spotlight_title', 'featured_title', 'featured_text' );
		foreach ( $text_keys as $k ) {
			if ( isset( $in[ $k ] ) ) {
				$opts[ $k ] = sanitize_text_field( $in[ $k ] );
			}
		}
		foreach ( array( 'delivery_text', 'topbar', 'about', 'age_text' ) as $k ) {
			if ( isset( $in[ $k ] ) ) {
				$opts[ $k ] = sanitize_textarea_field( $in[ $k ] );
			}
		}
		if ( isset( $in['whatsapp'] ) ) {
			$opts['whatsapp'] = preg_replace( '/\D+/', '', $in['whatsapp'] );
		}
		if ( isset( $in['instagram'] ) ) {
			$opts['instagram'] = ltrim( sanitize_text_field( $in['instagram'] ), '@' );
		}
		foreach ( array( 'promo_offers_image', 'promo_combos_image', 'wholesale_image' ) as $k ) {
			if ( isset( $in[ $k ] ) ) {
				$opts[ $k ] = absint( $in[ $k ] );
			}
		}
		foreach ( array( 'promo_offers_title', 'promo_offers_text', 'promo_offers_button', 'promo_combos_title', 'promo_combos_text', 'promo_combos_button' ) as $k ) {
			if ( isset( $in[ $k ] ) ) {
				$opts[ $k ] = sanitize_text_field( $in[ $k ] );
			}
		}
		foreach ( array( 'promo_offers_link', 'promo_combos_link' ) as $k ) {
			if ( isset( $in[ $k ] ) ) {
				$v          = trim( (string) $in[ $k ] );
				$opts[ $k ] = ( '' === $v || '{whatsapp}' === $v || 0 === strpos( $v, '/' ) ) ? sanitize_text_field( $v ) : esc_url_raw( $v );
			}
		}
		if ( isset( $in['spotlight_product'] ) ) {
			$opts['spotlight_product'] = absint( $in['spotlight_product'] );
		}
		if ( isset( $in['nav_scope'] ) ) {
			$opts['nav_scope'] = 'all' === $in['nav_scope'] ? 'all' : 'home';
		}
		if ( isset( $in['newsletter_sc'] ) ) {
			$opts['newsletter_sc'] = sanitize_text_field( $in['newsletter_sc'] );
		}
		if ( isset( $in['pix_percent'] ) ) {
			$opts['pix_percent'] = max( 0, min( 90, (float) str_replace( ',', '.', $in['pix_percent'] ) ) );
		}
		if ( 'pix' === $tab && isset( $in['cash_gateway'] ) && is_string( $in['cash_gateway'] ) ) {
			$cash     = $in['cash_gateway'];
			$gateways = WC()->payment_gateways()->payment_gateways();
			if ( '' === $cash || isset( $gateways[ $cash ] ) ) {
				$opts['cash_gateway'] = $cash;
			}
		}
		if ( isset( $in['low_stock'] ) ) {
			$opts['low_stock'] = max( 0, (int) $in['low_stock'] );
		}
		if ( isset( $in['notify_emails'] ) ) {
			$emails                = array_filter( array_map( 'sanitize_email', preg_split( '/[\s,;]+/', (string) $in['notify_emails'] ) ), 'is_email' );
			$opts['notify_emails'] = implode( ', ', array_unique( $emails ) );
		}
		if ( 'avisos' === $tab ) {
			VIG_WaScript::save_fields( $in, $opts );
		}
		foreach ( array( 'pix_apply', 'age_gate', 'birth_required', 'login_panel', 'simple_menu', 'hero_nature', 'notify_push', 'notify_panel', 'notify_sound', 'notify_email', 'notify_wc_off', 'notify_pending', 'notify_wa' ) as $k ) {
			if ( isset( $in[ $k ] ) ) {
				$opts[ $k ] = empty( $in[ $k ] ) ? 0 : 1;
			}
		}
		if ( isset( $in['pix_gateways'] ) ) {
			$opts['pix_gateways'] = array_values( array_filter( array_map( 'sanitize_key', (array) $in['pix_gateways'] ) ) );
		}
		if ( isset( $in['extra_cats'] ) ) {
			$opts['extra_cats'] = array_values( array_filter( array_map( 'absint', (array) $in['extra_cats'] ) ) );
		}
		if ( isset( $in['sections'] ) && is_array( $in['sections'] ) ) {
			$sections = array();
			foreach ( $in['sections'] as $k => $v ) {
				$sections[ sanitize_key( $k ) ] = empty( $v ) ? 0 : 1;
			}
			$opts['sections'] = $sections;
		}
		if ( isset( $in['slides'] ) && is_array( $in['slides'] ) ) {
			$slides = array();
			foreach ( array_slice( $in['slides'], 0, self::MAX_SLIDES ) as $s ) {
				$s        = (array) $s;
				$slides[] = array(
					'active'      => empty( $s['active'] ) ? 0 : 1,
					'style'       => in_array( $s['style'] ?? '', array( 'natureza', 'verde', 'escuro', 'dourado' ), true ) ? $s['style'] : 'natureza',
					'eyebrow'     => sanitize_text_field( $s['eyebrow'] ?? '' ),
					'title'       => sanitize_text_field( $s['title'] ?? '' ),
					'highlight'   => sanitize_text_field( $s['highlight'] ?? '' ),
					'title_after' => sanitize_text_field( $s['title_after'] ?? '' ),
					'text'        => sanitize_textarea_field( $s['text'] ?? '' ),
					'price_pre'   => sanitize_text_field( $s['price_pre'] ?? '' ),
					'price'       => sanitize_text_field( $s['price'] ?? '' ),
					'button'      => sanitize_text_field( $s['button'] ?? '' ),
					'link'        => ( '{whatsapp}' === trim( $s['link'] ?? '' ) || 0 === strpos( trim( $s['link'] ?? '' ), '/' ) ) ? sanitize_text_field( $s['link'] ) : esc_url_raw( $s['link'] ?? '' ),
					'image_id'    => absint( $s['image_id'] ?? 0 ),
					'image_def'   => sanitize_file_name( $s['image_def'] ?? '' ),
				);
			}
			$opts['slides'] = $slides;
		}

		$synced = true;
		if ( 'home' === $tab && isset( $in['sections'] ) && is_array( $in['sections'] ) ) {
			$order = array();
			if ( ! empty( $in['home_order'] ) && is_array( $in['home_order'] ) ) {
				$order = self::home_section_order( $in['home_order'] );
				if ( isset( $in['home_order_start'] ) ) {
					$current = self::effective_home_section_order( VIG_Layouts::current_home_section_order(), $opts['home_order'] ?? array() );
					if ( ! is_string( $in['home_order_start'] ) || ! hash_equals( wp_hash( implode( ',', $current ) ), $in['home_order_start'] ) ) {
						$synced = 'stale';
					}
				}
			}
			if ( true === $synced ) {
				$synced = VIG_Layouts::sync_home_sections( $opts['sections'], false, $order );
			}
			if ( true === $synced && $order ) {
				$opts['home_order'] = $order;
			}
		}
		update_option( VIG_OPTION, $opts, true );
		if ( in_array( $tab, array( 'banner', 'loja', 'home', 'pix' ), true ) ) {
			$front_id = (int) get_option( 'page_on_front' );
			if ( $front_id ) {
				delete_post_meta( $front_id, '_elementor_element_cache' );
				clean_post_cache( $front_id );
			}
		}
		if ( function_exists( 'vi_cache_flush' ) ) {
			vi_cache_flush();
		}
		$result = true === $synced ? '&saved=1' : '&home_sync_error=1';
		if ( 'unmanaged' === $synced ) {
			$result = '&home_unmanaged=1';
		} elseif ( 'stale' === $synced ) {
			$result = '&home_sync_error=1&home_order_conflict=1';
		}
		wp_safe_redirect( admin_url( 'admin.php?page=vi-gestor-config&tab=' . $tab . $result ) );
		exit;
	}

	/**
	 * Troca as páginas de carrinho/checkout para os shortcodes clássicos.
	 */
	public static function classic_checkout() {
		if ( ! current_user_can( VIG_Admin::CAP ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'villa-ibit-gestor' ) );
		}
		check_admin_referer( 'vig_classic_checkout' );
		wp_die( 'A substituição do carrinho e checkout está desativada. Aplique apenas o estilo no Visual Villa Ibit.', '', array( 'response' => 409 ) );
	}
}
