<?php
/**
 * Painel (resumo do dia) e Relatórios (período, gráfico, mais vendidos, categorias e pagamentos).
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;

class VIG_Dashboard {

	const PAID = array( 'wc-processing', 'wc-completed', 'wc-on-hold' );

	/**
	 * Pedidos pagos desde um timestamp.
	 *
	 * @return WC_Order[]
	 */
	private static function paid_orders( $since ) {
		return wc_get_orders( array( 'status' => self::PAID, 'date_created' => '>=' . $since, 'limit' => 2000, 'type' => 'shop_order' ) );
	}

	private static function sum( $orders ) {
		$t = 0;
		foreach ( $orders as $o ) {
			$t += (float) $o->get_total() - (float) $o->get_total_refunded();
		}
		return $t;
	}

	/**
	 * Gráfico de barras (vendas por dia).
	 */
	private static function chart( $orders, $days ) {
		$tz     = wp_timezone();
		$bucket = array();
		for ( $i = $days - 1; $i >= 0; $i-- ) {
			$bucket[ ( new DateTime( "-{$i} days", $tz ) )->format( 'Y-m-d' ) ] = 0;
		}
		foreach ( $orders as $o ) {
			$d = $o->get_date_created();
			if ( $d ) {
				$k = $d->date_i18n( 'Y-m-d' );
				if ( isset( $bucket[ $k ] ) ) {
					$bucket[ $k ] += (float) $o->get_total() - (float) $o->get_total_refunded();
				}
			}
		}
		$max  = max( 1, max( $bucket ) );
		$step = $days > 31 ? 7 : ( $days > 14 ? 3 : 1 );
		echo '<div class="vig-chart" role="img" aria-label="' . esc_attr__( 'Gráfico de vendas por dia', 'villa-ibit-gestor' ) . '"><div class="vig-chart__bars">';
		$i = 0;
		foreach ( $bucket as $day => $val ) {
			$h     = $val > 0 ? max( 3, round( $val / $max * 100 ) ) : 0;
			$label = date_i18n( 'd/m', strtotime( $day ) );
			echo '<div class="vig-chart__col" title="' . esc_attr( $label . ': ' . wp_strip_all_tags( wc_price( $val ) ) ) . '"><span class="vig-chart__bar" style="height:' . (int) $h . '%"></span><em>' . ( 0 === $i % $step ? esc_html( $label ) : '&nbsp;' ) . '</em></div>';
			$i++;
		}
		echo '</div><p class="vig-chart__max">' . esc_html( sprintf( __( 'Maior dia: %s', 'villa-ibit-gestor' ), wp_strip_all_tags( wc_price( $max > 1 ? $max : 0 ) ) ) ) . '</p></div>';
	}

	private static function kpi( $label, $value, $foot = '', $url = '', $class = '' ) {
		$tag = $url ? 'a' : 'div';
		echo '<' . $tag . ' class="vig-kpi ' . esc_attr( $class ) . '"' . ( $url ? ' href="' . esc_url( $url ) . '"' : '' ) . '><span>' . esc_html( $label ) . '</span><strong>' . wp_kses_post( $value ) . '</strong>' . ( $foot ? '<em>' . wp_kses_post( $foot ) . '</em>' : '' ) . '</' . $tag . '>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	/* ================================================================ */
	public static function render() {
		$tz      = wp_timezone();
		$today   = ( new DateTime( 'today', $tz ) )->getTimestamp();
		$month   = ( new DateTime( '-29 days today', $tz ) )->getTimestamp();
		$prev    = ( new DateTime( '-59 days today', $tz ) )->getTimestamp();
		$o_month = self::paid_orders( $month );
		$o_today = array_filter( $o_month, function ( $o ) use ( $today ) { return $o->get_date_created() && $o->get_date_created()->getTimestamp() >= $today; } );
		$o_prev  = array_filter( self::paid_orders( $prev ), function ( $o ) use ( $month ) { return $o->get_date_created() && $o->get_date_created()->getTimestamp() < $month; } );
		$m_total = self::sum( $o_month );
		$p_total = self::sum( $o_prev );
		$diff    = $p_total > 0 ? round( ( $m_total - $p_total ) / $p_total * 100 ) : null;
		$to_ship = VIG_Admin::count_orders( 'wc-processing' );
		$pending = VIG_Admin::count_orders( array( 'wc-pending', 'wc-on-hold' ) );
		$low     = VIG_Products::low_stock_items( max( 0, (int) vig_value( 'low_stock', 3 ) ), 8 );
		$user    = wp_get_current_user();

		$actions  = VIG_Admin::btn( __( 'Novo produto', 'villa-ibit-gestor' ), admin_url( 'admin.php?page=vi-gestor-produto' ), 'is-primary', 'plus' );
		$actions .= '<div class="vig-dash-action-pair">';
		$actions .= VIG_Admin::btn( __( 'Criar cupom', 'villa-ibit-gestor' ), admin_url( 'admin.php?page=vi-gestor-cupons' ), 'is-ghost', 'ticket' );
		$actions .= VIG_Bling::dashboard_action() . '</div>';
		VIG_Admin::header( 'vi-gestor', sprintf( __( 'Olá, %s!', 'villa-ibit-gestor' ), $user->first_name ? $user->first_name : $user->display_name ), $actions, date_i18n( 'l, d \d\e F' ) );

		VIG_Admin::app_card( true );
		if ( class_exists( 'VIG_Notify' ) ) {
			VIG_Notify::dashboard_card();
		}
		echo '<div class="vig-kpis">';
		self::kpi( __( 'Vendas hoje', 'villa-ibit-gestor' ), wc_price( self::sum( $o_today ) ), sprintf( _n( '%d pedido', '%d pedidos', count( $o_today ), 'villa-ibit-gestor' ), count( $o_today ) ) );
		self::kpi( __( 'Últimos 30 dias', 'villa-ibit-gestor' ), wc_price( $m_total ), null === $diff ? sprintf( _n( '%d pedido', '%d pedidos', count( $o_month ), 'villa-ibit-gestor' ), count( $o_month ) ) : '<b class="' . ( $diff >= 0 ? 'is-up' : 'is-down' ) . '">' . ( $diff >= 0 ? '▲ ' : '▼ ' ) . abs( $diff ) . '%</b> ' . esc_html__( 'vs. 30 dias anteriores', 'villa-ibit-gestor' ) );
		self::kpi( __( 'Ticket médio', 'villa-ibit-gestor' ), wc_price( count( $o_month ) ? $m_total / count( $o_month ) : 0 ), __( 'últimos 30 dias', 'villa-ibit-gestor' ) );
		self::kpi( __( 'Para separar e enviar', 'villa-ibit-gestor' ), (string) $to_ship, __( 'pedidos pagos →', 'villa-ibit-gestor' ), admin_url( 'admin.php?page=vi-gestor-pedidos&status=processing' ), $to_ship ? 'is-alert' : '' );
		self::kpi( __( 'Aguardando pagamento', 'villa-ibit-gestor' ), (string) $pending, __( 'PIX/boleto em aberto →', 'villa-ibit-gestor' ), admin_url( 'admin.php?page=vi-gestor-pedidos&status=pending' ) );
		echo '</div>';

		echo '<div class="vig-grid-dash">';
		echo '<section class="vig-card vig-span2"><div class="vig-card__head"><h2 class="vig-card__title">' . esc_html__( 'Vendas dos últimos 14 dias', 'villa-ibit-gestor' ) . '</h2><a href="' . esc_url( admin_url( 'admin.php?page=vi-gestor-relatorios' ) ) . '">' . esc_html__( 'Relatórios completos', 'villa-ibit-gestor' ) . ' →</a></div>';
		self::chart( array_filter( $o_month, function ( $o ) { return $o->get_date_created() && $o->get_date_created()->getTimestamp() >= strtotime( '-14 days' ); } ), 14 );
		echo '</section>';

		echo '<section class="vig-card"><div class="vig-card__head"><h2 class="vig-card__title">' . esc_html__( 'Estoque acabando', 'villa-ibit-gestor' ) . '</h2><a href="' . esc_url( admin_url( 'admin.php?page=vi-gestor-estoque&estoque=baixo' ) ) . '">' . esc_html__( 'Repor', 'villa-ibit-gestor' ) . ' →</a></div>';
		if ( ! $low ) {
			echo '<p class="vig-ok">' . VIG_Admin::icon( 'check', 16 ) . esc_html__( 'Tudo certo: nenhum produto ou sabor com estoque baixo.', 'villa-ibit-gestor' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
		} else {
			echo '<ul class="vig-list">';
			foreach ( $low as $item ) {
				$qty = (int) $item->get_stock_quantity();
				$pid = $item->get_parent_id() ? $item->get_parent_id() : $item->get_id();
				echo '<li><a href="' . esc_url( admin_url( 'admin.php?page=vi-gestor-produto&id=' . $pid ) ) . '">' . esc_html( wp_strip_all_tags( $item->get_name() ) ) . '</a><span class="vig-pill ' . ( $qty <= 0 ? 'is-red' : 'is-gold' ) . '">' . esc_html( $qty <= 0 ? __( 'Esgotado', 'villa-ibit-gestor' ) : sprintf( __( '%d un.', 'villa-ibit-gestor' ), $qty ) ) . '</span></li>';
			}
			echo '</ul>';
		}
		echo '</section>';

		echo '<section class="vig-card vig-span2 vig-card--flush"><div class="vig-card__head vig-card__head--pad"><h2 class="vig-card__title">' . esc_html__( 'Pedidos recentes', 'villa-ibit-gestor' ) . '</h2><a href="' . esc_url( admin_url( 'admin.php?page=vi-gestor-pedidos' ) ) . '">' . esc_html__( 'Ver todos', 'villa-ibit-gestor' ) . ' →</a></div>';
		VIG_Orders::table( wc_get_orders( array( 'limit' => 8, 'type' => 'shop_order', 'orderby' => 'date', 'order' => 'DESC' ) ), true );
		echo '</section>';

		echo '<section class="vig-card"><h2 class="vig-card__title">' . esc_html__( 'Atalhos', 'villa-ibit-gestor' ) . '</h2><div class="vig-shortcut-grid">';
		$short = array(
			array( 'plus', __( 'Novo produto', 'villa-ibit-gestor' ), 'vi-gestor-produto' ),
			array( 'layers', __( 'Estoque rápido', 'villa-ibit-gestor' ), 'vi-gestor-estoque' ),
			array( 'grid', __( 'Categorias', 'villa-ibit-gestor' ), 'vi-gestor-categorias' ),
			array( 'ticket', __( 'Cupons', 'villa-ibit-gestor' ), 'vi-gestor-cupons' ),
			array( 'star', __( 'Avaliações', 'villa-ibit-gestor' ), 'vi-gestor-avaliacoes' ),
			array( 'gear', __( 'Banner da home', 'villa-ibit-gestor' ), 'vi-gestor-config&tab=banner' ),
		);
		foreach ( $short as $s ) {
			echo '<a href="' . esc_url( admin_url( 'admin.php?page=' . $s[2] ) ) . '">' . VIG_Admin::icon( $s[0], 20 ) . '<span>' . esc_html( $s[1] ) . '</span></a>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</div></section>';
		echo '</div>';
		VIG_Admin::footer();
	}

	/* ================================================================ */
	public static function render_reports() {
		$days   = isset( $_GET['dias'] ) ? absint( $_GET['dias'] ) : 30; // phpcs:ignore WordPress.Security.NonceVerification
		$days   = in_array( $days, array( 7, 30, 90 ), true ) ? $days : 30;
		$since  = ( new DateTime( '-' . ( $days - 1 ) . ' days today', wp_timezone() ) )->getTimestamp();
		$orders = self::paid_orders( $since );
		$total  = self::sum( $orders );

		$products = array();
		$cats     = array();
		$pay      = array();
		$items_n  = 0;
		foreach ( $orders as $o ) {
			$pm         = $o->get_payment_method_title() ? $o->get_payment_method_title() : __( 'Outro', 'villa-ibit-gestor' );
			$pay[ $pm ] = ( $pay[ $pm ] ?? 0 ) + (float) $o->get_total();
			foreach ( $o->get_items() as $item ) {
				$pid   = $item->get_product_id();
				$qty   = (int) $item->get_quantity();
				$items_n += $qty;
				if ( ! isset( $products[ $pid ] ) ) {
					$products[ $pid ] = array( 'name' => $item->get_name(), 'qty' => 0, 'total' => 0 );
				}
				$products[ $pid ]['qty']   += $qty;
				$products[ $pid ]['total'] += (float) $item->get_total();
				foreach ( wc_get_product_terms( $pid, 'product_cat', array( 'fields' => 'names' ) ) as $cn ) {
					$cats[ $cn ] = ( $cats[ $cn ] ?? 0 ) + (float) $item->get_total();
				}
			}
		}
		uasort( $products, function ( $a, $b ) { return $b['total'] <=> $a['total']; } );
		arsort( $cats );
		arsort( $pay );

		$seg = '<nav class="vig-seg">';
		foreach ( array( 7, 30, 90 ) as $d ) {
			$seg .= '<a class="' . ( $d === $days ? 'is-on' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=vi-gestor-relatorios&dias=' . $d ) ) . '">' . esc_html( sprintf( __( '%d dias', 'villa-ibit-gestor' ), $d ) ) . '</a>';
		}
		$seg .= '</nav>';
		VIG_Admin::header( 'vi-gestor-relatorios', __( 'Relatórios', 'villa-ibit-gestor' ), $seg, __( 'Considera pedidos pagos (processando, concluído e em espera).', 'villa-ibit-gestor' ) );

		echo '<div class="vig-kpis">';
		self::kpi( __( 'Faturamento', 'villa-ibit-gestor' ), wc_price( $total ), sprintf( __( 'nos últimos %d dias', 'villa-ibit-gestor' ), $days ) );
		self::kpi( __( 'Pedidos', 'villa-ibit-gestor' ), (string) count( $orders ) );
		self::kpi( __( 'Ticket médio', 'villa-ibit-gestor' ), wc_price( count( $orders ) ? $total / count( $orders ) : 0 ) );
		self::kpi( __( 'Itens vendidos', 'villa-ibit-gestor' ), (string) $items_n );
		echo '</div>';

		echo '<section class="vig-card"><h2 class="vig-card__title">' . esc_html__( 'Faturamento por dia', 'villa-ibit-gestor' ) . '</h2>';
		self::chart( $orders, $days );
		echo '</section><div class="vig-grid-dash">';

		echo '<section class="vig-card vig-span2"><h2 class="vig-card__title">' . esc_html__( 'Produtos mais vendidos', 'villa-ibit-gestor' ) . '</h2>';
		if ( $products ) {
			echo '<div class="vig-table-wrap"><table class="vig-table"><thead><tr><th>' . esc_html__( 'Produto', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Unidades', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Faturamento', 'villa-ibit-gestor' ) . '</th></tr></thead><tbody>';
			foreach ( array_slice( $products, 0, 10, true ) as $pid => $row ) {
				echo '<tr><td><a href="' . esc_url( admin_url( 'admin.php?page=vi-gestor-produto&id=' . $pid ) ) . '">' . esc_html( $row['name'] ) . '</a></td><td>' . (int) $row['qty'] . '</td><td class="vig-strong">' . wp_kses_post( wc_price( $row['total'] ) ) . '</td></tr>';
			}
			echo '</tbody></table></div>';
		} else {
			echo '<p class="vig-empty">' . esc_html__( 'Sem vendas no período.', 'villa-ibit-gestor' ) . '</p>';
		}
		echo '</section><div class="vig-stack">';
		foreach ( array( array( __( 'Por categoria', 'villa-ibit-gestor' ), $cats ), array( __( 'Por forma de pagamento', 'villa-ibit-gestor' ), $pay ) ) as $block ) {
			echo '<section class="vig-card"><h2 class="vig-card__title">' . esc_html( $block[0] ) . '</h2>';
			$max = $block[1] ? max( $block[1] ) : 1;
			if ( ! $block[1] ) {
				echo '<p class="vig-empty">' . esc_html__( 'Sem dados.', 'villa-ibit-gestor' ) . '</p>';
			}
			foreach ( array_slice( $block[1], 0, 6, true ) as $name => $v ) {
				echo '<div class="vig-hbar"><div class="vig-hbar__top"><span>' . esc_html( $name ) . '</span><strong>' . wp_kses_post( wc_price( $v ) ) . '</strong></div><span class="vig-hbar__track"><span style="width:' . (int) round( $v / max( 1, $max ) * 100 ) . '%"></span></span></div>';
			}
			echo '</section>';
		}
		echo '</div></div>';
		VIG_Admin::footer();
	}
}
