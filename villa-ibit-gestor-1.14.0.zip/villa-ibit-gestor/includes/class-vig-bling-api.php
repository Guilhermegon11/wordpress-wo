<?php
/** Cliente de leitura e autorização OAuth da API v3 do Bling. */
defined( 'ABSPATH' ) || exit;

class VIG_Bling_API {
	const BASE = 'https://api.bling.com.br/Api/v3';
	const APP = 'vig_bling_app';
	const TOKENS = 'vig_bling_tokens';

	public static function connected() {
		return (bool) get_option( self::TOKENS, '' );
	}

	private static function request( $url, $args ) {
		// O limite é por conta. Espaça inclusive chamadas de renovação do token.
		static $last_call = 0;
		$wait = 0.38 - ( microtime( true ) - $last_call );
		if ( $wait > 0 ) {
			usleep( (int) ceil( $wait * 1000000 ) );
		}
		$last_call = microtime( true );
		$args['timeout'] = 15;
		$args['redirection'] = 0;
		$response = wp_remote_request( $url, $args );
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'bling_temp', 'O Bling não respondeu. A tentativa será repetida.' );
		}
		$status = wp_remote_retrieve_response_code( $response );
		if ( 429 === $status || $status >= 500 || 408 === $status ) {
			$retry = wp_remote_retrieve_header( $response, 'retry-after' );
			$delay = is_numeric( $retry ) ? (int) $retry : max( 0, (int) strtotime( (string) $retry ) - time() );
			return new WP_Error( 'bling_temp', 'O Bling pediu uma pausa ou está indisponível (HTTP ' . $status . ').', array( 'delay' => $delay ) );
		}
		if ( $status < 200 || $status >= 300 ) {
			return new WP_Error( 'bling_http_' . $status, 'A API do Bling retornou HTTP ' . $status . '.' );
		}
		$json = json_decode( wp_remote_retrieve_body( $response ), true );
		return is_array( $json ) ? $json : new WP_Error( 'bling_temp', 'O Bling retornou uma resposta ilegível.' );
	}

	/** Chamado apenas enquanto a trava da integração estiver ativa. */
	public static function exchange( $body ) {
		$app = get_option( self::APP, array() );
		$secret = VIG_Secrets::open( $app['secret'] ?? '' );
		if ( empty( $app['client_id'] ) || is_wp_error( $secret ) || ! $secret ) {
			return new WP_Error( 'bling_auth', 'Salve o Client ID e o Client Secret do aplicativo novamente.' );
		}
		$tokens = self::request( self::BASE . '/oauth/token', array(
			'method' => 'POST',
			'headers' => array(
				'Authorization' => 'Basic ' . base64_encode( $app['client_id'] . ':' . $secret ),
				'Content-Type' => 'application/x-www-form-urlencoded',
				'Accept' => '1.0',
				'enable-jwt' => '1',
			),
			'body' => $body,
		) );
		if ( is_wp_error( $tokens ) ) {
			if ( 'bling_temp' === $tokens->get_error_code() ) {
				return $tokens;
			}
			return new WP_Error( 'bling_auth', 'O Bling recusou a autorização. Confira o aplicativo e conecte a conta novamente.' );
		}
		if ( empty( $tokens['access_token'] ) || empty( $tokens['refresh_token'] ) || empty( $tokens['expires_in'] ) ) {
			return new WP_Error( 'bling_auth', 'A autorização do Bling veio incompleta. Conecte a conta novamente.' );
		}
		$data = array(
			'access' => $tokens['access_token'],
			'refresh' => $tokens['refresh_token'],
			'expires' => time() + (int) $tokens['expires_in'],
		);
		$sealed = VIG_Secrets::seal( wp_json_encode( $data ) );
		if ( is_wp_error( $sealed ) ) {
			return new WP_Error( 'bling_auth', 'Não foi possível proteger as credenciais recebidas. Confira as chaves do WordPress.' );
		}
		if ( ! update_option( self::TOKENS, $sealed, false ) && $sealed !== get_option( self::TOKENS ) ) {
			return new WP_Error( 'bling_auth', 'O WordPress não conseguiu salvar a autorização. Conecte a conta novamente.' );
		}
		return $data;
	}

	private static function tokens( $force_refresh = false ) {
		$cipher = get_option( self::TOKENS, '' );
		$plain = $cipher ? VIG_Secrets::open( $cipher ) : '';
		$data = is_wp_error( $plain ) ? null : json_decode( $plain, true );
		if ( empty( $data['access'] ) || empty( $data['refresh'] ) ) {
			return new WP_Error( 'bling_auth', 'Conecte a conta Bling para continuar.' );
		}
		if ( $force_refresh || (int) $data['expires'] <= time() + 90 ) {
			return self::exchange( array( 'grant_type' => 'refresh_token', 'refresh_token' => $data['refresh'] ) );
		}
		return $data;
	}

	public static function get( $path, $params = array() ) {
		$url = self::BASE . $path;
		if ( $params ) {
			$url .= '?' . preg_replace( '/%5B[0-9]+%5D(?==)/i', '%5B%5D', http_build_query( $params, '', '&', PHP_QUERY_RFC3986 ) );
		}
		for ( $try = 0; $try < 2; ++$try ) {
			$tokens = self::tokens( $try > 0 );
			if ( is_wp_error( $tokens ) ) {
				return $tokens;
			}
			$json = self::request( $url, array(
				'method' => 'GET',
				'headers' => array( 'Authorization' => 'Bearer ' . $tokens['access'], 'enable-jwt' => '1', 'Accept' => 'application/json' ),
			) );
			if ( is_wp_error( $json ) && 'bling_http_401' === $json->get_error_code() ) {
				continue;
			}
			if ( is_wp_error( $json ) ) {
				return $json;
			}
			if ( ! isset( $json['data'] ) || ! is_array( $json['data'] ) ) {
				return new WP_Error( 'bling_temp', 'A resposta do Bling veio sem o campo de dados.' );
			}
			return $json['data'];
		}
		return new WP_Error( 'bling_auth', 'O Bling recusou o acesso. Reconecte o aplicativo.' );
	}
}
