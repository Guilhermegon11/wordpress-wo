<?php
/**
 * Produtos: lista e editor completo, com cadastro de sabores (viram as opções da página do produto).
 *
 * Como funciona por baixo: os sabores são gravados como variações do WooCommerce
 * (atributo "Sabor"), então estoque por sabor, carrinho e pedidos funcionam normalmente.
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;

class VIG_Product_Editor {

	public static function init() {
		add_action( 'admin_post_vig_save_product_full', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_vig_product_action', array( __CLASS__, 'action' ) );
		add_action( 'wp_ajax_vig_toggle_featured', array( __CLASS__, 'ajax_featured' ) );
	}

	/**
	 * Liga/desliga o destaque (estrela) direto na lista de produtos.
	 */
	public static function ajax_featured() {
		VIG_Admin::check_ajax();
		$p = wc_get_product( isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0 ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! $p || $p->is_type( 'variation' ) ) {
			wp_send_json_error( array( 'message' => __( 'Produto inválido.', 'villa-ibit-gestor' ) ), 400 );
		}
		$p->set_featured( ! $p->is_featured() );
		$p->save();
		wp_send_json_success( array( 'featured' => $p->is_featured() ) );
	}

	/* ================================================================ *
	 * Leitura dos sabores de um produto
	 * ================================================================ */

	/**
	 * Atributo de variação do produto (o primeiro).
	 *
	 * @return array{label:string,key:string,taxonomy:bool}|null
	 */
	private static function variation_attribute( WC_Product $p ) {
		foreach ( $p->get_attributes() as $key => $attr ) {
			if ( $attr->get_variation() ) {
				return array( 'label' => wc_attribute_label( $attr->get_name(), $p ), 'key' => $key, 'name' => $attr->get_name(), 'taxonomy' => $attr->is_taxonomy() );
			}
		}
		return null;
	}

	/** O editor de sabores representa uma única opção local por variação. */
	private static function editor_notice( WC_Product $p ) {
		$source = $p->get_meta( '_vig_bling_id' )
			? __( 'Edite o cadastro no Bling. A próxima sincronização traz as alterações para a loja.', 'villa-ibit-gestor' )
			: __( 'Abra o editor completo do WooCommerce para alterar esse cadastro.', 'villa-ibit-gestor' );
		if ( ! $p->is_type( array( 'simple', 'variable' ) ) ) {
			return $source;
		}
		$axes = array();
		foreach ( $p->get_attributes() as $key => $attribute ) {
			if ( $attribute->get_variation() ) {
				$axes[ $key ] = $attribute;
			}
		}
		if ( ! $p->is_type( 'variable' ) ) {
			return '';
		}
		if ( count( $axes ) !== 1 || reset( $axes )->is_taxonomy() || $p->get_manage_stock( 'edit' ) ) {
			return $source;
		}
		$key  = key( $axes );
		$seen = array();
		foreach ( $p->get_children() as $id ) {
			$child = wc_get_product( $id );
			$attrs = $child ? $child->get_attributes() : array();
			$value = strtolower( trim( (string) ( $attrs[ $key ] ?? '' ) ) );
			if ( '' === $value || isset( $seen[ $value ] ) || count( $attrs ) !== 1 || 'publish' !== $child->get_status( 'edit' ) ) {
				return $source;
			}
			$seen[ $value ] = true;
		}
		return '';
	}

	/** Evita que um formulário aberto antes de uma importação sobrescreva o catálogo atualizado. */
	private static function edit_revision( WC_Product $p ) {
		$data = $p->get_data();
		$data['attributes'] = array_map( function ( $attr ) { return $attr->get_data(); }, $p->get_attributes() );
		if ( $p->is_type( 'variable' ) ) {
			foreach ( $p->get_children() as $id ) {
				$child = wc_get_product( $id );
				$data['variations'][ $id ] = $child ? $child->get_data() : null;
			}
		}
		return wp_hash( wp_json_encode( $data ) );
	}

	/** null indica promoções distintas, que o campo único não deve sobrescrever ao salvar. */
	private static function common_sale( WC_Product $p ) {
		$prices = array();
		foreach ( $p->get_children() as $id ) {
			$child = wc_get_product( $id );
			if ( $child ) {
				$prices[] = (string) $child->get_sale_price( 'edit' );
			}
		}
		return count( array_unique( $prices ) ) > 1 ? null : ( $prices[0] ?? '' );
	}

	/**
	 * Nome legível do valor de uma variação.
	 */
	private static function variation_value( WC_Product_Variation $v, $attr ) {
		$values = $v->get_attributes();
		$raw    = isset( $values[ $attr['key'] ] ) ? $values[ $attr['key'] ] : reset( $values );
		if ( $attr['taxonomy'] && $raw ) {
			$term = get_term_by( 'slug', $raw, $attr['name'] );
			return $term ? $term->name : $raw;
		}
		return (string) $raw;
	}

	/**
	 * Sabores atuais: [ ['id','name','stock','price','in_stock'] ].
	 */
	public static function flavors( WC_Product $p ) {
		if ( ! $p->is_type( 'variable' ) ) {
			return array();
		}
		$attr = self::variation_attribute( $p );
		if ( ! $attr ) {
			return array();
		}
		$base = (float) $p->get_variation_regular_price( 'min' );
		$out  = array();
		foreach ( $p->get_children() as $vid ) {
			$v = wc_get_product( $vid );
			if ( ! $v instanceof WC_Product_Variation ) {
				continue;
			}
			$out[] = array(
				'id'       => $vid,
				'name'     => self::variation_value( $v, $attr ),
				'stock'    => $v->get_manage_stock() ? (string) $v->get_stock_quantity() : '',
				'price'    => (float) $v->get_regular_price() !== $base ? wc_format_localized_price( $v->get_regular_price() ) : '',
				'in_stock' => 'outofstock' !== $v->get_stock_status(),
			);
		}
		return $out;
	}

	/* ================================================================ *
	 * Lista
	 * ================================================================ */
	public static function render_list() {
		$q      = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$cat    = isset( $_GET['cat'] ) ? sanitize_title( wp_unslash( $_GET['cat'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : 'all'; // phpcs:ignore WordPress.Security.NonceVerification
		$paged  = max( 1, isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1 ); // phpcs:ignore WordPress.Security.NonceVerification

		$args = array( 'limit' => 20, 'page' => $paged, 'paginate' => true, 'orderby' => 'date', 'order' => 'DESC', 'status' => array( 'publish', 'draft', 'private', 'pending' ) );
		if ( in_array( $status, array( 'publish', 'draft' ), true ) ) {
			$args['status'] = array( $status );
		} elseif ( 'outofstock' === $status ) {
			$args['stock_status'] = 'outofstock';
		} elseif ( 'sale' === $status ) {
			$ids             = wc_get_product_ids_on_sale();
			$args['include'] = $ids ? $ids : array( 0 );
		}
		if ( $cat ) {
			$args['category'] = array( $cat );
		}
		if ( $q ) {
			$by_sku          = wc_get_products( array( 'sku' => $q, 'return' => 'ids', 'limit' => 50, 'status' => $args['status'] ) );
			$by_name         = get_posts( array( 'post_type' => 'product', 's' => $q, 'fields' => 'ids', 'posts_per_page' => 200, 'post_status' => 'any' ) );
			$found           = array_unique( array_merge( $by_sku, $by_name ) );
			$args['include'] = $found ? $found : array( 0 );
		}
		$result = wc_get_products( $args );

		$counts = wp_count_posts( 'product' );
		VIG_Admin::header(
			'vi-gestor-produtos',
			__( 'Produtos', 'villa-ibit-gestor' ),
			VIG_Admin::btn( __( 'Novo produto', 'villa-ibit-gestor' ), admin_url( 'admin.php?page=vi-gestor-produto' ), 'is-primary', 'plus' ),
			sprintf( __( '%1$d publicados · %2$d rascunhos', 'villa-ibit-gestor' ), (int) $counts->publish, (int) $counts->draft )
		);

		$filters = array( 'all' => __( 'Todos', 'villa-ibit-gestor' ), 'publish' => __( 'Publicados', 'villa-ibit-gestor' ), 'draft' => __( 'Rascunhos', 'villa-ibit-gestor' ), 'sale' => __( 'Em oferta', 'villa-ibit-gestor' ), 'outofstock' => __( 'Esgotados', 'villa-ibit-gestor' ) );
		$cats    = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
		echo '<div class="vig-toolbar"><nav class="vig-seg">';
		foreach ( $filters as $k => $l ) {
			echo '<a class="' . ( $k === $status ? 'is-on' : '' ) . '" href="' . esc_url( add_query_arg( array( 'page' => 'vi-gestor-produtos', 'status' => $k, 'cat' => $cat ), admin_url( 'admin.php' ) ) ) . '">' . esc_html( $l ) . '</a>';
		}
		echo '</nav><form class="vig-search" method="get"><input type="hidden" name="page" value="vi-gestor-produtos"><input type="hidden" name="status" value="' . esc_attr( $status ) . '">';
		echo '<label class="screen-reader-text" for="vig-cat">' . esc_html__( 'Categoria', 'villa-ibit-gestor' ) . '</label><select id="vig-cat" name="cat" onchange="this.form.submit()"><option value="">' . esc_html__( 'Todas as categorias', 'villa-ibit-gestor' ) . '</option>';
		if ( ! is_wp_error( $cats ) ) {
			foreach ( $cats as $t ) {
				echo '<option value="' . esc_attr( $t->slug ) . '"' . selected( $cat, $t->slug, false ) . '>' . esc_html( $t->name ) . '</option>';
			}
		}
		echo '</select><span class="vig-search__box">' . VIG_Admin::icon( 'search', 16 ) . '<label class="screen-reader-text" for="vig-q">' . esc_html__( 'Buscar', 'villa-ibit-gestor' ) . '</label><input id="vig-q" type="search" name="q" value="' . esc_attr( $q ) . '" placeholder="' . esc_attr__( 'Buscar por nome ou código', 'villa-ibit-gestor' ) . '"></span></form></div>'; // phpcs:ignore WordPress.Security.EscapeOutput

		if ( ! $result->products ) {
			VIG_Admin::empty_state( __( 'Nenhum produto encontrado', 'villa-ibit-gestor' ), __( 'Cadastre seu primeiro produto com fotos, preço e sabores.', 'villa-ibit-gestor' ), VIG_Admin::btn( __( 'Novo produto', 'villa-ibit-gestor' ), admin_url( 'admin.php?page=vi-gestor-produto' ), 'is-primary', 'plus' ) );
			VIG_Admin::footer();
			return;
		}

		echo '<div class="vig-card vig-card--flush"><div class="vig-table-wrap"><table class="vig-table vig-table--products"><thead><tr><th>' . esc_html__( 'Produto', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Preço', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Sabores', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Estoque', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Vendas', 'villa-ibit-gestor' ) . '</th><th><span class="screen-reader-text">' . esc_html__( 'Ações', 'villa-ibit-gestor' ) . '</span></th></tr></thead><tbody>';
		foreach ( $result->products as $p ) {
			$edit    = admin_url( 'admin.php?page=vi-gestor-produto&id=' . $p->get_id() );
			$flavors = self::flavors( $p );
			$thumb   = $p->get_image_id() ? wp_get_attachment_image_url( $p->get_image_id(), 'thumbnail' ) : wc_placeholder_img_src( 'thumbnail' );
			$cats_t  = wp_strip_all_tags( wc_get_product_category_list( $p->get_id(), ', ' ) );
			// Estoque resumido.
			if ( $flavors ) {
				$out   = count( array_filter( $flavors, function ( $f ) { return ! $f['in_stock']; } ) );
				$units = array_sum( array_map( function ( $f ) { return '' === $f['stock'] ? 0 : (int) $f['stock']; }, $flavors ) );
				$stock = $out === count( $flavors ) ? '<span class="vig-pill is-red">' . esc_html__( 'Esgotado', 'villa-ibit-gestor' ) . '</span>' : ( $out ? '<span class="vig-pill is-gold">' . esc_html( sprintf( __( '%d esgotado(s)', 'villa-ibit-gestor' ), $out ) ) . '</span>' : '<span class="vig-pill is-green">' . esc_html__( 'Em estoque', 'villa-ibit-gestor' ) . '</span>' );
				$stock .= $units ? '<br><span class="vig-muted">' . esc_html( sprintf( __( '%d un. no total', 'villa-ibit-gestor' ), $units ) ) . '</span>' : '';
			} else {
				$stock = $p->is_in_stock() ? '<span class="vig-pill is-green">' . esc_html( $p->get_manage_stock() ? sprintf( __( '%d un.', 'villa-ibit-gestor' ), $p->get_stock_quantity() ) : __( 'Em estoque', 'villa-ibit-gestor' ) ) . '</span>' : '<span class="vig-pill is-red">' . esc_html__( 'Esgotado', 'villa-ibit-gestor' ) . '</span>';
			}
			echo '<tr><td class="vig-cell-head"><a class="vig-prod" href="' . esc_url( $edit ) . '"><img src="' . esc_url( $thumb ) . '" alt=""><span><strong>' . esc_html( $p->get_name() ) . '</strong>';
			echo '<em>' . esc_html( $cats_t ? $cats_t : __( 'Sem categoria', 'villa-ibit-gestor' ) ) . '</em>';
			if ( 'publish' !== $p->get_status() ) {
				echo '<span class="vig-pill">' . esc_html__( 'Rascunho', 'villa-ibit-gestor' ) . '</span>';
			}
			if ( $p->is_featured() ) {
				echo '<span class="vig-pill is-gold">' . esc_html__( 'Destaque', 'villa-ibit-gestor' ) . '</span>';
			}
			echo '</span></a></td>';
			echo '<td class="vig-nowrap" data-label="' . esc_attr__( 'Preço', 'villa-ibit-gestor' ) . '">' . wp_kses_post( $p->get_price_html() ) . '</td>';
			echo '<td data-label="' . esc_attr__( 'Sabores', 'villa-ibit-gestor' ) . '">' . ( $flavors ? '<span class="vig-flavor-count" title="' . esc_attr( implode( ', ', wp_list_pluck( $flavors, 'name' ) ) ) . '">' . esc_html( sprintf( _n( '%d sabor', '%d sabores', count( $flavors ), 'villa-ibit-gestor' ), count( $flavors ) ) ) . '</span>' : '<span class="vig-muted">—</span>' ) . '</td>';
			echo '<td data-label="' . esc_attr__( 'Estoque', 'villa-ibit-gestor' ) . '">' . $stock . '</td>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<td data-label="' . esc_attr__( 'Vendas', 'villa-ibit-gestor' ) . '">' . (int) $p->get_total_sales() . '</td>';
			echo '<td class="vig-row-actions">';
			echo '<button type="button" class="vig-icon-btn vig-star' . ( $p->is_featured() ? ' is-on' : '' ) . '" data-vig-star="' . (int) $p->get_id() . '" aria-pressed="' . ( $p->is_featured() ? 'true' : 'false' ) . '" title="' . esc_attr__( 'Destaque (aparece na "Produtos em destaque" da home)', 'villa-ibit-gestor' ) . '" aria-label="' . esc_attr__( 'Destaque', 'villa-ibit-gestor' ) . '">' . VIG_Admin::icon( 'star', 16 ) . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo VIG_Admin::btn( __( 'Editar', 'villa-ibit-gestor' ), $edit, 'is-ghost is-sm', 'edit' ); // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<a class="vig-icon-btn" href="' . esc_url( get_permalink( $p->get_id() ) ) . '" target="_blank" title="' . esc_attr__( 'Ver na loja', 'villa-ibit-gestor' ) . '" aria-label="' . esc_attr__( 'Ver na loja', 'villa-ibit-gestor' ) . '">' . VIG_Admin::icon( 'eye', 16 ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<a class="vig-icon-btn" href="' . esc_url( self::action_url( 'duplicate', $p->get_id() ) ) . '" title="' . esc_attr__( 'Duplicar', 'villa-ibit-gestor' ) . '" aria-label="' . esc_attr__( 'Duplicar', 'villa-ibit-gestor' ) . '">' . VIG_Admin::icon( 'copy', 16 ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<a class="vig-icon-btn is-danger" data-vig-confirm="' . esc_attr__( 'Mover este produto para a lixeira?', 'villa-ibit-gestor' ) . '" href="' . esc_url( self::action_url( 'trash', $p->get_id() ) ) . '" title="' . esc_attr__( 'Excluir', 'villa-ibit-gestor' ) . '" aria-label="' . esc_attr__( 'Excluir', 'villa-ibit-gestor' ) . '">' . VIG_Admin::icon( 'trash', 16 ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
			echo '</td></tr>';
		}
		echo '</tbody></table></div></div>';
		VIG_Admin::pager( $paged, $result->max_num_pages );
		VIG_Admin::footer();
	}

	private static function action_url( $do, $id ) {
		return wp_nonce_url( admin_url( 'admin-post.php?action=vig_product_action&do=' . $do . '&id=' . (int) $id ), 'vig_product_action_' . $id );
	}

	public static function action() {
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		$do = isset( $_GET['do'] ) ? sanitize_key( wp_unslash( $_GET['do'] ) ) : '';
		if ( ! current_user_can( VIG_Admin::CAP ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'villa-ibit-gestor' ) );
		}
		check_admin_referer( 'vig_product_action_' . $id );
		$list = admin_url( 'admin.php?page=vi-gestor-produtos' );
		$p    = wc_get_product( $id );
		if ( ! $p ) {
			VIG_Admin::back( $list, __( 'Produto não encontrado.', 'villa-ibit-gestor' ), true );
		}
		if ( 'trash' === $do ) {
			wp_trash_post( $id );
			VIG_Admin::back( $list, __( 'Produto movido para a lixeira.', 'villa-ibit-gestor' ) );
		}
		if ( 'duplicate' === $do ) {
			if ( ! class_exists( 'WC_Admin_Duplicate_Product' ) ) {
				include_once WC_ABSPATH . 'includes/admin/class-wc-admin-duplicate-product.php';
			}
			$copy = ( new WC_Admin_Duplicate_Product() )->product_duplicate( $p );
			VIG_Admin::back( admin_url( 'admin.php?page=vi-gestor-produto&id=' . $copy->get_id() ), __( 'Cópia criada como rascunho. Ajuste e publique.', 'villa-ibit-gestor' ) );
		}
		VIG_Admin::back( $list, __( 'Ação inválida.', 'villa-ibit-gestor' ), true );
	}

	/* ================================================================ *
	 * Formulário
	 * ================================================================ */
	public static function render_form() {
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$p  = $id ? wc_get_product( $id ) : null;
		if ( $id && ! $p ) {
			VIG_Admin::header( 'vi-gestor-produtos', __( 'Produto não encontrado', 'villa-ibit-gestor' ) );
			VIG_Admin::footer();
			return;
		}
		$notice = $p ? self::editor_notice( $p ) : '';
		if ( $notice ) {
			$links = VIG_Admin::btn( __( 'Estoque rápido', 'villa-ibit-gestor' ), add_query_arg( array( 'page' => 'vi-gestor-estoque', 'q' => $p->get_sku() ?: $p->get_name() ), admin_url( 'admin.php' ) ), 'is-ghost' );
			if ( ! $p->get_meta( '_vig_bling_id' ) && current_user_can( 'edit_post', $id ) ) {
				$links .= VIG_Admin::btn( __( 'Editar no WooCommerce', 'villa-ibit-gestor' ), get_edit_post_link( $id, 'raw' ), 'is-primary' );
			}
			VIG_Admin::header( 'vi-gestor-produtos', $p->get_name() );
			VIG_Admin::empty_state( __( 'Este cadastro usa opções fora do editor de sabores', 'villa-ibit-gestor' ), $notice, $links );
			VIG_Admin::footer();
			return;
		}
		$is_new   = ! $p;
		$flavors  = $p ? self::flavors( $p ) : array();
		$attr     = $p && $p->is_type( 'variable' ) ? self::variation_attribute( $p ) : null;
		$label    = $attr ? $attr['label'] : 'Sabor';
		$price    = $p ? ( $p->is_type( 'variable' ) ? wc_format_localized_price( $p->get_variation_regular_price( 'min' ) ) : wc_format_localized_price( $p->get_regular_price() ) ) : '';
		$sale     = '';
		$mixed_sales = false;
		if ( $p ) {
			if ( $p->is_type( 'variable' ) ) {
				$vp          = self::common_sale( $p );
				$mixed_sales = null === $vp;
				$sale        = $mixed_sales ? '' : wc_format_localized_price( $vp );
			} else {
				$sale = wc_format_localized_price( $p->get_sale_price() );
			}
		}
		$specs = array();
		$shared_specs = array();
		if ( $p ) {
			foreach ( $p->get_attributes() as $a ) {
				if ( $a->get_variation() ) {
					continue;
				}
				if ( $a->is_taxonomy() ) {
					$shared_specs[] = wc_attribute_label( $a->get_name() );
				} else {
					$specs[] = array( wc_attribute_label( $a->get_name() ), implode( ', ', $a->get_options() ) );
				}
			}
		}
		$cat_ids   = $p ? $p->get_category_ids() : array();
		$brand_ids = ( $p && taxonomy_exists( 'product_brand' ) ) ? wp_get_object_terms( $p->get_id(), 'product_brand', array( 'fields' => 'ids' ) ) : array();
		$gallery   = $p ? $p->get_gallery_image_ids() : array();
		$image     = $p ? $p->get_image_id() : 0;

		$actions = '';
		if ( $p ) {
			$actions .= VIG_Admin::btn( __( 'Ver na loja', 'villa-ibit-gestor' ), get_permalink( $p->get_id() ), 'is-ghost', 'eye', 'target="_blank"' );
		}
		$actions .= '<button type="submit" form="vig-product-form" class="vig-btn is-primary">' . VIG_Admin::icon( 'check', 16 ) . '<span>' . esc_html__( 'Salvar produto', 'villa-ibit-gestor' ) . '</span></button>';
		VIG_Admin::header( $is_new ? 'vi-gestor-produto' : 'vi-gestor-produtos', $is_new ? __( 'Novo produto', 'villa-ibit-gestor' ) : $p->get_name(), $actions, $is_new ? __( 'Preencha os dados, adicione os sabores e salve.', 'villa-ibit-gestor' ) : '' );
		?>
		<p class="vig-backlink"><a href="<?php echo esc_url( admin_url( 'admin.php?page=vi-gestor-produtos' ) ); ?>"><?php echo VIG_Admin::icon( 'back', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'Todos os produtos', 'villa-ibit-gestor' ); ?></a></p>
		<form id="vig-product-form" class="vig-editor" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'vig_save_product_full' ); ?>
			<input type="hidden" name="action" value="vig_save_product_full">
			<input type="hidden" name="id" value="<?php echo (int) $id; ?>">
			<?php if ( $p ) : ?><input type="hidden" name="vig_revision" value="<?php echo esc_attr( self::edit_revision( $p ) ); ?>"><?php endif; ?>

			<div class="vig-editor__main">
				<section class="vig-card">
					<h2 class="vig-card__title"><?php esc_html_e( 'Informações básicas', 'villa-ibit-gestor' ); ?></h2>
					<div class="vig-field"><label for="vig-name"><?php esc_html_e( 'Nome do produto', 'villa-ibit-gestor' ); ?> <b class="vig-req">*</b></label><input id="vig-name" type="text" name="name" required value="<?php echo esc_attr( $p ? $p->get_name() : '' ); ?>" placeholder="<?php esc_attr_e( 'Ex.: Elf Bar Ice King 40K', 'villa-ibit-gestor' ); ?>"></div>
					<div class="vig-field"><label for="vig-short"><?php esc_html_e( 'Descrição curta', 'villa-ibit-gestor' ); ?></label><textarea id="vig-short" name="short" rows="2" placeholder="<?php esc_attr_e( 'Aparece ao lado do preço. Ex.: Até 40.000 puffs, tela inteligente e 30 sabores gelados.', 'villa-ibit-gestor' ); ?>"><?php echo esc_textarea( $p ? wp_strip_all_tags( $p->get_short_description() ) : '' ); ?></textarea></div>
					<div class="vig-field"><label for="vig-desc"><?php esc_html_e( 'Descrição completa', 'villa-ibit-gestor' ); ?></label>
						<?php wp_editor( $p ? $p->get_description() : '', 'vig-desc', array( 'textarea_name' => 'description', 'textarea_rows' => 8, 'media_buttons' => false, 'teeny' => true, 'quicktags' => false ) ); ?>
					</div>
				</section>

				<section class="vig-card">
					<h2 class="vig-card__title"><?php esc_html_e( 'Fotos', 'villa-ibit-gestor' ); ?></h2>
					<div class="vig-photos">
						<div class="vig-photo-main" data-vig-image>
							<input type="hidden" name="image_id" value="<?php echo (int) $image; ?>">
							<button type="button" class="vig-photo-drop" data-vig-pick-image>
								<img src="<?php echo esc_url( $image ? wp_get_attachment_image_url( $image, 'medium' ) : '' ); ?>" alt=""<?php echo $image ? '' : ' hidden'; ?>>
								<span<?php echo $image ? ' hidden' : ''; ?>><?php echo VIG_Admin::icon( 'plus', 22 ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'Foto principal', 'villa-ibit-gestor' ); ?></span>
							</button>
							<button type="button" class="vig-link-btn" data-vig-clear-image><?php esc_html_e( 'Remover', 'villa-ibit-gestor' ); ?></button>
						</div>
						<div class="vig-gallery" data-vig-gallery>
							<input type="hidden" name="gallery" value="<?php echo esc_attr( implode( ',', $gallery ) ); ?>">
							<ul class="vig-gallery__list">
								<?php foreach ( $gallery as $gid ) : ?>
									<li data-id="<?php echo (int) $gid; ?>"><img src="<?php echo esc_url( wp_get_attachment_image_url( $gid, 'thumbnail' ) ); ?>" alt=""><button type="button" aria-label="<?php esc_attr_e( 'Remover foto', 'villa-ibit-gestor' ); ?>" data-vig-gallery-remove>&times;</button></li>
								<?php endforeach; ?>
							</ul>
							<button type="button" class="vig-photo-add" data-vig-gallery-add><?php echo VIG_Admin::icon( 'plus', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'Mais fotos', 'villa-ibit-gestor' ); ?></button>
						</div>
					</div>
					<p class="vig-help"><?php esc_html_e( 'Use fotos quadradas com fundo branco ou transparente (mínimo 800 × 800 px). Arraste as fotos extras para mudar a ordem.', 'villa-ibit-gestor' ); ?></p>
				</section>

				<section class="vig-card">
					<h2 class="vig-card__title"><?php esc_html_e( 'Preço', 'villa-ibit-gestor' ); ?></h2>
					<div class="vig-grid3">
						<div class="vig-field"><label for="vig-price"><?php esc_html_e( 'Preço (R$)', 'villa-ibit-gestor' ); ?> <b class="vig-req">*</b></label><input id="vig-price" type="text" inputmode="decimal" name="price" value="<?php echo esc_attr( $price ); ?>" placeholder="0,00" data-vig-price></div>
						<div class="vig-field"><label for="vig-sale"><?php esc_html_e( 'Preço promocional (R$)', 'villa-ibit-gestor' ); ?></label><input id="vig-sale" type="text" inputmode="decimal" name="sale" value="<?php echo esc_attr( $sale ); ?>" placeholder="<?php esc_attr_e( 'Opcional', 'villa-ibit-gestor' ); ?>" data-vig-sale></div>
						<div class="vig-field vig-pix-preview"><span><?php esc_html_e( 'Cliente paga no PIX', 'villa-ibit-gestor' ); ?></span><strong data-vig-pix data-pct="<?php echo esc_attr( (string) vig_value( 'pix_percent', 5 ) ); ?>">—</strong></div>
					</div>
					<?php if ( $mixed_sales ) : ?>
						<p class="vig-help"><?php esc_html_e( 'Os sabores têm promoções diferentes. Deixe o preço promocional em branco para manter os valores ou preencha para aplicar o mesmo preço a todos.', 'villa-ibit-gestor' ); ?></p>
						<label class="vig-check"><input type="checkbox" name="clear_flavor_sales" value="1"> <?php esc_html_e( 'Remover todas as promoções dos sabores', 'villa-ibit-gestor' ); ?></label>
					<?php endif; ?>
				</section>

				<section class="vig-card" data-vig-flavors>
					<div class="vig-card__head">
						<div>
							<h2 class="vig-card__title"><?php esc_html_e( 'Sabores', 'villa-ibit-gestor' ); ?></h2>
							<p class="vig-help"><?php esc_html_e( 'Cada sabor vira um botão de escolha na página do produto. Deixe vazio se o produto não tem opções.', 'villa-ibit-gestor' ); ?></p>
						</div>
						<label class="vig-inline-select"><?php esc_html_e( 'Nome da opção', 'villa-ibit-gestor' ); ?>
							<select name="option_label">
								<?php foreach ( array( 'Sabor', 'Cor', 'Resistência', 'Tamanho', 'Opção' ) as $l ) : ?><option value="<?php echo esc_attr( $l ); ?>"<?php selected( $label, $l ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?>
								<?php if ( ! in_array( $label, array( 'Sabor', 'Cor', 'Resistência', 'Tamanho', 'Opção' ), true ) ) : ?><option value="<?php echo esc_attr( $label ); ?>" selected><?php echo esc_html( $label ); ?></option><?php endif; ?>
							</select>
						</label>
					</div>
					<div class="vig-flavors__head" aria-hidden="true"><span></span><span><?php esc_html_e( 'Sabor', 'villa-ibit-gestor' ); ?></span><span><?php esc_html_e( 'Estoque', 'villa-ibit-gestor' ); ?></span><span><?php esc_html_e( 'Preço próprio', 'villa-ibit-gestor' ); ?></span><span><?php esc_html_e( 'Disponível', 'villa-ibit-gestor' ); ?></span><span></span></div>
					<ul class="vig-flavors" data-vig-flavor-list>
						<?php foreach ( $flavors as $i => $f ) { self::flavor_row( $i, $f ); } ?>
					</ul>
					<template data-vig-flavor-template><?php self::flavor_row( '__i__', array( 'id' => 0, 'name' => '', 'stock' => '', 'price' => '', 'in_stock' => true ) ); ?></template>
					<div class="vig-flavors__add">
						<button type="button" class="vig-btn is-ghost" data-vig-flavor-add><?php echo VIG_Admin::icon( 'plus', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php esc_html_e( 'Adicionar sabor', 'villa-ibit-gestor' ); ?></span></button>
						<details class="vig-bulk-add"><summary><?php esc_html_e( 'Colar vários de uma vez', 'villa-ibit-gestor' ); ?></summary>
							<textarea rows="4" data-vig-flavor-bulk placeholder="<?php esc_attr_e( "Um sabor por linha:\nGrape Ice (Uva gelada)\nGreen Apple (Maçã verde)\nMenthol (Menta)", 'villa-ibit-gestor' ); ?>"></textarea>
							<button type="button" class="vig-btn is-sm" data-vig-flavor-bulk-add><?php esc_html_e( 'Adicionar à lista', 'villa-ibit-gestor' ); ?></button>
						</details>
					</div>
					<p class="vig-help"><?php esc_html_e( 'Estoque em branco = sem controle de quantidade. Preço próprio em branco = usa o preço do produto. Arraste para mudar a ordem.', 'villa-ibit-gestor' ); ?></p>
				</section>

				<section class="vig-card" data-vig-simple-stock<?php echo $flavors ? ' hidden' : ''; ?>>
					<h2 class="vig-card__title"><?php esc_html_e( 'Estoque', 'villa-ibit-gestor' ); ?></h2>
					<div class="vig-grid3">
						<div class="vig-field"><label for="vig-stock"><?php esc_html_e( 'Quantidade', 'villa-ibit-gestor' ); ?></label><input id="vig-stock" type="number" name="stock" value="<?php echo esc_attr( ( $p && ! $flavors && $p->get_manage_stock() ) ? (string) $p->get_stock_quantity() : '' ); ?>" placeholder="<?php esc_attr_e( 'Sem controle', 'villa-ibit-gestor' ); ?>"></div>
						<div class="vig-field"><label for="vig-stock-status"><?php esc_html_e( 'Disponibilidade', 'villa-ibit-gestor' ); ?></label><select id="vig-stock-status" name="stock_status"><option value="instock"<?php selected( $p ? $p->get_stock_status() : 'instock', 'instock' ); ?>><?php esc_html_e( 'Em estoque', 'villa-ibit-gestor' ); ?></option><option value="outofstock"<?php selected( $p ? $p->get_stock_status() : '', 'outofstock' ); ?>><?php esc_html_e( 'Esgotado', 'villa-ibit-gestor' ); ?></option></select></div>
						<div class="vig-field"><label for="vig-sku"><?php esc_html_e( 'Código (SKU)', 'villa-ibit-gestor' ); ?></label><input id="vig-sku" type="text" name="sku" value="<?php echo esc_attr( $p ? $p->get_sku() : '' ); ?>" placeholder="<?php esc_attr_e( 'Opcional', 'villa-ibit-gestor' ); ?>"></div>
					</div>
				</section>

				<section class="vig-card" data-vig-specs>
					<h2 class="vig-card__title"><?php esc_html_e( 'Especificações', 'villa-ibit-gestor' ); ?></h2>
					<p class="vig-help"><?php esc_html_e( 'Aparecem como destaques ao lado do preço e na aba "Especificações". Ex.: Puffs → até 40.000 · Nicotina → 5% · Bateria → 650 mAh.', 'villa-ibit-gestor' ); ?></p>
					<ul class="vig-specs" data-vig-spec-list>
						<?php foreach ( $specs as $s ) { self::spec_row( $s[0], $s[1] ); } ?>
					</ul>
					<?php if ( $shared_specs ) : ?><p class="vig-help"><?php echo esc_html( sprintf( __( 'Atributos globais mantidos pelo WooCommerce: %s.', 'villa-ibit-gestor' ), implode( ', ', $shared_specs ) ) ); ?></p><?php endif; ?>
					<template data-vig-spec-template><?php self::spec_row( '', '' ); ?></template>
					<button type="button" class="vig-btn is-ghost" data-vig-spec-add><?php echo VIG_Admin::icon( 'plus', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php esc_html_e( 'Adicionar especificação', 'villa-ibit-gestor' ); ?></span></button>
				</section>

				<section class="vig-card">
					<h2 class="vig-card__title"><?php esc_html_e( 'Entrega (para cálculo do frete)', 'villa-ibit-gestor' ); ?></h2>
					<div class="vig-grid4">
						<div class="vig-field"><label for="vig-weight"><?php esc_html_e( 'Peso (kg)', 'villa-ibit-gestor' ); ?></label><input id="vig-weight" type="text" inputmode="decimal" name="weight" value="<?php echo esc_attr( $p ? wc_format_localized_decimal( $p->get_weight() ) : '' ); ?>" placeholder="0,15"></div>
						<div class="vig-field"><label for="vig-len"><?php esc_html_e( 'Comprimento (cm)', 'villa-ibit-gestor' ); ?></label><input id="vig-len" type="text" inputmode="decimal" name="length" value="<?php echo esc_attr( $p ? wc_format_localized_decimal( $p->get_length() ) : '' ); ?>"></div>
						<div class="vig-field"><label for="vig-wid"><?php esc_html_e( 'Largura (cm)', 'villa-ibit-gestor' ); ?></label><input id="vig-wid" type="text" inputmode="decimal" name="width" value="<?php echo esc_attr( $p ? wc_format_localized_decimal( $p->get_width() ) : '' ); ?>"></div>
						<div class="vig-field"><label for="vig-hei"><?php esc_html_e( 'Altura (cm)', 'villa-ibit-gestor' ); ?></label><input id="vig-hei" type="text" inputmode="decimal" name="height" value="<?php echo esc_attr( $p ? wc_format_localized_decimal( $p->get_height() ) : '' ); ?>"></div>
					</div>
				</section>
			</div>

			<aside class="vig-editor__side">
				<section class="vig-card">
					<h2 class="vig-card__title"><?php esc_html_e( 'Publicação', 'villa-ibit-gestor' ); ?></h2>
					<div class="vig-field"><label for="vig-status"><?php esc_html_e( 'Status', 'villa-ibit-gestor' ); ?></label><select id="vig-status" name="status"><option value="publish"<?php selected( $p ? $p->get_status() : 'publish', 'publish' ); ?>><?php esc_html_e( 'Publicado (aparece na loja)', 'villa-ibit-gestor' ); ?></option><option value="draft"<?php selected( $p ? $p->get_status() : '', 'draft' ); ?>><?php esc_html_e( 'Rascunho (escondido)', 'villa-ibit-gestor' ); ?></option></select></div>
					<label class="vig-switch"><input type="checkbox" name="featured" value="1"<?php checked( $p && $p->is_featured() ); ?>><span class="vig-switch__ui" aria-hidden="true"></span><span><?php esc_html_e( 'Destaque (aparece na "Produtos em destaque" da home)', 'villa-ibit-gestor' ); ?></span></label>
					<button type="submit" class="vig-btn is-primary is-block"><?php echo VIG_Admin::icon( 'check', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php esc_html_e( 'Salvar produto', 'villa-ibit-gestor' ); ?></span></button>
					<?php if ( $p ) : ?>
						<ul class="vig-meta-list">
							<li><span><?php esc_html_e( 'Vendas', 'villa-ibit-gestor' ); ?></span><strong><?php echo (int) $p->get_total_sales(); ?></strong></li>
							<li><span><?php esc_html_e( 'Avaliações', 'villa-ibit-gestor' ); ?></span><strong><?php echo (int) $p->get_review_count(); ?></strong></li>
							<li><span><?php esc_html_e( 'Criado em', 'villa-ibit-gestor' ); ?></span><strong><?php echo esc_html( $p->get_date_created() ? $p->get_date_created()->date_i18n( 'd/m/Y' ) : '—' ); ?></strong></li>
						</ul>
						<p class="vig-side-links"><a href="<?php echo esc_url( self::action_url( 'duplicate', $p->get_id() ) ); ?>"><?php esc_html_e( 'Duplicar produto', 'villa-ibit-gestor' ); ?></a> · <a class="is-danger" data-vig-confirm="<?php esc_attr_e( 'Mover este produto para a lixeira?', 'villa-ibit-gestor' ); ?>" href="<?php echo esc_url( self::action_url( 'trash', $p->get_id() ) ); ?>"><?php esc_html_e( 'Excluir', 'villa-ibit-gestor' ); ?></a></p>
					<?php endif; ?>
				</section>

				<section class="vig-card">
					<h2 class="vig-card__title"><?php esc_html_e( 'Categorias', 'villa-ibit-gestor' ); ?></h2>
					<div class="vig-checklist-box">
						<?php self::category_checkboxes( 0, $cat_ids, 0 ); ?>
					</div>
					<div class="vig-field vig-field--tight"><label for="vig-new-cat"><?php esc_html_e( 'Nova categoria', 'villa-ibit-gestor' ); ?></label><input id="vig-new-cat" type="text" name="new_category" placeholder="<?php esc_attr_e( 'Digite para criar', 'villa-ibit-gestor' ); ?>"></div>
				</section>

				<?php if ( taxonomy_exists( 'product_brand' ) ) : $brands = get_terms( array( 'taxonomy' => 'product_brand', 'hide_empty' => false ) ); ?>
				<section class="vig-card">
					<h2 class="vig-card__title"><?php esc_html_e( 'Marca', 'villa-ibit-gestor' ); ?></h2>
					<div class="vig-field"><label class="screen-reader-text" for="vig-brand"><?php esc_html_e( 'Marca', 'villa-ibit-gestor' ); ?></label><select id="vig-brand" name="brand"><option value=""><?php esc_html_e( '— Sem marca —', 'villa-ibit-gestor' ); ?></option>
						<?php if ( ! is_wp_error( $brands ) ) { foreach ( $brands as $b ) { echo '<option value="' . (int) $b->term_id . '"' . selected( in_array( $b->term_id, $brand_ids, true ), true, false ) . '>' . esc_html( $b->name ) . '</option>'; } } ?>
					</select></div>
					<div class="vig-field vig-field--tight"><label for="vig-new-brand"><?php esc_html_e( 'Nova marca', 'villa-ibit-gestor' ); ?></label><input id="vig-new-brand" type="text" name="new_brand" placeholder="<?php esc_attr_e( 'Digite para criar', 'villa-ibit-gestor' ); ?>"></div>
				</section>
				<?php endif; ?>
			</aside>
			<input type="hidden" name="vig_form_complete" value="1">
		</form>
		<?php
		VIG_Admin::footer();
	}

	private static function category_checkboxes( $parent, $selected, $depth ) {
		$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'parent' => $parent, 'exclude' => array( (int) get_option( 'default_product_cat' ) ) ) );
		if ( is_wp_error( $terms ) ) {
			return;
		}
		foreach ( $terms as $t ) {
			echo '<label class="vig-check" style="margin-left:' . (int) ( $depth * 18 ) . 'px"><input type="checkbox" name="categories[]" value="' . (int) $t->term_id . '"' . checked( in_array( (int) $t->term_id, array_map( 'intval', $selected ), true ), true, false ) . '> ' . esc_html( $t->name ) . '</label>';
			self::category_checkboxes( $t->term_id, $selected, $depth + 1 );
		}
	}

	private static function flavor_row( $i, $f ) {
		$n = 'flavors[' . $i . ']';
		?>
		<li class="vig-flavor">
			<span class="vig-flavor__drag" aria-hidden="true"><?php echo VIG_Admin::icon( 'drag', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
			<input type="hidden" name="<?php echo esc_attr( $n ); ?>[id]" value="<?php echo (int) $f['id']; ?>">
			<label class="screen-reader-text"><?php esc_html_e( 'Nome do sabor', 'villa-ibit-gestor' ); ?></label>
			<input type="text" name="<?php echo esc_attr( $n ); ?>[name]" value="<?php echo esc_attr( $f['name'] ); ?>" placeholder="<?php esc_attr_e( 'Ex.: Grape Ice (Uva gelada)', 'villa-ibit-gestor' ); ?>" class="vig-flavor__name">
			<label class="screen-reader-text"><?php esc_html_e( 'Estoque', 'villa-ibit-gestor' ); ?></label>
			<input type="number" name="<?php echo esc_attr( $n ); ?>[stock]" value="<?php echo esc_attr( $f['stock'] ); ?>" placeholder="∞" min="0">
			<label class="screen-reader-text"><?php esc_html_e( 'Preço próprio', 'villa-ibit-gestor' ); ?></label>
			<input type="text" inputmode="decimal" name="<?php echo esc_attr( $n ); ?>[price]" value="<?php echo esc_attr( $f['price'] ); ?>" placeholder="<?php esc_attr_e( 'Igual', 'villa-ibit-gestor' ); ?>">
			<label class="vig-switch vig-switch--sm" title="<?php esc_attr_e( 'Disponível', 'villa-ibit-gestor' ); ?>"><input type="checkbox" name="<?php echo esc_attr( $n ); ?>[on]" value="1"<?php checked( $f['in_stock'] ); ?>><span class="vig-switch__ui" aria-hidden="true"></span><span class="screen-reader-text"><?php esc_html_e( 'Disponível', 'villa-ibit-gestor' ); ?></span></label>
			<button type="button" class="vig-icon-btn is-danger" data-vig-row-remove aria-label="<?php esc_attr_e( 'Remover sabor', 'villa-ibit-gestor' ); ?>"><?php echo VIG_Admin::icon( 'trash', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
		</li>
		<?php
	}

	private static function spec_row( $k, $v ) {
		?>
		<li class="vig-spec">
			<label class="screen-reader-text"><?php esc_html_e( 'Nome', 'villa-ibit-gestor' ); ?></label><input type="text" name="spec_name[]" value="<?php echo esc_attr( $k ); ?>" placeholder="<?php esc_attr_e( 'Ex.: Puffs', 'villa-ibit-gestor' ); ?>">
			<label class="screen-reader-text"><?php esc_html_e( 'Valor', 'villa-ibit-gestor' ); ?></label><input type="text" name="spec_value[]" value="<?php echo esc_attr( $v ); ?>" placeholder="<?php esc_attr_e( 'Ex.: até 40.000', 'villa-ibit-gestor' ); ?>">
			<button type="button" class="vig-icon-btn is-danger" data-vig-row-remove aria-label="<?php esc_attr_e( 'Remover', 'villa-ibit-gestor' ); ?>"><?php echo VIG_Admin::icon( 'trash', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
		</li>
		<?php
	}

	/* ================================================================ *
	 * Salvar
	 * ================================================================ */
	public static function save() {
		VIG_Admin::check_post( 'vig_save_product_full' );
		$in   = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitizado campo a campo.
		$id   = absint( $in['id'] ?? 0 );
		$name = sanitize_text_field( $in['name'] ?? '' );
		$back = admin_url( 'admin.php?page=vi-gestor-produto' . ( $id ? '&id=' . $id : '' ) );
		if ( empty( $in['vig_form_complete'] ) ) {
			VIG_Admin::back( $back, __( 'O formulário chegou incompleto. Reabra o produto antes de salvar. Se acontecer de novo, confira o limite max_input_vars da hospedagem.', 'villa-ibit-gestor' ), true );
		}
		if ( '' === $name ) {
			VIG_Admin::back( $back, __( 'Informe o nome do produto.', 'villa-ibit-gestor' ), true );
		}

		$price = wc_format_decimal( sanitize_text_field( $in['price'] ?? '' ) );
		$sale  = wc_format_decimal( sanitize_text_field( $in['sale'] ?? '' ) );
		if ( '' !== $sale && '' !== $price && (float) $sale >= (float) $price ) {
			VIG_Admin::back( $back, __( 'O preço promocional precisa ser menor que o preço.', 'villa-ibit-gestor' ), true );
		}

		// Sabores enviados (na ordem da tela).
		$flavors = array();
		$seen    = array();
		foreach ( (array) ( $in['flavors'] ?? array() ) as $f ) {
			$fname = trim( str_replace( '|', '/', sanitize_text_field( $f['name'] ?? '' ) ) );
			if ( '' === $fname || isset( $seen[ strtolower( $fname ) ] ) ) {
				continue;
			}
			$seen[ strtolower( $fname ) ] = true;
			$flavors[]                    = array(
				'id'    => absint( $f['id'] ?? 0 ),
				'name'  => $fname,
				'stock' => isset( $f['stock'] ) && '' !== trim( (string) $f['stock'] ) ? max( 0, (int) $f['stock'] ) : null,
				'price' => wc_format_decimal( sanitize_text_field( $f['price'] ?? '' ) ),
				'on'    => ! empty( $f['on'] ),
			);
		}
		$variable = count( $flavors ) > 0;
		$label    = sanitize_text_field( $in['option_label'] ?? 'Sabor' );
		$label    = $label ? $label : 'Sabor';

		// Tipo do produto (simples ou com sabores).
		$type = $variable ? 'variable' : 'simple';
		$keep_sales = false;
		if ( $id ) {
			$current = wc_get_product( $id );
			if ( ! $current ) {
				VIG_Admin::back( admin_url( 'admin.php?page=vi-gestor-produtos' ), __( 'Produto não encontrado.', 'villa-ibit-gestor' ), true );
			}
			$notice = self::editor_notice( $current );
			if ( $notice ) {
				VIG_Admin::back( $back, $notice, true );
			}
			if ( ! hash_equals( self::edit_revision( $current ), (string) ( $in['vig_revision'] ?? '' ) ) ) {
				VIG_Admin::back( $back, __( 'O cadastro mudou enquanto você editava. Confira os dados atuais e tente novamente.', 'villa-ibit-gestor' ), true );
			}
			if ( $variable && $current->is_type( 'variable' ) && '' === $sale && empty( $in['clear_flavor_sales'] ) ) {
				$keep_sales = null === self::common_sale( $current );
			}
			if ( $current->get_type() !== $type && in_array( $current->get_type(), array( 'simple', 'variable' ), true ) ) {
				if ( 'simple' === $type ) {
					foreach ( $current->get_children() as $child ) {
						wp_delete_post( $child, true );
					}
				}
				wp_set_object_terms( $id, $type, 'product_type' );
				wc_delete_product_transients( $id );
			}
			$classname = WC_Product_Factory::get_product_classname( $id, in_array( $current->get_type(), array( 'simple', 'variable' ), true ) ? $type : $current->get_type() );
			$p         = new $classname( $id );
		} else {
			$p = $variable ? new WC_Product_Variable() : new WC_Product_Simple();
		}

		$p->set_name( $name );
		$p->set_status( in_array( $in['status'] ?? '', array( 'publish', 'draft' ), true ) ? $in['status'] : 'publish' );
		$p->set_featured( ! empty( $in['featured'] ) );
		$p->set_short_description( sanitize_textarea_field( $in['short'] ?? '' ) );
		$p->set_description( wp_kses_post( $in['description'] ?? '' ) );
		$p->set_image_id( absint( $in['image_id'] ?? 0 ) );
		$p->set_gallery_image_ids( array_filter( array_map( 'absint', explode( ',', (string) ( $in['gallery'] ?? '' ) ) ) ) );
		foreach ( array( 'weight', 'length', 'width', 'height' ) as $dim ) {
			$p->{'set_' . $dim}( wc_format_decimal( sanitize_text_field( $in[ $dim ] ?? '' ) ) );
		}
		$sku = sanitize_text_field( $in['sku'] ?? '' );
		try {
			$p->set_sku( $sku );
		} catch ( WC_Data_Exception $e ) {
			VIG_Admin::back( $back, __( 'Esse código (SKU) já é usado por outro produto.', 'villa-ibit-gestor' ), true );
		}

		// Categorias (incluindo uma nova).
		$cats = array_filter( array_map( 'absint', (array) ( $in['categories'] ?? array() ) ) );
		$new  = sanitize_text_field( $in['new_category'] ?? '' );
		if ( $new ) {
			$t = term_exists( $new, 'product_cat' );
			$t = $t ? $t : wp_insert_term( $new, 'product_cat' );
			if ( ! is_wp_error( $t ) ) {
				$cats[] = (int) $t['term_id'];
			}
		}
		$p->set_category_ids( $cats );

		// Atributos: especificações + opção de sabores.
		$attributes = array_filter( $p->get_attributes(), function ( $attr ) { return $attr->is_taxonomy() && ! $attr->get_variation(); } );
		$names      = (array) ( $in['spec_name'] ?? array() );
		$values     = (array) ( $in['spec_value'] ?? array() );
		foreach ( $names as $k => $sn ) {
			$sn = sanitize_text_field( $sn );
			$sv = sanitize_text_field( $values[ $k ] ?? '' );
			if ( '' === $sn || '' === $sv || ( $variable && 0 === strcasecmp( $sn, $label ) ) || isset( $attributes[ sanitize_title( $sn ) ] ) ) {
				continue;
			}
			$a = new WC_Product_Attribute();
			$a->set_name( $sn );
			$a->set_options( array_map( 'trim', explode( '|', str_replace( ',', '|', $sv ) ) ) );
			$a->set_visible( true );
			$a->set_variation( false );
			$attributes[ sanitize_title( $sn ) ] = $a;
		}
		if ( $variable ) {
			$a = new WC_Product_Attribute();
			$a->set_name( $label );
			$a->set_options( wp_list_pluck( $flavors, 'name' ) );
			$a->set_visible( true );
			$a->set_variation( true );
			$attributes = array( sanitize_title( $label ) => $a ) + $attributes;
		}
		$p->set_attributes( $attributes );

		if ( ! $variable ) {
			$p->set_regular_price( $price );
			$p->set_sale_price( $sale );
			$stock = isset( $in['stock'] ) && '' !== trim( (string) $in['stock'] ) ? (int) $in['stock'] : null;
			if ( null === $stock ) {
				$p->set_manage_stock( false );
				$p->set_stock_status( 'outofstock' === ( $in['stock_status'] ?? '' ) ? 'outofstock' : 'instock' );
			} else {
				$p->set_manage_stock( true );
				$p->set_stock_quantity( $stock );
			}
		} else {
			$p->set_manage_stock( false );
		}

		$id = $p->save();

		// Marca.
		if ( taxonomy_exists( 'product_brand' ) ) {
			$brand     = absint( $in['brand'] ?? 0 );
			$new_brand = sanitize_text_field( $in['new_brand'] ?? '' );
			if ( $new_brand ) {
				$t     = term_exists( $new_brand, 'product_brand' );
				$t     = $t ? $t : wp_insert_term( $new_brand, 'product_brand' );
				$brand = is_wp_error( $t ) ? $brand : (int) $t['term_id'];
			}
			wp_set_object_terms( $id, $brand ? array( $brand ) : array(), 'product_brand' );
		}

		if ( $variable ) {
			self::sync_flavors( $id, $label, $flavors, $price, $sale, $keep_sales );
		}

		wc_delete_product_transients( $id );
		if ( function_exists( 'vi_cache_flush' ) ) {
			vi_cache_flush();
		}
		VIG_Admin::back( admin_url( 'admin.php?page=vi-gestor-produto&id=' . $id ), __( 'Produto salvo.', 'villa-ibit-gestor' ) );
	}

	/**
	 * Cria/atualiza/remove as variações para ficarem iguais à lista de sabores.
	 */
	private static function sync_flavors( $id, $label, $flavors, $price, $sale, $keep_sales ) {
		$parent = wc_get_product( $id );
		$key    = sanitize_title( $label );

		// Variações existentes, indexadas por ID e por nome do sabor.
		$by_id   = array();
		$by_name = array();
		foreach ( $parent->get_children() as $vid ) {
			$v = wc_get_product( $vid );
			if ( ! $v instanceof WC_Product_Variation ) {
				continue;
			}
			$by_id[ $vid ] = $v;
			$vals          = $v->get_attributes();
			$raw           = $vals ? (string) reset( $vals ) : '';
			$tax           = $vals ? (string) key( $vals ) : '';
			if ( $raw && taxonomy_exists( $tax ) ) {
				$term = get_term_by( 'slug', $raw, $tax );
				$raw  = $term ? $term->name : $raw;
			}
			$by_name[ strtolower( $raw ) ] = $v;
		}

		$keep = array();
		foreach ( $flavors as $order => $f ) {
			$v = null;
			if ( $f['id'] && isset( $by_id[ $f['id'] ] ) ) {
				$v = $by_id[ $f['id'] ];
			} elseif ( isset( $by_name[ strtolower( $f['name'] ) ] ) ) {
				$v = $by_name[ strtolower( $f['name'] ) ];
			}
			if ( ! $v ) {
				$v = new WC_Product_Variation();
				$v->set_parent_id( $id );
			}
			$v->set_attributes( array( $key => $f['name'] ) );
			$v->set_regular_price( '' !== $f['price'] ? $f['price'] : $price );
			$own_sale = $keep_sales ? $v->get_sale_price( 'edit' ) : $sale;
			$v->set_sale_price( '' !== $own_sale && (float) $own_sale < (float) $v->get_regular_price( 'edit' ) ? $own_sale : '' );
			$v->set_menu_order( $order );
			$v->set_status( 'publish' );
			if ( null === $f['stock'] ) {
				$v->set_manage_stock( false );
				$v->set_stock_status( $f['on'] ? 'instock' : 'outofstock' );
			} else {
				$v->set_manage_stock( true );
				$v->set_stock_quantity( $f['on'] ? $f['stock'] : 0 );
			}
			$keep[] = $v->save();
		}
		foreach ( array_keys( $by_id ) as $vid ) {
			if ( ! in_array( $vid, $keep, true ) ) {
				wp_delete_post( $vid, true );
			}
		}
		WC_Product_Variable::sync( $id );
		wc_delete_product_transients( $id );
	}
}
