<?php
/**
 * Pedidos: lista, detalhe completo, troca de status, notas, impressão e WhatsApp do cliente.
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;

class VIG_Orders {

	public static function init() {
		add_action( 'wp_ajax_vig_order_status', array( __CLASS__, 'ajax_status' ) );
		add_action( 'admin_post_vig_order_update', array( __CLASS__, 'update' ) );
	}

	public static function url( $order_id = 0 ) {
		return admin_url( 'admin.php?page=vi-gestor-pedidos' . ( $order_id ? '&pedido=' . (int) $order_id : '' ) );
	}

	/**
	 * Mensagem pronta para o cliente, conforme o status.
	 */
	public static function wa_message( WC_Order $order ) {
		$name   = $order->get_billing_first_name();
		$number = $order->get_order_number();
		$store  = get_bloginfo( 'name' );
		switch ( $order->get_status() ) {
			case 'pending':
			case 'on-hold':
				return sprintf( __( 'Olá, %1$s! Aqui é da %2$s. Vimos seu pedido #%3$s e ele está aguardando pagamento. Posso te ajudar a finalizar?', 'villa-ibit-gestor' ), $name, $store, $number );
			case 'processing':
				return sprintf( __( 'Olá, %1$s! Seu pedido #%2$s na %3$s foi confirmado e já está sendo separado. Já te aviso quando sair para entrega!', 'villa-ibit-gestor' ), $name, $number, $store );
			case 'completed':
				return sprintf( __( 'Olá, %1$s! Seu pedido #%2$s na %3$s foi entregue. Obrigado pela compra! Se puder, deixe sua avaliação no site.', 'villa-ibit-gestor' ), $name, $number, $store );
			default:
				return sprintf( __( 'Olá, %1$s! Aqui é da %2$s, sobre o seu pedido #%3$s.', 'villa-ibit-gestor' ), $name, $store, $number );
		}
	}

	/**
	 * Tabela de pedidos (Painel e lista).
	 */
	public static function table( $orders, $compact = false ) {
		$orders = array_filter( $orders, function ( $o ) { return $o instanceof WC_Order && ! ( $o instanceof WC_Order_Refund ); } );
		if ( ! $orders ) {
			echo '<p class="vig-empty">' . esc_html__( 'Nenhum pedido por aqui.', 'villa-ibit-gestor' ) . '</p>';
			return;
		}
		$statuses = wc_get_order_statuses();
		echo '<div class="vig-table-wrap"><table class="vig-table"><thead><tr><th>' . esc_html__( 'Pedido', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Cliente', 'villa-ibit-gestor' ) . '</th>';
		if ( ! $compact ) {
			echo '<th>' . esc_html__( 'Itens', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Pagamento', 'villa-ibit-gestor' ) . '</th>';
		}
		echo '<th>' . esc_html__( 'Total', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Status', 'villa-ibit-gestor' ) . '</th><th><span class="screen-reader-text">' . esc_html__( 'Ações', 'villa-ibit-gestor' ) . '</span></th></tr></thead><tbody>';
		foreach ( $orders as $order ) {
			$date  = $order->get_date_created();
			$wa    = VIG_Admin::wa_number( $order->get_billing_phone() );
			$count = $order->get_item_count();
			$name  = trim( $order->get_formatted_billing_full_name() );
			echo '<tr data-order="' . (int) $order->get_id() . '">';
			echo '<td class="vig-cell-head"><a class="vig-strong" href="' . esc_url( self::url( $order->get_id() ) ) . '">#' . esc_html( $order->get_order_number() ) . '</a><br><span class="vig-muted">' . esc_html( $date ? $date->date_i18n( 'd/m H:i' ) : '' ) . '</span></td>';
			echo '<td data-label="' . esc_attr__( 'Cliente', 'villa-ibit-gestor' ) . '"><span class="vig-avatar">' . esc_html( $name ? mb_strtoupper( mb_substr( $name, 0, 1 ) ) : '?' ) . '</span>' . esc_html( $name ? $name : __( 'Visitante', 'villa-ibit-gestor' ) ) . '<br><span class="vig-muted">' . esc_html( $order->get_billing_city() ) . '</span></td>';
			if ( ! $compact ) {
				echo '<td data-label="' . esc_attr__( 'Itens', 'villa-ibit-gestor' ) . '">' . esc_html( sprintf( _n( '%d item', '%d itens', $count, 'villa-ibit-gestor' ), $count ) ) . '</td>';
				echo '<td data-label="' . esc_attr__( 'Pagamento', 'villa-ibit-gestor' ) . '">' . esc_html( $order->get_payment_method_title() ? $order->get_payment_method_title() : '—' ) . '</td>';
			}
			echo '<td class="vig-strong vig-nowrap" data-label="' . esc_attr__( 'Total', 'villa-ibit-gestor' ) . '">' . wp_kses_post( $order->get_formatted_order_total() ) . '</td>';
			echo '<td class="vig-cell-wide" data-label="' . esc_attr__( 'Status', 'villa-ibit-gestor' ) . '"><label class="screen-reader-text" for="vig-st-' . (int) $order->get_id() . '">' . esc_html__( 'Status', 'villa-ibit-gestor' ) . '</label><select id="vig-st-' . (int) $order->get_id() . '" class="vig-status is-' . esc_attr( $order->get_status() ) . '" data-vig-status>';
			foreach ( $statuses as $key => $label ) {
				echo '<option value="' . esc_attr( $key ) . '"' . selected( 'wc-' . $order->get_status(), $key, false ) . '>' . esc_html( $label ) . '</option>';
			}
			echo '</select><span class="vig-saved" aria-live="polite"></span></td>';
			echo '<td class="vig-row-actions">';
			if ( $wa ) {
				echo '<a class="vig-icon-btn is-wa" target="_blank" rel="noopener" title="WhatsApp" aria-label="WhatsApp" href="' . esc_url( 'https://wa.me/' . $wa . '?text=' . rawurlencode( self::wa_message( $order ) ) ) . '">' . VIG_Admin::icon( 'chat', 16 ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo VIG_Admin::btn( __( 'Abrir', 'villa-ibit-gestor' ), self::url( $order->get_id() ), 'is-ghost is-sm' ); // phpcs:ignore WordPress.Security.EscapeOutput
			echo '</td></tr>';
		}
		echo '</tbody></table></div>';
	}

	public static function render() {
		$order_id = isset( $_GET['pedido'] ) ? absint( $_GET['pedido'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		if ( $order_id ) {
			self::render_detail( $order_id );
			return;
		}
		$status   = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : 'all'; // phpcs:ignore WordPress.Security.NonceVerification
		$search   = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$customer = isset( $_GET['cliente'] ) ? absint( $_GET['cliente'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$paged    = max( 1, isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1 ); // phpcs:ignore WordPress.Security.NonceVerification
		$filters  = array(
			'all'        => __( 'Todos', 'villa-ibit-gestor' ),
			'processing' => __( 'Pagos — separar', 'villa-ibit-gestor' ),
			'pending'    => __( 'Aguardando pagamento', 'villa-ibit-gestor' ),
			'on-hold'    => __( 'Em espera', 'villa-ibit-gestor' ),
			'completed'  => __( 'Concluídos', 'villa-ibit-gestor' ),
			'cancelled'  => __( 'Cancelados', 'villa-ibit-gestor' ),
		);
		$args = array( 'limit' => 25, 'paged' => $paged, 'paginate' => true, 'type' => 'shop_order', 'orderby' => 'date', 'order' => 'DESC' );
		if ( 'all' !== $status && isset( $filters[ $status ] ) ) {
			$args['status'] = array( 'wc-' . $status );
		}
		if ( $customer ) {
			$args['customer_id'] = $customer;
		}
		if ( $search ) {
			if ( ctype_digit( ltrim( $search, '#' ) ) ) {
				$args['include'] = array( absint( ltrim( $search, '#' ) ) );
			} else {
				$found           = WC_Data_Store::load( 'order' )->search_orders( $search );
				$args['include'] = $found ? array_map( 'absint', $found ) : array( 0 );
			}
		}
		$result = wc_get_orders( $args );

		VIG_Admin::header( 'vi-gestor-pedidos', __( 'Pedidos', 'villa-ibit-gestor' ), '', sprintf( __( '%d pedidos pagos aguardando envio', 'villa-ibit-gestor' ), VIG_Admin::count_orders( 'wc-processing' ) ) );
		echo '<div class="vig-toolbar"><nav class="vig-seg">';
		foreach ( $filters as $key => $label ) {
			$n = 'all' === $key ? '' : ' <b>' . (int) VIG_Admin::count_orders( 'wc-' . $key ) . '</b>';
			echo '<a class="' . ( $key === $status ? 'is-on' : '' ) . '" href="' . esc_url( add_query_arg( array( 'page' => 'vi-gestor-pedidos', 'status' => $key ), admin_url( 'admin.php' ) ) ) . '">' . esc_html( $label ) . wp_kses_post( $n ) . '</a>';
		}
		echo '</nav><form method="get" class="vig-search"><input type="hidden" name="page" value="vi-gestor-pedidos"><input type="hidden" name="status" value="' . esc_attr( $status ) . '"><span class="vig-search__box">' . VIG_Admin::icon( 'search', 16 ) . '<label class="screen-reader-text" for="vig-q">' . esc_html__( 'Buscar pedido', 'villa-ibit-gestor' ) . '</label><input id="vig-q" type="search" name="q" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'Nº do pedido, nome, e-mail ou telefone', 'villa-ibit-gestor' ) . '"></span></form></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $customer ) {
			$u = get_userdata( $customer );
			echo '<p class="vig-filter-note">' . esc_html( sprintf( __( 'Mostrando pedidos de %s', 'villa-ibit-gestor' ), $u ? $u->display_name : '#' . $customer ) ) . ' · <a href="' . esc_url( self::url() ) . '">' . esc_html__( 'limpar', 'villa-ibit-gestor' ) . '</a></p>';
		}
		echo '<section class="vig-card vig-card--flush">';
		self::table( $result->orders );
		echo '</section>';
		VIG_Admin::pager( $paged, $result->max_num_pages );
		VIG_Admin::footer();
	}

	/**
	 * Detalhe do pedido.
	 */
	private static function render_detail( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || $order instanceof WC_Order_Refund ) {
			VIG_Admin::header( 'vi-gestor-pedidos', __( 'Pedido não encontrado', 'villa-ibit-gestor' ) );
			VIG_Admin::footer();
			return;
		}
		$wa      = VIG_Admin::wa_number( $order->get_billing_phone() );
		$date    = $order->get_date_created();
		$actions = '<button type="button" class="vig-btn is-ghost" onclick="window.print()">' . VIG_Admin::icon( 'print', 16 ) . '<span>' . esc_html__( 'Imprimir', 'villa-ibit-gestor' ) . '</span></button>';
		if ( $wa ) {
			$actions .= VIG_Admin::btn( __( 'WhatsApp do cliente', 'villa-ibit-gestor' ), 'https://wa.me/' . $wa . '?text=' . rawurlencode( self::wa_message( $order ) ), 'is-wa', 'chat', 'target="_blank" rel="noopener"' );
		}
		VIG_Admin::header( 'vi-gestor-pedidos', sprintf( __( 'Pedido #%s', 'villa-ibit-gestor' ), $order->get_order_number() ), $actions, $date ? sprintf( __( 'Feito em %s', 'villa-ibit-gestor' ), $date->date_i18n( 'd/m/Y \à\s H:i' ) ) : '' );
		echo '<p class="vig-backlink"><a href="' . esc_url( self::url() ) . '">' . VIG_Admin::icon( 'back', 16 ) . esc_html__( 'Todos os pedidos', 'villa-ibit-gestor' ) . '</a></p>'; // phpcs:ignore WordPress.Security.EscapeOutput
		?>
		<div class="vig-editor">
			<div class="vig-editor__main">
				<section class="vig-card">
					<div class="vig-card__head"><h2 class="vig-card__title"><?php esc_html_e( 'Itens', 'villa-ibit-gestor' ); ?></h2><?php echo VIG_Admin::status_badge( $order->get_status() ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
					<ul class="vig-order-items">
						<?php foreach ( $order->get_items() as $item ) :
							$prod  = $item->get_product();
							$thumb = $prod && $prod->get_image_id() ? wp_get_attachment_image_url( $prod->get_image_id(), 'thumbnail' ) : wc_placeholder_img_src( 'thumbnail' );
							$meta  = wc_display_item_meta( $item, array( 'echo' => false, 'before' => '', 'after' => '', 'separator' => ' · ', 'label_before' => '', 'label_after' => ': ' ) );
							?>
							<li>
								<img src="<?php echo esc_url( $thumb ); ?>" alt="">
								<div><strong><?php echo esc_html( $item->get_name() ); ?></strong><?php if ( $meta ) : ?><span class="vig-muted"><?php echo wp_kses_post( wp_strip_all_tags( $meta ) ); ?></span><?php endif; ?><?php if ( $prod && $prod->get_sku() ) : ?><span class="vig-muted">SKU <?php echo esc_html( $prod->get_sku() ); ?></span><?php endif; ?></div>
								<span class="vig-qty">× <?php echo (int) $item->get_quantity(); ?></span>
								<strong class="vig-nowrap"><?php echo wp_kses_post( $order->get_formatted_line_subtotal( $item ) ); ?></strong>
							</li>
						<?php endforeach; ?>
					</ul>
					<dl class="vig-totals">
						<div><dt><?php esc_html_e( 'Subtotal', 'villa-ibit-gestor' ); ?></dt><dd><?php echo wp_kses_post( wc_price( $order->get_subtotal(), array( 'currency' => $order->get_currency() ) ) ); ?></dd></div>
						<?php if ( (float) $order->get_discount_total() ) : ?><div><dt><?php echo esc_html( sprintf( __( 'Cupom (%s)', 'villa-ibit-gestor' ), implode( ', ', $order->get_coupon_codes() ) ) ); ?></dt><dd>−<?php echo wp_kses_post( wc_price( $order->get_discount_total(), array( 'currency' => $order->get_currency() ) ) ); ?></dd></div><?php endif; ?>
						<?php foreach ( $order->get_fees() as $fee ) : ?><div><dt><?php echo esc_html( $fee->get_name() ); ?></dt><dd><?php echo wp_kses_post( wc_price( $fee->get_total(), array( 'currency' => $order->get_currency() ) ) ); ?></dd></div><?php endforeach; ?>
						<div><dt><?php echo esc_html( sprintf( __( 'Entrega (%s)', 'villa-ibit-gestor' ), $order->get_shipping_method() ? $order->get_shipping_method() : '—' ) ); ?></dt><dd><?php echo wp_kses_post( wc_price( $order->get_shipping_total(), array( 'currency' => $order->get_currency() ) ) ); ?></dd></div>
						<?php if ( (float) $order->get_total_refunded() ) : ?><div><dt><?php esc_html_e( 'Reembolsado', 'villa-ibit-gestor' ); ?></dt><dd>−<?php echo wp_kses_post( wc_price( $order->get_total_refunded(), array( 'currency' => $order->get_currency() ) ) ); ?></dd></div><?php endif; ?>
						<div class="is-total"><dt><?php esc_html_e( 'Total', 'villa-ibit-gestor' ); ?></dt><dd><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></dd></div>
					</dl>
					<p class="vig-muted"><?php echo esc_html( sprintf( __( 'Pagamento: %s', 'villa-ibit-gestor' ), $order->get_payment_method_title() ? $order->get_payment_method_title() : '—' ) ); ?><?php if ( $order->get_date_paid() ) : ?> · <?php echo esc_html( sprintf( __( 'pago em %s', 'villa-ibit-gestor' ), $order->get_date_paid()->date_i18n( 'd/m/Y H:i' ) ) ); ?><?php endif; ?><?php if ( $order->get_transaction_id() ) : ?> · <?php echo esc_html( sprintf( __( 'transação %s', 'villa-ibit-gestor' ), $order->get_transaction_id() ) ); ?><?php endif; ?></p>
					<?php VIG_Cash_Change::render_order_change( $order ); ?>
				</section>

				<?php if ( $order->get_customer_note() ) : ?>
				<section class="vig-card vig-card--note">
					<h2 class="vig-card__title"><?php esc_html_e( 'Observação do cliente', 'villa-ibit-gestor' ); ?></h2>
					<p><?php echo esc_html( $order->get_customer_note() ); ?></p>
				</section>
				<?php endif; ?>

				<section class="vig-card">
					<h2 class="vig-card__title"><?php esc_html_e( 'Histórico e notas', 'villa-ibit-gestor' ); ?></h2>
					<ul class="vig-timeline">
						<?php foreach ( wc_get_order_notes( array( 'order_id' => $order_id ) ) as $note ) : ?>
							<li class="<?php echo $note->customer_note ? 'is-customer' : ''; ?>"><p><?php echo wp_kses_post( wpautop( wptexturize( $note->content ) ) ); ?></p><span class="vig-muted"><?php echo esc_html( $note->date_created->date_i18n( 'd/m/Y H:i' ) ); ?><?php echo $note->customer_note ? ' · ' . esc_html__( 'enviada ao cliente', 'villa-ibit-gestor' ) : ''; ?><?php echo $note->added_by && 'system' !== $note->added_by ? ' · ' . esc_html( $note->added_by ) : ''; ?></span></li>
						<?php endforeach; ?>
					</ul>
				</section>
			</div>

			<aside class="vig-editor__side">
				<form class="vig-card" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'vig_order_update_' . $order_id ); ?>
					<input type="hidden" name="action" value="vig_order_update"><input type="hidden" name="order" value="<?php echo (int) $order_id; ?>">
					<h2 class="vig-card__title"><?php esc_html_e( 'Status do pedido', 'villa-ibit-gestor' ); ?></h2>
					<div class="vig-field"><label class="screen-reader-text" for="vig-ostatus"><?php esc_html_e( 'Status', 'villa-ibit-gestor' ); ?></label><select id="vig-ostatus" name="status">
						<?php foreach ( wc_get_order_statuses() as $k => $l ) : ?><option value="<?php echo esc_attr( $k ); ?>"<?php selected( 'wc-' . $order->get_status(), $k ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?>
					</select></div>
					<div class="vig-field"><label for="vig-note"><?php esc_html_e( 'Adicionar nota (opcional)', 'villa-ibit-gestor' ); ?></label><textarea id="vig-note" name="note" rows="3" placeholder="<?php esc_attr_e( 'Ex.: Código de rastreio BR123…', 'villa-ibit-gestor' ); ?>"></textarea></div>
					<label class="vig-check"><input type="checkbox" name="note_customer" value="1"> <?php esc_html_e( 'Enviar a nota para o e-mail do cliente', 'villa-ibit-gestor' ); ?></label>
					<button class="vig-btn is-primary is-block"><?php echo VIG_Admin::icon( 'check', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php esc_html_e( 'Atualizar pedido', 'villa-ibit-gestor' ); ?></span></button>
					<p class="vig-help"><?php esc_html_e( 'Ao mudar para Processando ou Concluído, o WooCommerce envia o e-mail automático ao cliente.', 'villa-ibit-gestor' ); ?></p>
				</form>

				<section class="vig-card">
					<h2 class="vig-card__title"><?php esc_html_e( 'Cliente', 'villa-ibit-gestor' ); ?></h2>
					<p class="vig-strong"><?php echo esc_html( $order->get_formatted_billing_full_name() ); ?></p>
					<ul class="vig-meta-list">
						<?php if ( $order->get_billing_email() ) : ?><li><span><?php esc_html_e( 'E-mail', 'villa-ibit-gestor' ); ?></span><a href="mailto:<?php echo esc_attr( $order->get_billing_email() ); ?>"><?php echo esc_html( $order->get_billing_email() ); ?></a></li><?php endif; ?>
						<?php if ( $order->get_billing_phone() ) : ?><li><span><?php esc_html_e( 'Telefone', 'villa-ibit-gestor' ); ?></span><strong><?php echo esc_html( $order->get_billing_phone() ); ?></strong></li><?php endif; ?>
						<?php foreach ( array( '_billing_cpf' => 'CPF', '_billing_cnpj' => 'CNPJ' ) as $mk => $ml ) : $mv = $order->get_meta( $mk ); if ( $mv ) : ?><li><span><?php echo esc_html( $ml ); ?></span><strong><?php echo esc_html( $mv ); ?></strong></li><?php endif; endforeach; ?>
						<?php $vig_b = class_exists( 'VIG_Birthdate' ) ? VIG_Birthdate::from_order( $order ) : null; if ( $vig_b ) : ?><li><span><?php esc_html_e( 'Nascimento', 'villa-ibit-gestor' ); ?></span><strong<?php echo $vig_b['age'] < VIG_Birthdate::MIN_AGE ? ' class="vig-red"' : ''; ?>><?php echo esc_html( $vig_b['date'] . ' · ' . sprintf( _n( '%d ano', '%d anos', $vig_b['age'], 'villa-ibit-gestor' ), $vig_b['age'] ) ); ?></strong></li><?php elseif ( $order->get_meta( '_billing_birthdate' ) ) : ?><li><span><?php esc_html_e( 'Nascimento', 'villa-ibit-gestor' ); ?></span><strong><?php echo esc_html( $order->get_meta( '_billing_birthdate' ) ); ?></strong></li><?php endif; ?>
					</ul>
					<?php if ( $order->get_customer_id() ) : ?><p><a href="<?php echo esc_url( add_query_arg( 'cliente', $order->get_customer_id(), self::url() ) ); ?>"><?php esc_html_e( 'Ver outros pedidos deste cliente', 'villa-ibit-gestor' ); ?></a></p><?php endif; ?>
				</section>

				<section class="vig-card">
					<h2 class="vig-card__title"><?php esc_html_e( 'Entrega', 'villa-ibit-gestor' ); ?></h2>
					<address class="vig-address"><?php echo wp_kses_post( $order->get_formatted_shipping_address() ? $order->get_formatted_shipping_address() : $order->get_formatted_billing_address() ); ?></address>
					<?php $maps = $order->get_shipping_address_map_url(); if ( $maps ) : ?><p><a href="<?php echo esc_url( $maps ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Abrir no mapa', 'villa-ibit-gestor' ); ?></a></p><?php endif; ?>
				</section>

				<p class="vig-side-links"><a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>"><?php esc_html_e( 'Abrir na tela completa do WooCommerce (reembolsos, edição de itens)', 'villa-ibit-gestor' ); ?></a></p>
			</aside>
		</div>
		<?php
		VIG_Admin::footer();
	}

	public static function update() {
		$order_id = isset( $_POST['order'] ) ? absint( $_POST['order'] ) : 0;
		VIG_Admin::check_post( 'vig_order_update_' . $order_id );
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			VIG_Admin::back( self::url(), __( 'Pedido não encontrado.', 'villa-ibit-gestor' ), true );
		}
		$status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '';
		$note   = isset( $_POST['note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['note'] ) ) : '';
		if ( $note ) {
			$order->add_order_note( $note, ! empty( $_POST['note_customer'] ) ? 1 : 0, true );
		}
		if ( array_key_exists( $status, wc_get_order_statuses() ) && 'wc-' . $order->get_status() !== $status ) {
			$order->update_status( substr( $status, 3 ), __( 'Status alterado pelo Villa Ibit Gestor.', 'villa-ibit-gestor' ), true );
		}
		VIG_Admin::back( self::url( $order_id ), __( 'Pedido atualizado.', 'villa-ibit-gestor' ) );
	}

	public static function ajax_status() {
		VIG_Admin::check_ajax();
		$order  = wc_get_order( isset( $_POST['order'] ) ? absint( $_POST['order'] ) : 0 );
		$status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '';
		if ( ! $order || ! array_key_exists( $status, wc_get_order_statuses() ) ) {
			wp_send_json_error( array( 'message' => __( 'Pedido ou status inválido.', 'villa-ibit-gestor' ) ), 400 );
		}
		$order->update_status( substr( $status, 3 ), __( 'Status alterado pelo Villa Ibit Gestor.', 'villa-ibit-gestor' ), true );
		wp_send_json_success( array( 'status' => $order->get_status() ) );
	}
}
