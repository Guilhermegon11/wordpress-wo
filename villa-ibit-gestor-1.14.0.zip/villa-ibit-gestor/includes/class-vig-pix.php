<?php
/**
 * PIX: exibe "R$ X no PIX" (quando o tema não faz isso) e aplica o desconto no checkout (opcional).
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;

class VIG_Pix {

	public static function init() {
		add_action( 'woocommerce_cart_calculate_fees', array( __CLASS__, 'discount' ) );
		add_action( 'wp_footer', array( __CLASS__, 'refresh_on_payment_change' ), 50 );
		add_action( 'after_setup_theme', array( __CLASS__, 'maybe_price_html' ), 20 );
	}

	private static function percent() {
		return max( 0, min( 90, (float) vig_value( 'pix_percent', 5 ) ) );
	}

	/**
	 * Linha "Desconto PIX" quando a forma de pagamento escolhida está marcada nas configurações.
	 *
	 * @param WC_Cart $cart Carrinho.
	 */
	public static function discount( $cart ) {
		if ( ( is_admin() && ! wp_doing_ajax() ) || ! vig_value( 'pix_apply', 0 ) ) {
			return;
		}
		$pct      = self::percent();
		$gateways = (array) vig_value( 'pix_gateways', array() );
		$chosen   = WC()->session ? WC()->session->get( 'chosen_payment_method' ) : '';
		if ( $pct <= 0 || ! $chosen || ! in_array( $chosen, $gateways, true ) ) {
			return;
		}
		$base = (float) $cart->get_cart_contents_total() + (float) $cart->get_cart_contents_tax();
		if ( $base <= 0 ) {
			return;
		}
		$label = sprintf( __( 'Desconto PIX (%s%%)', 'villa-ibit-gestor' ), wc_format_localized_decimal( $pct ) );
		$cart->add_fee( $label, -round( $base * $pct / 100, wc_get_price_decimals() ), false );
	}

	/**
	 * No checkout clássico, recalcula o total ao trocar a forma de pagamento.
	 */
	public static function refresh_on_payment_change() {
		if ( ! vig_value( 'pix_apply', 0 ) || ! function_exists( 'is_checkout' ) || ! is_checkout() || is_order_received_page() ) {
			return;
		}
		?>
		<script>
		jQuery(function ($) {
			$('form.checkout').on('change', 'input[name="payment_method"]', function () { $(document.body).trigger('update_checkout'); });
		});
		</script>
		<?php
	}

	/**
	 * Se o tema ativo não for o Villa Ibit, mostra o preço no PIX abaixo do preço normal.
	 */
	public static function maybe_price_html() {
		if ( current_theme_supports( 'vi-pix-display' ) ) {
			return;
		}
		add_filter(
			'woocommerce_get_price_html',
			function ( $html, $product ) {
				$pct = self::percent();
				if ( $pct <= 0 || '' === $html || ( is_admin() && ! wp_doing_ajax() ) ) {
					return $html;
				}
				$price = $product->is_type( 'variable' ) ? (float) $product->get_variation_price( 'min', true ) : (float) wc_get_price_to_display( $product );
				if ( $price <= 0 ) {
					return $html;
				}
				return $html . '<span class="vi-pix" style="display:flex;align-items:center;gap:6px;font-weight:700;color:#075046"><img src="' . esc_url( VIG_URL . 'assets/pix.svg' ) . '" alt="" width="14" height="14" style="display:inline-block;width:14px;height:14px">' . wc_price( $price * ( 1 - $pct / 100 ) ) . ' <small>' . esc_html( sprintf( __( 'no PIX (%s%% OFF)', 'villa-ibit-gestor' ), wc_format_localized_decimal( $pct ) ) ) . '</small></span>';
			},
			20,
			2
		);
	}
}
