<?php
/**
 * Troco para pagamentos em dinheiro, registrado no pedido sem alterar o total.
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;

final class VIG_Cash_Change {
	private const FIELD    = 'vig_cash_tendered';
	private const TENDERED = '_vig_cash_tendered';
	private const CHANGE   = '_vig_cash_change';

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'woocommerce_review_order_before_submit', array( __CLASS__, 'classic_field' ) );
		add_action( 'woocommerce_pay_order_before_submit', array( __CLASS__, 'classic_field' ) );
		add_action( 'woocommerce_after_checkout_validation', array( __CLASS__, 'validate_classic' ), 20, 2 );
		add_action( 'woocommerce_checkout_create_order', array( __CLASS__, 'save_classic' ), 1000 );
		add_action( 'woocommerce_before_pay_action', array( __CLASS__, 'retry_order' ) );
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( __CLASS__, 'render_order_change' ) );
	}

	public static function gateway_id() {
		$gateway = vig_value( 'cash_gateway', 'cod' );
		return is_string( $gateway ) && preg_match( '/^[A-Za-z0-9_.:-]+$/D', $gateway ) ? $gateway : '';
	}

	public static function applicable( $method, $currency ) {
		return 'BRL' === $currency && is_string( $method ) && '' !== $method && self::gateway_id() === $method;
	}

	public static function assets() {
		$gateway = self::gateway_id();
		if ( ! is_checkout() || is_order_received_page() || '' === $gateway ) {
			return;
		}
		wp_enqueue_style( 'vig-cash-change', VIG_URL . 'assets/cash-change.css', array(), VIG_VER );
		// Em um checkout de blocos, a integração de blocos fornece seus próprios recursos.
		if ( ! is_checkout_pay_page() && has_block( 'woocommerce/checkout', get_queried_object_id() ) ) {
			return;
		}
		wp_enqueue_script( 'vig-cash-change-classic', VIG_URL . 'assets/cash-change-classic.js', array( 'jquery' ), VIG_VER, true );
		// A seleção por CSS também funciona com JavaScript desligado.
		$css = '#payment:not(:has(input[name="payment_method"][value="' . $gateway . '"]:checked)) [data-vig-cash-change]{display:none}';
		wp_add_inline_style( 'vig-cash-change', $css );
	}

	private static function posted_value() {
		// O checkout do WooCommerce verifica o nonce antes de processar o pedido.
		return isset( $_POST[ self::FIELD ] ) ? wp_unslash( $_POST[ self::FIELD ] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	}

	public static function classic_field() {
		$gateway   = self::gateway_id();
		$order_id  = absint( get_query_var( 'order-pay' ) );
		$order     = $order_id ? wc_get_order( $order_id ) : false;
		$currency  = $order ? $order->get_currency() : get_woocommerce_currency();
		if ( ! self::applicable( $gateway, $currency ) || ( ! $order && ( ! WC()->cart || ! WC()->cart->needs_payment() ) ) ) {
			return;
		}
		$available = WC()->payment_gateways()->get_available_payment_gateways();
		if ( ! isset( $available[ $gateway ] ) ) {
			return;
		}
		$value = self::posted_value();
		if ( $order && ! isset( $_POST[ self::FIELD ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$value = $order->get_meta( self::TENDERED );
		}
		?>
		<div class="form-row form-row-wide vig-cash-change" data-vig-cash-change="<?php echo esc_attr( $gateway ); ?>">
			<label for="vig_cash_tendered"><?php esc_html_e( 'Troco para quanto? (R$)', 'villa-ibit-gestor' ); ?></label>
			<input id="vig_cash_tendered" name="vig_cash_tendered" type="text" class="input-text" inputmode="decimal" maxlength="30" autocomplete="off" aria-describedby="vig_cash_help" placeholder="<?php esc_attr_e( 'Ex.: 250,00', 'villa-ibit-gestor' ); ?>" value="<?php echo esc_attr( is_string( $value ) ? $value : '' ); ?>">
			<small id="vig_cash_help"><?php esc_html_e( 'Informe o valor em dinheiro que vai entregar. Se tiver o valor exato, deixe em branco.', 'villa-ibit-gestor' ); ?></small>
		</div>
		<?php
	}

	/** Aceita reais no formato brasileiro e decimal com ponto. Rejeita números ambíguos ou truncados. */
	private static function tendered_cents( $raw, $total ) {
		if ( null === $raw || ( is_string( $raw ) && '' === trim( $raw ) ) ) {
			return null;
		}

		if ( is_string( $raw ) && strlen( $raw ) <= 40 ) {
			$value = preg_replace( '/^R\$[\s\xC2\xA0]*/', '', trim( $raw ) );
			if ( preg_match( '/\A(?:[0-9]{1,9}|[0-9]{1,3}(?:\.[0-9]{3}){1,2})(?:,[0-9]{1,2})?\z/', $value ) ) {
				$value = str_replace( ',', '.', str_replace( '.', '', $value ) );
			} elseif ( ! preg_match( '/\A[0-9]{1,9}\.[0-9]{1,2}\z/', $value ) ) {
				$value = null;
			}
			if ( null !== $value ) {
				$cents = round( (float) $value * 100 );
				if ( $cents >= round( (float) $total * 100 ) ) {
					return $cents;
				}
				return new WP_Error( 'vig_cash_too_low', __( 'O valor em dinheiro precisa ser igual ou maior que o total do pedido, incluindo o frete.', 'villa-ibit-gestor' ) );
			}
		}
		return new WP_Error( 'vig_cash_invalid', __( 'Informe um valor válido para o troco. Por exemplo, 250,00.', 'villa-ibit-gestor' ) );
	}

	public static function validate_classic( $data, $errors ) {
		if ( ! WC()->cart || ! self::applicable( $data['payment_method'] ?? '', get_woocommerce_currency() ) ) {
			return;
		}
		$result = self::tendered_cents( self::posted_value(), WC()->cart->get_total( 'edit' ) );
		if ( is_wp_error( $result ) ) {
			$errors->add( $result->get_error_code(), $result->get_error_message() );
		}
	}

	/** Compartilhado pelos checkouts. O chamador usa o save normal do WooCommerce. */
	public static function apply_to_order( $order, $raw, $method = null ) {
		$method = null === $method ? $order->get_payment_method() : $method;
		$total  = $order->get_total( 'edit' );
		$cents  = self::applicable( $method, $order->get_currency() ) ? self::tendered_cents( $raw, $total ) : null;
		if ( is_wp_error( $cents ) ) {
			return $cents;
		}
		if ( null === $cents ) {
			$order->delete_meta_data( self::TENDERED );
			$order->delete_meta_data( self::CHANGE );
		} else {
			$order->update_meta_data( self::TENDERED, number_format( $cents / 100, 2, '.', '' ) );
			$order->update_meta_data( self::CHANGE, number_format( ( $cents - round( (float) $total * 100 ) ) / 100, 2, '.', '' ) );
		}
		return true;
	}

	public static function save_classic( $order ) {
		$result = self::apply_to_order( $order, self::posted_value() );
		if ( is_wp_error( $result ) ) {
			throw new Exception( $result->get_error_message() );
		}
	}

	/** O WooCommerce já verificou nonce e chave do pedido e ainda vai confirmar e salvar o método. */
	public static function retry_order( $order ) {
		$method = isset( $_POST['payment_method'] ) ? wp_unslash( $_POST['payment_method'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$result = self::apply_to_order( $order, self::posted_value(), $method );
		if ( is_wp_error( $result ) ) {
			wc_add_notice( $result->get_error_message(), 'error' );
			// Neste fluxo o WooCommerce grava o método mesmo quando já há um aviso de erro.
			wp_safe_redirect( $order->get_checkout_payment_url() );
			exit;
		}
	}

	public static function render_order_change( $order ) {
		$tendered = $order->get_meta( self::TENDERED );
		$change   = $order->get_meta( self::CHANGE );
		if ( '' === $tendered || '' === $change ) {
			return;
		}
		$format = array( 'currency' => $order->get_currency() );
		echo '<p><strong>' . esc_html__( 'Valor em dinheiro', 'villa-ibit-gestor' ) . '</strong> ' . wp_kses_post( wc_price( $tendered, $format ) ) . '<br>';
		echo '<strong>' . esc_html__( 'Troco a devolver', 'villa-ibit-gestor' ) . '</strong> ' . wp_kses_post( wc_price( $change, $format ) ) . '</p>';
	}
}
