<?php
/**
 * Exclusão mútua entre requisições e tarefas de integração.
 */
defined( 'ABSPATH' ) || exit;

final class VIG_Integration_Lock {
	/**
	 * Retorna a posse da trava, false se outro processo a detém, ou WP_Error.
	 * option_name é único e o valor inclui expiração e um token do proprietário.
	 * A trava não passa pelo cache de opções.
	 */
	public static function acquire( $name, $seconds ) {
		global $wpdb;
		$key = '_vig_lock_' . hash( 'sha256', $name );
		$value = ( time() + max( 1, (int) $seconds ) ) . ':' . wp_generate_uuid4();
		$added = $wpdb->query( $wpdb->prepare(
			"INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
			$key, $value
		) );
		if ( false === $added ) {
			return new WP_Error( 'vig_lock_db', 'Falha ao obter a trava no banco de dados.' );
		}
		if ( 1 !== $added ) {
			$old = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $key ) );
			if ( $wpdb->last_error ) {
				return new WP_Error( 'vig_lock_db', 'Falha ao ler a trava no banco de dados.' );
			}
			if ( null === $old || (int) $old > time() ) {
				return false;
			}
			// O valor completo impede que dois processos assumam a mesma trava vencida.
			$claimed = $wpdb->update( $wpdb->options, array( 'option_value' => $value ), array( 'option_name' => $key, 'option_value' => $old ) );
			if ( false === $claimed ) {
				return new WP_Error( 'vig_lock_db', 'Falha ao renovar a trava no banco de dados.' );
			}
			if ( 1 !== $claimed ) {
				return false;
			}
		}
		return array( 'option_name' => $key, 'option_value' => $value );
	}

	public static function release( $lease ) {
		global $wpdb;
		$wpdb->delete( $wpdb->options, $lease );
	}
}
