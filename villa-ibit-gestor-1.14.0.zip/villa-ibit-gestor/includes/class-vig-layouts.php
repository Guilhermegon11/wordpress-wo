<?php
/**
 * Layouts (Elementor) das páginas criadas pela configuração automática.
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;

class VIG_Layouts {

	private static $n = 0;

	private static function id() {
		self::$n++;
		return substr( md5( 'vig' . self::$n . wp_rand() ), 0, 7 );
	}

	private static function box( $v ) {
		return array( 'unit' => 'px', 'top' => (string) $v[0], 'right' => (string) $v[1], 'bottom' => (string) $v[2], 'left' => (string) $v[3], 'isLinked' => false );
	}

	/** Widget. */
	public static function w( $type, $settings = array() ) {
		return array( 'id' => self::id(), 'elType' => 'widget', 'widgetType' => $type, 'settings' => (object) $settings, 'elements' => array() );
	}

	/** Seção de largura total (os widgets Villa Ibit já têm a própria largura). */
	public static function full( $widgets ) {
		return array(
			'id'       => self::id(),
			'elType'   => 'container',
			'isInner'  => false,
			'settings' => array(
				'content_width' => 'full',
				'padding'       => self::box( array( 0, 0, 0, 0 ) ),
				'flex_gap'      => array( 'unit' => 'px', 'size' => 0, 'column' => '0', 'row' => '0', 'isLinked' => true ),
			),
			'elements' => $widgets,
		);
	}

	/** Seção de texto (largura de leitura). */
	public static function text_box( $widgets ) {
		return array(
			'id'       => self::id(),
			'elType'   => 'container',
			'isInner'  => false,
			'settings' => array(
				'content_width' => 'boxed',
				'boxed_width'   => array( 'unit' => 'px', 'size' => 900, 'sizes' => array() ),
				'padding'       => self::box( array( 40, 24, 64, 24 ) ),
				'flex_gap'      => array( 'unit' => 'px', 'size' => 16, 'column' => '16', 'row' => '16', 'isLinked' => true ),
				'css_classes'   => 'vi-legal',
			),
			'elements' => $widgets,
		);
	}

	private static function hero( $title, $text = '' ) {
		return self::full( array( self::w( 'vi-cabecalho', array( 'title' => $title, 'text' => $text, 'crumbs' => 'yes' ) ) ) );
	}

	private static function html_page( $html ) {
		return self::text_box( array( self::w( 'text-editor', array( 'editor' => $html ) ) ) );
	}

	/** A mesma lista serve para montar uma home nova e acrescentar uma seção na atual. */
	private static function home_widgets() {
		return array(
			'categories' => self::w( 'vi-categorias', array( 'title' => 'Compre por categoria', 'layout' => 'bento', 'link_all' => 'yes' ) ),
			'novidades'  => self::w( 'vi-vitrine', array( 'eyebrow' => '', 'title' => 'Novidades', 'source' => 'novidades', 'limit' => 12, 'columns' => '5', 'style' => 'band' ) ),
			'promos'     => self::w( 'vi-cartoes' ),
			'duo'        => self::w( 'vi-vendidos-destaques', array( 'title_sold' => 'Mais vendidos', 'title_featured' => 'Produtos em destaque', 'limit' => 3 ) ),
			'featured'   => self::w( 'vi-vitrine', array( 'eyebrow' => '', 'source' => 'destaques', 'limit' => 10, 'columns' => '5', 'style' => 'band' ) ),
			'tabs'       => self::w( 'vi-vitrine-abas', array( 'title' => 'Mais vendidos' ) ),
			'spotlight'  => self::w( 'vi-destaque' ),
			'deals'      => self::w( 'vi-vitrine', array( 'eyebrow' => '', 'title' => 'Ofertas que valem a pena', 'source' => 'ofertas', 'style' => 'dark' ) ),
			'brands'     => self::w( 'vi-marcas', array( 'title' => 'Marcas originais' ) ),
			'extra'      => self::w( 'vi-vitrine', array( 'eyebrow' => '', 'source' => 'categoria', 'limit' => 8, 'columns' => '4', 'style' => 'light' ) ),
			'wholesale'  => self::w( 'vi-atacado', array( 'eyebrow' => 'Atacado Villa Ibit', 'button' => 'Pedir tabela no WhatsApp' ) ),
			'reviews'    => self::w( 'vi-avaliacoes' ),
			'blog'       => self::w( 'vi-blog' ),
			'social'     => self::w( 'vi-instagram-vip' ),
		);
	}

	private static function home_layout() {
		$layout = array(
			self::full( array( self::w( 'vi-banner', array( 'source' => 'painel', 'show_offers' => 'yes' ) ) ) ),
			self::full( array( self::w( 'vi-selos' ) ) ),
		);
		$defaults = vig_defaults();
		$active   = array_merge(
			(array) ( $defaults['sections'] ?? array( 'categories' => 1, 'novidades' => 1, 'promos' => 1, 'duo' => 1, 'wholesale' => 1 ) ),
			(array) vi_gestor_get( 'sections' )
		);
		$widgets = self::home_widgets();
		$order   = vi_gestor_get( 'home_order' );
		$keys    = $order ? VIG_Settings::home_section_order( $order ) : array_keys( $widgets );
		foreach ( $keys as $key ) {
			if ( ! empty( $active[ $key ] ) ) {
				$layout[] = self::full( array( $widgets[ $key ] ) );
			}
		}
		return $layout;
	}

	private static function home_widget_key( $element ) {
		if ( empty( $element->widgetType ) || ! is_string( $element->widgetType ) ) {
			return '';
		}
		$settings = (array) ( $element->settings ?? array() );
		if ( 'viv-section' === $element->widgetType && class_exists( 'VIV_Layouts' ) ) {
			return VIG_Visual_Home_Order::section_key( $settings['section'] ?? '' );
		}
		if ( 'vi-vitrine' === $element->widgetType && isset( $settings['source'] ) && ! is_string( $settings['source'] ) ) {
			return '';
		}
		return function_exists( 'vi_home_section_key' ) ? vi_home_section_key( $element->widgetType, $settings ) : '';
	}

	private static function collect_home_sections( array $elements, array &$found ) {
		foreach ( $elements as $element ) {
			if ( isset( $element->widgetType ) && is_string( $element->widgetType ) ) {
				if ( 0 === strpos( $element->widgetType, 'vi-' ) ) {
					$found['villa'] = true;
				} elseif ( 'viv-section' === $element->widgetType && class_exists( 'VIV_Layouts' ) ) {
					$found['visual'] = true;
				}
				$key = self::home_widget_key( $element );
				if ( $key ) {
					$found[ $key ][] = $element;
					continue;
				}
			}
			if ( ! empty( $element->elements ) && is_array( $element->elements ) ) {
				self::collect_home_sections( $element->elements, $found );
			}
		}
	}

	public static function current_home_section_order() {
		$id = (int) get_option( 'page_on_front' );
		if ( ! $id || 'page' !== get_option( 'show_on_front' ) ) {
			return array();
		}
		if ( ! did_action( 'elementor/loaded' ) || 'builder' !== get_post_meta( $id, '_elementor_edit_mode', true ) ) {
			if ( ! class_exists( 'VIV_Layouts' ) ) {
				return array();
			}
			$present = VIG_Visual_Home_Order::current_order( (string) get_post_field( 'post_content', $id, 'raw' ) );
			$saved   = vi_gestor_get( 'home_order' );
			return $saved ? array_values( array_intersect( VIG_Settings::home_section_order( $saved ), $present ) ) : $present;
		}
		$raw   = get_post_meta( $id, '_elementor_data', true );
		$nodes = is_string( $raw ) ? json_decode( $raw ) : null;
		$found = array();
		if ( is_array( $nodes ) ) {
			self::collect_home_sections( $nodes, $found );
		}
		unset( $found['villa'], $found['visual'] );
		return array_keys( $found );
	}

	/** Ordenação estável: mantém a sequência de widgets duplicados e só escreve nos lugares selecionados. */
	private static function sort_section_slots( array $slots, array $order, array $groups = array() ) {
		if ( ! $groups ) {
			foreach ( $slots as $slot ) {
				$groups[ $slot['key'] ][] = $slot['node'];
			}
		}
		$index   = 0;
		$changed = false;
		foreach ( $order as $key ) {
			foreach ( $groups[ $key ] ?? array() as $node ) {
				if ( $slots[ $index ]['node'] !== $node ) {
					$slots[ $index ]['node'] = $node;
					$changed = true;
				}
				++$index;
			}
		}
		return $changed;
	}

	/** Identifica um widget ou uma cadeia de contêineres que envolve apenas esse widget. */
	private static function wrapped_section_key( $element ) {
		while ( empty( $element->widgetType ) && isset( $element->elements ) && is_array( $element->elements ) && 1 === count( $element->elements ) ) {
			$element = $element->elements[0];
		}
		return self::home_widget_key( $element );
	}

	/** Move um bloco completo com seu estilo sempre que os elementos irmãos comportarem a mesma estrutura. */
	private static function order_home_containers( array &$elements, array $order, array &$widget_slots ) {
		$containers = array();
		foreach ( $elements as $index => $element ) {
			$type = $element->elType ?? '';
			if ( ! in_array( $type, array( 'section', 'column', 'container' ), true ) ) {
				continue;
			}
			$key = self::wrapped_section_key( $element );
			if ( in_array( $key, $order, true ) ) {
				$containers[ $type ][] = array( 'key' => $key, 'node' => &$elements[ $index ] );
			}
		}
		$changed = false;
		foreach ( $containers as $slots ) {
			$changed = self::sort_section_slots( $slots, $order ) || $changed;
		}
		// Em contêineres mistos, só os slots de widgets Villa participam da ordenação global.
		foreach ( $elements as $index => $element ) {
			$key = self::home_widget_key( $element );
			if ( in_array( $key, $order, true ) ) {
				$widget_slots[] = array( 'key' => $key, 'node' => &$elements[ $index ] );
			} elseif ( ! empty( $element->elements ) && is_array( $element->elements ) ) {
				$changed = self::order_home_containers( $element->elements, $order, $widget_slots ) || $changed;
			}
		}
		return $changed;
	}

	/** Insere uma seção recém-habilitada sem mexer na ordem dos elementos que o editor já publicou. */
	private static function insert_before_next_section( array &$elements, array $next, $widget, $top = true ) {
		foreach ( $elements as $index => $element ) {
			$key = $top ? self::wrapped_section_key( $element ) : self::home_widget_key( $element );
			if ( isset( $next[ $key ] ) ) {
				$new = $top ? (object) self::full( array( $widget ) ) : $widget;
				array_splice( $elements, $index, 0, array( $new ) );
				return true;
			}
			if ( ! empty( $element->elements ) && is_array( $element->elements ) && self::insert_before_next_section( $element->elements, $next, $widget, false ) ) {
				return true;
			}
		}
		return false;
	}

	/** Acrescenta seções ligadas e aplica a sequência explícita sem reconstruir a página. */
	public static function sync_home_sections( array $active, $from_settings = false, array $order = array() ) {
		$id = (int) get_option( 'page_on_front' );
		if ( ! $id || 'page' !== get_option( 'show_on_front' ) || ( ! $order && ! array_filter( $active ) ) ) {
			return true;
		}
		if ( ! did_action( 'elementor/loaded' ) || 'builder' !== get_post_meta( $id, '_elementor_edit_mode', true ) ) {
			if ( $order && '' !== trim( (string) get_post_field( 'post_content', $id, 'raw' ) ) && ! self::current_home_section_order() ) {
				return 'unmanaged';
			}
			return true;
		}
		$raw = get_post_meta( $id, '_elementor_data', true );
		$els = is_string( $raw ) ? json_decode( $raw ) : null;
		if ( ! is_array( $els ) ) {
			return false;
		}
		$found = array();
		self::collect_home_sections( $els, $found );
		$theme_widgets = function_exists( 'vi_home_section_key' ) && ( ! empty( $found['villa'] ) || ( $from_settings && empty( $found['visual'] ) ) );
		unset( $found['villa'] );
		$is_visual = ! empty( $found['visual'] );
		unset( $found['visual'] );
		if ( ! $theme_widgets && ! $is_visual ) {
			return $order ? 'unmanaged' : true;
		}
		if ( $is_visual && ! $theme_widgets && ! $found && $order ) {
			return 'unmanaged';
		}
		$changed = false;
		if ( $theme_widgets ) {
			$widgets = self::home_widgets();
			$saved   = vi_gestor_get( 'home_order' );
			$insert  = ! $order && $saved;
			$keys    = $insert ? VIG_Settings::effective_home_section_order( array_keys( $found ), $saved ) : array_keys( $widgets );
			foreach ( $keys as $index => $key ) {
				if ( empty( $active[ $key ] ) || isset( $found[ $key ] ) ) {
					continue;
				}
				$widget = (object) $widgets[ $key ];
				$next   = $insert ? array_flip( array_slice( $keys, $index + 1 ) ) : array();
				if ( ! $next || ! self::insert_before_next_section( $els, $next, $widget ) ) {
					$els[] = (object) self::full( array( $widget ) );
				}
				$found[ $key ][] = $widget;
				$changed         = true;
			}
		}
		if ( $order ) {
			$order        = VIG_Settings::home_section_order( $order );
			$widget_slots = array();
			$changed      = self::order_home_containers( $els, $order, $widget_slots ) || $changed;
			$changed      = self::sort_section_slots( $widget_slots, $order, $found ) || $changed;
		}
		if ( ! $changed ) {
			return true;
		}
		// Se o editor publicou outra versão durante o salvamento, não a sobrescreva.
		$json = wp_json_encode( $els );
		if ( false === $json || ! update_post_meta( $id, '_elementor_data', wp_slash( $json ), $raw ) ) {
			return false;
		}
		delete_post_meta( $id, '_elementor_element_cache' );
		delete_post_meta( $id, '_elementor_css' );
		clean_post_cache( $id );
		return true;
	}

	/**
	 * Definições: slug => [título, layout Elementor, conteúdo de reserva (sem Elementor), papel].
	 */
	public static function pages() {
		$store = get_bloginfo( 'name' );
		$wa    = function_exists( 'vi_wa_link' ) ? vi_wa_link() : 'https://wa.me/' . vig_value( 'whatsapp', '' );

		$faq = array(
			array( 'Os produtos são originais?', 'Sim. Trabalhamos apenas com produtos 100% originais, com procedência e lacrados de fábrica.' ),
			array( 'Quais formas de pagamento vocês aceitam?', 'PIX (com desconto), cartão de crédito e outras opções exibidas no checkout. No PIX o pagamento é aprovado na hora e o pedido já entra para separação.' ),
			array( 'Onde vocês entregam?', 'Entregamos somente em Governador Valadares (MG).' ),
			array( 'Como consulto o frete?', 'Informe o CEP do endereço de entrega no carrinho para consultar as opções disponíveis.' ),
			array( 'Como acompanho meu pedido?', 'Entre em Minha conta › Meus pedidos. Você também recebe as atualizações por e-mail e pode falar com a gente no WhatsApp.' ),
			array( 'Posso trocar ou devolver um produto?', 'Sim, conforme a nossa política de trocas e devoluções e o Código de Defesa do Consumidor. Veja os detalhes na página Trocas e devoluções.' ),
			array( 'Preciso ter 18 anos para comprar?', 'Sim. A venda é proibida para menores de 18 anos e podemos pedir documento na entrega.' ),
			array( 'Vocês vendem no atacado?', 'Sim, temos condições especiais para lojistas, distribuidores e revendedores. Fale com a gente pelo WhatsApp.' ),
		);
		$faq_tabs = array();
		foreach ( $faq as $q ) {
			$faq_tabs[] = array( '_id' => self::id(), 'tab_title' => $q[0], 'tab_content' => '<p>' . esc_html( $q[1] ) . '</p>' );
		}
		$faq_fallback = '';
		foreach ( $faq as $q ) {
			$faq_fallback .= '<h3>' . esc_html( $q[0] ) . '</h3><p>' . esc_html( $q[1] ) . '</p>';
		}

		$privacy = '<p><strong>[Revise este texto com seu contador/advogado e preencha os dados entre colchetes.]</strong></p>'
			. '<h2>1. Quem somos</h2><p>' . esc_html( $store ) . ', CNPJ [00.000.000/0000-00], com sede em [endereço], é a responsável pelo tratamento dos seus dados pessoais, nos termos da Lei Geral de Proteção de Dados (Lei 13.709/2018 — LGPD).</p>'
			. '<h2>2. Quais dados coletamos</h2><p>Nome, CPF, data de nascimento, e-mail, telefone, endereço de entrega e cobrança, histórico de pedidos e dados de navegação (como cookies e endereço IP). Dados de cartão são processados diretamente pelo meio de pagamento e não ficam armazenados na loja.</p>'
			. '<h2>3. Para que usamos</h2><p>Processar e entregar pedidos, emitir documentos fiscais, confirmar a maioridade, prestar atendimento, prevenir fraudes, cumprir obrigações legais e, com o seu consentimento, enviar ofertas.</p>'
			. '<h2>4. Com quem compartilhamos</h2><p>Somente com parceiros necessários para a operação: meios de pagamento, transportadoras e entregadores, plataforma da loja e hospedagem, e autoridades quando exigido por lei.</p>'
			. '<h2>5. Cookies</h2><p>Usamos cookies para manter o carrinho, lembrar a confirmação de idade e entender como o site é usado. Você pode bloqueá-los no navegador, mas algumas funções podem deixar de funcionar.</p>'
			. '<h2>6. Seus direitos</h2><p>Você pode pedir acesso, correção, exclusão ou portabilidade dos seus dados e revogar consentimentos pelo e-mail [seu-email] ou pelo WhatsApp da loja.</p>'
			. '<h2>7. Por quanto tempo guardamos</h2><p>Pelo tempo necessário para cumprir as finalidades acima e as obrigações legais e fiscais.</p>'
			. '<p>Última atualização: [data].</p>';

		$terms = '<p><strong>[Revise este texto e preencha os dados entre colchetes.]</strong></p>'
			. '<h2>1. Maioridade</h2><p>A venda dos produtos desta loja é proibida para menores de 18 anos. Ao comprar, você declara ter 18 anos ou mais. Podemos pedir documento com foto na entrega.</p>'
			. '<h2>2. Pedidos e preços</h2><p>Os preços e a disponibilidade podem mudar sem aviso. O pedido é confirmado após a aprovação do pagamento. O desconto do PIX vale apenas para pagamentos feitos via PIX.</p>'
			. '<h2>3. Entrega</h2><p>Entregamos somente em Governador Valadares (MG). Consulte o frete no carrinho com o CEP do endereço de entrega.</p>'
			. '<h2>4. Conta do cliente</h2><p>Você é responsável por manter sua senha em segurança e pelos dados informados no cadastro.</p>'
			. '<h2>5. Contato</h2><p>' . esc_html( $store ) . ' — CNPJ [00.000.000/0000-00] — [endereço] — WhatsApp da loja.</p>';

		$returns = '<p><strong>[Revise este texto conforme a sua operação.]</strong></p>'
			. '<h2>Direito de arrependimento</h2><p>Em compras pela internet, você pode desistir em até 7 dias corridos após o recebimento (art. 49 do Código de Defesa do Consumidor). O produto deve ser devolvido lacrado, sem uso e na embalagem original.</p>'
			. '<h2>Produto com defeito</h2><p>Se o produto apresentar defeito de fabricação, fale com a gente em até 7 dias após o recebimento pelo WhatsApp, com fotos ou vídeo e o número do pedido. Analisamos e fazemos a troca ou o reembolso.</p>'
			. '<h2>Como solicitar</h2><p>Envie uma mensagem pelo WhatsApp da loja com o número do pedido. Nós explicamos como fazer a devolução sem custo nos casos acima.</p>'
			. '<h2>Reembolso</h2><p>O valor é devolvido pela mesma forma de pagamento em até [X] dias úteis após recebermos o produto.</p>';

		return array(
			'inicio'                => array(
				'title'    => __( 'Início', 'villa-ibit-gestor' ),
				'role'     => 'front',
				'fallback' => '',
				'data'     => self::home_layout(),
			),
			'todos-os-produtos'     => array(
				'title'    => __( 'Todos os produtos', 'villa-ibit-gestor' ),
				'role'     => 'shop',
				'fallback' => '',
				'data'     => array( self::full( array( self::w( 'vi-catalogo', array( 'title' => 'Todos os produtos', 'text' => 'Pods descartáveis, pod system, líquidos e acessórios 100% originais.', 'hero' => 'yes', 'filters' => 'yes', 'per_page' => 24 ) ) ) ) ),
			),
			'categorias'            => array(
				'title'    => __( 'Categorias', 'villa-ibit-gestor' ),
				'role'     => '',
				'fallback' => '[villa_ibit secao="categorias" layout="grid"]',
				'data'     => array(
					self::hero( 'Categorias', 'Encontre o produto certo para você.' ),
					self::full( array( self::w( 'vi-categorias', array( 'title' => '', 'layout' => 'grid' ) ) ) ),
					self::full( array( self::w( 'vi-vitrine', array( 'eyebrow' => 'Promoções', 'title' => 'Ofertas da semana', 'source' => 'ofertas', 'limit' => 6, 'columns' => '6', 'style' => 'dark' ) ) ) ),
					self::full( array( self::w( 'vi-marcas', array( 'title' => 'Compre por marca' ) ) ) ),
				),
			),
			'acessorios'            => array(
				'title'    => __( 'Acessórios', 'villa-ibit-gestor' ),
				'role'     => '',
				'fallback' => '[villa_ibit secao="catalogo" categoria="acessorios"]',
				'data'     => array( self::full( array( self::w( 'vi-catalogo', array( 'title' => 'Acessórios', 'text' => 'Coils, cartuchos e tudo para manter o seu aparelho em dia.', 'category' => 'acessorios', 'hero' => 'yes', 'filters' => 'yes', 'per_page' => 24 ) ) ) ) ),
			),
			'entrar'                => array(
				'title'    => __( 'Entrar / Cadastrar', 'villa-ibit-gestor' ),
				'role'     => 'login',
				'fallback' => '[villa_ibit secao="login"]',
				'data'     => array(
					self::hero( 'Entrar / Cadastrar' ),
					self::full( array( self::w( 'vi-login', array( 'title' => 'Bem-vindo de volta', 'text' => 'Entre com seu e-mail ou crie sua conta em menos de 1 minuto.' ) ) ) ),
				),
			),
			'modelo-produto'        => array(
				'title'    => __( 'Modelo — Página do produto', 'villa-ibit-gestor' ),
				'role'     => 'tpl_product',
				'status'   => 'private',
				'fallback' => '',
				'data'     => array(
					self::full( array( self::w( 'vi-produto-compra', array( 'crumbs' => 'yes', 'delivery' => 'yes', 'trust' => 'yes' ) ) ) ),
					self::full( array( self::w( 'vi-produto-abas' ) ) ),
					self::full( array( self::w( 'vi-produto-relacionados' ) ) ),
					self::full( array( self::w( 'vi-atacado' ) ) ),
				),
			),
			'carrinho'              => array(
				'title'    => __( 'Carrinho', 'villa-ibit-gestor' ),
				'role'     => 'cart',
				'fallback' => '<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->',
				'data'     => array( self::full( array( self::w( 'vi-etapas' ), self::w( 'vi-woo', array( 'which' => 'cart' ) ) ) ), self::full( array( self::w( 'vi-selos' ) ) ) ),
			),
			'finalizar-compra'      => array(
				'title'    => __( 'Finalizar compra', 'villa-ibit-gestor' ),
				'role'     => 'checkout',
				'fallback' => '<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->',
				'data'     => array( self::full( array( self::w( 'vi-etapas' ), self::w( 'vi-woo', array( 'which' => 'checkout' ) ) ) ) ),
			),
			'minha-conta'           => array(
				'title'    => __( 'Minha conta', 'villa-ibit-gestor' ),
				'role'     => 'myaccount',
				'fallback' => '<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->',
				'data'     => array( self::hero( 'Minha conta' ), self::full( array( self::w( 'vi-woo', array( 'which' => 'account' ) ) ) ) ),
			),
			'perguntas-frequentes'  => array(
				'title'    => __( 'Perguntas frequentes', 'villa-ibit-gestor' ),
				'role'     => '',
				'fallback' => $faq_fallback,
				'data'     => array(
					self::hero( 'Perguntas frequentes', 'Tire suas dúvidas sobre pagamento, entrega, trocas e produtos.' ),
					self::text_box(
						array(
							self::w( 'accordion', array( 'tabs' => $faq_tabs, 'title_html_tag' => 'h3' ) ),
							self::w( 'heading', array( 'title' => 'Não achou sua dúvida?', 'header_size' => 'h2' ) ),
							self::w( 'button', array( 'text' => 'Falar no WhatsApp', 'link' => array( 'url' => $wa, 'is_external' => 'on', 'nofollow' => '' ), 'background_color' => '#034D43', 'border_radius' => array( 'unit' => 'px', 'top' => '999', 'right' => '999', 'bottom' => '999', 'left' => '999', 'isLinked' => true ) ) ),
						)
					),
				),
			),
			'politica-de-privacidade' => array(
				'title'    => __( 'Política de privacidade', 'villa-ibit-gestor' ),
				'role'     => 'privacy',
				'fallback' => $privacy,
				'data'     => array( self::hero( 'Política de privacidade' ), self::html_page( $privacy ) ),
			),
			'termos-de-uso'         => array(
				'title'    => __( 'Termos de uso', 'villa-ibit-gestor' ),
				'role'     => 'terms',
				'fallback' => $terms,
				'data'     => array( self::hero( 'Termos de uso' ), self::html_page( $terms ) ),
			),
			'trocas-e-devolucoes'   => array(
				'title'    => __( 'Trocas e devoluções', 'villa-ibit-gestor' ),
				'role'     => '',
				'fallback' => $returns,
				'data'     => array( self::hero( 'Trocas e devoluções' ), self::html_page( $returns ) ),
			),
			'blog'                  => array(
				'title'    => __( 'Dicas e novidades', 'villa-ibit-gestor' ),
				'role'     => 'posts',
				'fallback' => '',
				'data'     => null,
			),
		);
	}
}
