<?php
/** Importação unidirecional Bling → WooCommerce. */
defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/class-vig-bling-api.php';
require_once __DIR__ . '/class-vig-bling-product.php';

class VIG_Bling {
	const PAGE = 'vi-gestor-bling';
	const JOB = 'vig_bling_job';
	const HOURLY = 'vig_bling_hourly';
	const WORK = 'vig_bling_work';
	const LIMIT = 50;

	public static function init() {
		add_filter( 'cron_schedules', array( __CLASS__, 'intervals' ) );
		add_action( self::HOURLY, array( __CLASS__, 'automatic' ) );
		add_action( self::WORK, array( __CLASS__, 'tick' ) );
		foreach ( array( 'save', 'connect', 'callback', 'disconnect', 'sync' ) as $action ) {
			add_action( 'admin_post_vig_bling_' . $action, array( __CLASS__, $action ) );
		}
		add_filter( 'woocommerce_duplicate_product_exclude_meta', array( __CLASS__, 'exclude_links' ) );
		register_deactivation_hook( VIG_FILE, array( __CLASS__, 'deactivate' ) );
		if ( VIG_Bling_API::connected() ) {
			self::schedule();
		}
	}

	public static function exclude_links( $keys ) {
		return array_unique( array_merge( $keys, array( '_vig_bling_id', '_vig_bling_last_stock', '_vig_bling_category_id', '_vig_bling_brand_id', '_vig_bling_image' ) ) );
	}

	public static function intervals( $schedules ) {
		$schedules['vig_bling_minute'] = array( 'interval' => MINUTE_IN_SECONDS, 'display' => 'A cada minuto (Villa Ibit)' );
		return $schedules;
	}

	private static function schedule() {
		$app = get_option( VIG_Bling_API::APP, array() );
		if ( ! empty( $app['automatic'] ) && ! wp_next_scheduled( self::HOURLY ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', self::HOURLY );
		}
		$job = get_option( self::JOB, array() );
		if ( 'running' === ( $job['status'] ?? '' ) && ! wp_next_scheduled( self::WORK ) ) {
			wp_schedule_event( time() + 1, 'vig_bling_minute', self::WORK );
		}
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( self::HOURLY );
		wp_clear_scheduled_hook( self::WORK );
	}

	private static function locked( $callback ) {
		$lease = VIG_Integration_Lock::acquire( 'bling', 600 );
		if ( is_wp_error( $lease ) ) {
			return $lease;
		}
		if ( ! $lease ) {
			return new WP_Error( 'bling_busy', 'A integração está ocupada. Tente de novo em instantes.' );
		}
		try {
			return $callback();
		} finally {
			VIG_Integration_Lock::release( $lease );
		}
	}

	private static function input( $name ) {
		return isset( $_POST[ $name ] ) && is_string( $_POST[ $name ] ) ? trim( wp_unslash( $_POST[ $name ] ) ) : '';
	}

	private static function back( $result, $message, $success_fragment = '' ) {
		$url = admin_url( 'admin.php?page=' . self::PAGE );
		VIG_Admin::back( is_wp_error( $result ) ? $url : $url . $success_fragment, is_wp_error( $result ) ? $result->get_error_message() : $message, is_wp_error( $result ) );
	}

	private static function reset_connection() {
		self::deactivate();
		delete_option( VIG_Bling_API::TOKENS );
		delete_option( self::JOB );
		delete_transient( 'vig_bling_state_' . get_current_user_id() );
	}

	public static function save() {
		VIG_Admin::check_post( 'vig_bling_save' );
		$result = self::locked( function () {
			$app = get_option( VIG_Bling_API::APP, array() );
			$id = sanitize_text_field( self::input( 'client_id' ) );
			$secret = self::input( 'client_secret' );
			$new_id = $id !== ( $app['client_id'] ?? '' );
			if ( ! $id || ( ! $secret && ( $new_id || empty( $app['secret'] ) ) ) ) {
				return new WP_Error( 'bling_config', 'Informe o Client ID e o Client Secret do mesmo aplicativo.' );
			}
			if ( $secret ) {
				$sealed = VIG_Secrets::seal( $secret );
				if ( is_wp_error( $sealed ) ) {
					return $sealed;
				}
				$app['secret'] = $sealed;
			}
			if ( $new_id || $secret ) {
				self::reset_connection();
			}
			$app['client_id'] = $id;
			$app['automatic'] = isset( $_POST['automatic'] ) ? 1 : 0;
			update_option( VIG_Bling_API::APP, $app, false );
			if ( ! $app['automatic'] ) {
				wp_clear_scheduled_hook( self::HOURLY );
			}
			if ( VIG_Bling_API::connected() ) {
				self::schedule();
			}
			return true;
		} );
		self::back( $result, 'Configuração do Bling salva.' );
	}

	public static function connect() {
		VIG_Admin::check_post( 'vig_bling_connect' );
		$app = get_option( VIG_Bling_API::APP, array() );
		if ( empty( $app['client_id'] ) || empty( $app['secret'] ) ) {
			self::back( new WP_Error( 'bling_config', 'Salve as credenciais do aplicativo primeiro.' ), '' );
		}
		$state = wp_generate_password( 48, false, false );
		set_transient( 'vig_bling_state_' . get_current_user_id(), array(
			'hash' => wp_hash( $state ),
			'app' => wp_hash( $app['client_id'] . ':' . $app['secret'] ),
		), 10 * MINUTE_IN_SECONDS );
		$url = add_query_arg( array( 'response_type' => 'code', 'client_id' => $app['client_id'], 'state' => $state ), 'https://www.bling.com.br/Api/v3/oauth/authorize' );
		wp_redirect( $url );
		exit;
	}

	public static function callback() {
		if ( ! current_user_can( VIG_Admin::CAP ) ) {
			wp_die( 'Sem permissão.' );
		}
		$result = self::locked( function () {
			$key = 'vig_bling_state_' . get_current_user_id();
			$expected = get_transient( $key );
			$app = get_option( VIG_Bling_API::APP, array() );
			$state = isset( $_GET['state'] ) && is_string( $_GET['state'] ) ? wp_unslash( $_GET['state'] ) : '';
			if ( ! $state || empty( $expected['hash'] ) || ! hash_equals( $expected['hash'], wp_hash( $state ) ) || ! hash_equals( $expected['app'], wp_hash( ( $app['client_id'] ?? '' ) . ':' . ( $app['secret'] ?? '' ) ) ) ) {
				return new WP_Error( 'bling_state', 'Autorização inválida ou vencida. Comece de novo pelo botão Conectar.' );
			}
			delete_transient( $key );
			$code = isset( $_GET['code'] ) && is_string( $_GET['code'] ) ? trim( wp_unslash( $_GET['code'] ) ) : '';
			if ( ! $code || isset( $_GET['error'] ) ) {
				return new WP_Error( 'bling_denied', 'A autorização foi cancelada. Conecte novamente para importar.' );
			}
			$tokens = VIG_Bling_API::exchange( array( 'grant_type' => 'authorization_code', 'code' => $code ) );
			if ( is_wp_error( $tokens ) ) {
				return $tokens;
			}
			delete_option( self::JOB );
			if ( ! empty( $app['automatic'] ) ) {
				self::start();
			}
			self::schedule();
			return true;
		} );
		self::back( $result, 'Conta Bling conectada.' );
	}

	public static function disconnect() {
		VIG_Admin::check_post( 'vig_bling_disconnect' );
		$result = self::locked( function () {
			self::reset_connection();
			return true;
		} );
		self::back( $result, 'Conta desconectada. Os produtos continuam no WooCommerce.' );
	}

	public static function sync() {
		VIG_Admin::check_post( 'vig_bling_sync' );
		$result = self::locked( function () {
			if ( ! VIG_Bling_API::connected() ) {
				return new WP_Error( 'bling_auth', 'Conecte o Bling antes de sincronizar.' );
			}
			self::start( true );
			return true;
		} );
		self::back( $result, 'Sincronização na fila. Acompanhe o andamento abaixo.', '#vig-bling-andamento' );
	}

	public static function automatic() {
		self::locked( function () {
			$app = get_option( VIG_Bling_API::APP, array() );
			if ( ! VIG_Bling_API::connected() || empty( $app['automatic'] ) ) {
				return;
			}
			self::start();
		} );
	}

	private static function start( $resume = false ) {
		$job = get_option( self::JOB, array() );
		if ( empty( $job ) || 'done' === $job['status'] ) {
			$job = array(
				'status' => 'running', 'phase' => 2, 'page' => 1, 'queue' => null, 'offset' => 0,
				'imported' => 0, 'retired' => 0, 'failures' => 0, 'recent' => array(), 'after' => 0,
				'attempt' => 0, 'message' => '', 'category_warning' => '', 'stock_warning' => '', 'started' => time(), 'finished' => 0,
			);
		} elseif ( $resume && 'paused' === $job['status'] ) {
			$job['status'] = 'running';
			$job['after'] = $job['attempt'] = 0;
			$job['message'] = '';
		}
		update_option( self::JOB, $job, false );
		self::schedule();
	}

	private static function pause( &$job, $message ) {
		$job['status'] = 'paused';
		$job['message'] = $message;
		wp_clear_scheduled_hook( self::WORK );
	}

	private static function retry( &$job, $error ) {
		$code = $error->get_error_code();
		if ( 'bling_auth' === $code || 'bling_http_403' === $code ) {
			self::pause( $job, $error->get_error_message() . ' Confira a autorização e as permissões de leitura.' );
			return true;
		}
		if ( 'bling_temp' !== $code ) {
			return false;
		}
		++$job['attempt'];
		$details = (array) $error->get_error_data();
		$delay = max( (int) ( $details['delay'] ?? 0 ), min( HOUR_IN_SECONDS, MINUTE_IN_SECONDS * ( 2 ** min( 6, $job['attempt'] - 1 ) ) ) );
		$job['after'] = time() + $delay;
		$job['message'] = $error->get_error_message();
		return true;
	}

	private static function issue( &$job, $id, $error ) {
		++$job['failures'];
		$job['recent'][] = 'ID ' . $id . ': ' . wp_strip_all_tags( $error->get_error_message() );
		$job['recent'] = array_slice( $job['recent'], -10 );
	}

	private static function page( &$job ) {
		$list = VIG_Bling_API::get( '/produtos', array( 'pagina' => $job['page'], 'limite' => self::LIMIT, 'criterio' => $job['phase'] ) );
		if ( is_wp_error( $list ) ) {
			if ( ! self::retry( $job, $list ) ) {
				self::pause( $job, $list->get_error_message() . ' Confira as permissões do aplicativo.' );
			}
			return false;
		}
		$job['queue'] = array();
		foreach ( $list as $row ) {
			$job['queue'][] = array( 'id' => absint( $row['id'] ?? 0 ), 'parent' => absint( $row['idProdutoPai'] ?? 0 ), 'format' => $row['formato'] ?? '' );
		}
		$job['offset'] = $job['attempt'] = $job['after'] = 0;
		$job['message'] = '';
		return true;
	}

	private static function next_page( &$job ) {
		if ( count( $job['queue'] ) >= self::LIMIT ) {
			++$job['page'];
		} elseif ( $job['phase'] < 4 ) {
			++$job['phase'];
			$job['page'] = 1;
		} else {
			$job['status'] = 'done';
			$job['finished'] = time();
			wp_clear_scheduled_hook( self::WORK );
		}
		$job['queue'] = null;
		$job['offset'] = 0;
	}

	private static function balances( $data, &$job ) {
		$balances = $missing = array();
		$items = array_merge( array( $data ), $data['variacoes'] ?? array() );
		foreach ( $items as $item ) {
			if ( empty( $item['id'] ) || 'P' !== ( $item['tipo'] ?? 'P' ) || 'V' === ( $item['formato'] ?? '' ) ) {
				continue;
			}
			$value = $item['estoque']['saldoVirtualTotal'] ?? null;
			if ( is_numeric( $value ) ) {
				$balances[ $item['id'] ] = $value;
			} else {
				$missing[] = $item['id'];
			}
		}
		foreach ( array_chunk( $missing, 100 ) as $ids ) {
			$rows = VIG_Bling_API::get( '/estoques/saldos', array( 'idsProdutos' => $ids ) );
			if ( is_wp_error( $rows ) ) {
				if ( 'bling_http_403' === $rows->get_error_code() ) {
					$job['stock_warning'] = 'O Bling não liberou a consulta de estoques. Confira as permissões de leitura para sincronizar todos os saldos.';
					break;
				}
				return $rows;
			}
			foreach ( $rows as $row ) {
				if ( ! empty( $row['produto']['id'] ) && is_numeric( $row['saldoVirtualTotal'] ?? null ) ) {
					$balances[ $row['produto']['id'] ] = $row['saldoVirtualTotal'];
				}
			}
			foreach ( $ids as $id ) {
				if ( ! isset( $balances[ $id ] ) ) {
					$job['stock_warning'] = 'Há produtos sem saldo informado no Bling. Produtos físicos novos sem saldo conhecido ficam indisponíveis até a próxima atualização de estoque.';
				}
			}
		}
		return $balances;
	}

	private static function category( $id, &$job ) {
		$app = get_option( VIG_Bling_API::APP, array() );
		$key = 'vig_bling_cat_' . md5( ( $app['client_id'] ?? '' ) . ':' . $id );
		$name = get_transient( $key );
		if ( false !== $name ) {
			return $name;
		}
		$data = VIG_Bling_API::get( '/categorias/produtos/' . $id );
		if ( is_wp_error( $data ) ) {
			if ( 'bling_http_403' !== $data->get_error_code() && 'bling_http_404' !== $data->get_error_code() ) {
				return $data;
			}
			$job['category_warning'] = 'Uma categoria não pôde ser consultada. Confira o cadastro e a permissão de leitura de categorias no Bling.';
			return '';
		}
		$name = sanitize_text_field( $data['descricao'] ?? '' );
		if ( $name ) {
			set_transient( $key, $name, HOUR_IN_SECONDS );
		}
		return $name;
	}

	private static function item( $row, &$job ) {
		$id = $row['id'];
		if ( ! $id ) {
			return new WP_Error( 'bling_item', 'A lista do Bling retornou um registro sem ID.' );
		}
		if ( 4 === $job['phase'] ) {
			return VIG_Bling_Product::retire( $id );
		}
		if ( $row['parent'] ) {
			return false; // As variações são importadas com o pai.
		}
		$path = 'V' === $row['format'] ? '/produtos/variacoes/' : '/produtos/';
		$data = VIG_Bling_API::get( $path . $id );
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		if ( (string) ( $data['id'] ?? '' ) !== (string) $id ) {
			return new WP_Error( 'bling_item', 'A resposta do Bling não corresponde ao ID solicitado.' );
		}
		$balances = self::balances( $data, $job );
		if ( is_wp_error( $balances ) ) {
			return $balances;
		}
		if ( ! empty( $data['categoria']['id'] ) ) {
			$name = self::category( absint( $data['categoria']['id'] ), $job );
			if ( is_wp_error( $name ) ) {
				return $name;
			}
			if ( '' !== $name ) {
				$data['_vig_category_name'] = $name;
			}
		} elseif ( array_key_exists( 'categoria', $data ) ) {
			$data['_vig_category_name'] = '';
		}
		return VIG_Bling_Product::upsert( $data, $balances );
	}

	public static function tick() {
		self::locked( function () {
			$job = get_option( self::JOB, array() );
			if ( ! VIG_Bling_API::connected() || 'running' !== ( $job['status'] ?? '' ) ) {
				wp_clear_scheduled_hook( self::WORK );
				return;
			}
			if ( $job['after'] > time() ) {
				return;
			}
			$deadline = microtime( true ) + 12;
			$changed = false;
			for ( $i = 0; $i < 12 && microtime( true ) < $deadline && 'running' === $job['status']; ++$i ) {
				if ( null === $job['queue'] && ! self::page( $job ) ) {
					break;
				}
				if ( $job['offset'] >= count( $job['queue'] ) ) {
					self::next_page( $job );
					update_option( self::JOB, $job, false );
					continue;
				}
				$row = $job['queue'][ $job['offset'] ];
				try {
					$result = self::item( $row, $job );
				} catch ( Throwable $e ) {
					$result = new WP_Error( 'bling_item', 'Não foi possível gravar o produto no WooCommerce. Confira o cadastro e o SKU.' );
				}
				if ( is_wp_error( $result ) ) {
					if ( self::retry( $job, $result ) ) {
						break;
					}
					self::issue( $job, $row['id'], $result );
				} elseif ( $result ) {
					++$job[ 4 === $job['phase'] ? 'retired' : 'imported' ];
					$changed = true;
				}
				++$job['offset'];
				$job['attempt'] = $job['after'] = 0;
				$job['message'] = '';
				update_option( self::JOB, $job, false );
			}
			update_option( self::JOB, $job, false );
			if ( $changed && function_exists( 'vi_cache_flush' ) ) {
				vi_cache_flush();
			}
		} );
	}

	private static function form_fields( $action ) {
		$action = 'vig_bling_' . $action;
		return wp_nonce_field( $action, '_wpnonce', true, false )
			. '<input type="hidden" name="action" value="' . esc_attr( $action ) . '">';
	}

	private static function form_button( $action, $label ) {
		return '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
			. self::form_fields( $action )
			. '<button type="submit" class="vig-btn"><span>' . esc_html( $label ) . '</span></button></form>';
	}

	public static function dashboard_action() {
		$label = __( 'Sincronizar Bling', 'villa-ibit-gestor' );
		$url   = admin_url( 'admin.php?page=' . self::PAGE );
		if ( ! VIG_Bling_API::connected() ) {
			return VIG_Admin::btn( $label, $url, 'is-bling', 'sync', 'title="' . esc_attr__( 'Conectar a conta do Bling', 'villa-ibit-gestor' ) . '"' );
		}
		$job = get_option( self::JOB, array() );
		if ( 'running' === ( $job['status'] ?? '' ) ) {
			return VIG_Admin::btn( $label, $url . '#vig-bling-andamento', 'is-bling', 'sync', 'title="' . esc_attr__( 'Acompanhar a sincronização em andamento', 'villa-ibit-gestor' ) . '"' );
		}
		return '<button type="submit" form="vig-dashboard-bling" class="vig-btn is-bling">' . VIG_Admin::icon( 'sync', 16 ) . '<span>' . esc_html( $label ) . '</span></button>'
			. '<form id="vig-dashboard-bling" hidden method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
			. self::form_fields( 'sync' ) . '</form>';
	}

	public static function render() {
		if ( ! current_user_can( VIG_Admin::CAP ) ) {
			wp_die( 'Sem permissão.' );
		}
		$app = get_option( VIG_Bling_API::APP, array() );
		$job = get_option( self::JOB, array() );
		$connected = VIG_Bling_API::connected();
		VIG_Admin::header( self::PAGE, 'Bling', '', 'Importe e atualize o catálogo do Bling no WooCommerce.' );
		?>
		<form class="vig-card vig-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<h2 class="vig-h2">Aplicativo do Bling</h2>
			<p>No Bling, cadastre o aplicativo com leitura de produtos, categorias de produtos e estoques. Copie este endereço para o campo de redirecionamento do aplicativo.</p>
			<div class="vig-field"><label for="vig-bling-callback">URL de redirecionamento</label>
				<input id="vig-bling-callback" type="text" readonly value="<?php echo esc_attr( admin_url( 'admin-post.php?action=vig_bling_callback' ) ); ?>"></div>
			<div class="vig-grid2">
				<div class="vig-field"><label for="vig-bling-id">Client ID</label><input id="vig-bling-id" name="client_id" required value="<?php echo esc_attr( $app['client_id'] ?? '' ); ?>"></div>
				<div class="vig-field"><label for="vig-bling-secret">Client Secret</label><input id="vig-bling-secret" name="client_secret" type="password" autocomplete="new-password"<?php echo empty( $app['secret'] ) ? ' required' : ''; ?> placeholder="<?php echo empty( $app['secret'] ) ? '' : 'Já salvo. Preencha apenas para trocar.'; ?>"></div>
			</div>
			<p><label><input type="checkbox" name="automatic" value="1" <?php checked( ! isset( $app['automatic'] ) || ! empty( $app['automatic'] ) ); ?>> Sincronizar ao conectar e repetir a cada hora.</label></p>
			<?php wp_nonce_field( 'vig_bling_save' ); ?>
			<input type="hidden" name="action" value="vig_bling_save"><button class="vig-btn is-primary">Salvar configuração</button>
		</form>
		<section class="vig-card vig-form"><h2 class="vig-h2">Catálogo</h2>
			<p><?php echo $connected ? 'Conta conectada.' : 'Conta desconectada.'; ?> O Bling fornece os dados dos produtos. O vínculo usa o ID do Bling e, no primeiro encontro, o SKU compatível. Cadastros ativos entram na vitrine. Itens inativos ficam em rascunho e itens excluídos saem da venda se já estiverem vinculados.</p>
			<?php if ( ! empty( $app['client_id'] ) ) : ?>
				<div style="display:flex;flex-wrap:wrap;gap:.6rem">
				<?php echo self::form_button( 'connect', $connected ? 'Reconectar ao Bling' : 'Conectar ao Bling' ); ?>
				<?php if ( $connected ) : ?>
					<?php echo self::form_button( 'sync', 'Sincronizar agora' ); ?>
					<?php echo self::form_button( 'disconnect', 'Desconectar' ); ?>
				<?php endif; ?>
				</div>
			<?php endif; ?>
			<p>O saldo disponível é atualizado quando muda no Bling. Uma conferência com o mesmo saldo preserva as baixas de estoque por vendas na loja. Esta integração lê o catálogo do Bling. Os pedidos do WooCommerce seguem na loja.</p>
			<p class="vig-help">O WordPress processa o catálogo em lotes pelo WP-Cron. Em lojas com pouco tráfego, configure o cron da hospedagem para executar os eventos do WordPress.</p>
		</section>
		<?php if ( $job ) : ?>
			<section id="vig-bling-andamento" class="vig-card vig-form"><h2 class="vig-h2">Andamento da última sincronização</h2>
			<?php
			$labels = array( 'running' => 'Em andamento', 'paused' => 'Pausada', 'done' => 'Concluída' );
			$phase = array( 2 => 'ativos', 3 => 'inativos', 4 => 'excluídos' );
			echo '<p><strong>' . esc_html( $labels[ $job['status'] ] ) . '</strong> · ' . esc_html( wp_date( 'd/m/Y H:i', $job['finished'] ?: $job['started'] ) ) . '</p>';
			echo '<p>' . (int) $job['imported'] . ' processado(s), ' . (int) $job['retired'] . ' retirado(s) de venda, ' . (int) $job['failures'] . ' com erro.</p>';
			if ( 'done' !== $job['status'] ) {
				echo '<p>Página ' . (int) $job['page'] . ' de itens ' . esc_html( $phase[ $job['phase'] ] ) . '. Atualize esta tela para acompanhar.</p>';
			}
			foreach ( array_filter( array_merge( array( $job['message'], $job['category_warning'], $job['stock_warning'] ?? '' ), $job['recent'] ) ) as $message ) {
				echo '<p>' . esc_html( $message ) . '</p>';
			}
			if ( $job['after'] > time() ) {
				echo '<p>Próxima tentativa a partir de ' . esc_html( wp_date( 'd/m/Y H:i', $job['after'] ) ) . '.</p>';
			}
			?>
			</section>
		<?php endif; ?>
		<?php
		VIG_Admin::footer();
	}
}
