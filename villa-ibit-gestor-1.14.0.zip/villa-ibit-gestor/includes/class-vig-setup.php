<?php
/**
 * Configurar loja: páginas montadas no Elementor, menus, Brasil/R$, produtos de demonstração.
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;

class VIG_Setup {

	const OPT = 'vig_setup';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ), 20 );
		foreach ( array( 'all', 'pages', 'design', 'demo', 'remove_demo' ) as $action ) {
			add_action( 'admin_post_vig_setup_' . $action, array( __CLASS__, 'handle' ) );
		}
	}

	public static function menu() {
		add_submenu_page( 'vi-gestor', 'Configuração da loja', 'Configurar loja', 'manage_options', 'vi-gestor-setup', array( __CLASS__, 'render' ) );
	}

	/** Uma loja com sinais de operação nunca pode ser reconfigurada pelo instalador de demonstração. */
	public static function existing_store_signals() {
		global $wpdb;
		$signals = array();
		$state   = get_option( self::OPT, array() );
		if ( get_option( 'vig_new_store_started' ) || ! empty( $state['done'] ) || ! empty( $state['started'] ) || ! empty( $state['pages'] ) ) {
			$signals[] = 'Configuração Villa Ibit já iniciada';
		}
		// Inclui rascunhos, itens na lixeira, variações e cupons.
		$catalog = $wpdb->get_var( "SELECT ID FROM {$wpdb->posts} WHERE post_type IN ('product','product_variation','shop_coupon') LIMIT 1" );
		if ( $wpdb->last_error ) {
			throw new RuntimeException( 'Não foi possível consultar o catálogo.' );
		}
		if ( $catalog ) {
			$signals[] = 'Catálogo ou cupons cadastrados';
		}
		$orders = wc_get_orders( array( 'type' => array( 'shop_order', 'shop_order_refund' ), 'status' => array_unique( array_merge( array_keys( wc_get_order_statuses() ), array( 'trash', 'wc-checkout-draft' ) ) ), 'limit' => 1, 'return' => 'ids' ) );
		if ( $wpdb->last_error ) {
			throw new RuntimeException( 'Não foi possível consultar os pedidos.' );
		}
		if ( $orders ) {
			$signals[] = 'Pedidos ou reembolsos registrados';
		}
		if ( get_users( array( 'role__in' => array( 'customer', 'subscriber' ), 'number' => 1, 'fields' => 'ID', 'count_total' => false ) ) ) {
			$signals[] = 'Clientes cadastrados';
		}

		if ( self::has_existing_pages() ) {
			$signals[] = 'Páginas ou navegação em uso';
		}
		foreach ( WC()->payment_gateways()->payment_gateways() as $gateway ) {
			$settings = get_option( $gateway->get_option_key(), array() );
			// Uma conta desativada também pode conter credenciais ou instruções já personalizadas.
			$custom = false;
			$fields = $gateway->get_form_fields();
			foreach ( (array) $settings as $key => $value ) {
				$default = $fields[ $key ]['default'] ?? '';
				if ( $value !== $default && ( ! is_scalar( $value ) || ! is_scalar( $default ) || (string) $value !== (string) $default ) ) {
					$custom = true;
					break;
				}
			}
			if ( 'yes' === $gateway->enabled || $custom || ! in_array( $gateway->id, array( 'bacs', 'cheque', 'cod', 'paypal' ), true ) ) {
				$signals[] = 'Meios de pagamento instalados ou configurados';
				break;
			}
		}
		if ( get_option( 'woocommerce_bacs_accounts' ) || get_option( 'woocommerce_store_address' ) || get_option( 'woocommerce_store_postcode' ) ) {
			$signals[] = 'Dados bancários ou endereço da loja configurados';
		}
		if ( WC_Shipping_Zones::get_zones() || ( new WC_Shipping_Zone( 0 ) )->get_shipping_methods() ) {
			$signals[] = 'Zonas ou métodos de entrega configurados';
		}
		$kit = (int) get_option( 'elementor_active_kit' );
		if ( $kit && get_post_meta( $kit, '_elementor_page_settings', true ) ) {
			$signals[] = 'Kit global do Elementor já configurado';
		}
		$plugins = array_merge( (array) get_option( 'active_plugins', array() ), array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
		$base = array( 'woocommerce/woocommerce.php', 'elementor/elementor.php', 'elementor-pro/elementor-pro.php', plugin_basename( VIG_FILE ), 'villa-ibit-visual/villa-ibit-visual.php', 'sqlite-database-integration/load.php' );
		if ( array_diff( $plugins, $base ) ) {
			$signals[] = 'Outras extensões ativas';
		}
		if ( $wpdb->last_error ) {
			throw new RuntimeException( 'Não foi possível verificar a instalação.' );
		}
		return $signals;
	}

	private static function has_existing_pages() {
		if ( get_option( 'page_on_front' ) || get_option( 'page_for_posts' ) || get_option( 'woocommerce_terms_page_id' ) || wp_get_nav_menus() ) {
			return true;
		}
		$core = array();
		foreach ( array( 'shop', 'cart', 'checkout', 'myaccount' ) as $role ) {
			$id = wc_get_page_id( $role );
			if ( $id <= 0 ) {
				continue;
			}
			$post = get_post( $id );
			$template = get_post_meta( $id, '_wp_page_template', true );
			if ( ! $post || 'page' !== $post->post_type || 'publish' !== $post->post_status || get_post_meta( $id, '_elementor_edit_mode', true ) || ( $template && 'default' !== $template ) ) {
				return true;
			}
			$content = trim( $post->post_content );
			if ( 'shop' === $role ) {
				$standard = '' === $content;
			} else {
				$tag      = 'myaccount' === $role ? 'woocommerce_my_account' : 'woocommerce_' . $role;
				$blocks   = array_values( array_filter( parse_blocks( $content ), static function ( $block ) {
					return $block['blockName'] || '' !== trim( $block['innerHTML'] );
				} ) );
				$standard = '[' . $tag . ']' === $content || ( 1 === count( $blocks ) && (
					'core/shortcode' === $blocks[0]['blockName'] && '[' . $tag . ']' === trim( $blocks[0]['innerHTML'] )
					|| 'woocommerce/' . $role === $blocks[0]['blockName']
				) );
			}
			if ( ! $standard ) {
				return true;
			}
			$core[] = $id;
		}
		// A página de exemplo padrão existe numa instalação nova de WordPress.
		$sample = get_post( 2 );
		if ( $sample && 'page' === $sample->post_type && in_array( $sample->post_name, array( 'sample-page', sanitize_title( __( 'Sample Page' ) ) ), true ) ) {
			$core[] = 2;
		}
		return (bool) get_posts( array( 'post_type' => array( 'page', 'wp_navigation' ), 'post_status' => array( 'publish', 'private', 'future' ), 'post__not_in' => $core, 'numberposts' => 1, 'fields' => 'ids' ) );
	}

	/** Executada somente no painel e no POST do instalador, sem gravar nada. */
	public static function barriers() {
		try {
			return self::existing_store_signals();
		} catch ( Throwable $error ) {
			return array( 'Diagnóstico indisponível. A criação da loja vazia está bloqueada.' );
		}
	}

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Sem permissão.', '', array( 'response' => 403 ) );
		}
		$barriers = self::barriers();
		VIG_Admin::header( 'vi-gestor-setup', 'Configuração da loja' );
		if ( isset( $_GET['done'] ) ) {
			echo '<div class="notice notice-success"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['done'] ) ) ) . '</p></div>';
		}
		?>
		<section class="vig-card">
			<h2 class="vig-h2">Loja existente</h2>
			<p>Continue usando o cadastro, os pedidos, o checkout e as integrações que já operam na loja. Para aplicar a home ou o carrinho, use o instalador de visual.</p>
			<?php if ( class_exists( 'VIV_Admin' ) ) : ?>
				<a class="vig-btn is-primary" href="<?php echo esc_url( admin_url( 'tools.php?page=villa-ibit-visual' ) ); ?>">Configurar o visual das páginas</a>
			<?php else : ?>
				<p>Instale <strong>villa-ibit-visual.zip</strong> e abra <strong>Ferramentas &gt; Visual Villa Ibit</strong>.</p>
			<?php endif; ?>
			<?php if ( $barriers ) : ?>
				<h3>Por que o instalador de demonstração está bloqueado</h3>
				<ul><?php foreach ( $barriers as $reason ) : ?><li><?php echo esc_html( $reason ); ?></li><?php endforeach; ?></ul>
			<?php endif; ?>
		</section>
		<?php if ( ! $barriers ) : ?>
			<details class="vig-card"><summary><strong>Configurar uma loja nova e vazia</strong></summary>
				<p>Esta ação cria as páginas e menus Villa Ibit, usa Brasil e Real e configura o kit do Elementor se ainda não tiver personalizações. As páginas WooCommerce já atribuídas continuam com seus conteúdos e URLs originais.</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<?php wp_nonce_field( 'vig_setup_all' ); ?>
					<input type="hidden" name="action" value="vig_setup_all">
					<p><label><input type="checkbox" name="include_demo" value="1"> Adicionar catálogo e conteúdo de demonstração</label></p>
					<p><label><input type="checkbox" name="include_test_methods" value="1"> Criar PIX manual de demonstração</label></p>
					<p><label><input type="checkbox" name="new_store" value="1" required> Esta é uma instalação vazia e quero criar a loja Villa Ibit.</label></p>
					<button class="button button-primary">Configurar loja vazia</button>
				</form>
			</details>
		<?php endif;
		VIG_Admin::footer();
	}

	public static function handle() {
		$action = isset( $_POST['action'] ) ? sanitize_key( wp_unslash( $_POST['action'] ) ) : '';
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Sem permissão.', '', array( 'response' => 403 ) );
		}
		check_admin_referer( $action );
		if ( 'vig_setup_all' !== $action || '1' !== ( $_POST['new_store'] ?? '' ) ) {
			wp_die( 'Use a tela Configurar loja. As ações antigas de substituição foram encerradas.', '', array( 'response' => 409 ) );
		}
		$barriers = self::barriers();
		if ( $barriers ) {
			wp_die( esc_html( 'Configuração bloqueada: ' . implode( '. ', $barriers ) ), '', array( 'response' => 409 ) );
		}
		// A restrição única impede duas execuções, mesmo se a segunda chegar antes do primeiro commit.
		// O marcador sobrevive a uma interrupção; não voltamos a executar a instalação às cegas.
		global $wpdb;
		$claimed = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s,%s,'no')", 'vig_new_store_started', (string) time() ) );
		if ( 1 !== $claimed ) {
			wp_die( 'A configuração desta loja já foi iniciada. Abra o painel para conferir o resultado.', '', array( 'response' => 409 ) );
		}
		wp_cache_delete( 'notoptions', 'options' );
		$state            = (array) get_option( self::OPT, array() );
		$state['started'] = time();
		update_option( self::OPT, $state, false );

		self::store_settings();
		$kit = (int) get_option( 'elementor_active_kit' );
		if ( $kit && ! get_post_meta( $kit, '_elementor_page_settings', true ) ) {
			self::elementor_kit();
		}
		if ( '1' === ( $_POST['include_demo'] ?? '' ) ) {
			wp_defer_term_counting( true );
			try {
				self::demo();
			} finally {
				wp_defer_term_counting( false );
			}
		}
		self::ensure_combos();
		self::pages();
		self::menus();
		if ( '1' === ( $_POST['include_test_methods'] ?? '' ) ) {
			self::shipping_payment();
		}
		$state         = (array) get_option( self::OPT, array() );
		$state['done'] = time();
		update_option( self::OPT, $state, false );
		self::clear_elementor_css();
		update_option( 'woocommerce_queue_flush_rewrite_rules', 'yes' );
		wp_safe_redirect( add_query_arg( array( 'page' => 'vi-gestor-setup', 'done' => 'Configuração da loja vazia concluída.' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/* ================================================================ *
	 * Configurações do WooCommerce (Brasil)
	 * ================================================================ */
	public static function store_settings() {
		$set = array(
			'woocommerce_currency'                         => 'BRL',
			'woocommerce_currency_pos'                     => 'left_space',
			'woocommerce_price_thousand_sep'               => '.',
			'woocommerce_price_decimal_sep'                => ',',
			'woocommerce_price_num_decimals'               => 2,
			'woocommerce_default_country'                  => 'BR:MG',
			'woocommerce_allowed_countries'                => 'specific',
			'woocommerce_specific_allowed_countries'       => array( 'BR' ),
			'woocommerce_ship_to_countries'                => '',
			'woocommerce_enable_reviews'                   => 'yes',
			'woocommerce_review_rating_verification_label' => 'yes',
			'woocommerce_enable_review_rating'             => 'yes',
			'woocommerce_enable_myaccount_registration'    => 'yes',
			'woocommerce_enable_checkout_login_reminder'   => 'yes',
			'woocommerce_enable_signup_and_login_from_checkout' => 'yes',
			'woocommerce_registration_generate_password'   => 'no',
			'woocommerce_enable_ajax_add_to_cart'          => 'yes',
			'woocommerce_weight_unit'                      => 'kg',
			'woocommerce_dimension_unit'                   => 'cm',
			'woocommerce_manage_stock'                     => 'yes',
		);
		foreach ( $set as $k => $v ) {
			update_option( $k, $v );
		}
		if ( ! get_option( 'timezone_string' ) ) {
			update_option( 'timezone_string', 'America/Sao_Paulo' );
		}
		update_option( 'elementor_disable_color_schemes', 'yes' );
		update_option( 'elementor_disable_typography_schemes', 'yes' );
	}

	/**
	 * Cores, fontes e largura no "Kit" do Elementor.
	 */
	public static function elementor_kit() {
		$kit = (int) get_option( 'elementor_active_kit' );
		if ( ! $kit ) {
			return;
		}
		$s = get_post_meta( $kit, '_elementor_page_settings', true );
		$s = is_array( $s ) ? $s : array();
		$s['system_colors']     = array(
			array( '_id' => 'primary', 'title' => 'Verde Villa', 'color' => '#034D43' ),
			array( '_id' => 'secondary', 'title' => 'Dourado', 'color' => '#FFD695' ),
			array( '_id' => 'text', 'title' => 'Texto', 'color' => '#10201D' ),
			array( '_id' => 'accent', 'title' => 'Oferta', 'color' => '#B42318' ),
		);
		$s['custom_colors']     = array(
			array( '_id' => 'vi_forest', 'title' => 'Verde floresta', 'color' => '#022C26' ),
			array( '_id' => 'vi_goldbg', 'title' => 'Dourado claro', 'color' => '#FFF3DC' ),
			array( '_id' => 'vi_bg', 'title' => 'Fundo', 'color' => '#F4F9F6' ),
			array( '_id' => 'vi_mint', 'title' => 'Verde-menta', 'color' => '#E6F2EC' ),
			array( '_id' => 'vi_muted', 'title' => 'Texto secundário', 'color' => '#55655F' ),
		);
		$s['system_typography'] = array(
			array( '_id' => 'primary', 'title' => 'Títulos', 'typography_typography' => 'custom', 'typography_font_family' => 'Sora', 'typography_font_weight' => '700' ),
			array( '_id' => 'secondary', 'title' => 'Subtítulos', 'typography_typography' => 'custom', 'typography_font_family' => 'DM Sans', 'typography_font_weight' => '700' ),
			array( '_id' => 'text', 'title' => 'Texto', 'typography_typography' => 'custom', 'typography_font_family' => 'DM Sans', 'typography_font_weight' => '400' ),
			array( '_id' => 'accent', 'title' => 'Botões', 'typography_typography' => 'custom', 'typography_font_family' => 'DM Sans', 'typography_font_weight' => '700' ),
		);
		$s['container_width']   = array( 'unit' => 'px', 'size' => 1328, 'sizes' => array() );
		$s['body_background_background'] = 'classic';
		$s['body_background_color']      = '#F4F9F6';
		update_post_meta( $kit, '_elementor_page_settings', $s );
	}

	/**
	 * Limpa o CSS gerado pelo Elementor (para as novas cores e fontes aparecerem).
	 */
	public static function clear_elementor_css() {
		if ( did_action( 'elementor/loaded' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
			\Elementor\Plugin::$instance->files_manager->clear_cache();
		}
	}

	/**
	 * Ao atualizar o plugin: se o Elementor ainda usa as fontes antigas que a configuração colocou,
	 * troca pelas novas (Sora e DM Sans) e pelo fundo verde-menta. Personalizações feitas à mão são mantidas.
	 */
	public static function migrate_kit() {
		$kit = (int) get_option( 'elementor_active_kit' );
		if ( ! $kit ) {
			return;
		}
		$s = get_post_meta( $kit, '_elementor_page_settings', true );
		if ( ! is_array( $s ) || empty( $s['system_typography'] ) ) {
			return;
		}
		$old = false;
		foreach ( (array) $s['system_typography'] as $t ) {
			if ( isset( $t['typography_font_family'] ) && in_array( $t['typography_font_family'], array( 'Bricolage Grotesque', 'Manrope' ), true ) ) {
				$old = true;
			}
		}
		if ( $old ) {
			self::elementor_kit();
			self::clear_elementor_css();
		}
	}

	/**
	 * Atualiza apenas cores do kit e imagens de banner distribuídas com o tema.
	 * O conteúdo, as fotos enviadas e os estilos escolhidos no painel são preservados.
	 */
	public static function migrate_claro_menta() {
		$kit = (int) get_option( 'elementor_active_kit' );
		if ( $kit ) {
			$settings = get_post_meta( $kit, '_elementor_page_settings', true );
			if ( is_array( $settings ) ) {
				$changed = false;
				foreach ( array( 'system_colors', 'custom_colors' ) as $group ) {
					foreach ( (array) ( $settings[ $group ] ?? array() ) as $i => $entry ) {
						$id    = $entry['_id'] ?? '';
						$color = strtoupper( (string) ( $entry['color'] ?? '' ) );
						if ( 'primary' === $id && '#023832' === $color ) {
							$settings[ $group ][ $i ]['color'] = '#034D43';
							$changed = true;
						} elseif ( 'vi_forest' === $id && '#011F1A' === $color ) {
							$settings[ $group ][ $i ]['color'] = '#022C26';
							$changed = true;
						}
					}
				}
				if ( $changed ) {
					update_post_meta( $kit, '_elementor_page_settings', $settings );
					self::clear_elementor_css();
				}
			}
		}
		$options = get_option( VIG_OPTION, array() );
		if ( empty( $options['slides'] ) || ! is_array( $options['slides'] ) ) {
			return;
		}
		$images = array(
			'banner-1-natureza.jpg' => array( 'banner-1-elfbar.jpg', 'verde' ),
			'banner-2-natureza.jpg' => array( 'banner-2-ignite.jpg', 'escuro' ),
			'banner-3-natureza.jpg' => array( 'banner-3-delivery.jpg', 'dourado' ),
		);
		$changed = false;
		foreach ( $options['slides'] as $i => $slide ) {
			$filename = $slide['image_def'] ?? '';
			if ( isset( $images[ $filename ] ) && empty( $slide['image_id'] ) && empty( $slide['image_url'] ) && 'natureza' === ( $slide['style'] ?? '' ) ) {
				list( $options['slides'][ $i ]['image_def'], $options['slides'][ $i ]['style'] ) = $images[ $filename ];
				$changed = true;
			}
		}
		if ( $changed ) {
			update_option( VIG_OPTION, $options );
		}
	}

	/**
	 * Versão 1.6.3: verde um pouco mais escuro. Troca as cores antigas no kit do Elementor
	 * e nas páginas montadas pelo Configurar loja. Cores escolhidas à mão são mantidas.
	 */
	public static function migrate_163() {
		$map = array(
			'#034D43' => '#023832',
			'#0A6B5C' => '#075046',
			'#022C26' => '#011F1A',
		);
		$swap = function ( $v ) use ( $map ) {
			foreach ( $map as $old => $new ) {
				$v = str_ireplace( $old, $new, $v );
			}
			return $v;
		};

		$kit = (int) get_option( 'elementor_active_kit' );
		if ( $kit ) {
			$s = get_post_meta( $kit, '_elementor_page_settings', true );
			if ( is_array( $s ) ) {
				$hit = false;
				foreach ( array( 'system_colors', 'custom_colors' ) as $group ) {
					if ( empty( $s[ $group ] ) || ! is_array( $s[ $group ] ) ) {
						continue;
					}
					foreach ( $s[ $group ] as $i => $c ) {
						if ( isset( $c['color'] ) ) {
							$new = $swap( $c['color'] );
							if ( $new !== $c['color'] ) {
								$s[ $group ][ $i ]['color'] = $new;
								$hit                        = true;
							}
						}
					}
				}
				if ( $hit ) {
					update_post_meta( $kit, '_elementor_page_settings', $s );
				}
			}
		}

		$state = get_option( self::OPT, array() );
		$ids   = array( (int) get_option( 'page_on_front' ) );
		if ( ! empty( $state['pages'] ) && is_array( $state['pages'] ) ) {
			$ids = array_merge( $ids, array_map( 'intval', $state['pages'] ) );
		}
		foreach ( array_unique( array_filter( $ids ) ) as $id ) {
			$raw = get_post_meta( $id, '_elementor_data', true );
			if ( ! is_string( $raw ) || '' === $raw ) {
				continue;
			}
			$new = $swap( $raw );
			if ( $new !== $raw ) {
				update_post_meta( $id, '_elementor_data', wp_slash( $new ) );
				delete_post_meta( $id, '_elementor_css' );
			}
		}
		self::clear_elementor_css();
	}

	/**
	 * Versão 1.6.2: a faixa de destaques passa a se chamar "Novidades" (sem etiqueta e sem texto)
	 * e o pop-up 18+ fica desligado. Textos trocados à mão são mantidos.
	 */
	public static function migrate_162() {
		$old_title = 'Destaques do mês';
		$old_text  = 'Selecionados pela Villa: ofertas especiais e queima de estoque.';

		$opts = get_option( VIG_OPTION, array() );
		$opts = is_array( $opts ) ? $opts : array();
		// A verificação de idade é uma escolha explícita da loja.
		if ( isset( $opts['featured_title'] ) && $old_title === $opts['featured_title'] ) {
			$opts['featured_title'] = 'Novidades';
		}
		if ( isset( $opts['featured_text'] ) && $old_text === $opts['featured_text'] ) {
			$opts['featured_text'] = '';
		}
		update_option( VIG_OPTION, $opts );

		$state = get_option( self::OPT, array() );
		$ids   = array( (int) get_option( 'page_on_front' ) );
		if ( ! empty( $state['pages']['inicio'] ) ) {
			$ids[] = (int) $state['pages']['inicio'];
		}
		$changed = false;
		foreach ( array_unique( array_filter( $ids ) ) as $id ) {
			$raw  = get_post_meta( $id, '_elementor_data', true );
			$data = is_string( $raw ) && '' !== $raw ? json_decode( $raw, true ) : ( is_array( $raw ) ? $raw : null );
			if ( ! is_array( $data ) ) {
				continue;
			}
			$hit  = false;
			$data = self::fix_featured_widget( $data, $old_title, $old_text, $hit );
			if ( $hit ) {
				update_post_meta( $id, '_elementor_data', wp_slash( wp_json_encode( $data ) ) );
				delete_post_meta( $id, '_elementor_css' );
				$changed = true;
			}
		}
		if ( $changed ) {
			self::clear_elementor_css();
		}
	}

	/**
	 * Categoria "Combos" (aba Combos do menu e cartão Combos especiais da home).
	 */
	public static function ensure_combos() {
		if ( ! taxonomy_exists( 'product_cat' ) || get_term_by( 'slug', 'combos', 'product_cat' ) ) {
			return;
		}
		wp_insert_term( 'Combos', 'product_cat', array( 'slug' => 'combos', 'description' => 'Kits e combos promocionais.' ) );
	}

	/**
	 * Versão 1.7.0: visual natureza (fotos reais, menu de abas, nova home).
	 * - Seções da home seguem a ordem pedida pelo cliente (as antigas ficam desligadas, dá para religar).
	 * - Slides com as imagens padrão antigas passam para as fotos de montanha (estilo Natureza).
	 * - Página Início do Elementor: se só tem widgets Villa Ibit, é remontada no novo layout
	 *   (os slides editados no Elementor são mantidos). O conteúdo anterior fica guardado em _vig_backup_170.
	 */
	public static function migrate_170() {
		$img_map = array( 'banner-1-elfbar.jpg' => 'banner-1-natureza.jpg', 'banner-2-ignite.jpg' => 'banner-2-natureza.jpg', 'banner-3-delivery.jpg' => 'banner-3-natureza.jpg' );

		$opts = get_option( VIG_OPTION, array() );
		$opts = is_array( $opts ) ? $opts : array();
		if ( isset( $opts['sections'] ) && is_array( $opts['sections'] ) ) {
			foreach ( array( 'featured', 'tabs', 'spotlight', 'deals', 'extra', 'brands', 'reviews', 'blog', 'social' ) as $k ) {
				$opts['sections'][ $k ] = 0;
			}
			foreach ( array( 'categories', 'novidades', 'promos', 'duo', 'wholesale' ) as $k ) {
				$opts['sections'][ $k ] = 1;
			}
		}
		if ( ! empty( $opts['slides'] ) && is_array( $opts['slides'] ) ) {
			foreach ( $opts['slides'] as $i => $sl ) {
				if ( empty( $sl['image_id'] ) && isset( $sl['image_def'], $img_map[ $sl['image_def'] ] ) ) {
					$opts['slides'][ $i ]['image_def'] = $img_map[ $sl['image_def'] ];
					$opts['slides'][ $i ]['style']     = 'natureza';
				}
			}
		}
		$old = array( 'wholesale_title' => array( 'Quer comprar no atacado?', 'Compre no atacado' ), 'wholesale_text' => array( 'Condições especiais para lojistas, distribuidores e revendedores.', 'Misture marcas e sabores com condições especiais para lojistas e revendedores.' ) );
		foreach ( $old as $k => $pair ) {
			if ( isset( $opts[ $k ] ) && $pair[0] === $opts[ $k ] ) {
				$opts[ $k ] = $pair[1];
			}
		}
		update_option( VIG_OPTION, $opts );

		self::ensure_combos();

		$state = get_option( self::OPT, array() );
		$ids   = array( (int) get_option( 'page_on_front' ) );
		if ( ! empty( $state['pages']['inicio'] ) ) {
			$ids[] = (int) $state['pages']['inicio'];
		}
		$changed = false;
		foreach ( array_unique( array_filter( $ids ) ) as $id ) {
			$raw  = get_post_meta( $id, '_elementor_data', true );
			$data = is_string( $raw ) && '' !== $raw ? json_decode( $raw, true ) : ( is_array( $raw ) ? $raw : null );
			if ( ! is_array( $data ) ) {
				continue;
			}
			$types  = array();
			$banner = null;
			self::collect_widgets( $data, $types, $banner );
			if ( ! $types ) {
				continue;
			}
			if ( $banner ) {
				$banner = self::banner_to_natureza( $banner, $img_map );
			}
			$only_ours = ! array_filter( $types, function ( $t ) { return 0 !== strpos( $t, 'vi-' ); } );
			if ( $only_ours && class_exists( 'VIG_Layouts' ) ) {
				$pages = VIG_Layouts::pages();
				$new   = json_decode( wp_json_encode( $pages['inicio']['data'] ), true );
				if ( $banner ) {
					foreach ( $new as $c => $cont ) {
						foreach ( (array) ( $cont['elements'] ?? array() ) as $w => $el ) {
							if ( isset( $el['widgetType'] ) && 'vi-banner' === $el['widgetType'] ) {
								$new[ $c ]['elements'][ $w ] = $banner;
							}
						}
					}
				}
				if ( '' === (string) get_post_meta( $id, '_vig_backup_170', true ) ) {
					update_post_meta( $id, '_vig_backup_170', wp_slash( is_string( $raw ) ? $raw : wp_json_encode( $raw ) ) );
				}
				$data = $new;
			} elseif ( $banner ) {
				$data = self::replace_banner( $data, $banner );
			} else {
				continue;
			}
			update_post_meta( $id, '_elementor_data', wp_slash( wp_json_encode( $data ) ) );
			delete_post_meta( $id, '_elementor_css' );
			$changed = true;
		}
		self::clear_elementor_css();
		return $changed;
	}

	/**
	 * Versão 1.7.1: Novidades da home na faixa amarela com folhas de palmeira.
	 * Na Início do Elementor, a vitrine "Novidades" em grade passa para a faixa (5 produtos).
	 */
	public static function migrate_171() {
		$state = get_option( self::OPT, array() );
		$ids   = array( (int) get_option( 'page_on_front' ) );
		if ( ! empty( $state['pages']['inicio'] ) ) {
			$ids[] = (int) $state['pages']['inicio'];
		}
		$changed = false;
		foreach ( array_unique( array_filter( $ids ) ) as $id ) {
			$raw  = get_post_meta( $id, '_elementor_data', true );
			$data = is_string( $raw ) && '' !== $raw ? json_decode( $raw, true ) : ( is_array( $raw ) ? $raw : null );
			if ( ! is_array( $data ) ) {
				continue;
			}
			$hit  = false;
			$data = self::novidades_to_band( $data, $hit );
			if ( $hit ) {
				update_post_meta( $id, '_elementor_data', wp_slash( wp_json_encode( $data ) ) );
				delete_post_meta( $id, '_elementor_css' );
				$changed = true;
			}
		}
		if ( $changed ) {
			self::clear_elementor_css();
		}
		return $changed;
	}

	private static function novidades_to_band( array $els, &$hit ) {
		foreach ( $els as $i => $el ) {
			if ( ! is_array( $el ) ) {
				continue;
			}
			if ( isset( $el['widgetType'] ) && 'vi-vitrine' === $el['widgetType'] && 'novidades' === ( $el['settings']['source'] ?? '' ) && 'light' === ( $el['settings']['style'] ?? '' ) ) {
				$els[ $i ]['settings']['style']   = 'band';
				$els[ $i ]['settings']['limit']   = 5;
				$els[ $i ]['settings']['columns'] = '5';
				$els[ $i ]['settings']['badge']   = '';
				$hit                              = true;
			}
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
				$els[ $i ]['elements'] = self::novidades_to_band( $el['elements'], $hit );
			}
		}
		return $els;
	}

	/**
	 * Versão 1.7.2: a faixa Novidades desliza para o lado. Na Início do Elementor, ela passa de 5 para 12 produtos.
	 */
	public static function migrate_172() {
		$state = get_option( self::OPT, array() );
		$ids   = array( (int) get_option( 'page_on_front' ) );
		if ( ! empty( $state['pages']['inicio'] ) ) {
			$ids[] = (int) $state['pages']['inicio'];
		}
		$changed = false;
		foreach ( array_unique( array_filter( $ids ) ) as $id ) {
			$raw  = get_post_meta( $id, '_elementor_data', true );
			$data = is_string( $raw ) && '' !== $raw ? json_decode( $raw, true ) : ( is_array( $raw ) ? $raw : null );
			if ( ! is_array( $data ) ) {
				continue;
			}
			$hit  = false;
			$data = self::novidades_more( $data, $hit );
			if ( $hit ) {
				update_post_meta( $id, '_elementor_data', wp_slash( wp_json_encode( $data ) ) );
				delete_post_meta( $id, '_elementor_css' );
				$changed = true;
			}
		}
		if ( $changed ) {
			self::clear_elementor_css();
		}
		return $changed;
	}

	private static function novidades_more( array $els, &$hit ) {
		foreach ( $els as $i => $el ) {
			if ( ! is_array( $el ) ) {
				continue;
			}
			if ( isset( $el['widgetType'] ) && 'vi-vitrine' === $el['widgetType'] && 'novidades' === ( $el['settings']['source'] ?? '' ) && 'band' === ( $el['settings']['style'] ?? '' ) && (int) ( $el['settings']['limit'] ?? 0 ) <= 5 ) {
				$els[ $i ]['settings']['limit'] = 12;
				$hit                            = true;
			}
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
				$els[ $i ]['elements'] = self::novidades_more( $el['elements'], $hit );
			}
		}
		return $els;
	}

	/** Lista os tipos de widget da página e guarda o primeiro banner. */
	private static function collect_widgets( array $els, array &$types, &$banner ) {
		foreach ( $els as $el ) {
			if ( ! is_array( $el ) ) {
				continue;
			}
			if ( ! empty( $el['widgetType'] ) ) {
				$types[] = $el['widgetType'];
				if ( 'vi-banner' === $el['widgetType'] && null === $banner ) {
					$banner = $el;
				}
			}
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
				self::collect_widgets( $el['elements'], $types, $banner );
			}
		}
	}

	/** Slides do Elementor com as imagens padrão antigas passam para as fotos novas. */
	private static function banner_to_natureza( array $banner, array $img_map ) {
		if ( empty( $banner['settings']['slides'] ) || ! is_array( $banner['settings']['slides'] ) ) {
			return $banner;
		}
		foreach ( $banner['settings']['slides'] as $i => $sl ) {
			$url  = isset( $sl['image']['url'] ) ? (string) $sl['image']['url'] : '';
			$file = basename( (string) wp_parse_url( $url, PHP_URL_PATH ) );
			if ( empty( $sl['image']['id'] ) && isset( $img_map[ $file ] ) ) {
				$banner['settings']['slides'][ $i ]['image']['url'] = str_replace( $file, $img_map[ $file ], $url );
				$banner['settings']['slides'][ $i ]['style']        = 'natureza';
			}
		}
		return $banner;
	}

	/** Troca o banner antigo pelo convertido, mantendo o resto da página. */
	private static function replace_banner( array $els, array $banner ) {
		foreach ( $els as $i => $el ) {
			if ( ! is_array( $el ) ) {
				continue;
			}
			if ( isset( $el['id'], $el['widgetType'] ) && 'vi-banner' === $el['widgetType'] && $el['id'] === $banner['id'] ) {
				$els[ $i ] = $banner;
			} elseif ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
				$els[ $i ]['elements'] = self::replace_banner( $el['elements'], $banner );
			}
		}
		return $els;
	}

	/**
	 * Percorre os elementos do Elementor e limpa os textos antigos da vitrine "destaques".
	 */
	private static function fix_featured_widget( array $els, $old_title, $old_text, &$hit ) {
		foreach ( $els as $i => $el ) {
			if ( ! is_array( $el ) ) {
				continue;
			}
			if ( isset( $el['widgetType'] ) && 'vi-vitrine' === $el['widgetType'] && isset( $el['settings']['source'] ) && 'destaques' === $el['settings']['source'] ) {
				$s = &$els[ $i ]['settings'];
				if ( isset( $s['eyebrow'] ) && 'Selecionados' === $s['eyebrow'] ) {
					$s['eyebrow'] = '';
					$hit          = true;
				}
				if ( isset( $s['title'] ) && $old_title === $s['title'] ) {
					$s['title'] = 'Novidades';
					$hit        = true;
				}
				if ( isset( $s['subtitle'] ) && $old_text === $s['subtitle'] ) {
					$s['subtitle'] = '';
					$hit           = true;
				}
				unset( $s );
			}
			if ( ! empty( $el['elements'] ) && is_array( $el['elements'] ) ) {
				$els[ $i ]['elements'] = self::fix_featured_widget( $el['elements'], $old_title, $old_text, $hit );
			}
		}
		return $els;
	}

	/* ================================================================ *
	 * Páginas
	 * ================================================================ */
	public static function pages( $only = null ) {
		$state = get_option( self::OPT, array() );
		$has_e = did_action( 'elementor/loaded' );
		$roles = array( 'shop' => 'shop', 'cart' => 'cart', 'checkout' => 'checkout', 'myaccount' => 'myaccount' );
		$ids   = array();

		foreach ( VIG_Layouts::pages() as $slug => $def ) {
			if ( is_array( $only ) && ! in_array( $slug, $only, true ) ) {
				continue;
			}
			// Nunca reutilize um ID para substituir conteúdo existente. O WooCommerce
			// pode ter criado carrinho, checkout e conta em blocos antes do Gestor.
			if ( isset( $roles[ $def['role'] ] ) ) {
				$assigned = (int) wc_get_page_id( $roles[ $def['role'] ] );
				if ( $assigned > 0 && get_post( $assigned ) ) {
					$ids[ $slug ] = $assigned;
					continue;
				}
			}
			if ( in_array( $def['role'], array( 'terms', 'privacy' ), true ) ) {
				$option   = 'terms' === $def['role'] ? 'woocommerce_terms_page_id' : 'wp_page_for_privacy_policy';
				$assigned = (int) get_option( $option );
				if ( $assigned > 0 && get_post( $assigned ) ) {
					$ids[ $slug ] = $assigned;
					continue;
				}
			}
			$args = array(
				'post_type'    => 'page',
				'post_title'   => $def['title'],
				'post_status'  => isset( $def['status'] ) ? $def['status'] : 'publish',
				'post_content' => $def['fallback'],
				'post_name'    => $slug,
			);
			$id = wp_insert_post( wp_slash( $args ) );
			if ( ! $id || is_wp_error( $id ) ) {
				continue;
			}
			$ids[ $slug ] = (int) $id;

			if ( $def['data'] ) {
				update_post_meta( $id, '_elementor_edit_mode', 'builder' );
				update_post_meta( $id, '_elementor_template_type', 'wp-page' );
				update_post_meta( $id, '_elementor_version', defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '3.0.0' );
				update_post_meta( $id, '_elementor_data', wp_slash( wp_json_encode( $def['data'] ) ) );
				update_post_meta( $id, '_elementor_page_settings', array( 'hide_title' => 'yes' ) );
				update_post_meta( $id, '_wp_page_template', $has_e ? 'elementor_header_footer' : 'default' );
				delete_post_meta( $id, '_elementor_css' );
				delete_post_meta( $id, '_elementor_element_cache' );
				delete_post_meta( $id, '_elementor_page_assets' );
			} else {
				foreach ( array( '_elementor_edit_mode', '_elementor_data' ) as $m ) {
					delete_post_meta( $id, $m );
				}
				update_post_meta( $id, '_wp_page_template', 'default' );
			}

			switch ( $def['role'] ) {
				case 'front':
					update_option( 'show_on_front', 'page' );
					update_option( 'page_on_front', $id );
					break;
				case 'posts':
					update_option( 'page_for_posts', $id );
					break;
				case 'shop':
				case 'cart':
				case 'checkout':
				case 'myaccount':
					update_option( 'woocommerce_' . $def['role'] . '_page_id', $id );
					break;
				case 'terms':
					update_option( 'woocommerce_terms_page_id', $id );
					break;
				case 'privacy':
					update_option( 'wp_page_for_privacy_policy', $id );
					break;
				case 'tpl_product':
					$opts                = get_option( VIG_OPTION, array() );
					$opts                = is_array( $opts ) ? $opts : array();
					$opts['tpl_product'] = $id;
					update_option( VIG_OPTION, $opts, true );
					break;
			}
		}
		$state['pages'] = array_merge( (array) ( $state['pages'] ?? array() ), $ids );
		update_option( self::OPT, $state, false );
	}

	/* ================================================================ *
	 * Menus
	 * ================================================================ */
	private static function new_menu( $name ) {
		$id = wp_create_nav_menu( $name );
		if ( is_wp_error( $id ) ) {
			wp_die( 'O menu já existe ou não pôde ser criado. Confira em Aparência > Menus.', '', array( 'response' => 409 ) );
		}
		return (int) $id;
	}

	private static function add_item( $menu, $args ) {
		return wp_update_nav_menu_item( $menu, 0, array_merge( array( 'menu-item-status' => 'publish' ), $args ) );
	}

	public static function menus() {
		$state = get_option( self::OPT, array() );
		$pages = isset( $state['pages'] ) ? (array) $state['pages'] : array();
		$page  = function ( $slug ) use ( $pages ) { return isset( $pages[ $slug ] ) ? (int) $pages[ $slug ] : 0; };
		$term  = function ( $slug ) { $t = get_term_by( 'slug', $slug, 'product_cat' ); return $t ? (int) $t->term_id : 0; };

		$main = self::new_menu( 'Villa Ibit — Principal' );
		// Nomes curtos: o menu fica numa linha só no topo, ao lado do logo.
		foreach ( array( 'pods-descartaveis' => 'Pods', 'pod-system' => 'Pod System', 'liquidos' => 'Líquidos' ) as $slug => $label ) {
			if ( $term( $slug ) ) {
				self::add_item( $main, array( 'menu-item-title' => $label, 'menu-item-object' => 'product_cat', 'menu-item-object-id' => $term( $slug ), 'menu-item-type' => 'taxonomy' ) );
			}
		}
		if ( $page( 'acessorios' ) ) {
			self::add_item( $main, array( 'menu-item-title' => 'Acessórios', 'menu-item-object' => 'page', 'menu-item-object-id' => $page( 'acessorios' ), 'menu-item-type' => 'post_type' ) );
		}
		self::add_item( $main, array( 'menu-item-title' => 'Ofertas', 'menu-item-url' => add_query_arg( 'ofertas', '1', get_permalink( wc_get_page_id( 'shop' ) ) ), 'menu-item-type' => 'custom', 'menu-item-classes' => 'vi-push vi-nav__item--sale' ) );
		if ( $term( 'atacado' ) ) {
			self::add_item( $main, array( 'menu-item-title' => 'Atacado', 'menu-item-object' => 'product_cat', 'menu-item-object-id' => $term( 'atacado' ), 'menu-item-type' => 'taxonomy', 'menu-item-classes' => 'vi-nav__item--pill' ) );
		}

		$foot = self::new_menu( 'Villa Ibit — Rodapé' );
		foreach ( array( 'perguntas-frequentes', 'trocas-e-devolucoes', 'politica-de-privacidade', 'termos-de-uso', 'entrar', 'blog' ) as $slug ) {
			if ( $page( $slug ) ) {
				self::add_item( $foot, array( 'menu-item-object' => 'page', 'menu-item-object-id' => $page( $slug ), 'menu-item-type' => 'post_type' ) );
			}
		}
		$loc              = (array) get_theme_mod( 'nav_menu_locations', array() );
		$loc['principal'] = $main;
		$loc['rodape']    = $foot;
		set_theme_mod( 'nav_menu_locations', $loc );
	}

	/* ================================================================ *
	 * Pagamento de demonstração. A loja define a cobertura e os serviços de entrega.
	 * ================================================================ */
	public static function shipping_payment() {
		$gateways = WC()->payment_gateways() ? WC()->payment_gateways()->payment_gateways() : array();
		$enabled  = array_filter( $gateways, function ( $g ) { return 'yes' === $g->enabled; } );
		if ( ! $enabled && ! get_option( 'woocommerce_bacs_settings' ) && ! get_option( 'woocommerce_bacs_accounts' ) ) {
			update_option(
				'woocommerce_bacs_settings',
				array(
					'enabled'      => 'yes',
					'title'        => 'PIX (manual)',
					'description'  => 'Após finalizar, você recebe a chave PIX e o valor com desconto. Envie o comprovante pelo WhatsApp.',
					'instructions' => 'Chave PIX: [sua chave]. Envie o comprovante pelo WhatsApp para liberarmos o pedido.',
				)
			);
			$opts                 = get_option( VIG_OPTION, array() );
			$opts                 = is_array( $opts ) ? $opts : array();
			$opts['pix_gateways'] = array_values( array_unique( array_merge( (array) ( $opts['pix_gateways'] ?? array() ), array( 'bacs' ) ) ) );
			$opts['pix_apply']    = 1;
			update_option( VIG_OPTION, $opts, true );
		}
	}

	/* ================================================================ *
	 * Demonstração
	 * ================================================================ */
	public static function demo_ids() {
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT p.ID, p.post_type FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key = '_vi_demo'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$out  = array( 'products' => array(), 'posts' => array(), 'attachments' => array() );
		foreach ( $rows as $r ) {
			if ( 'product' === $r->post_type ) {
				$out['products'][] = (int) $r->ID;
			} elseif ( 'attachment' === $r->post_type ) {
				$out['attachments'][] = (int) $r->ID;
			} elseif ( 'post' === $r->post_type ) {
				$out['posts'][] = (int) $r->ID;
			}
		}
		return $out;
	}

	private static function term( $name, $slug, $tax, $args = array() ) {
		$t = get_term_by( 'slug', $slug, $tax );
		if ( $t ) {
			return (int) $t->term_id;
		}
		$r = wp_insert_term( $name, $tax, array_merge( array( 'slug' => $slug ), $args ) );
		if ( is_wp_error( $r ) ) {
			return 0;
		}
		update_term_meta( $r['term_id'], '_vi_demo', 1 );
		return (int) $r['term_id'];
	}

	private static function image( $file ) {
		$found = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'meta_key' => '_vi_demo_file', 'meta_value' => $file, 'fields' => 'ids', 'numberposts' => 1 ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
		if ( $found ) {
			return (int) $found[0];
		}
		$path = VIG_DIR . 'demo/img/' . $file;
		if ( ! file_exists( $path ) ) {
			return 0;
		}
		$upload = wp_upload_bits( $file, null, file_get_contents( $path ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! empty( $upload['error'] ) ) {
			return 0;
		}
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$type = wp_check_filetype( $upload['file'] );
		$id   = wp_insert_attachment( array( 'post_mime_type' => $type['type'], 'post_title' => preg_replace( '/\.[^.]+$/', '', $file ), 'post_status' => 'inherit' ), $upload['file'] );
		if ( ! $id || is_wp_error( $id ) ) {
			return 0;
		}
		wp_update_attachment_metadata( $id, wp_generate_attachment_metadata( $id, $upload['file'] ) );
		update_post_meta( $id, '_vi_demo', 1 );
		update_post_meta( $id, '_vi_demo_file', $file );
		return (int) $id;
	}

	public static function demo() {
		$data = json_decode( (string) file_get_contents( VIG_DIR . 'demo/products.json' ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		if ( ! is_array( $data ) ) {
			return;
		}

		// Categorias (ordem = ordem na loja).
		$cats = array(
			'pods-descartaveis' => array( 'Pods Descartáveis', 'Mais de 100 sabores das melhores marcas. Prontos para usar, sem recarga de líquido.' ),
			'pod-system'        => array( 'Pod System', 'Aparelhos recarregáveis e kits de alta performance.' ),
			'liquidos'          => array( 'Líquidos', 'Nicsalt e juices importados.' ),
			'acessorios'        => array( 'Acessórios', 'Coils, cartuchos e reposição para o seu aparelho.' ),
			'atacado'           => array( 'Atacado', 'Condições especiais para lojistas, distribuidores e revendedores.' ),
		);
		$cat_ids = array();
		$order   = 0;
		foreach ( $cats as $slug => $c ) {
			$cat_ids[ $slug ] = self::term( $c[0], $slug, 'product_cat', array( 'description' => $c[1] ) );
			update_term_meta( $cat_ids[ $slug ], 'order', $order++ );
		}
		$coils = self::term( 'Coils e resistências', 'coils-resistencias', 'product_cat', array( 'parent' => $cat_ids['acessorios'] ) );

		$featured = array( 'Elf Bar BC Pro 45k', 'Ignite V500 50.000 Puffs', 'Elf Bar Ice King 40K', 'Vaporesso Xros 6 Mini' );
		$cat_img  = array();
		$created  = array();

		foreach ( $data as $i => $p ) {
			if ( wc_get_product_id_by_sku( $p['sku'] ) ) {
				continue;
			}
			$options  = ( ! empty( $p['attr'][1] ) ) ? array_values( array_unique( array_map( function ( $o ) { return trim( str_replace( '|', '/', $o ) ); }, (array) $p['attr'][1] ) ) ) : array();
			$variable = count( $options ) > 1;
			$product  = $variable ? new WC_Product_Variable() : new WC_Product_Simple();
			$brand    = $p['brand'];
			$product->set_name( $p['name'] );
			$product->set_status( 'publish' );
			$product->set_sku( $p['sku'] );
			$product->set_featured( in_array( $p['name'], $featured, true ) );

			$terms = array();
			foreach ( (array) $p['cats'] as $slug ) {
				if ( 'acessorios' === $slug ) {
					$terms[] = $cat_ids['acessorios'];
					$terms[] = $coils;
				} elseif ( isset( $cat_ids[ $slug ] ) ) {
					$terms[] = $cat_ids[ $slug ];
				}
			}
			$product->set_category_ids( array_filter( $terms ) );

			$img = self::image( $p['img'] );
			if ( $img ) {
				$product->set_image_id( $img );
				foreach ( (array) $p['cats'] as $slug ) {
					if ( ! isset( $cat_img[ $slug ] ) ) {
						$cat_img[ $slug ] = $img;
					}
				}
			}

			$label = $p['attr'][0] ?? 'Sabor';
			$n     = count( $options );
			$short = $p['puffs']
				? sprintf( '%s com até %s puffs. %s', $brand ? $brand : 'Pod', $p['puffs'], $n > 1 ? sprintf( 'Escolha entre %d %s.', $n, 'Sabor' === $label ? 'sabores' : 'opções' ) : '' )
				: ( $n > 1 ? sprintf( 'Disponível em %d %s. Produto 100%% original.', $n, 'Cor' === $label ? 'cores' : ( 'Sabor' === $label ? 'sabores' : 'opções' ) ) : 'Produto 100% original, com procedência.' );
			$product->set_short_description( trim( $short ) );
			$product->set_description( $p['desc'] ? wpautop( esc_html( $p['desc'] ) ) : '<p>' . esc_html( $p['name'] ) . ' — produto original, com procedência e garantia de qualidade Villa Ibit.</p>' );
			$product->set_reviews_allowed( true );

			$attrs = array();
			if ( $variable ) {
				$a = new WC_Product_Attribute();
				$a->set_name( $label );
				$a->set_options( $options );
				$a->set_visible( true );
				$a->set_variation( true );
				$attrs[] = $a;
			}
			if ( $p['puffs'] ) {
				$a = new WC_Product_Attribute();
				$a->set_name( 'Puffs' );
				$a->set_options( array( 'até ' . $p['puffs'] ) );
				$a->set_visible( true );
				$a->set_variation( false );
				$attrs[] = $a;
			}
			$product->set_attributes( $attrs );

			if ( ! $variable ) {
				$product->set_regular_price( (string) $p['price'] );
				if ( ! empty( $p['sale'] ) ) {
					$product->set_sale_price( (string) $p['sale'] );
				}
				$product->set_manage_stock( true );
				$product->set_stock_quantity( 5 + ( $i * 7 ) % 30 );
			}
			$id = $product->save();
			update_post_meta( $id, '_vi_demo', 1 );
			update_post_meta( $id, 'total_sales', ( $i * 37 ) % 120 + 3 );

			if ( $brand && taxonomy_exists( 'product_brand' ) ) {
				$b = self::term( $brand, sanitize_title( $brand ), 'product_brand' );
				if ( $b ) {
					wp_set_object_terms( $id, array( $b ), 'product_brand' );
				}
			}

			if ( $variable ) {
				$key = sanitize_title( $label );
				foreach ( $options as $k => $opt ) {
					$v = new WC_Product_Variation();
					$v->set_parent_id( $id );
					$v->set_attributes( array( $key => $opt ) );
					$v->set_regular_price( (string) $p['price'] );
					if ( ! empty( $p['sale'] ) ) {
						$v->set_sale_price( (string) $p['sale'] );
					}
					$v->set_manage_stock( true );
					$qty = ( $k * 5 + $i * 3 ) % 23;
					$v->set_stock_quantity( 0 === ( $k + $i ) % 9 ? 0 : max( 2, $qty ) );
					$v->set_status( 'publish' );
					$v->save();
				}
				WC_Product_Variable::sync( $id );
			}
			wc_delete_product_transients( $id );
			$created[ $p['name'] ] = $id;
		}

		foreach ( $cat_img as $slug => $img ) {
			if ( isset( $cat_ids[ $slug ] ) && ! get_term_meta( $cat_ids[ $slug ], 'thumbnail_id', true ) ) {
				update_term_meta( $cat_ids[ $slug ], 'thumbnail_id', $img );
			}
		}
		if ( isset( $cat_img['acessorios'] ) && $coils ) {
			update_term_meta( $coils, 'thumbnail_id', $cat_img['acessorios'] );
		}

		self::demo_reviews( $created );
		self::demo_posts();
	}

	private static function demo_reviews( $created ) {
		$reviews = array(
			array( 'Elf Bar Ice King 40K', 5, 'Exemplo de avaliação: sabor gelado na medida e chegou no mesmo dia. (Texto de demonstração — remova antes de lançar.)' ),
			array( 'Ignite V500 50.000 Puffs', 5, 'Exemplo de avaliação: dura muito e a tela ajuda a acompanhar a bateria. (Texto de demonstração.)' ),
			array( 'Elf Bar BC Pro 45k', 4, 'Exemplo de avaliação: ótimo custo-benefício na promoção. (Texto de demonstração.)' ),
			array( 'Vaporesso Xros 6 Mini', 5, 'Exemplo de avaliação: aparelho leve e bonito, entrega rápida. (Texto de demonstração.)' ),
		);
		foreach ( $reviews as $r ) {
			if ( empty( $created[ $r[0] ] ) ) {
				continue;
			}
			$cid = wp_insert_comment(
				array(
					'comment_post_ID'      => $created[ $r[0] ],
					'comment_author'       => 'Cliente (demonstração)',
					'comment_author_email' => 'demo@example.com',
					'comment_content'      => $r[2],
					'comment_type'         => 'review',
					'comment_approved'     => 1,
				)
			);
			if ( $cid ) {
				update_comment_meta( $cid, 'rating', $r[1] );
				update_comment_meta( $cid, 'verified', 0 );
				update_comment_meta( $cid, '_vi_demo', 1 );
				WC_Comments::clear_transients( $created[ $r[0] ] );
			}
		}
	}

	private static function demo_posts() {
		$cat   = self::term( 'Guias', 'guias', 'category' );
		$posts = array(
			array( 'Pod descartável ou Pod System: qual combina com você?', 'p57333.webp', '<p>O <strong>pod descartável</strong> já vem carregado e com líquido: é só usar até acabar. É prático para quem quer variar sabores e não quer manutenção.</p><p>O <strong>pod system</strong> é recarregável: você troca o líquido e a coil (resistência). Exige um pouco mais de cuidado, mas permite escolher o líquido e a intensidade.</p><h2>Como escolher</h2><ul><li>Quer praticidade total? Descartável.</li><li>Usa todo dia e quer personalizar? Pod system.</li></ul><p>Ficou com dúvida? Chame a gente no WhatsApp. (Post de demonstração.)</p>' ),
			array( 'Como trocar a coil do seu Vaporesso Xros', 'p60783.webp', '<ol><li>Retire o cartucho do aparelho.</li><li>Encaixe o cartucho novo e preencha com líquido.</li><li>Espere de 3 a 5 minutos para o algodão absorver antes de usar.</li></ol><p>Trocar a coil no tempo certo evita gosto de queimado. (Post de demonstração.)</p>' ),
			array( 'Nicsalt: o que é e como escolher o seu', 'p58501.webp', '<p>O nicsalt (sal de nicotina) é um tipo de líquido feito para pods de baixa potência. Ele é diferente do freebase, usado em aparelhos mais potentes.</p><p>Confira sempre a indicação do fabricante do seu aparelho antes de escolher o líquido. (Post de demonstração.)</p>' ),
		);
		foreach ( $posts as $p ) {
			if ( get_page_by_path( sanitize_title( $p[0] ), OBJECT, 'post' ) ) {
				continue;
			}
			$id = wp_insert_post( array( 'post_title' => $p[0], 'post_content' => $p[2], 'post_status' => 'publish', 'post_type' => 'post', 'post_category' => array( $cat ) ) );
			if ( $id && ! is_wp_error( $id ) ) {
				update_post_meta( $id, '_vi_demo', 1 );
				$img = self::image( $p[1] );
				if ( $img ) {
					set_post_thumbnail( $id, $img );
				}
			}
		}
	}

	public static function remove_demo() {
		$ids = self::demo_ids();
		foreach ( $ids['products'] as $id ) {
			$p = wc_get_product( $id );
			if ( $p ) {
				if ( $p->is_type( 'variable' ) ) {
					foreach ( $p->get_children() as $child ) {
						wp_delete_post( $child, true );
					}
				}
				wp_delete_post( $id, true );
			}
		}
		foreach ( $ids['posts'] as $id ) {
			wp_delete_post( $id, true );
		}
		foreach ( get_comments( array( 'meta_key' => '_vi_demo', 'meta_value' => 1, 'status' => 'all', 'type' => 'all' ) ) as $c ) { // phpcs:ignore WordPress.DB.SlowDBQuery
			wp_delete_comment( $c->comment_ID, true );
		}
		foreach ( $ids['attachments'] as $id ) {
			wp_delete_attachment( $id, true );
		}
		foreach ( array( 'product_cat', 'product_brand', 'category' ) as $tax ) {
			if ( ! taxonomy_exists( $tax ) ) {
				continue;
			}
			$terms = get_terms( array( 'taxonomy' => $tax, 'hide_empty' => false, 'meta_key' => '_vi_demo', 'meta_value' => 1 ) ); // phpcs:ignore WordPress.DB.SlowDBQuery
			if ( is_wp_error( $terms ) ) {
				continue;
			}
			foreach ( $terms as $t ) {
				$t = get_term( $t->term_id, $tax );
				if ( $t && ! is_wp_error( $t ) && 0 === (int) $t->count ) {
					wp_delete_term( $t->term_id, $tax );
				}
			}
		}
		wc_delete_product_transients();
	}
}
