<?php
/**
 * Marcas: o WooCommerce 9.6+ já traz "Produtos › Marcas". Em versões antigas, o plugin cria a mesma taxonomia.
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;

class VIG_Brands {

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ), 20 );
	}

	public static function register() {
		if ( taxonomy_exists( 'product_brand' ) ) {
			return;
		}
		register_taxonomy(
			'product_brand',
			array( 'product' ),
			array(
				'hierarchical'      => true,
				'show_admin_column' => true,
				'show_in_rest'      => true,
				'rewrite'           => array( 'slug' => 'marca' ),
				'labels'            => array(
					'name'          => __( 'Marcas', 'villa-ibit-gestor' ),
					'singular_name' => __( 'Marca', 'villa-ibit-gestor' ),
					'add_new_item'  => __( 'Adicionar marca', 'villa-ibit-gestor' ),
					'edit_item'     => __( 'Editar marca', 'villa-ibit-gestor' ),
					'search_items'  => __( 'Buscar marcas', 'villa-ibit-gestor' ),
					'menu_name'     => __( 'Marcas', 'villa-ibit-gestor' ),
				),
			)
		);
	}
}
