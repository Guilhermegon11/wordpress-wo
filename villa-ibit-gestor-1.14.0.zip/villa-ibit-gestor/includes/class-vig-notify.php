<?php
/**
 * Avisos de venda para o administrador.
 *
 * Canais:
 *  - notificação no celular/computador (Web Push pelo app do painel, sem serviço externo);
 *  - aviso com som dentro do painel aberto;
 *  - e-mail da Villa Ibit (substitui o "Novo pedido" do WooCommerce, para não chegar repetido);
 *  - WhatsApp pela WaScript ou pelo CallMeBot (opcional).
 *
 * Uma venda é avisada uma vez só: quando o pedido chega pela primeira vez a
 * "Processando" (pago), "Aguardando" (PIX manual / transferência) ou "Concluído".
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;

class VIG_Notify {

	const SUBS  = 'vig_push_subs';   // aparelhos inscritos.
	const VAPID = 'vig_vapid';       // chaves do Web Push (geradas no próprio site).
	const LOG   = 'vig_sales_log';   // últimos avisos (painel aberto + histórico).
	const SINCE = 'vig_notify_since'; // só avisa pedidos feitos depois da instalação.
	const META  = '_vig_notified';   // etapas já avisadas no pedido.
	const MAX_LOG = 30;

	/** @var array<int, array<string,bool>> Pedidos a avisar no fim da requisição. */
	private static $queue = array();

	public static function init() {
		if ( ! get_option( self::SINCE ) ) {
			update_option( self::SINCE, time(), false );
		}
		add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'on_status' ), 20, 4 );
		add_action( 'woocommerce_new_order', array( __CLASS__, 'on_new' ), 20, 2 );
		add_action( 'woocommerce_checkout_order_processed', array( __CLASS__, 'on_checkout' ), 20, 3 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( __CLASS__, 'on_checkout' ), 20, 1 );
		add_filter( 'woocommerce_email_enabled_new_order', array( __CLASS__, 'wc_new_order_email' ), 20, 2 );
		add_action( 'shutdown', array( __CLASS__, 'flush' ), 999 );

		add_action( 'wp_ajax_vig_push_subscribe', array( __CLASS__, 'ajax_subscribe' ) );
		add_action( 'wp_ajax_vig_push_unsubscribe', array( __CLASS__, 'ajax_unsubscribe' ) );
		add_action( 'wp_ajax_vig_push_test', array( __CLASS__, 'ajax_push_test' ) );
		add_action( 'wp_ajax_vig_sales_poll', array( __CLASS__, 'ajax_poll' ) );
		add_action( 'admin_post_vig_notify_test', array( __CLASS__, 'post_test' ) );
		add_action( 'admin_post_vig_push_remove', array( __CLASS__, 'post_remove' ) );
	}

	/* ================================================================== *
	 * Quando avisar
	 * ================================================================== */

	/** Status que contam como venda (pago ou aguardando a confirmação manual do PIX). */
	public static function sale_statuses() {
		return (array) apply_filters( 'vig_notify_sale_statuses', array( 'processing', 'on-hold', 'completed' ) );
	}

	public static function on_status( $order_id, $from, $to, $order = null ) {
		$sale = self::sale_statuses();
		if ( ! in_array( $to, $sale, true ) || in_array( $from, $sale, true ) ) {
			return; // não é venda, ou já era venda antes (ex.: PIX confirmado à mão).
		}
		self::queue( $order ? $order : $order_id, 'sale' );
	}

	/** Pedido criado direto como pago (ex.: criado por um app ou pela API). */
	public static function on_new( $order_id, $order = null ) {
		$order = $order instanceof WC_Order ? $order : wc_get_order( $order_id );
		if ( $order && in_array( $order->get_status(), self::sale_statuses(), true ) ) {
			self::queue( $order, 'sale' );
		}
	}

	/** Fim do checkout: pedidos que ainda aguardam pagamento (só se ligado). */
	public static function on_checkout( $order, $posted = null, $maybe_order = null ) {
		if ( ! vig_value( 'notify_pending', 0 ) ) {
			return;
		}
		$order = $maybe_order instanceof WC_Order ? $maybe_order : $order;
		self::queue( $order, 'pending' );
	}

	/**
	 * Põe o pedido na fila (os avisos saem no fim da requisição, depois da resposta ao cliente).
	 *
	 * @param WC_Order|int $order Pedido.
	 * @param string       $stage sale|pending.
	 */
	public static function queue( $order, $stage ) {
		$order = $order instanceof WC_Order ? $order : wc_get_order( $order );
		if ( ! self::should_notify( $order, $stage ) ) {
			return;
		}
		self::$queue[ $order->get_id() ][ $stage ] = true;
	}

	public static function should_notify( $order, $stage ) {
		if ( ! $order instanceof WC_Order || $order instanceof WC_Order_Refund ) {
			return false;
		}
		if ( 'admin' === $order->get_created_via() ) {
			return (bool) apply_filters( 'vig_notify_admin_orders', false, $order ); // pedido lançado à mão no painel.
		}
		$since   = (int) get_option( self::SINCE );
		$created = $order->get_date_created();
		if ( $since && $created && $created->getTimestamp() < $since - DAY_IN_SECONDS ) {
			return false; // pedido antigo, de antes de os avisos existirem.
		}
		return ! in_array( $stage, (array) $order->get_meta( self::META ), true );
	}

	/** Envia o que estiver na fila. */
	public static function flush() {
		if ( ! self::$queue ) {
			return;
		}
		$queue       = self::$queue;
		self::$queue = array();
		if ( self::has_remote_channels() ) {
			// Responde ao cliente primeiro; os envios para o celular/WhatsApp seguem em segundo plano.
			if ( function_exists( 'fastcgi_finish_request' ) ) {
				fastcgi_finish_request();
			} elseif ( function_exists( 'litespeed_finish_request' ) ) {
				litespeed_finish_request();
			}
			ignore_user_abort( true );
		}
		foreach ( $queue as $order_id => $stages ) {
			$order = wc_get_order( $order_id );
			if ( ! $order ) {
				continue;
			}
			$is_sale = in_array( $order->get_status(), self::sale_statuses(), true );
			if ( isset( $stages['sale'] ) || $is_sale ) {
				$stage = 'sale'; // pagou na mesma requisição: um aviso só, o de venda.
			} elseif ( 'pending' === $order->get_status() ) {
				$stage = 'pending';
			} else {
				continue; // falhou ou foi cancelado antes de avisar.
			}
			if ( ! self::should_notify( $order, $stage ) ) {
				continue;
			}
			$sent   = (array) $order->get_meta( self::META );
			$sent[] = $stage;
			$order->update_meta_data( self::META, array_values( array_unique( $sent ) ) );
			$order->save_meta_data();
			self::dispatch( $order, $stage );
		}
	}

	private static function has_remote_channels() {
		return ( vig_value( 'notify_push', 1 ) && self::subscriptions() ) || ( vig_value( 'notify_wa', 0 ) && 'callmebot' === VIG_WaScript::provider() && vig_value( 'notify_wa_key', '' ) );
	}

	/* ================================================================== *
	 * Envio
	 * ================================================================== */

	/**
	 * Manda o aviso por todos os canais ligados.
	 *
	 * @param WC_Order|null $order Pedido (null = teste sem pedido).
	 * @param string        $stage sale|pending.
	 * @param bool          $test  Aviso de teste.
	 * @return array Resultado por canal: [ok(bool), texto].
	 */
	public static function dispatch( $order, $stage = 'sale', $test = false ) {
		$msg     = self::message( $order, $stage, $test );
		$results = array();
		if ( vig_value( 'notify_push', 1 ) ) {
			$results['push'] = self::push_all( $msg );
		}
		if ( vig_value( 'notify_email', 0 ) ) {
			$results['email'] = self::send_email( $order, $msg );
		}
		if ( vig_value( 'notify_wa', 0 ) ) {
			$results['wa'] = 'wascript' === VIG_WaScript::provider()
				? ( $test ? VIG_WaScript::test() : VIG_WaScript::queue( $order, $stage ) )
				: self::send_whatsapp( $msg );
		}
		self::log( $msg, $results );
		if ( $order && ! $test ) {
			$parts = array();
			foreach ( $results as $ch => $r ) {
				if ( null !== $r ) {
					$parts[] = self::channel_label( $ch ) . ': ' . $r[1];
				}
			}
			$order->add_order_note( __( 'Avisos da venda para o administrador.', 'villa-ibit-gestor' ) . ( $parts ? ' ' . implode( ' · ', $parts ) : '' ) );
		}
		return $results;
	}

	public static function channel_label( $ch ) {
		$labels = array(
			'push'  => __( 'Celular/computador', 'villa-ibit-gestor' ),
			'email' => __( 'E-mail', 'villa-ibit-gestor' ),
			'wa'    => __( 'WhatsApp', 'villa-ibit-gestor' ),
			'panel' => __( 'Painel aberto', 'villa-ibit-gestor' ),
		);
		return isset( $labels[ $ch ] ) ? $labels[ $ch ] : $ch;
	}

	/** Texto simples a partir de um valor em R$. */
	public static function money( $value ) {
		return trim( str_replace( "\xC2\xA0", ' ', html_entity_decode( wp_strip_all_tags( wc_price( (float) $value ) ), ENT_QUOTES, 'UTF-8' ) ) );
	}

	/**
	 * Monta o conteúdo do aviso.
	 *
	 * @return array title, body, url, tag, order, number, total, status, lines, customer, place, payment, shipping, phone, test.
	 */
	public static function message( $order, $stage = 'sale', $test = false ) {
		if ( ! $order instanceof WC_Order ) {
			$sample = array(
				'title'    => __( '[Teste] Nova venda! #0000 · R$ 189,90', 'villa-ibit-gestor' ),
				'body'     => __( 'Assim chega o aviso de cada venda. Toque para abrir os pedidos.', 'villa-ibit-gestor' ),
				'url'      => VIG_Orders::url(),
				'tag'      => 'vig-test',
				'order'    => 0,
				'number'   => '0000',
				'total'    => 'R$ 189,90',
				'status'   => 'processing',
				'paid'     => true,
				'lines'    => array( array( 'name' => 'Ignite V50 — Menta', 'qty' => 2, 'total' => 'R$ 189,90' ) ),
				'customer' => __( 'Cliente de teste', 'villa-ibit-gestor' ),
				'place'    => 'Governador Valadares/MG',
				'payment'  => 'PIX',
				'shipping' => 'Delivery GV',
				'phone'    => '',
				'test'     => true,
				'stage'    => $stage,
			);
			return $sample;
		}
		$status = $order->get_status();
		$paid   = in_array( $status, array( 'processing', 'completed' ), true );
		$total  = self::money( $order->get_total() );
		$number = $order->get_order_number();
		$name   = trim( $order->get_formatted_billing_full_name() );
		$city   = $order->get_shipping_city() ? $order->get_shipping_city() : $order->get_billing_city();
		$state  = $order->get_shipping_state() ? $order->get_shipping_state() : $order->get_billing_state();
		$lines  = array();
		foreach ( $order->get_items() as $item ) {
			$label = $item->get_name();
			$meta  = array();
			foreach ( $item->get_formatted_meta_data( '_', true ) as $m ) {
				$meta[] = wp_strip_all_tags( $m->display_value );
			}
			$lines[] = array(
				'name'  => $label . ( $meta && false === strpos( $label, ' - ' ) ? ' — ' . implode( ', ', $meta ) : '' ),
				'qty'   => (int) $item->get_quantity(),
				'total' => self::money( (float) $item->get_total() + (float) $item->get_total_tax() ),
			);
		}
		if ( 'pending' === $stage ) {
			/* translators: 1: nº do pedido, 2: total */
			$title = sprintf( __( 'Novo pedido #%1$s · %2$s (aguardando pagamento)', 'villa-ibit-gestor' ), $number, $total );
		} else {
			/* translators: 1: nº do pedido, 2: total */
			$title = sprintf( __( 'Nova venda! #%1$s · %2$s', 'villa-ibit-gestor' ), $number, $total );
		}
		if ( $test ) {
			$title = __( '[Teste]', 'villa-ibit-gestor' ) . ' ' . $title;
		}
		$place   = trim( $city . ( $state ? '/' . $state : '' ), '/' );
		$items   = array();
		foreach ( array_slice( $lines, 0, 3 ) as $l ) {
			$items[] = $l['qty'] . '× ' . $l['name'];
		}
		if ( count( $lines ) > 3 ) {
			/* translators: %d: quantidade de outros itens */
			$items[] = sprintf( __( '+%d itens', 'villa-ibit-gestor' ), count( $lines ) - 3 );
		}
		$pay_state = $paid ? __( 'pago', 'villa-ibit-gestor' ) : ( 'on-hold' === $status ? __( 'confira o pagamento', 'villa-ibit-gestor' ) : __( 'aguardando pagamento', 'villa-ibit-gestor' ) );
		$body_parts = array_filter(
			array(
				trim( ( $name ? $name : __( 'Visitante', 'villa-ibit-gestor' ) ) . ( $place ? ' · ' . $place : '' ) ),
				implode( ', ', $items ),
				trim( ( $order->get_payment_method_title() ? wp_strip_all_tags( $order->get_payment_method_title() ) . ' · ' : '' ) . $pay_state ),
			)
		);
		return array(
			'title'    => $title,
			'body'     => mb_substr( implode( "\n", $body_parts ), 0, 600 ),
			'url'      => VIG_Orders::url( $order->get_id() ),
			'tag'      => 'vig-order-' . $order->get_id(),
			'order'    => $order->get_id(),
			'number'   => (string) $number,
			'total'    => $total,
			'status'   => $status,
			'paid'     => $paid,
			'lines'    => $lines,
			'customer' => $name ? $name : __( 'Visitante', 'villa-ibit-gestor' ),
			'place'    => $place,
			'payment'  => wp_strip_all_tags( (string) $order->get_payment_method_title() ),
			'shipping' => wp_strip_all_tags( (string) $order->get_shipping_method() ),
			'phone'    => VIG_Admin::wa_number( $order->get_billing_phone() ),
			'test'     => (bool) $test,
			'stage'    => $stage,
		);
	}

	/** Guarda o aviso no histórico (é dele que o painel aberto lê as novidades). */
	private static function log( $msg, $results ) {
		$log = get_option( self::LOG, array() );
		$log = is_array( $log ) ? $log : array();
		array_unshift(
			$log,
			array(
				'id'      => wp_generate_uuid4(),
				'time'    => time(),
				'order'   => (int) $msg['order'],
				'title'   => $msg['title'],
				'body'    => $msg['body'],
				'url'     => $msg['url'],
				'test'    => ! empty( $msg['test'] ),
				'results' => $results,
			)
		);
		update_option( self::LOG, array_slice( $log, 0, self::MAX_LOG ), false );
	}

	public static function log_entries() {
		$log = get_option( self::LOG, array() );
		return is_array( $log ) ? $log : array();
	}

	/* ---------- E-mail ---------- */

	/** Endereços que recebem o e-mail (padrão: e-mail do administrador do site). */
	public static function email_recipients() {
		$raw  = (string) vig_value( 'notify_emails', '' );
		$list = array_filter( array_map( 'sanitize_email', preg_split( '/[\s,;]+/', $raw ) ), 'is_email' );
		return $list ? array_values( array_unique( $list ) ) : array( get_option( 'admin_email' ) );
	}

	/** Desliga o "Novo pedido" do WooCommerce quando o e-mail da Villa Ibit está ligado (evita 2 e-mails). */
	public static function wc_new_order_email( $enabled, $order = null ) {
		if ( vig_value( 'notify_email', 0 ) && vig_value( 'notify_wc_off', 0 ) ) {
			return false;
		}
		return $enabled;
	}

	public static function send_email( $order, $msg ) {
		$to      = self::email_recipients();
		$subject = ( $msg['paid'] || ! empty( $msg['test'] ) ? '💰 ' : '🕒 ' ) . $msg['title'];
		$headers = array( 'Content-Type: text/html; charset=UTF-8' );
		$ok      = wp_mail( $to, $subject, self::email_html( $msg ), $headers );
		/* translators: %s: endereços de e-mail */
		return array( (bool) $ok, $ok ? sprintf( __( 'enviado para %s', 'villa-ibit-gestor' ), implode( ', ', $to ) ) : __( 'o servidor não conseguiu enviar (confira o plugin de SMTP)', 'villa-ibit-gestor' ) );
	}

	/** HTML do e-mail (estilos em linha, cores da loja). */
	public static function email_html( $msg ) {
		$g     = '#023832';
		$sand  = '#F6F2EA';
		$gold  = '#FFD695';
		$store = get_bloginfo( 'name' );
		$logo  = '';
		if ( function_exists( 'get_template_directory' ) && file_exists( get_template_directory() . '/assets/img/logo-verde.png' ) ) {
			$logo = get_template_directory_uri() . '/assets/img/logo-verde.png';
		}
		$badge_bg  = $msg['paid'] ? '#E6F2EC' : '#FFF3DC';
		$badge_ink = $msg['paid'] ? '#075046' : '#8A6420';
		$badge     = $msg['paid'] ? __( 'Pagamento confirmado', 'villa-ibit-gestor' ) : ( 'on-hold' === $msg['status'] ? __( 'Confira o pagamento (PIX/transferência)', 'villa-ibit-gestor' ) : __( 'Aguardando pagamento', 'villa-ibit-gestor' ) );
		$heading   = 'pending' === $msg['stage'] ? __( 'Novo pedido', 'villa-ibit-gestor' ) : __( 'Nova venda!', 'villa-ibit-gestor' );

		$rows = '';
		foreach ( $msg['lines'] as $l ) {
			$rows .= '<tr><td style="padding:10px 0;border-top:1px solid #E6DECF;font-size:14px;color:#10201D"><strong>' . esc_html( $l['qty'] ) . '×</strong> ' . esc_html( $l['name'] ) . '</td><td style="padding:10px 0;border-top:1px solid #E6DECF;font-size:14px;color:#10201D;text-align:right;white-space:nowrap">' . esc_html( $l['total'] ) . '</td></tr>';
		}
		$info = array(
			__( 'Cliente', 'villa-ibit-gestor' )   => $msg['customer'] . ( $msg['place'] ? ' · ' . $msg['place'] : '' ),
			__( 'Pagamento', 'villa-ibit-gestor' ) => $msg['payment'],
			__( 'Entrega', 'villa-ibit-gestor' )   => $msg['shipping'],
		);
		$info_html = '';
		foreach ( $info as $k => $v ) {
			if ( '' !== trim( (string) $v ) ) {
				$info_html .= '<tr><td style="padding:4px 12px 4px 0;font-size:13px;color:#55655F;white-space:nowrap;vertical-align:top">' . esc_html( $k ) . '</td><td style="padding:4px 0;font-size:14px;color:#10201D">' . esc_html( $v ) . '</td></tr>';
			}
		}
		$btn = function ( $label, $url, $bg, $ink ) {
			return '<a href="' . esc_url( $url ) . '" style="display:inline-block;margin:6px 6px 0 0;padding:13px 22px;border-radius:999px;background:' . $bg . ';color:' . $ink . ';font-weight:700;font-size:14px;text-decoration:none">' . esc_html( $label ) . '</a>';
		};
		$buttons = $btn( __( 'Abrir o pedido no painel', 'villa-ibit-gestor' ), $msg['url'], $g, '#ffffff' );
		if ( $msg['phone'] ) {
			$buttons .= $btn( __( 'Chamar o cliente no WhatsApp', 'villa-ibit-gestor' ), 'https://wa.me/' . $msg['phone'], '#1F8F4E', '#ffffff' );
		}

		$html  = '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . esc_html( $msg['title'] ) . '</title></head>';
		$html .= '<body style="margin:0;padding:0;background:' . $sand . ';font-family:\'DM Sans\',Arial,Helvetica,sans-serif">';
		$html .= '<div style="display:none;max-height:0;overflow:hidden">' . esc_html( str_replace( "\n", ' · ', $msg['body'] ) ) . '</div>';
		$html .= '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:' . $sand . '"><tr><td align="center" style="padding:24px 12px">';
		$html .= '<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:560px;background:#ffffff;border:1px solid #E6DECF;border-radius:20px;overflow:hidden">';
		$html .= '<tr><td style="background:' . $g . ';padding:18px 24px;color:' . $gold . ';font-weight:800;font-size:15px;letter-spacing:.06em;text-transform:uppercase">' . esc_html( $store ) . '</td></tr>';
		$html .= '<tr><td style="padding:26px 24px 6px">';
		if ( $logo ) {
			$html .= '<img src="' . esc_url( $logo ) . '" alt="" width="120" style="display:block;width:120px;height:auto;margin:0 0 14px">';
		}
		if ( ! empty( $msg['test'] ) ) {
			$html .= '<p style="margin:0 0 10px;font-size:12px;font-weight:700;color:#8A6420">' . esc_html__( 'ESTE É UM AVISO DE TESTE', 'villa-ibit-gestor' ) . '</p>';
		}
		$html .= '<p style="margin:0;font-size:14px;color:#55655F">' . esc_html( $heading ) . ' · ' . esc_html__( 'pedido', 'villa-ibit-gestor' ) . ' #' . esc_html( $msg['number'] ) . '</p>';
		$html .= '<p style="margin:4px 0 10px;font-family:Sora,Arial,sans-serif;font-size:34px;line-height:1.1;font-weight:800;color:' . $g . '">' . esc_html( $msg['total'] ) . '</p>';
		$html .= '<span style="display:inline-block;padding:5px 12px;border-radius:999px;background:' . $badge_bg . ';color:' . $badge_ink . ';font-size:12px;font-weight:700">' . esc_html( $badge ) . '</span>';
		$html .= '</td></tr>';
		$html .= '<tr><td style="padding:18px 24px 4px"><table role="presentation" width="100%" cellspacing="0" cellpadding="0">' . $rows . '</table></td></tr>';
		$html .= '<tr><td style="padding:10px 24px 6px"><table role="presentation" cellspacing="0" cellpadding="0">' . $info_html . '</table></td></tr>';
		$html .= '<tr><td style="padding:12px 24px 26px">' . $buttons . '</td></tr>';
		$html .= '</table>';
		$html .= '<p style="margin:14px 0 0;font-size:12px;color:#55655F">' . esc_html__( 'Aviso automático do painel Villa Ibit. Para mudar quem recebe: Villa Ibit › Configurações › Avisos de venda.', 'villa-ibit-gestor' ) . '</p>';
		$html .= '</td></tr></table></body></html>';
		return $html;
	}

	/* ---------- WhatsApp (CallMeBot) ---------- */

	public static function whatsapp_text( $msg ) {
		$lines = array( '*' . $msg['title'] . '*' );
		foreach ( explode( "\n", $msg['body'] ) as $l ) {
			$lines[] = $l;
		}
		$lines[] = $msg['url'];
		return implode( "\n", $lines );
	}

	public static function send_whatsapp( $msg ) {
		$phone = preg_replace( '/\D+/', '', (string) vig_value( 'notify_wa_phone', '' ) );
		$key   = trim( (string) vig_value( 'notify_wa_key', '' ) );
		if ( ! $phone || ! $key ) {
			return array( false, __( 'falta o número ou a apikey', 'villa-ibit-gestor' ) );
		}
		$url = add_query_arg(
			array(
				'phone'  => rawurlencode( '+' . $phone ),
				'text'   => rawurlencode( self::whatsapp_text( $msg ) ),
				'apikey' => rawurlencode( $key ),
			),
			'https://api.callmebot.com/whatsapp.php'
		);
		$res = wp_remote_get( $url, array( 'timeout' => 15 ) );
		if ( is_wp_error( $res ) ) {
			return array( false, $res->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		$body = wp_strip_all_tags( (string) wp_remote_retrieve_body( $res ) );
		if ( 200 === $code && false === stripos( $body, 'error' ) && false === stripos( $body, 'apikey is invalid' ) ) {
			return array( true, __( 'enviado', 'villa-ibit-gestor' ) );
		}
		/* translators: %s: resposta do serviço */
		return array( false, sprintf( __( 'o CallMeBot recusou: %s', 'villa-ibit-gestor' ), mb_substr( trim( preg_replace( '/\s+/', ' ', $body ) ), 0, 120 ) ) );
	}

	/* ================================================================== *
	 * Web Push (RFC 8030 + VAPID RFC 8292 + criptografia RFC 8291)
	 * ================================================================== */

	public static function b64u_encode( $bin ) {
		return rtrim( strtr( base64_encode( $bin ), '+/', '-_' ), '=' );
	}

	public static function b64u_decode( $str ) {
		$str = strtr( (string) $str, '-_', '+/' );
		$pad = strlen( $str ) % 4;
		return (string) base64_decode( $pad ? $str . str_repeat( '=', 4 - $pad ) : $str, true );
	}

	public static function push_supported() {
		return function_exists( 'openssl_pkey_new' ) && function_exists( 'openssl_pkey_derive' ) && function_exists( 'hash_hkdf' ) && in_array( 'aes-128-gcm', openssl_get_cipher_methods(), true );
	}

	/** Gera um par de chaves P-256. */
	private static function ec_new() {
		$key = openssl_pkey_new( array( 'curve_name' => 'prime256v1', 'private_key_type' => OPENSSL_KEYTYPE_EC ) );
		if ( ! $key ) {
			return null;
		}
		$d = openssl_pkey_get_details( $key );
		if ( empty( $d['ec']['x'] ) ) {
			return null;
		}
		$public = "\x04" . str_pad( $d['ec']['x'], 32, "\0", STR_PAD_LEFT ) . str_pad( $d['ec']['y'], 32, "\0", STR_PAD_LEFT );
		return array( $key, $public );
	}

	/** Chave pública crua (65 bytes) → chave do OpenSSL. */
	public static function ec_public_pem( $raw ) {
		$der = hex2bin( '3059301306072a8648ce3d020106082a8648ce3d030107034200' ) . $raw;
		return "-----BEGIN PUBLIC KEY-----\n" . chunk_split( base64_encode( $der ), 64, "\n" ) . "-----END PUBLIC KEY-----\n";
	}

	/** Chaves VAPID do site (criadas na primeira vez). */
	public static function vapid() {
		$v = get_option( self::VAPID );
		if ( is_array( $v ) && ! empty( $v['public'] ) && ! empty( $v['private'] ) ) {
			return $v;
		}
		if ( ! self::push_supported() ) {
			return null;
		}
		$pair = self::ec_new();
		if ( ! $pair || ! openssl_pkey_export( $pair[0], $pem ) ) {
			return null;
		}
		$v = array( 'public' => self::b64u_encode( $pair[1] ), 'private' => $pem );
		update_option( self::VAPID, $v, false );
		return $v;
	}

	/** Assinatura DER (ECDSA) → R||S com 64 bytes, como o JWT pede. */
	public static function der_to_raw( $der ) {
		$pos = 2; // 0x30 len
		if ( ord( $der[1] ) & 0x80 ) {
			$pos += ord( $der[1] ) & 0x7f;
		}
		$out = '';
		for ( $i = 0; $i < 2; $i++ ) {
			$pos++; // 0x02
			$len  = ord( $der[ $pos ] );
			$pos++;
			$int  = substr( $der, $pos, $len );
			$pos += $len;
			$out .= str_pad( ltrim( $int, "\0" ), 32, "\0", STR_PAD_LEFT );
		}
		return $out;
	}

	/** Cabeçalho Authorization do VAPID para o serviço de push do aparelho. */
	public static function vapid_header( $endpoint, $vapid, $exp = null ) {
		$p    = wp_parse_url( $endpoint );
		$aud  = $p['scheme'] . '://' . $p['host'] . ( isset( $p['port'] ) ? ':' . $p['port'] : '' );
		$mail = get_option( 'admin_email' );
		$head = self::b64u_encode( wp_json_encode( array( 'typ' => 'JWT', 'alg' => 'ES256' ) ) );
		$body = self::b64u_encode( wp_json_encode( array( 'aud' => $aud, 'exp' => $exp ? $exp : time() + 12 * HOUR_IN_SECONDS, 'sub' => 'mailto:' . ( $mail ? $mail : 'admin@' . $p['host'] ) ), JSON_UNESCAPED_SLASHES ) );
		$data = $head . '.' . $body;
		if ( ! openssl_sign( $data, $sig, $vapid['private'], OPENSSL_ALGO_SHA256 ) ) {
			return '';
		}
		return 'vapid t=' . $data . '.' . self::b64u_encode( self::der_to_raw( $sig ) ) . ', k=' . $vapid['public'];
	}

	/**
	 * Criptografa a mensagem para o aparelho (aes128gcm, RFC 8291).
	 *
	 * @param string $payload Texto (JSON).
	 * @param string $p256dh  Chave pública do aparelho (base64url).
	 * @param string $auth    Segredo do aparelho (base64url).
	 * @return string|null Corpo pronto para enviar.
	 */
	public static function encrypt( $payload, $p256dh, $auth ) {
		$ua_public = self::b64u_decode( $p256dh );
		$secret    = self::b64u_decode( $auth );
		if ( 65 !== strlen( $ua_public ) || 16 !== strlen( $secret ) ) {
			return null;
		}
		$pair = self::ec_new();
		$peer = openssl_pkey_get_public( self::ec_public_pem( $ua_public ) );
		if ( ! $pair || ! $peer ) {
			return null;
		}
		list( $as_key, $as_public ) = $pair;
		$shared = openssl_pkey_derive( $peer, $as_key, 32 );
		if ( ! $shared ) {
			return null;
		}
		$ikm   = hash_hkdf( 'sha256', $shared, 32, "WebPush: info\0" . $ua_public . $as_public, $secret );
		$salt  = random_bytes( 16 );
		$cek   = hash_hkdf( 'sha256', $ikm, 16, "Content-Encoding: aes128gcm\0", $salt );
		$nonce = hash_hkdf( 'sha256', $ikm, 12, "Content-Encoding: nonce\0", $salt );
		$tag   = '';
		$ct    = openssl_encrypt( $payload . "\x02", 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag, '', 16 );
		if ( false === $ct ) {
			return null;
		}
		return $salt . pack( 'N', 4096 ) . chr( 65 ) . $as_public . $ct . $tag;
	}

	public static function subscriptions() {
		$subs = get_option( self::SUBS, array() );
		return is_array( $subs ) ? $subs : array();
	}

	private static function save_subscriptions( $subs ) {
		update_option( self::SUBS, $subs, false );
	}

	/**
	 * Envia para um aparelho.
	 *
	 * @return array [ok, código HTTP, texto]
	 */
	public static function push_one( $sub, $msg ) {
		$vapid = self::vapid();
		if ( ! $vapid ) {
			return array( false, 0, __( 'o servidor não tem suporte a notificações (OpenSSL)', 'villa-ibit-gestor' ) );
		}
		$payload = wp_json_encode(
			array(
				'title' => $msg['title'],
				'body'  => $msg['body'],
				'url'   => $msg['url'],
				'tag'   => $msg['tag'],
			),
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
		);
		$body = self::encrypt( $payload, $sub['p256dh'], $sub['auth'] );
		$auth = self::vapid_header( $sub['endpoint'], $vapid );
		if ( null === $body || '' === $auth ) {
			return array( false, 0, __( 'não foi possível preparar a mensagem', 'villa-ibit-gestor' ) );
		}
		$res = wp_remote_post(
			$sub['endpoint'],
			array(
				'timeout' => 10,
				'headers' => array(
					'Authorization'    => $auth,
					'TTL'              => (string) DAY_IN_SECONDS,
					'Urgency'          => 'high',
					'Content-Type'     => 'application/octet-stream',
					'Content-Encoding' => 'aes128gcm',
				),
				'body'    => $body,
			)
		);
		if ( is_wp_error( $res ) ) {
			return array( false, 0, $res->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		return array( $code >= 200 && $code < 300, $code, (string) wp_remote_retrieve_body( $res ) );
	}

	/** Envia para todos os aparelhos e limpa os que foram desinstalados. */
	public static function push_all( $msg ) {
		$subs = self::subscriptions();
		if ( ! $subs ) {
			return null; // nenhum aparelho ativado: não conta como erro.
		}
		$ok      = 0;
		$changed = false;
		$err     = '';
		foreach ( $subs as $key => $sub ) {
			$r = self::push_one( $sub, $msg );
			if ( $r[0] ) {
				$ok++;
				$subs[ $key ]['last_ok'] = time();
				$changed                 = true;
			} elseif ( in_array( $r[1], array( 404, 410 ), true ) ) {
				unset( $subs[ $key ] ); // o aparelho desativou ou desinstalou.
				$changed = true;
			} else {
				$err = $r[1] ? 'HTTP ' . $r[1] : $r[2];
			}
		}
		if ( $changed ) {
			self::save_subscriptions( $subs );
		}
		$total = count( $subs );
		/* translators: 1: aparelhos que receberam, 2: total */
		$text = sprintf( _n( '%1$d de %2$d aparelho', '%1$d de %2$d aparelhos', max( 1, $total ), 'villa-ibit-gestor' ), $ok, $total );
		return array( $ok > 0, $text . ( $err ? ' (' . $err . ')' : '' ) );
	}

	/* ================================================================== *
	 * AJAX e formulários
	 * ================================================================== */

	public static function ajax_subscribe() {
		VIG_Admin::check_ajax();
		$sub = json_decode( isset( $_POST['sub'] ) ? wp_unslash( $_POST['sub'] ) : '', true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$endpoint = is_array( $sub ) && isset( $sub['endpoint'] ) ? esc_url_raw( $sub['endpoint'], array( 'https' ) ) : '';
		$p256dh   = isset( $sub['keys']['p256dh'] ) ? preg_replace( '/[^A-Za-z0-9_\-]/', '', $sub['keys']['p256dh'] ) : '';
		$auth     = isset( $sub['keys']['auth'] ) ? preg_replace( '/[^A-Za-z0-9_\-]/', '', $sub['keys']['auth'] ) : '';
		if ( ! $endpoint || 65 !== strlen( self::b64u_decode( $p256dh ) ) || 16 !== strlen( self::b64u_decode( $auth ) ) ) {
			wp_send_json_error( array( 'message' => __( 'Inscrição inválida.', 'villa-ibit-gestor' ) ), 400 );
		}
		$subs = self::subscriptions();
		$key  = md5( $endpoint );
		$new  = ! isset( $subs[ $key ] );
		$subs[ $key ] = array(
			'endpoint' => $endpoint,
			'p256dh'   => $p256dh,
			'auth'     => $auth,
			'user'     => get_current_user_id(),
			'device'   => isset( $_POST['device'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST['device'] ) ), 0, 60 ) : '',
			'created'  => $new ? time() : (int) ( $subs[ $key ]['created'] ?? time() ),
			'last_ok'  => (int) ( $subs[ $key ]['last_ok'] ?? 0 ),
		);
		self::save_subscriptions( $subs );
		$result = null;
		if ( $new || ! empty( $_POST['test'] ) ) {
			$msg          = self::message( null );
			$msg['title'] = __( 'Pronto! Avisos de venda ligados', 'villa-ibit-gestor' );
			$msg['body']  = __( 'Este aparelho vai receber uma notificação a cada nova venda da loja.', 'villa-ibit-gestor' );
			$result       = self::push_one( $subs[ $key ], $msg );
		}
		wp_send_json_success( array( 'new' => $new, 'count' => count( $subs ), 'sent' => $result ? $result[0] : null ) );
	}

	public static function ajax_unsubscribe() {
		VIG_Admin::check_ajax();
		$endpoint = isset( $_POST['endpoint'] ) ? esc_url_raw( wp_unslash( $_POST['endpoint'] ) ) : '';
		$subs     = self::subscriptions();
		unset( $subs[ md5( $endpoint ) ] );
		self::save_subscriptions( $subs );
		wp_send_json_success( array( 'count' => count( $subs ) ) );
	}

	public static function ajax_push_test() {
		VIG_Admin::check_ajax();
		$endpoint = isset( $_POST['endpoint'] ) ? esc_url_raw( wp_unslash( $_POST['endpoint'] ) ) : '';
		$subs     = self::subscriptions();
		if ( ! isset( $subs[ md5( $endpoint ) ] ) ) {
			wp_send_json_error( array( 'message' => __( 'Este aparelho não está ativado.', 'villa-ibit-gestor' ) ), 404 );
		}
		$r = self::push_one( $subs[ md5( $endpoint ) ], self::message( null ) );
		if ( $r[0] ) {
			wp_send_json_success();
		}
		wp_send_json_error( array( 'message' => $r[1] ? 'HTTP ' . $r[1] : $r[2] ) );
	}

	/** O painel aberto pergunta a cada 30 s se chegou venda nova. */
	public static function ajax_poll() {
		VIG_Admin::check_ajax();
		$since = isset( $_POST['since'] ) ? (int) $_POST['since'] : time();
		$seen  = isset( $_POST['seen'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['seen'] ) ) : array();
		$items = array();
		foreach ( self::log_entries() as $e ) {
			if ( (int) $e['time'] < $since ) {
				break;
			}
			if ( in_array( $e['id'], $seen, true ) ) {
				continue;
			}
			$items[] = array(
				'id'    => $e['id'],
				'time'  => (int) $e['time'],
				'title' => $e['title'],
				'body'  => $e['body'],
				'url'   => $e['url'],
				'test'  => ! empty( $e['test'] ),
			);
		}
		wp_send_json_success(
			array(
				'items'   => array_reverse( array_slice( $items, 0, 5 ) ),
				'now'     => time(),
				'to_ship' => VIG_Admin::count_orders( 'wc-processing' ),
				'nonce'   => wp_create_nonce( 'vig_ajax' ),
			)
		);
	}

	/** Botão "Enviar aviso de teste" (todos os canais ligados). */
	public static function post_test() {
		VIG_Admin::check_post( 'vig_notify_test' );
		$latest  = wc_get_orders( array( 'limit' => 1, 'type' => 'shop_order', 'orderby' => 'date', 'order' => 'DESC' ) );
		$order   = $latest ? $latest[0] : null;
		$results = self::dispatch( $order, 'sale', true );
		$parts   = array();
		$fail    = false;
		foreach ( $results as $ch => $r ) {
			if ( null === $r ) {
				$parts[] = self::channel_label( $ch ) . ': ' . __( 'nenhum aparelho ativado', 'villa-ibit-gestor' );
				continue;
			}
			$fail    = $fail || ! $r[0];
			$parts[] = self::channel_label( $ch ) . ': ' . ( $r[0] ? '✓ ' : '✗ ' ) . $r[1];
		}
		$text = $parts ? __( 'Aviso de teste enviado.', 'villa-ibit-gestor' ) . ' ' . implode( ' · ', $parts ) : __( 'Ligue pelo menos um canal para testar.', 'villa-ibit-gestor' );
		VIG_Admin::back( admin_url( 'admin.php?page=vi-gestor-config&tab=avisos' ), $text, $fail || ! $parts );
	}

	/** Remover um aparelho da lista. */
	public static function post_remove() {
		VIG_Admin::check_post( 'vig_push_remove' );
		$key  = isset( $_REQUEST['key'] ) ? sanitize_key( wp_unslash( $_REQUEST['key'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- conferido acima.
		$subs = self::subscriptions();
		unset( $subs[ $key ] );
		self::save_subscriptions( $subs );
		VIG_Admin::back( admin_url( 'admin.php?page=vi-gestor-config&tab=avisos' ), __( 'Aparelho removido. Ele não recebe mais os avisos.', 'villa-ibit-gestor' ) );
	}

	/* ================================================================== *
	 * Telas
	 * ================================================================== */

	/** Dados para o admin.js. */
	public static function js_data() {
		$vapid = vig_value( 'notify_push', 1 ) ? self::vapid() : null;
		return array(
			'vapid' => $vapid ? $vapid['public'] : '',
			'poll'  => (bool) vig_value( 'notify_panel', 1 ),
			'sound' => (bool) vig_value( 'notify_sound', 1 ),
			'since' => time() - 120, // pega também o que chegou enquanto a tela trocava.
			'icon'  => VIG_URL . 'assets/icons/app-192.png',
		);
	}

	/** Cartão do Painel: aparece (pelo JS) só se este aparelho ainda não recebe os avisos. */
	public static function dashboard_card() {
		if ( ! vig_value( 'notify_push', 1 ) || ! self::push_supported() ) {
			return;
		}
		echo '<section class="vig-card vig-pushcard" data-vig-pushcard hidden><span class="vig-pushcard__icon">' . VIG_Admin::icon( 'bell', 24 ) . '</span><div class="vig-pushcard__body"><h2 class="vig-card__title">' . esc_html__( 'Receba um aviso a cada venda', 'villa-ibit-gestor' ) . '</h2><p class="vig-muted">' . esc_html__( 'O celular ou o computador mostra uma notificação com o valor e o cliente assim que um pedido é pago, mesmo com o painel fechado.', 'villa-ibit-gestor' ) . '</p><p class="vig-help" data-vig-push-msg hidden></p></div><div class="vig-pushcard__actions"><button type="button" class="vig-btn is-primary" data-vig-push-on>' . VIG_Admin::icon( 'bell', 16 ) . '<span>' . esc_html__( 'Ativar neste aparelho', 'villa-ibit-gestor' ) . '</span></button><button type="button" class="vig-btn is-ghost" data-vig-pushcard-close><span>' . esc_html__( 'Agora não', 'villa-ibit-gestor' ) . '</span></button></div></section>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	/** Quadro "Este aparelho" e a lista de aparelhos (Configurações › Avisos de venda). */
	public static function devices_box() {
		$subs = self::subscriptions();
		echo '<div class="vig-device" data-vig-push>';
		echo '<div class="vig-device__state"><span class="vig-device__icon">' . VIG_Admin::icon( 'phone', 20 ) . '</span><div><strong>' . esc_html__( 'Este aparelho', 'villa-ibit-gestor' ) . '</strong><span data-vig-push-status>' . esc_html__( 'Verificando…', 'villa-ibit-gestor' ) . '</span></div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<div class="vig-device__actions"><button type="button" class="vig-btn is-primary" data-vig-push-on hidden>' . VIG_Admin::icon( 'bell', 16 ) . '<span>' . esc_html__( 'Ativar avisos neste aparelho', 'villa-ibit-gestor' ) . '</span></button><button type="button" class="vig-btn is-ghost" data-vig-push-test hidden><span>' . esc_html__( 'Testar neste aparelho', 'villa-ibit-gestor' ) . '</span></button><button type="button" class="vig-btn is-ghost" data-vig-push-off hidden><span>' . esc_html__( 'Desativar neste aparelho', 'villa-ibit-gestor' ) . '</span></button></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<p class="vig-help" data-vig-push-msg hidden></p></div>';
		if ( ! self::push_supported() ) {
			echo '<p class="vig-help is-err">' . esc_html__( 'O servidor da hospedagem não tem o OpenSSL completo, então as notificações não funcionam aqui. Os avisos por e-mail e no painel continuam.', 'villa-ibit-gestor' ) . '</p>';
		}
		echo '<h3 class="vig-h3">' . esc_html__( 'Aparelhos que recebem os avisos', 'villa-ibit-gestor' ) . ' <span class="vig-badge">' . (int) count( $subs ) . '</span></h3>';
		if ( ! $subs ) {
			echo '<p class="vig-muted">' . esc_html__( 'Nenhum ainda. Abra o painel no celular (de preferência pelo app na tela inicial) e toque em "Ativar avisos neste aparelho". Repita em cada celular ou computador que deve avisar.', 'villa-ibit-gestor' ) . '</p>';
			return;
		}
		echo '<ul class="vig-list vig-devices">';
		foreach ( $subs as $key => $s ) {
			$u = ! empty( $s['user'] ) ? get_userdata( (int) $s['user'] ) : null;
			echo '<li data-endpoint="' . esc_attr( $s['endpoint'] ) . '"><span><strong>' . esc_html( $s['device'] ? $s['device'] : __( 'Aparelho', 'villa-ibit-gestor' ) ) . '</strong> <span class="vig-pill is-green" data-vig-this hidden>' . esc_html__( 'este aparelho', 'villa-ibit-gestor' ) . '</span><br><span class="vig-muted">' . esc_html( ( $u ? $u->display_name . ' · ' : '' ) . sprintf( __( 'ativado em %s', 'villa-ibit-gestor' ), wp_date( 'd/m/Y', (int) $s['created'] ) ) . ( ! empty( $s['last_ok'] ) ? ' · ' . sprintf( __( 'último aviso %s', 'villa-ibit-gestor' ), wp_date( 'd/m H:i', (int) $s['last_ok'] ) ) : '' ) ) . '</span></span>';
			// Link (e não formulário): este quadro fica dentro do formulário das configurações.
			$remove = wp_nonce_url( admin_url( 'admin-post.php?action=vig_push_remove&key=' . rawurlencode( $key ) ), 'vig_push_remove' );
			echo '<a class="vig-icon-btn is-danger" href="' . esc_url( $remove ) . '" data-vig-confirm="' . esc_attr__( 'Este aparelho vai parar de receber os avisos. Continuar?', 'villa-ibit-gestor' ) . '" title="' . esc_attr__( 'Remover', 'villa-ibit-gestor' ) . '" aria-label="' . esc_attr__( 'Remover', 'villa-ibit-gestor' ) . '">' . VIG_Admin::icon( 'trash', 16 ) . '</a></li>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</ul>';
	}

	/** Botão de teste e histórico (fora do formulário de configurações). */
	public static function test_box() {
		echo '<section class="vig-card"><div class="vig-card__head"><h2 class="vig-card__title">' . esc_html__( 'Testar os avisos', 'villa-ibit-gestor' ) . '</h2></div>';
		echo '<p class="vig-muted">' . esc_html__( 'Salve as alterações antes de testar. A WaScript recebe uma mensagem de teste. Os outros canais ligados usam os dados do último pedido, identificado como teste.', 'villa-ibit-gestor' ) . '</p>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		wp_nonce_field( 'vig_notify_test' );
		echo '<input type="hidden" name="action" value="vig_notify_test"><button class="vig-btn is-primary">' . VIG_Admin::icon( 'bell', 16 ) . '<span>' . esc_html__( 'Enviar aviso de teste', 'villa-ibit-gestor' ) . '</span></button></form>'; // phpcs:ignore WordPress.Security.EscapeOutput
		$log = self::log_entries();
		echo '<h3 class="vig-h3">' . esc_html__( 'Últimos avisos', 'villa-ibit-gestor' ) . '</h3>';
		if ( ! $log ) {
			echo '<p class="vig-muted">' . esc_html__( 'Nenhum aviso enviado ainda. Eles aparecem aqui a cada venda.', 'villa-ibit-gestor' ) . '</p></section>';
			return;
		}
		echo '<ul class="vig-list vig-notelog">';
		foreach ( array_slice( $log, 0, 10 ) as $e ) {
			echo '<li><span><a href="' . esc_url( $e['url'] ) . '">' . esc_html( $e['title'] ) . '</a><br><span class="vig-muted">' . esc_html( wp_date( 'd/m H:i', (int) $e['time'] ) ) . '</span></span><span class="vig-notelog__ch">';
			foreach ( (array) $e['results'] as $ch => $r ) {
				if ( null === $r ) {
					continue;
				}
				if ( 'wa' === $ch && ! empty( $e['order'] ) && empty( $e['test'] ) ) {
					$r = VIG_WaScript::log_result( $e['order'], $r );
				}
				$label = self::channel_label( $ch );
				$color = $r[0] ? 'is-green' : 'is-red';
				$mark  = $r[0] ? '✓ ' : '✗ ';
				if ( isset( $r[3] ) && in_array( $r[3], array( 'waiting', 'sending' ), true ) ) {
					$label .= ' (' . ( 'waiting' === $r[3] ? 'na fila' : 'enviando' ) . ')';
					$color = 'is-gold';
					$mark  = '';
				}
				echo '<span class="vig-pill ' . esc_attr( $color ) . '" title="' . esc_attr( $r[1] ) . '">' . esc_html( $mark . $label ) . '</span>';
			}
			echo '</span></li>';
		}
		echo '</ul></section>';
	}
}
