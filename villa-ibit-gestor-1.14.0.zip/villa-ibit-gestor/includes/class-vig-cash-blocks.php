<?php
/**
 * Campo de troco no checkout em blocos do WooCommerce.
 */

use Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface;
use Automattic\WooCommerce\StoreApi\Exceptions\RouteException;
use Automattic\WooCommerce\StoreApi\Schemas\V1\CheckoutSchema;

defined( 'ABSPATH' ) || exit;

final class VIG_Cash_Blocks implements IntegrationInterface {
	public static function init() {
		add_action( 'woocommerce_blocks_checkout_block_registration', static function ( $registry ) {
			$registry->register( new self() );
		} );
		add_filter( 'render_block_woocommerce/checkout-payment-block', array( __CLASS__, 'field_marker' ) );
		add_action( 'woocommerce_init', array( __CLASS__, 'register_schema' ) );
		add_action( 'woocommerce_store_api_checkout_update_order_from_request', array( __CLASS__, 'save' ), 1000, 2 );
	}

	public function get_name() {
		return 'vig-cash-change';
	}

	public function initialize() {
		wp_register_script(
			'vig-cash-change-blocks',
			VIG_URL . 'assets/cash-change-blocks.js',
			array( 'wc-blocks-checkout', 'wc-blocks-data-store', 'wc-settings', 'wp-data', 'wp-element' ),
			VIG_VER,
			true
		);
	}

	public function get_script_handles() {
		return array( 'vig-cash-change-blocks' );
	}

	public function get_editor_script_handles() {
		return array();
	}

	public function get_script_data() {
		return array( 'gateway' => VIG_Cash_Change::gateway_id() );
	}

	public static function field_marker( $content ) {
		if ( '' === VIG_Cash_Change::gateway_id() || trim( $content ) === '' ) {
			return $content;
		}
		// O Checkout hidrata os filhos identificados por data-block-name.
		return $content . '<div data-block-name="villa-ibit/checkout-cash-change"></div>';
	}

	public static function register_schema() {
		woocommerce_store_api_register_endpoint_data(
			array(
				'endpoint'        => CheckoutSchema::IDENTIFIER,
				'namespace'       => 'villa-ibit-gestor',
				'schema_callback' => static function () {
					return array(
						'cash_tendered' => array(
							'description' => 'Valor em reais que o cliente entregará em dinheiro.',
							'type'        => 'string',
							'context'     => array( 'view', 'edit' ),
						),
					);
				},
				'schema_type'     => ARRAY_A,
			)
		);
	}

	public static function save( $order, $request ) {
		if ( 'POST' !== $request->get_method() ) {
			return;
		}
		$extensions = $request->get_param( 'extensions' );
		$amount     = $extensions['villa-ibit-gestor']['cash_tendered'] ?? '';
		$result     = VIG_Cash_Change::apply_to_order( $order, $amount );
		if ( is_wp_error( $result ) ) {
			throw new RouteException( 'vig_invalid_cash_tendered', $result->get_error_message(), 400 );
		}
	}
}
