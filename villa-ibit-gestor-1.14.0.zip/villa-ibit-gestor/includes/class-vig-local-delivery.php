<?php
/**
 * Cobertura local opcional aplicada às cotações dos transportadores já instalados.
 *
 * @package VillaIbitGestor
 */
defined( 'ABSPATH' ) || exit;

final class VIG_Local_Delivery {
	private const KEY = 'local_delivery_zone';

	public static function init() {
		add_filter( 'woocommerce_cart_shipping_packages', array( __CLASS__, 'mark_packages' ), PHP_INT_MAX );
		add_filter( 'woocommerce_package_rates', array( __CLASS__, 'filter_rates' ), PHP_INT_MAX, 2 );
	}

	/** A zona precisa combinar o estado de Minas Gerais e uma lista de CEPs. */
	private static function eligible_zone( $zone ) {
		if ( ! $zone || ! $zone->get_id() ) {
			return false;
		}
		$minas_gerais = false;
		$has_postcodes = false;
		foreach ( $zone->get_zone_locations() as $location ) {
			if ( 'state' === $location->type && 'BR:MG' === strtoupper( $location->code ) ) {
				$minas_gerais = true;
			} elseif ( 'postcode' === $location->type && preg_match( '/^[0-9]/', $location->code ) ) {
				$has_postcodes = true;
			} else {
				return false;
			}
		}
		return $minas_gerais && $has_postcodes;
	}

	private static function matches( $package, $zone_id ) {
		$destination = $package['destination'] ?? array();
		$city        = trim( $destination['city'] ?? '' );
		if ( 'BR' !== strtoupper( $destination['country'] ?? '' ) || 'MG' !== strtoupper( $destination['state'] ?? '' )
			|| ! preg_match( '/^\d{5}-?\d{3}$/D', trim( $destination['postcode'] ?? '' ) ) ) {
			return false;
		}
		// Calculadoras de frete podem conhecer o CEP antes de o cliente preencher a cidade.
		if ( '' !== $city && 'governador-valadares' !== sanitize_title( $city ) ) {
			return false;
		}
		$zone = WC_Shipping_Zones::get_zone_matching_package( $package );
		return $zone && $zone_id === (int) $zone->get_id() && self::eligible_zone( $zone );
	}

	public static function mark_packages( $packages ) {
		$zone_id = absint( vig_value( self::KEY, 0 ) );
		if ( $zone_id ) {
			foreach ( $packages as $key => $package ) {
				// O WooCommerce inclui esta chave no hash das tarifas salvas na sessão.
				$packages[ $key ]['vig_delivery_scope'] = $zone_id . ( self::matches( $package, $zone_id ) ? ':in' : ':out' );
			}
		}
		return $packages;
	}

	public static function filter_rates( $rates, $package ) {
		$zone_id = absint( vig_value( self::KEY, 0 ) );
		if ( ! $zone_id || ! $rates || self::matches( $package, $zone_id ) ) {
			return $rates;
		}
		$pickup_ids = apply_filters( 'woocommerce_local_pickup_methods', array( 'local_pickup', 'legacy_local_pickup', 'pickup_location' ) );
		return array_filter( $rates, static function ( $rate ) use ( $pickup_ids ) {
			return in_array( $rate->get_method_id(), $pickup_ids, true );
		} );
	}

	public static function settings() {
		$selected = absint( vig_value( self::KEY, 0 ) );
		$choices  = array();
		foreach ( WC_Shipping_Zones::get_zones() as $row ) {
			$zone  = WC_Shipping_Zones::get_zone( $row['zone_id'] );
			if ( self::eligible_zone( $zone ) ) {
				$choices[ $zone->get_id() ] = $zone->get_zone_name();
			}
		}
		?>
		<h2 class="vig-h2"><?php esc_html_e( 'Entrega em Governador Valadares', 'villa-ibit-gestor' ); ?></h2>
		<div class="vig-field">
			<label for="vig-delivery-zone"><?php esc_html_e( 'Limitar entregas à zona de CEPs', 'villa-ibit-gestor' ); ?></label>
			<select id="vig-delivery-zone" name="vig[local_delivery_zone]" aria-describedby="vig-delivery-help">
				<option value="0" <?php selected( $selected, 0 ); ?>><?php esc_html_e( 'Usar as regras atuais do WooCommerce', 'villa-ibit-gestor' ); ?></option>
				<?php if ( $selected && ! isset( $choices[ $selected ] ) ) : ?>
					<option selected value="<?php echo esc_attr( $selected ); ?>"><?php esc_html_e( 'Entregas suspensas: revise a zona alterada ou removida', 'villa-ibit-gestor' ); ?></option>
				<?php endif; ?>
				<?php foreach ( $choices as $zone_id => $label ) : ?>
					<option value="<?php echo esc_attr( $zone_id ); ?>" <?php selected( $selected, $zone_id ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
			<p id="vig-delivery-help" class="vig-help"><?php esc_html_e( 'No WooCommerce, crie uma zona somente com Minas Gerais e os CEPs atendidos em Governador Valadares. Coloque-a acima das zonas mais amplas e adicione o serviço que faz a entrega. Depois, selecione a zona aqui e salve. Fora da área, o cliente só poderá retirar se a loja já oferecer retirada para aquele endereço.', 'villa-ibit-gestor' ); ?>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=shipping' ) ); ?>"><?php esc_html_e( 'Abrir zonas de entrega', 'villa-ibit-gestor' ); ?></a></p>
		</div>
		<?php
	}

	/** Valida também no POST a zona que o lojista selecionou na lista. */
	public static function save_choice( &$options, $choice ) {
		if ( ! is_string( $choice ) || ! preg_match( '/^\d+$/D', $choice ) ) {
			return;
		}
		$id = absint( $choice );
		if ( $id && $id !== absint( $options[ self::KEY ] ?? 0 ) && ! self::eligible_zone( WC_Shipping_Zones::get_zone( $id ) ) ) {
			wp_die( esc_html__( 'A zona escolhida precisa conter somente Minas Gerais e os CEPs atendidos. Volte e confira as configurações.', 'villa-ibit-gestor' ) );
		}
		$options[ self::KEY ] = $id;
	}
}
