<?php
/**
 * Produtos do Bling para o catálogo do WooCommerce.
 *
 * Recebe o detalhe do produto pai e saldos virtuais indexados por ID do Bling.
 * O worker serializa os lotes. O ID externo fica no primeiro save, inclusive nas variações.
 */
defined( 'ABSPATH' ) || exit;

class VIG_Bling_Product {
	const META_ID = '_vig_bling_id';

	public static function upsert( array $data, array $balances ) {
		try {
			return self::import_product( $data, $balances );
		} catch ( Exception $exception ) {
			return new WP_Error( 'vig_bling_produto', $exception->getMessage() );
		}
	}

	private static function unique_id( $key, $value ) {
		$statuses = get_post_stati();
		if ( '_sku' === $key ) {
			unset( $statuses['trash'], $statuses['auto-draft'] );
		}
		$ids = get_posts( array(
			'post_type'        => array( 'product', 'product_variation' ),
			'post_status'      => $statuses,
			'fields'           => 'ids',
			'numberposts'      => 2,
			'meta_key'         => $key,
			'meta_value'       => (string) $value,
			'suppress_filters' => true,
		) );
		if ( count( $ids ) > 1 ) {
			$message = '_sku' === $key ? sprintf( 'Mais de um produto local usa o SKU %s. Corrija a duplicidade antes de importar.', $value ) : 'Mais de um item local está vinculado ao mesmo ID do Bling.';
			throw new RuntimeException( $message );
		}
		return $ids ? (int) $ids[0] : 0;
	}

	private static function sku_id( $sku ) {
		if ( '' === $sku ) {
			return 0;
		}
		$id     = self::unique_id( '_sku', $sku );
		$lookup = (int) wc_get_product_id_by_sku( $sku );
		if ( $lookup && $id !== $lookup ) {
			throw new RuntimeException( sprintf( 'O índice de SKU do WooCommerce diverge do cadastro %s. Regenere a tabela de consulta de produtos.', $sku ) );
		}
		return $id;
	}

	/** Exclusões no ERP retiram itens vinculados da vitrine, preservando os IDs usados em pedidos. */
	public static function retire( $id ) {
		try {
			$local = self::unique_id( self::META_ID, absint( $id ) );
			if ( ! $local || 'trash' === get_post_status( $local ) ) {
				return false;
			}
			$product = wc_get_product( $local );
			if ( ! $product ) {
				throw new RuntimeException( 'O vínculo do Bling aponta para um produto indisponível.' );
			}
			$target = $product->is_type( 'variation' ) ? 'private' : 'draft';
			if ( $product->get_status( 'edit' ) === $target ) {
				return false;
			}
			$product->set_status( $target );
			$product->save();
			if ( $product->is_type( 'variation' ) ) {
				WC_Product_Variable::sync( $product->get_parent_id() );
			}
			wc_delete_product_transients( $local );
			return true;
		} catch ( Exception $exception ) {
			return new WP_Error( 'vig_bling_exclusao', $exception->getMessage() );
		}
	}

	private static function match( $external_id, $sku, $parent_id = 0 ) {
		$linked  = self::unique_id( self::META_ID, $external_id );
		$by_sku  = self::sku_id( $sku );
		if ( $linked && $by_sku && $by_sku !== $linked ) {
			throw new RuntimeException( sprintf( 'O SKU %s pertence a outro item local.', $sku ) );
		}
		$id = $linked ? $linked : $by_sku;
		if ( ! $id ) {
			return 0;
		}
		if ( 'trash' === get_post_status( $id ) ) {
			throw new RuntimeException( 'O produto vinculado está na lixeira da loja. Restaure-o antes de importar.' );
		}
		$type = get_post_type( $id );
		if ( $parent_id ? 'product_variation' !== $type || $parent_id !== (int) wp_get_post_parent_id( $id ) : 'product' !== $type ) {
			throw new RuntimeException( sprintf( 'O SKU ou ID %s pertence a um item com outro tipo ou pai.', $sku ? $sku : $external_id ) );
		}
		$owner = (string) get_post_meta( $id, self::META_ID, true );
		if ( '' !== $owner && (string) $external_id !== $owner ) {
			throw new RuntimeException( sprintf( 'O SKU %s já está ligado a outro ID do Bling.', $sku ) );
		}
		return $id;
	}

	private static function import_product( $data, $balances ) {
		$external = absint( $data['id'] ?? 0 );
		$name     = sanitize_text_field( $data['nome'] ?? '' );
		if ( ! $external || '' === $name || ! in_array( $data['situacao'] ?? '', array( 'A', 'I' ), true ) ) {
			throw new RuntimeException( 'O Bling retornou um produto sem ID, nome ou situação válidos.' );
		}
		if ( ! in_array( $data['formato'] ?? '', array( 'S', 'V', 'E' ), true ) ) {
			throw new RuntimeException( 'O Bling retornou um formato de produto desconhecido.' );
		}
		if ( ! empty( $data['idProdutoPai'] ) || ! empty( $data['variacao']['produtoPai']['id'] ) ) {
			throw new RuntimeException( 'Uma variação precisa ser importada com o produto pai.' );
		}
		$sku      = sanitize_text_field( $data['codigo'] ?? '' );
		$id       = self::match( $external, $sku );
		$existing = $id ? wc_get_product( $id ) : false;
		$variable = 'V' === ( $data['formato'] ?? '' );
		$children = $existing && $existing->is_type( 'variable' ) ? $existing->get_children() : array();
		if ( $id && ( ! $existing || ! $existing->is_type( array( 'simple', 'variable' ) ) ) ) {
			throw new RuntimeException( 'O SKU local usa um tipo de produto incompatível com a importação.' );
		}
		if ( ! $variable && $children ) {
			foreach ( $children as $child_id ) {
				if ( ! get_post_meta( $child_id, self::META_ID, true ) ) {
					throw new RuntimeException( 'O SKU está em um produto com variações locais. Confira o formato do produto pai no Bling.' );
				}
			}
		}

		$product = $variable ? new WC_Product_Variable( $id ) : new WC_Product_Simple( $id );
		$product->update_meta_data( self::META_ID, (string) $external );
		if ( array_key_exists( 'codigo', $data ) ) {
			$product->set_sku( $sku );
		}
		if ( isset( $data['tipo'] ) ) {
			$product->set_virtual( in_array( $data['tipo'], array( 'S', 'N' ), true ) );
		}
		$product->set_name( $name );
		$status = 'A' === $data['situacao'] ? 'publish' : 'draft';
		$stage_variations = $variable && ( ! $existing || 'publish' !== $existing->get_status( 'edit' ) );
		$product->set_status( $stage_variations ? 'draft' : $status );
		if ( array_key_exists( 'descricaoCurta', $data ) ) {
			$product->set_short_description( wp_kses_post( (string) $data['descricaoCurta'] ) );
		}
		if ( array_key_exists( 'descricaoComplementar', $data ) ) {
			$product->set_description( wp_kses_post( (string) $data['descricaoComplementar'] ) );
		}
		$specs = array_filter( $product->get_attributes(), static function ( $attr ) {
			return ! $attr->get_variation();
		} );
		$plan = array();
		if ( $variable ) {
			if ( ! isset( $data['variacoes'] ) || ! is_array( $data['variacoes'] ) ) {
				throw new RuntimeException( 'O Bling não retornou a lista de variações deste produto.' );
			}
			$plan = self::variation_plan( $data['variacoes'], $id, $children, $product );
			$product->set_attributes( $plan['attributes'] + $specs );
			$product->set_manage_stock( false );
			// O sincronismo das variações calculará o preço e a disponibilidade do pai.
		} else {
			$product->set_attributes( $specs );
			self::price_and_stock( $product, $data, $balances );
		}
		self::shipping( $product, $data );
		self::category( $product, $data );
		$id = $product->save();
		if ( ! $id ) {
			throw new RuntimeException( 'O WooCommerce não conseguiu salvar o produto.' );
		}
		// Produtos de exemplo que ganharam vínculo real não devem entrar na limpeza de demonstração.
		delete_post_meta( $id, '_vi_demo' );
		if ( $variable ) {
			self::save_variations( $id, $plan, $children, $balances, $data );
			if ( $product->get_status( 'edit' ) !== $status ) {
				$product->set_status( $status );
				$product->save();
			}
		} elseif ( $children ) {
			foreach ( $children as $child_id ) {
				self::disable_variation( $child_id );
			}
		}
		self::brand( $product, $data );
		self::main_image( $product, $data );
		wc_delete_product_transients( $id );
		return $id;
	}

	private static function price_and_stock( $product, $data, $balances ) {
		if ( isset( $data['preco'] ) && is_numeric( $data['preco'] ) ) {
			$regular = wc_format_decimal( max( 0, (float) $data['preco'] ) );
			$product->set_regular_price( $regular );
			if ( '' !== $product->get_sale_price( 'edit' ) && (float) $product->get_sale_price( 'edit' ) >= (float) $regular ) {
				$product->set_sale_price( '' );
			}
		}
		$qty = $balances[ $data['id'] ] ?? ( $data['estoque']['saldoVirtualTotal'] ?? null );
		if ( ! is_numeric( $qty ) ) {
			if ( ! $product->get_id() && ! $product->get_virtual( 'edit' ) ) {
				$product->set_stock_status( 'outofstock' );
			}
			return;
		}
		// Conferir o mesmo saldo não repõe as unidades vendidas desde a leitura anterior.
		$qty = max( 0, wc_stock_amount( $qty ) );
		if ( ! $product->get_manage_stock( 'edit' ) || (string) $qty !== (string) $product->get_meta( '_vig_bling_last_stock', true, 'edit' ) ) {
			$product->set_manage_stock( true );
			$product->set_stock_quantity( $qty );
			$product->set_stock_status( $qty > 0 ? 'instock' : 'outofstock' );
			$product->update_meta_data( '_vig_bling_last_stock', (string) $qty );
		}
	}

	private static function shipping( $product, $data ) {
		$weight = $data['pesoBruto'] ?? null;
		if ( is_numeric( $weight ) ) {
			$product->set_weight( wc_get_weight( $weight, get_option( 'woocommerce_weight_unit', 'kg' ), 'kg' ) );
		}
		$dims  = $data['dimensoes'] ?? array();
		$units = array( 'm', 'cm', 'mm' );
		$unit  = $units[ $dims['unidadeMedida'] ?? -1 ] ?? null;
		if ( ! $unit ) {
			return;
		}
		foreach ( array( 'largura' => 'set_width', 'altura' => 'set_height', 'profundidade' => 'set_length' ) as $key => $setter ) {
			if ( isset( $dims[ $key ] ) && is_numeric( $dims[ $key ] ) ) {
				$product->$setter( wc_get_dimension( $dims[ $key ], get_option( 'woocommerce_dimension_unit', 'cm' ), $unit ) );
			}
		}
	}

	private static function combination( $label ) {
		$result = array();
		foreach ( explode( ';', (string) $label ) as $entry ) {
			$parts = array_map( 'trim', explode( ':', $entry, 2 ) );
			if ( count( $parts ) === 1 ) {
				$parts = array( 'Opção', $parts[0] );
			}
			$name  = sanitize_text_field( $parts[0] );
			$value = str_replace( '|', '/', sanitize_text_field( $parts[1] ) );
			$key   = sanitize_title( $name );
			if ( '' === $key || '' === $value || isset( $result[ $key ] ) ) {
				throw new RuntimeException( 'O Bling retornou uma combinação de variação inválida.' );
			}
			$result[ $key ] = array( $name, $value );
		}
		return $result;
	}

	private static function combination_key( $attributes ) {
		ksort( $attributes );
		return wp_json_encode( array_map( 'wc_strtolower', $attributes ) );
	}

	/** Confere todas as combinações e conflitos de SKU antes de escrever o produto pai. */
	private static function variation_plan( $rows, $parent, $children, $product ) {
		$attributes = array();
		$labels     = array();
		$rows_out   = array();
		$linked     = array();
		$used       = array();
		$axes       = null;
		$local      = array();
		$skus       = array();
		$known      = array();
		foreach ( $children as $child_id ) {
			$child = wc_get_product( $child_id );
			if ( $child && ! $child->get_meta( self::META_ID ) ) {
				$key             = self::combination_key( $child->get_attributes() );
				$local[ $key ][] = $child;
			}
		}
		foreach ( $rows as $row ) {
			$external = absint( $row['id'] ?? 0 );
			$sku      = sanitize_text_field( $row['codigo'] ?? '' );
			if ( $external === (int) $product->get_meta( self::META_ID ) || ( '' !== $sku && 0 === strcasecmp( $sku, $product->get_sku( 'edit' ) ) ) ) {
				throw new RuntimeException( 'O produto pai e a variação precisam ter IDs e SKUs distintos.' );
			}
			if ( ! $external || isset( $known[ $external ] ) || ( '' !== $sku && isset( $skus[ wc_strtolower( $sku ) ] ) ) ) {
				throw new RuntimeException( 'Confira IDs e SKUs das variações. Há um valor duplicado ou um ID ausente.' );
			}
			$known[ $external ] = true;
			$skus[ wc_strtolower( $sku ) ] = true;
			$parts = self::combination( $row['variacao']['nome'] ?? '' );
			$keys  = array_keys( $parts );
			sort( $keys );
			if ( null !== $axes && $axes !== $keys ) {
				throw new RuntimeException( 'As variações do Bling precisam usar os mesmos atributos para formar combinações no WooCommerce.' );
			}
			$axes   = $keys;
			$values = array();
			foreach ( $parts as $key => list( $name, $value ) ) {
				$labels[ $key ]                  = $name;
				$attributes[ $key ][ $value ]    = $value;
				$values[ $key ]                  = $value;
			}
			$key = self::combination_key( $values );
			if ( isset( $used[ $key ] ) ) {
				throw new RuntimeException( 'Duas variações do Bling usam a mesma combinação de atributos.' );
			}
			$used[ $key ] = true;
			// Para um pai novo, nenhum SKU pré-existente pode apontar para uma de suas variações.
			if ( ! $parent && ( self::unique_id( self::META_ID, $external ) || self::sku_id( $sku ) ) ) {
				throw new RuntimeException( sprintf( 'A variação %s já pertence a outro produto local.', $sku ? $sku : $external ) );
			}
			$id = $parent ? self::match( $external, $sku, $parent ) : 0;
			if ( ! $id && isset( $local[ $key ] ) ) {
				$candidates = $local[ $key ];
				$candidate  = $candidates[0];
				if ( 1 !== count( $candidates ) || ( '' !== $candidate->get_sku( 'edit' ) && $candidate->get_sku( 'edit' ) !== $sku ) ) {
					throw new RuntimeException( 'Já existe uma combinação local com outro SKU. Confira o vínculo antes de importar.' );
				}
				$id = $candidate->get_id();
			}
			if ( $id && isset( $linked[ $id ] ) ) {
				throw new RuntimeException( 'Duas variações do Bling apontam para a mesma variação local.' );
			}
			$linked[ $id ] = true;
			$rows_out[]    = array( 'id' => $id, 'data' => $row, 'attributes' => $values, 'sku' => $sku );
		}
		// Não esconder sabores locais de um pai vinculado por SKU.
		foreach ( $local as $key => $items ) {
			foreach ( $items as $child ) {
				if ( isset( $linked[ $child->get_id() ] ) ) {
					continue;
				}
				$values = $child->get_attributes();
				$keys   = array_keys( $values );
				sort( $keys );
				if ( $keys !== $axes || isset( $used[ $key ] ) || in_array( '', $values, true ) ) {
					throw new RuntimeException( 'As opções locais não coincidem com os atributos do Bling. Confira o cadastro antes de vincular.' );
				}
				foreach ( $values as $axis => $value ) {
					$attributes[ $axis ][ $value ] = $value;
				}
			}
		}
		$out = array();
		foreach ( $attributes as $key => $options ) {
			$attr = new WC_Product_Attribute();
			$attr->set_name( $labels[ $key ] );
			$attr->set_options( array_values( $options ) );
			$attr->set_position( count( $out ) );
			$attr->set_visible( true );
			$attr->set_variation( true );
			$out[ $key ] = $attr;
		}
		return array( 'attributes' => $out, 'rows' => $rows_out );
	}

	private static function disable_variation( $id ) {
		$variation = wc_get_product( $id );
		if ( $variation && 'publish' === $variation->get_status( 'edit' ) ) {
			$variation->set_status( 'private' );
			$variation->save();
		}
	}

	private static function save_variations( $parent, $plan, $children, $balances, $data ) {
		$keep = array();
		foreach ( $plan['rows'] as $pos => $item ) {
			$row = $item['data'];
			$v   = new WC_Product_Variation( $item['id'] );
			$v->set_parent_id( $parent );
			$v->update_meta_data( self::META_ID, (string) $row['id'] );
			if ( array_key_exists( 'codigo', $row ) ) {
				$v->set_sku( $item['sku'] );
			}
			$type = $row['tipo'] ?? ( $data['tipo'] ?? '' );
			if ( '' !== $type ) {
				$v->set_virtual( in_array( $type, array( 'S', 'N' ), true ) );
			}
			$v->set_attributes( $item['attributes'] );
			$v->set_menu_order( absint( $row['variacao']['ordem'] ?? $pos ) );
			$v->set_status( 'A' === ( $row['situacao'] ?? $data['situacao'] ) ? 'publish' : 'private' );
			if ( ! isset( $row['preco'] ) && isset( $data['preco'] ) ) {
				$row['preco'] = $data['preco'];
			}
			self::price_and_stock( $v, $row, $balances );
			self::shipping( $v, $row );
			// Em uma retomada, não regrave as variações que o lote anterior já concluiu.
			$vid = self::save_variation_if_changed( $v );
			if ( ! $vid ) {
				throw new RuntimeException( 'O WooCommerce não conseguiu salvar uma das variações.' );
			}
			$keep[ $vid ] = true;
		}
		foreach ( $children as $id ) {
			if ( ! isset( $keep[ $id ] ) && get_post_meta( $id, self::META_ID, true ) ) {
				self::disable_variation( $id );
			}
		}
		WC_Product_Variable::sync( $parent );
	}

	private static function save_variation_if_changed( $variation ) {
		if ( ! $variation->get_id() || $variation->get_changes() ) {
			return $variation->save();
		}
		foreach ( $variation->get_meta_data() as $meta ) {
			if ( ! $meta->id || $meta->get_changes() ) {
				return $variation->save();
			}
		}
		return $variation->get_id();
	}

	private static function term( $name, $taxonomy ) {
		$name = trim( sanitize_text_field( $name ) );
		if ( '' === $name ) {
			return 0;
		}
		$term = get_term_by( 'name', $name, $taxonomy );
		if ( $term ) {
			return (int) $term->term_id;
		}
		$new = wp_insert_term( $name, $taxonomy );
		if ( is_wp_error( $new ) ) {
			if ( 'term_exists' === $new->get_error_code() ) {
				return (int) $new->get_error_data();
			}
			throw new RuntimeException( 'Não foi possível salvar a categoria ou marca do Bling.' );
		}
		return (int) $new['term_id'];
	}

	private static function category( $product, $data ) {
		if ( ! array_key_exists( '_vig_category_name', $data ) ) {
			return;
		}
		$id     = self::term( $data['_vig_category_name'], 'product_cat' );
		$former = (int) $product->get_meta( '_vig_bling_category_id' );
		$cats   = array_diff( $product->get_category_ids( 'edit' ), array( $former ) );
		if ( $id ) {
			$cats[] = $id;
		}
		$product->set_category_ids( array_unique( $cats ) );
		$product->update_meta_data( '_vig_bling_category_id', $id );
	}

	private static function brand( $product, $data ) {
		if ( ! array_key_exists( 'marca', $data ) || ! taxonomy_exists( 'product_brand' ) ) {
			return;
		}
		$id       = self::term( $data['marca'], 'product_brand' );
		$previous = (int) get_post_meta( $product->get_id(), '_vig_bling_brand_id', true );
		if ( $id && ! has_term( $id, 'product_brand', $product->get_id() ) ) {
			$result = wp_set_object_terms( $product->get_id(), array( $id ), 'product_brand', true );
			if ( is_wp_error( $result ) ) {
				throw new RuntimeException( 'Não foi possível vincular a marca do Bling.' );
			}
		}
		if ( $previous && $previous !== $id ) {
			$result = wp_remove_object_terms( $product->get_id(), array( $previous ), 'product_brand' );
			if ( is_wp_error( $result ) ) {
				throw new RuntimeException( 'Não foi possível desvincular a antiga marca do Bling.' );
			}
		}
		update_post_meta( $product->get_id(), '_vig_bling_brand_id', $id );
	}

	/** Baixa a foto principal sem expor URLs assinadas nem depender da sua validade na loja. */
	private static function main_image( $product, $data ) {
		$media = $data['midia']['imagens'] ?? array();
		$first = $media['internas'][0] ?? ( $media['externas'][0] ?? array() );
		$url   = trim( (string) ( $first['link'] ?? ( $data['imagemURL'] ?? '' ) ) );
		if ( '' === $url ) {
			$current = (int) $product->get_image_id( 'edit' );
			if ( array_key_exists( 'imagemURL', $data ) && $current && get_post_meta( $current, '_vig_bling_image', true ) ) {
				$product->set_image_id( 0 );
				$product->save();
			}
			return;
		}
		$key    = ! empty( $first['anexo']['id'] ) ? 'anexo_' . absint( $first['anexo']['id'] ) : $url;
		$hash   = hash( 'sha256', $key );
		$photo  = (int) $product->get_image_id( 'edit' );
		if ( $photo && get_post_meta( $photo, '_vig_bling_image', true ) === $hash ) {
			return;
		}
		if ( ! wp_http_validate_url( $url ) ) {
			throw new RuntimeException( 'Os dados foram importados, mas o endereço da foto não é público ou válido.' );
		}
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$tmp = wp_tempnam( 'bling-image' );
		if ( ! $tmp ) {
			throw new RuntimeException( 'Não foi possível criar o arquivo temporário da foto.' );
		}
		try {
			$max      = 8 * MB_IN_BYTES;
			$response = wp_safe_remote_get( $url, array(
				'stream' => true, 'filename' => $tmp, 'timeout' => 10, 'limit_response_size' => $max + 1,
			) );
			if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) || filesize( $tmp ) > $max ) {
				throw new RuntimeException( 'Os dados foram importados, mas a foto não foi baixada (limite de 8 MB).' );
			}
			$types = array( 'image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp', 'image/gif' => 'gif', 'image/avif' => 'avif' );
			$ext   = $types[ wp_get_image_mime( $tmp ) ] ?? '';
			if ( '' === $ext ) {
				throw new RuntimeException( 'Os dados foram importados, mas o arquivo da foto tem formato inválido.' );
			}
			$file = array( 'name' => 'bling-' . absint( $data['id'] ) . '.' . $ext, 'tmp_name' => $tmp );
			$id   = media_handle_sideload( $file, $product->get_id(), $product->get_name() );
			if ( is_wp_error( $id ) ) {
				throw new RuntimeException( 'Os dados foram importados, mas não foi possível salvar a foto na biblioteca de mídia.' );
			}
			update_post_meta( $id, '_vig_bling_image', $hash );
			$product->set_image_id( $id );
			$product->save();
		} finally {
			if ( file_exists( $tmp ) ) {
				wp_delete_file( $tmp );
			}
		}
	}
}
