<?php
/**
 * Estrutura visual do painel Villa Ibit (barra lateral, cabeçalho, ícones) e utilidades.
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;

class VIG_Admin {

	const CAP = 'manage_woocommerce';

	/**
	 * Telas do painel: slug => [rótulo, ícone, callback, grupo].
	 */
	public static function screens() {
		return array(
			'vi-gestor'            => array( __( 'Painel', 'villa-ibit-gestor' ), 'home', array( 'VIG_Dashboard', 'render' ), 'loja' ),
			'vi-gestor-pedidos'    => array( __( 'Pedidos', 'villa-ibit-gestor' ), 'bag', array( 'VIG_Orders', 'render' ), 'loja' ),
			'vi-gestor-produtos'   => array( __( 'Produtos', 'villa-ibit-gestor' ), 'box', array( 'VIG_Product_Editor', 'render_list' ), 'catalogo' ),
			'vi-gestor-produto'    => array( __( 'Novo produto', 'villa-ibit-gestor' ), 'plus', array( 'VIG_Product_Editor', 'render_form' ), 'catalogo' ),
			'vi-gestor-estoque'    => array( __( 'Estoque rápido', 'villa-ibit-gestor' ), 'layers', array( 'VIG_Products', 'render' ), 'catalogo' ),
			'vi-gestor-categorias' => array( __( 'Categorias', 'villa-ibit-gestor' ), 'grid', array( 'VIG_Terms', 'render_categories' ), 'catalogo' ),
			'vi-gestor-marcas'     => array( __( 'Marcas', 'villa-ibit-gestor' ), 'tag', array( 'VIG_Terms', 'render_brands' ), 'catalogo' ),
			'vi-gestor-cupons'     => array( __( 'Cupons', 'villa-ibit-gestor' ), 'ticket', array( 'VIG_Coupons', 'render' ), 'vendas' ),
			'vi-gestor-clientes'   => array( __( 'Clientes', 'villa-ibit-gestor' ), 'users', array( 'VIG_Customers', 'render' ), 'vendas' ),
			'vi-gestor-avaliacoes' => array( __( 'Avaliações', 'villa-ibit-gestor' ), 'star', array( 'VIG_Reviews', 'render' ), 'vendas' ),
			'vi-gestor-relatorios' => array( __( 'Relatórios', 'villa-ibit-gestor' ), 'chart', array( 'VIG_Dashboard', 'render_reports' ), 'vendas' ),
			'vi-gestor-bling'      => array( __( 'Bling', 'villa-ibit-gestor' ), 'layers', array( 'VIG_Bling', 'render' ), 'sistema' ),
			'vi-gestor-config'     => array( __( 'Configurações', 'villa-ibit-gestor' ), 'gear', array( 'VIG_Settings', 'render' ), 'sistema' ),
		);
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'admin_body_class', array( __CLASS__, 'body_class' ) );
		add_filter( 'login_redirect', array( __CLASS__, 'login_redirect' ), 20, 3 );
		add_action( 'admin_menu', array( __CLASS__, 'simplify_menu' ), 999 );
		add_filter( 'post_row_actions', array( __CLASS__, 'row_action' ), 10, 2 );
		// Painel como app no celular (atalho na tela inicial).
		add_action( 'admin_head', array( __CLASS__, 'app_head' ) );
		add_action( 'admin_post_vig_manifest', array( __CLASS__, 'manifest' ) );
		add_action( 'admin_post_nopriv_vig_manifest', array( __CLASS__, 'manifest' ) );
		add_action( 'wp_ajax_vig_sw', array( __CLASS__, 'service_worker' ) );
		add_action( 'wp_ajax_nopriv_vig_sw', array( __CLASS__, 'service_worker' ) );
		add_action( 'admin_post_vig_set_brl', function () {
			self::check_post( 'vig_set_brl' );
			wp_die( 'Configure moeda e região diretamente em WooCommerce > Configurações.', '', array( 'response' => 409 ) );
		} );
	}

	public static function is_screen() {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		return 0 === strpos( $page, 'vi-gestor' );
	}

	public static function menu() {
		$screens = self::screens();
		add_menu_page( 'Villa Ibit', 'Villa Ibit', self::CAP, 'vi-gestor', $screens['vi-gestor'][2], 'dashicons-store', 3 );
		foreach ( $screens as $slug => $s ) {
			add_submenu_page( 'vi-gestor', $s[0], $s[0], 'vi-gestor-config' === $slug ? self::CAP : self::CAP, $slug, $s[2] );
		}
	}

	public static function assets( $hook ) {
		if ( ! self::is_screen() ) {
			return;
		}
		wp_enqueue_style( 'vig-fonts', 'https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap', array(), null );
		wp_enqueue_style( 'vig-admin', VIG_URL . 'assets/admin.css', array(), VIG_VER );
		wp_enqueue_media();
		wp_enqueue_script( 'vig-admin', VIG_URL . 'assets/admin.js', array( 'jquery', 'jquery-ui-sortable' ), VIG_VER, true );
		wp_localize_script(
			'vig-admin',
			'VIG',
			array(
				'ajax'  => admin_url( 'admin-ajax.php' ),
				'nonce' => wp_create_nonce( 'vig_ajax' ),
				'notify' => class_exists( 'VIG_Notify' ) ? VIG_Notify::js_data() : array(),
				'i18n'  => array(
					'pushOn'      => __( 'Recebe um aviso a cada nova venda.', 'villa-ibit-gestor' ),
					'pushOff'     => __( 'Ainda não recebe os avisos.', 'villa-ibit-gestor' ),
					'pushDenied'  => __( 'As notificações estão bloqueadas neste navegador. Toque no cadeado ao lado do endereço (ou nas configurações do app), libere as notificações deste site e tente de novo.', 'villa-ibit-gestor' ),
					'pushIos'     => __( 'No iPhone, os avisos só funcionam pelo app: coloque o painel na Tela de Início (Compartilhar › "Adicionar à Tela de Início"), abra por lá e toque em Ativar.', 'villa-ibit-gestor' ),
					'pushNo'      => __( 'Este navegador não mostra notificações. Use o Chrome, o Edge, o Firefox ou o Safari atualizados.', 'villa-ibit-gestor' ),
					'pushOk'      => __( 'Pronto! Este aparelho vai avisar cada nova venda. Mandamos uma notificação de confirmação.', 'villa-ibit-gestor' ),
					'pushTestOk'  => __( 'Teste enviado. A notificação deve aparecer em alguns segundos.', 'villa-ibit-gestor' ),
					'pushErr'     => __( 'Não foi possível ativar. Tente de novo em instantes.', 'villa-ibit-gestor' ),
					'pushRemoved' => __( 'Avisos desativados neste aparelho.', 'villa-ibit-gestor' ),
					'liveOpen'    => __( 'Abrir pedido', 'villa-ibit-gestor' ),
					'liveClose'   => __( 'Fechar', 'villa-ibit-gestor' ),
					'liveReload'  => __( 'Atualizar a lista', 'villa-ibit-gestor' ),
					'saved'   => __( 'Salvo', 'villa-ibit-gestor' ),
					'error'   => __( 'Não foi possível salvar', 'villa-ibit-gestor' ),
					'saving'  => __( 'Salvando…', 'villa-ibit-gestor' ),
					'pick'    => __( 'Escolher imagem', 'villa-ibit-gestor' ),
					'picks'   => __( 'Escolher fotos', 'villa-ibit-gestor' ),
					'use'     => __( 'Usar', 'villa-ibit-gestor' ),
					'confirm' => __( 'Tem certeza?', 'villa-ibit-gestor' ),
				),
			)
		);
	}

	public static function body_class( $classes ) {
		return self::is_screen() ? $classes . ' vig-screen folded' : $classes;
	}

	/**
	 * Após o login, abre o painel Villa Ibit (opcional).
	 */
	public static function login_redirect( $redirect, $requested, $user ) {
		if ( vig_value( 'login_panel', 0 ) && $user instanceof WP_User && $user->has_cap( self::CAP ) && ( ! $requested || admin_url() === $requested ) ) {
			return admin_url( 'admin.php?page=vi-gestor' );
		}
		return $redirect;
	}

	/**
	 * Esconde os menus nativos de Produtos e WooCommerce (opcional) — continua acessível pelo endereço.
	 */
	public static function simplify_menu() {
		if ( ! vig_value( 'simple_menu', 0 ) ) {
			return;
		}
		remove_menu_page( 'edit.php?post_type=product' );
		remove_menu_page( 'woocommerce' );
		remove_menu_page( 'wc-admin&path=/analytics/overview' );
		remove_menu_page( 'woocommerce-marketing' );
		remove_menu_page( 'edit-comments.php' );
	}

	/**
	 * Atalho "Editar no Villa Ibit" na lista nativa de produtos.
	 */
	public static function row_action( $actions, $post ) {
		if ( 'product' === $post->post_type && current_user_can( self::CAP ) ) {
			$actions['vig_edit'] = '<a href="' . esc_url( admin_url( 'admin.php?page=vi-gestor-produto&id=' . $post->ID ) ) . '">' . esc_html__( 'Editar no Villa Ibit', 'villa-ibit-gestor' ) . '</a>';
		}
		return $actions;
	}

	/* ------------------------------------------------------------------ *
	 * Ícones
	 * ------------------------------------------------------------------ */
	public static function icon( $name, $size = 18 ) {
		$p = array(
			'home'   => '<path d="M3 10l9-7 9 7v10a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
			'bag'    => '<path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/>',
			'box'    => '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><path d="M3.27 6.96L12 12.01l8.73-5.05M12 22.08V12"/>',
			'plus'   => '<path d="M12 5v14M5 12h14"/>',
			'sync'   => '<path d="M20 7a9 9 0 0 0-15 0L3 10m0-6v6h6M4 17a9 9 0 0 0 15 0l2-3m0 6v-6h-6"/>',
			'layers' => '<path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5M2 12l10 5 10-5"/>',
			'grid'   => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
			'tag'    => '<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><circle cx="7" cy="7" r="1.2" fill="currentColor"/>',
			'ticket' => '<path d="M3 7a2 2 0 0 0 2-2h14a2 2 0 0 0 2 2v3a2 2 0 0 0 0 4v3a2 2 0 0 0-2 2H5a2 2 0 0 0-2-2v-3a2 2 0 0 0 0-4z"/><path d="M13 5v2M13 11v2M13 17v2"/>',
			'users'  => '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
			'star'   => '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
			'chart'  => '<path d="M3 3v18h18"/><path d="M7 16v-4M12 16V8M17 16v-7"/>',
			'gear'   => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
			'wand'   => '<path d="M15 4V2M15 16v-2M8 9h2M20 9h2M17.8 11.8L19 13M17.8 6.2L19 5M3 21l9-9M12.2 6.2L11 5"/>',
			'ext'    => '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3"/>',
			'edit'   => '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.12 2.12 0 0 1 3 3L12 15l-4 1 1-4z"/>',
			'trash'  => '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>',
			'copy'   => '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
			'eye'    => '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
			'print'  => '<path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
			'drag'   => '<circle cx="9" cy="6" r="1.4" fill="currentColor"/><circle cx="15" cy="6" r="1.4" fill="currentColor"/><circle cx="9" cy="12" r="1.4" fill="currentColor"/><circle cx="15" cy="12" r="1.4" fill="currentColor"/><circle cx="9" cy="18" r="1.4" fill="currentColor"/><circle cx="15" cy="18" r="1.4" fill="currentColor"/>',
			'x'      => '<path d="M18 6L6 18M6 6l12 12"/>',
			'search' => '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35"/>',
			'alert'  => '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4M12 17h.01"/>',
			'check'  => '<path d="M20 6L9 17l-5-5"/>',
			'arrow'  => '<path d="M5 12h14M12 5l7 7-7 7"/>',
			'back'   => '<path d="M19 12H5M12 19l-7-7 7-7"/>',
			'more'   => '<circle cx="5" cy="12" r="1.6" fill="currentColor"/><circle cx="12" cy="12" r="1.6" fill="currentColor"/><circle cx="19" cy="12" r="1.6" fill="currentColor"/>',
			'phone'  => '<rect x="6" y="2" width="12" height="20" rx="3"/><path d="M11 18h2"/>',
			'download' => '<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>',
			'bell'   => '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
		);
		if ( 'chat' === $name ) {
			return '<svg class="vig-i vig-i--wa" width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/></svg>';
		}
		if ( 'pix' === $name ) {
			// Símbolo oficial do PIX.
			return '<svg class="vig-i vig-i--pix" width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 24 24" aria-hidden="true"><path fill="#37B4AA" d="M5.283 18.36a3.505 3.505 0 0 0 2.493-1.032l3.6-3.6a.684.684 0 0 1 .946 0l3.613 3.613a3.504 3.504 0 0 0 2.493 1.032h.71l-4.56 4.56a3.647 3.647 0 0 1-5.156 0L4.85 18.36ZM18.428 5.627a3.505 3.505 0 0 0-2.493 1.032l-3.613 3.614a.67.67 0 0 1-.946 0l-3.6-3.6A3.505 3.505 0 0 0 5.283 5.64h-.434l4.573-4.572a3.646 3.646 0 0 1 5.156 0l4.559 4.559ZM1.068 9.422 3.79 6.699h1.492a2.483 2.483 0 0 1 1.744.722l3.6 3.6a1.73 1.73 0 0 0 2.443 0l3.614-3.613a2.482 2.482 0 0 1 1.744-.723h1.767l2.737 2.737a3.646 3.646 0 0 1 0 5.156l-2.736 2.736h-1.768a2.482 2.482 0 0 1-1.744-.722l-3.613-3.613a1.77 1.77 0 0 0-2.444 0l-3.6 3.6a2.483 2.483 0 0 1-1.744.722H3.791l-2.723-2.723a3.646 3.646 0 0 1 0-5.156"/></svg>';
		}
		return isset( $p[ $name ] ) ? '<svg class="vig-i" width="' . (int) $size . '" height="' . (int) $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $p[ $name ] . '</svg>' : '';
	}

	/* ------------------------------------------------------------------ *
	 * Estrutura da página
	 * ------------------------------------------------------------------ */

	/**
	 * Abre a tela: barra lateral + cabeçalho.
	 *
	 * @param string $current Slug da tela ativa no menu.
	 * @param string $title   Título.
	 * @param string $actions HTML dos botões do topo.
	 * @param string $sub     Subtítulo.
	 */
	public static function header( $current, $title, $actions = '', $sub = '' ) {
		$groups = array(
			'loja'     => __( 'Loja', 'villa-ibit-gestor' ),
			'catalogo' => __( 'Catálogo', 'villa-ibit-gestor' ),
			'vendas'   => __( 'Vendas e clientes', 'villa-ibit-gestor' ),
			'sistema'  => __( 'Sistema', 'villa-ibit-gestor' ),
		);
		$counts = array(
			'vi-gestor-pedidos'    => self::count_orders( 'wc-processing' ),
			'vi-gestor-avaliacoes' => (int) get_comments( array( 'type' => 'review', 'status' => 'hold', 'count' => true ) ),
		);
		echo '<div class="vig-app">';
		echo '<aside class="vig-side"><a class="vig-brand" href="' . esc_url( admin_url( 'admin.php?page=vi-gestor' ) ) . '"><span class="vig-logo">VI</span><span><strong>Villa Ibit</strong><em>' . esc_html__( 'Gestor da loja', 'villa-ibit-gestor' ) . '</em></span></a>';
		echo '<nav class="vig-nav" aria-label="' . esc_attr__( 'Menu do gestor', 'villa-ibit-gestor' ) . '">';
		foreach ( $groups as $g => $label ) {
			echo '<p class="vig-nav__group">' . esc_html( $label ) . '</p>';
			foreach ( self::screens() as $slug => $s ) {
				if ( $s[3] !== $g ) {
					continue;
				}
				$on = $slug === $current;
				echo '<a class="vig-nav__item' . ( $on ? ' is-on' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=' . $slug ) ) . '"' . ( $on ? ' aria-current="page"' : '' ) . '>' . self::icon( $s[1] ) . '<span>' . esc_html( $s[0] ) . '</span>' . ( ! empty( $counts[ $slug ] ) ? '<b class="vig-nav__count">' . (int) $counts[ $slug ] . '</b>' : '' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			if ( 'sistema' === $g && current_user_can( 'manage_options' ) ) {
				$on = 'vi-gestor-setup' === $current;
				echo '<a class="vig-nav__item' . ( $on ? ' is-on' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=vi-gestor-setup' ) ) . '">' . self::icon( 'wand' ) . '<span>' . esc_html__( 'Configurar loja', 'villa-ibit-gestor' ) . '</span></a>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
		}
		echo '</nav><a class="vig-side__store" href="' . esc_url( home_url( '/' ) ) . '" target="_blank" rel="noopener">' . self::icon( 'ext', 16 ) . esc_html__( 'Ver a loja', 'villa-ibit-gestor' ) . '</a></aside>'; // phpcs:ignore WordPress.Security.EscapeOutput
		self::mobile_nav( $current, $groups, $counts );

		echo '<main class="vig-main"><header class="vig-bar"><div><h1 class="vig-title">' . esc_html( $title ) . '</h1>' . ( $sub ? '<p class="vig-sub">' . esc_html( $sub ) . '</p>' : '' ) . '</div><div class="vig-bar__actions">' . $actions . '</div></header>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<hr class="wp-header-end">';
		self::flash();

	}

	/**
	 * Barra inferior (celular) + folha "Mais" com o menu completo.
	 */
	private static function mobile_nav( $current, $groups, $counts ) {
		$main = array(
			'vi-gestor'         => array( __( 'Painel', 'villa-ibit-gestor' ), 'home' ),
			'vi-gestor-pedidos' => array( __( 'Pedidos', 'villa-ibit-gestor' ), 'bag' ),
			'vi-gestor-estoque' => array( __( 'Estoque', 'villa-ibit-gestor' ), 'layers' ),
			'vi-gestor-produtos' => array( __( 'Produtos', 'villa-ibit-gestor' ), 'box' ),
		);
		$in_main = isset( $main[ $current ] ) || 'vi-gestor-produto' === $current;
		echo '<nav class="vig-tabbar" aria-label="' . esc_attr__( 'Atalhos do gestor', 'villa-ibit-gestor' ) . '">';
		foreach ( $main as $slug => $m ) {
			$on = $slug === $current || ( 'vi-gestor-produtos' === $slug && 'vi-gestor-produto' === $current );
			echo '<a href="' . esc_url( admin_url( 'admin.php?page=' . $slug ) ) . '"' . ( $on ? ' aria-current="page"' : '' ) . '>' . self::icon( $m[1], 22 ) . '<span>' . esc_html( $m[0] ) . '</span>' . ( ! empty( $counts[ $slug ] ) ? '<b class="vig-tabbar__count">' . (int) $counts[ $slug ] . '</b>' : '' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '<button type="button" data-vig-sheet-open aria-controls="vig-sheet" aria-expanded="false"' . ( $in_main ? '' : ' class="is-on"' ) . '>' . self::icon( 'more', 22 ) . '<span>' . esc_html__( 'Mais', 'villa-ibit-gestor' ) . '</span></button>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '</nav>';

		echo '<div class="vig-sheet" id="vig-sheet" hidden><div class="vig-sheet__backdrop" data-vig-sheet-close></div>';
		echo '<div class="vig-sheet__panel" role="dialog" aria-modal="true" aria-labelledby="vig-sheet-t"><div class="vig-sheet__head"><strong id="vig-sheet-t">' . esc_html__( 'Menu', 'villa-ibit-gestor' ) . '</strong><button type="button" class="vig-icon-btn" data-vig-sheet-close aria-label="' . esc_attr__( 'Fechar', 'villa-ibit-gestor' ) . '">' . self::icon( 'x', 18 ) . '</button></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		foreach ( $groups as $g => $label ) {
			echo '<p class="vig-sheet__group">' . esc_html( $label ) . '</p><div class="vig-sheet__grid">';
			foreach ( self::screens() as $slug => $sc ) {
				if ( $sc[3] !== $g ) {
					continue;
				}
				echo '<a class="vig-sheet__item' . ( $slug === $current ? ' is-on' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=' . $slug ) ) . '">' . self::icon( $sc[1], 22 ) . '<span>' . esc_html( $sc[0] ) . '</span>' . ( ! empty( $counts[ $slug ] ) ? '<b class="vig-tabbar__count">' . (int) $counts[ $slug ] . '</b>' : '' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			if ( 'sistema' === $g && current_user_can( 'manage_options' ) ) {
				echo '<a class="vig-sheet__item' . ( 'vi-gestor-setup' === $current ? ' is-on' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=vi-gestor-setup' ) ) . '">' . self::icon( 'wand', 22 ) . '<span>' . esc_html__( 'Configurar loja', 'villa-ibit-gestor' ) . '</span></a>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '</div>';
		}
		echo '<a class="vig-sheet__store" href="' . esc_url( home_url( '/' ) ) . '" target="_blank" rel="noopener">' . self::icon( 'ext', 16 ) . esc_html__( 'Ver a loja', 'villa-ibit-gestor' ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '</div></div>';
	}

	/* ------------------------------------------------------------------ *
	 * App no celular (manifest, ícones e service worker)
	 * ------------------------------------------------------------------ */

	/**
	 * Tags do app no <head> das telas do gestor.
	 */
	public static function app_head() {
		if ( ! self::is_screen() ) {
			return;
		}
		$icons = VIG_URL . 'assets/icons/';
		echo '<link rel="manifest" href="' . esc_url( admin_url( 'admin-post.php?action=vig_manifest' ) ) . '">' . "\n";
		echo '<meta name="theme-color" content="#023832">' . "\n";
		echo '<meta name="mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="default"><meta name="apple-mobile-web-app-title" content="Villa Ibit">' . "\n";
		echo '<link rel="apple-touch-icon" href="' . esc_url( $icons . 'apple-180.png' ) . '">' . "\n";
		echo '<link rel="icon" type="image/png" sizes="192x192" href="' . esc_url( $icons . 'app-192.png' ) . '">' . "\n";
		echo "<script>if('serviceWorker' in navigator){window.addEventListener('load',function(){navigator.serviceWorker.register(" . wp_json_encode( admin_url( 'admin-ajax.php?action=vig_sw' ) ) . ',{scope:' . wp_json_encode( wp_parse_url( admin_url(), PHP_URL_PATH ) ) . "}).catch(function(){});});}</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput
	}

	/**
	 * Dados do manifest (separado para poder testar).
	 */
	public static function manifest_data() {
		$icons = VIG_URL . 'assets/icons/';
		$page  = function ( $slug ) { return admin_url( 'admin.php?page=' . $slug ); };
		return array(
			'name'             => 'Villa Ibit Gestor',
			'short_name'       => 'Villa Ibit',
			'description'      => __( 'Pedidos, estoque e vendas da loja Villa Ibit Club.', 'villa-ibit-gestor' ),
			'lang'             => 'pt-BR',
			'start_url'        => $page( 'vi-gestor' ),
			'scope'            => admin_url(),
			'id'               => $page( 'vi-gestor' ),
			'display'          => 'standalone',
			'orientation'      => 'portrait',
			'background_color' => '#F4F9F6',
			'theme_color'      => '#023832',
			'icons'            => array(
				array( 'src' => $icons . 'app-192.png', 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any' ),
				array( 'src' => $icons . 'app-512.png', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any' ),
				array( 'src' => $icons . 'app-512.png', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'maskable' ),
			),
			'shortcuts'        => array(
				array( 'name' => __( 'Pedidos', 'villa-ibit-gestor' ), 'url' => $page( 'vi-gestor-pedidos' ), 'icons' => array( array( 'src' => $icons . 'app-192.png', 'sizes' => '192x192' ) ) ),
				array( 'name' => __( 'Estoque rápido', 'villa-ibit-gestor' ), 'url' => $page( 'vi-gestor-estoque' ), 'icons' => array( array( 'src' => $icons . 'app-192.png', 'sizes' => '192x192' ) ) ),
				array( 'name' => __( 'Novo produto', 'villa-ibit-gestor' ), 'url' => $page( 'vi-gestor-produto' ), 'icons' => array( array( 'src' => $icons . 'app-192.png', 'sizes' => '192x192' ) ) ),
			),
		);
	}

	public static function manifest() {
		nocache_headers();
		header( 'Content-Type: application/manifest+json; charset=utf-8' );
		echo wp_json_encode( self::manifest_data(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ); // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	/**
	 * Service worker: sempre busca na internet (não guarda telas do painel);
	 * sem conexão, mostra um aviso simples.
	 */
	public static function service_worker() {
		header( 'Content-Type: application/javascript; charset=utf-8' );
		header( 'Cache-Control: no-cache' );
		$offline = '<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sem conexão</title><body style="margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#F4F9F6;font-family:system-ui,sans-serif;color:#10201D;text-align:center;padding:24px"><div><div style="width:64px;height:64px;margin:0 auto 16px;border-radius:18px;background:#023832;color:#FFD695;font:800 26px/64px Georgia,serif">VI</div><h1 style="font-size:20px;margin:0 0 8px">' . esc_html__( 'Sem conexão', 'villa-ibit-gestor' ) . '</h1><p style="margin:0 0 18px;color:#55655F">' . esc_html__( 'Abra de novo quando a internet voltar.', 'villa-ibit-gestor' ) . '</p><button onclick="location.reload()" style="border:0;border-radius:12px;background:#023832;color:#fff;font-weight:700;padding:12px 20px;font-size:15px">' . esc_html__( 'Tentar de novo', 'villa-ibit-gestor' ) . '</button></div></body></html>';
		echo "self.addEventListener('install',function(){self.skipWaiting();});\n";
		echo "self.addEventListener('activate',function(e){e.waitUntil(self.clients.claim());});\n";
		echo "var OFFLINE=" . wp_json_encode( $offline ) . ";\n"; // phpcs:ignore WordPress.Security.EscapeOutput
		echo "self.addEventListener('fetch',function(e){if(e.request.mode!=='navigate'){return;}e.respondWith(fetch(e.request).catch(function(){return new Response(OFFLINE,{headers:{'Content-Type':'text/html; charset=utf-8'}});}));});\n";
		// Avisos de venda (Web Push): mostra a notificação e abre o pedido ao tocar.
		echo 'var VIG_ICON=' . wp_json_encode( VIG_URL . 'assets/icons/app-192.png' ) . ',VIG_BADGE=' . wp_json_encode( VIG_URL . 'assets/icons/badge-96.png' ) . ',VIG_START=' . wp_json_encode( admin_url( 'admin.php?page=vi-gestor-pedidos' ) ) . ";\n"; // phpcs:ignore WordPress.Security.EscapeOutput
		echo "self.addEventListener('push',function(e){var d={};try{d=e.data?e.data.json():{};}catch(x){d={body:e.data?e.data.text():''};}e.waitUntil(self.registration.showNotification(d.title||'Nova venda na loja',{body:d.body||'',icon:VIG_ICON,badge:VIG_BADGE,tag:d.tag||'vig-venda',renotify:true,vibrate:[180,80,180],data:{url:d.url||VIG_START}}));});\n";
		echo "self.addEventListener('notificationclick',function(e){e.notification.close();var url=(e.notification.data&&e.notification.data.url)||VIG_START;e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(function(list){for(var i=0;i<list.length;i++){var c=list[i];if('navigate' in c&&'focus' in c){return c.navigate(url).then(function(w){return w?w.focus():self.clients.openWindow(url);}).catch(function(){return self.clients.openWindow(url);});}}return self.clients.openWindow(url);}));});\n";
		exit;
	}

	/**
	 * Cartão "Use no celular como app" (Painel e Configurações › Painel).
	 *
	 * @param bool $dismissible Pode fechar (fica escondido neste aparelho).
	 */
	public static function app_card( $dismissible = true ) {
		echo '<section class="vig-card vig-appcard"' . ( $dismissible ? ' data-vig-appcard' : '' ) . '>';
		echo '<span class="vig-appcard__icon"><img src="' . esc_url( VIG_URL . 'assets/icons/app-192.png' ) . '" alt="" width="56" height="56"></span>';
		echo '<div class="vig-appcard__body"><h2 class="vig-card__title">' . esc_html__( 'Use o painel no celular como um app', 'villa-ibit-gestor' ) . '</h2>';
		echo '<p class="vig-muted">' . esc_html__( 'Coloque o Villa Ibit na tela inicial para abrir os pedidos com um toque, em tela cheia.', 'villa-ibit-gestor' ) . '</p>';
		echo '<div class="vig-appcard__steps">';
		echo '<p data-vig-os="android"><strong>Android (Chrome):</strong> ' . esc_html__( 'toque em "Instalar app" abaixo ou, no menu ⋮ do Chrome, em "Adicionar à tela inicial".', 'villa-ibit-gestor' ) . '</p>';
		echo '<p data-vig-os="ios"><strong>iPhone (Safari):</strong> ' . esc_html__( 'toque no botão Compartilhar (quadrado com seta) e depois em "Adicionar à Tela de Início".', 'villa-ibit-gestor' ) . '</p>';
		echo '<p data-vig-os="desktop" class="vig-muted">' . esc_html__( 'Abra este endereço no navegador do celular, entre com seu usuário e siga o passo do seu aparelho.', 'villa-ibit-gestor' ) . '</p>';
		echo '</div>';
		echo '<div class="vig-appcard__actions"><button type="button" class="vig-btn is-primary" data-vig-install hidden>' . self::icon( 'download', 16 ) . '<span>' . esc_html__( 'Instalar app', 'villa-ibit-gestor' ) . '</span></button>'; // phpcs:ignore WordPress.Security.EscapeOutput
		if ( $dismissible ) {
			echo '<button type="button" class="vig-btn is-ghost" data-vig-appcard-close><span>' . esc_html__( 'Já instalei / ocultar', 'villa-ibit-gestor' ) . '</span></button>';
		}
		if ( ! vig_value( 'login_panel', 0 ) ) {
			echo '<p class="vig-help">' . wp_kses_post( sprintf( __( 'Dica: ligue <a href="%s">"Abrir o Villa Ibit ao entrar no painel"</a> para o app abrir direto no resumo da loja.', 'villa-ibit-gestor' ), esc_url( admin_url( 'admin.php?page=vi-gestor-config&tab=painel' ) ) ) ) . '</p>';
		}
		echo '</div></div></section>';
	}

	public static function footer() {
		echo '</main></div>';
	}

	/**
	 * Mensagem após salvar (?vig_msg=...).
	 */
	public static function flash() {
		$msg = isset( $_GET['vig_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['vig_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$err = ! empty( $_GET['vig_err'] ); // phpcs:ignore WordPress.Security.NonceVerification
		if ( $msg ) {
			echo '<div class="vig-toast' . ( $err ? ' is-err' : '' ) . '" role="status">' . self::icon( $err ? 'alert' : 'check', 18 ) . '<span>' . esc_html( $msg ) . '</span></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
	}

	/**
	 * Redireciona de volta com mensagem.
	 */
	public static function back( $url, $msg, $error = false ) {
		wp_safe_redirect( add_query_arg( array( 'vig_msg' => rawurlencode( $msg ), 'vig_err' => $error ? 1 : null ), $url ) );
		exit;
	}

	/**
	 * Botão/link com ícone.
	 */
	public static function btn( $label, $url, $class = '', $icon = '', $attrs = '' ) {
		return '<a class="vig-btn ' . esc_attr( $class ) . '" href="' . esc_url( $url ) . '" ' . $attrs . '>' . ( $icon ? self::icon( $icon, 16 ) : '' ) . '<span>' . esc_html( $label ) . '</span></a>';
	}

	/**
	 * Verificação para formulários (admin-post).
	 */
	public static function check_post( $action ) {
		if ( ! current_user_can( self::CAP ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'villa-ibit-gestor' ) );
		}
		check_admin_referer( $action );
	}

	/**
	 * Verificação comum das chamadas AJAX.
	 */
	public static function check_ajax() {
		check_ajax_referer( 'vig_ajax', 'nonce' );
		if ( ! current_user_can( self::CAP ) ) {
			wp_send_json_error( array( 'message' => __( 'Sem permissão.', 'villa-ibit-gestor' ) ), 403 );
		}
	}

	public static function count_orders( $status ) {
		return count( wc_get_orders( array( 'status' => $status, 'limit' => 500, 'return' => 'ids', 'type' => 'shop_order' ) ) );
	}

	/**
	 * Número de WhatsApp a partir do telefone do cliente (Brasil).
	 */
	public static function wa_number( $phone ) {
		$digits = preg_replace( '/\D+/', '', (string) $phone );
		if ( '' === $digits ) {
			return '';
		}
		$digits = ltrim( $digits, '0' );
		if ( strlen( $digits ) <= 11 ) {
			$digits = '55' . $digits;
		}
		return $digits;
	}

	/**
	 * Selo de status do pedido.
	 */
	public static function status_badge( $status ) {
		$status = str_replace( 'wc-', '', $status );
		$label  = wc_get_order_status_name( $status );
		return '<span class="vig-status-badge is-' . esc_attr( $status ) . '">' . esc_html( $label ) . '</span>';
	}

	/**
	 * Paginação.
	 */
	public static function pager( $current, $total ) {
		if ( $total <= 1 ) {
			return;
		}
		echo '<nav class="vig-pager">' . wp_kses_post( paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'current' => $current, 'total' => $total, 'prev_text' => '‹', 'next_text' => '›' ) ) ) . '</nav>';
	}

	/**
	 * Estado vazio.
	 */
	public static function empty_state( $title, $text = '', $button = '' ) {
		echo '<div class="vig-empty-state">' . self::icon( 'box', 36 ) . '<h3>' . esc_html( $title ) . '</h3>' . ( $text ? '<p>' . esc_html( $text ) . '</p>' : '' ) . $button . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}
