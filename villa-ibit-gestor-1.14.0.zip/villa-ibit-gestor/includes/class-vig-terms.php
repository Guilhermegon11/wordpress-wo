<?php
/**
 * Categorias e marcas: lista + criar/editar com imagem, descrição e ordem.
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;

class VIG_Terms {

	public static function init() {
		add_action( 'admin_post_vig_term_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_vig_term_delete', array( __CLASS__, 'delete' ) );
	}

	private static function conf( $tax ) {
		return 'product_brand' === $tax
			? array( 'page' => 'vi-gestor-marcas', 'one' => __( 'marca', 'villa-ibit-gestor' ), 'title' => __( 'Marcas', 'villa-ibit-gestor' ), 'img' => __( 'Logo da marca', 'villa-ibit-gestor' ), 'hier' => false, 'help' => __( 'As marcas aparecem na faixa “Compre por marca”, nos filtros da loja e nas abas da home.', 'villa-ibit-gestor' ) )
			: array( 'page' => 'vi-gestor-categorias', 'one' => __( 'categoria', 'villa-ibit-gestor' ), 'title' => __( 'Categorias', 'villa-ibit-gestor' ), 'img' => __( 'Miniatura (aparece no menu e na home)', 'villa-ibit-gestor' ), 'hier' => true, 'help' => __( 'As categorias principais aparecem sozinhas no menu, na home, nos filtros e no rodapé, na ordem definida aqui.', 'villa-ibit-gestor' ) );
	}

	public static function render_categories() {
		self::render( 'product_cat' );
	}

	public static function render_brands() {
		if ( ! taxonomy_exists( 'product_brand' ) ) {
			VIG_Admin::header( 'vi-gestor-marcas', __( 'Marcas', 'villa-ibit-gestor' ) );
			VIG_Admin::empty_state( __( 'Marcas indisponíveis', 'villa-ibit-gestor' ), __( 'Atualize o WooCommerce para a versão 9.6 ou mais nova.', 'villa-ibit-gestor' ) );
			VIG_Admin::footer();
			return;
		}
		self::render( 'product_brand' );
	}

	private static function render( $tax ) {
		$c       = self::conf( $tax );
		$edit_id = isset( $_GET['editar'] ) ? absint( $_GET['editar'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$term    = $edit_id ? get_term( $edit_id, $tax ) : null;
		$term    = ( $term && ! is_wp_error( $term ) ) ? $term : null;
		$terms   = get_terms( array( 'taxonomy' => $tax, 'hide_empty' => false, 'orderby' => 'product_cat' === $tax ? 'menu_order' : 'name' ) );
		$terms   = is_wp_error( $terms ) ? array() : $terms;
		$default = (int) get_option( 'default_product_cat' );

		VIG_Admin::header( $c['page'], $c['title'], '', $c['help'] );
		echo '<div class="vig-editor">';
		echo '<div class="vig-editor__main"><section class="vig-card vig-card--flush">';
		if ( ! $terms ) {
			VIG_Admin::empty_state( sprintf( __( 'Nenhuma %s ainda', 'villa-ibit-gestor' ), $c['one'] ), __( 'Use o formulário ao lado para criar.', 'villa-ibit-gestor' ) );
		} else {
			echo '<div class="vig-table-wrap"><table class="vig-table"><thead><tr><th>' . esc_html__( 'Nome', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Produtos', 'villa-ibit-gestor' ) . '</th>' . ( $c['hier'] ? '<th>' . esc_html__( 'Ordem', 'villa-ibit-gestor' ) . '</th>' : '' ) . '<th></th></tr></thead><tbody>';
			$rows = $c['hier'] ? self::sorted_tree( $terms ) : array_map( function ( $t ) { return array( $t, 0 ); }, $terms );
			foreach ( $rows as $row ) {
				list( $t, $depth ) = $row;
				$thumb = (int) get_term_meta( $t->term_id, 'thumbnail_id', true );
				$src   = $thumb ? wp_get_attachment_image_url( $thumb, 'thumbnail' ) : '';
				echo '<tr><td><a class="vig-prod" style="padding-left:' . (int) ( $depth * 26 ) . 'px" href="' . esc_url( add_query_arg( array( 'page' => $c['page'], 'editar' => $t->term_id ), admin_url( 'admin.php' ) ) ) . '">' . ( $src ? '<img src="' . esc_url( $src ) . '" alt="">' : '<span class="vig-noimg">' . esc_html( mb_strtoupper( mb_substr( $t->name, 0, 1 ) ) ) . '</span>' ) . '<span><strong>' . esc_html( $t->name ) . '</strong><em>' . esc_html( $depth ? __( 'Subcategoria', 'villa-ibit-gestor' ) : '/' . $t->slug ) . '</em>' . ( $t->term_id === $default ? '<span class="vig-pill">' . esc_html__( 'Padrão (oculta na loja)', 'villa-ibit-gestor' ) . '</span>' : '' ) . '</span></a></td>';
				echo '<td>' . (int) $t->count . '</td>';
				if ( $c['hier'] ) {
					echo '<td>' . (int) get_term_meta( $t->term_id, 'order', true ) . '</td>';
				}
				echo '<td class="vig-row-actions"><a class="vig-icon-btn" href="' . esc_url( get_term_link( $t ) ) . '" target="_blank" aria-label="' . esc_attr__( 'Ver na loja', 'villa-ibit-gestor' ) . '">' . VIG_Admin::icon( 'eye', 16 ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
				echo '<a class="vig-icon-btn" href="' . esc_url( add_query_arg( array( 'page' => $c['page'], 'editar' => $t->term_id ), admin_url( 'admin.php' ) ) ) . '" aria-label="' . esc_attr__( 'Editar', 'villa-ibit-gestor' ) . '">' . VIG_Admin::icon( 'edit', 16 ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
				if ( $t->term_id !== $default ) {
					echo '<a class="vig-icon-btn is-danger" data-vig-confirm="' . esc_attr__( 'Excluir? Os produtos continuam cadastrados, só saem desta lista.', 'villa-ibit-gestor' ) . '" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=vig_term_delete&tax=' . $tax . '&id=' . $t->term_id ), 'vig_term_delete_' . $t->term_id ) ) . '" aria-label="' . esc_attr__( 'Excluir', 'villa-ibit-gestor' ) . '">' . VIG_Admin::icon( 'trash', 16 ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput
				}
				echo '</td></tr>';
			}
			echo '</tbody></table></div>';
		}
		echo '</section></div>';

		// Formulário.
		$thumb = $term ? (int) get_term_meta( $term->term_id, 'thumbnail_id', true ) : 0;
		?>
		<aside class="vig-editor__side">
			<form class="vig-card" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'vig_term_save' ); ?>
				<input type="hidden" name="action" value="vig_term_save"><input type="hidden" name="tax" value="<?php echo esc_attr( $tax ); ?>"><input type="hidden" name="id" value="<?php echo $term ? (int) $term->term_id : 0; ?>">
				<h2 class="vig-card__title"><?php echo esc_html( $term ? sprintf( __( 'Editar %s', 'villa-ibit-gestor' ), $c['one'] ) : sprintf( __( 'Nova %s', 'villa-ibit-gestor' ), $c['one'] ) ); ?></h2>
				<div class="vig-field"><label for="vig-tname"><?php esc_html_e( 'Nome', 'villa-ibit-gestor' ); ?> <b class="vig-req">*</b></label><input id="vig-tname" type="text" name="name" required value="<?php echo esc_attr( $term ? $term->name : '' ); ?>"></div>
				<?php if ( $c['hier'] ) : ?>
					<div class="vig-field"><label for="vig-tparent"><?php esc_html_e( 'Dentro de (opcional)', 'villa-ibit-gestor' ); ?></label><select id="vig-tparent" name="parent"><option value="0"><?php esc_html_e( '— Categoria principal —', 'villa-ibit-gestor' ); ?></option>
						<?php foreach ( $terms as $t ) { if ( $term && $t->term_id === $term->term_id ) { continue; } echo '<option value="' . (int) $t->term_id . '"' . selected( $term ? $term->parent : 0, $t->term_id, false ) . '>' . esc_html( $t->name ) . '</option>'; } ?>
					</select></div>
					<div class="vig-field"><label for="vig-torder"><?php esc_html_e( 'Ordem (menor aparece primeiro)', 'villa-ibit-gestor' ); ?></label><input id="vig-torder" type="number" name="order" value="<?php echo esc_attr( $term ? (string) (int) get_term_meta( $term->term_id, 'order', true ) : '' ); ?>" placeholder="0"></div>
				<?php endif; ?>
				<div class="vig-field"><label for="vig-tdesc"><?php esc_html_e( 'Descrição', 'villa-ibit-gestor' ); ?></label><textarea id="vig-tdesc" name="description" rows="3"><?php echo esc_textarea( $term ? $term->description : '' ); ?></textarea></div>
				<div class="vig-field" data-vig-image>
					<span class="vig-label"><?php echo esc_html( $c['img'] ); ?></span>
					<input type="hidden" name="image_id" value="<?php echo (int) $thumb; ?>">
					<button type="button" class="vig-photo-drop vig-photo-drop--sm" data-vig-pick-image>
						<img src="<?php echo esc_url( $thumb ? wp_get_attachment_image_url( $thumb, 'medium' ) : '' ); ?>" alt=""<?php echo $thumb ? '' : ' hidden'; ?>>
						<span<?php echo $thumb ? ' hidden' : ''; ?>><?php echo VIG_Admin::icon( 'plus', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e( 'Escolher imagem', 'villa-ibit-gestor' ); ?></span>
					</button>
					<button type="button" class="vig-link-btn" data-vig-clear-image><?php esc_html_e( 'Remover', 'villa-ibit-gestor' ); ?></button>
				</div>
				<button class="vig-btn is-primary is-block"><?php echo VIG_Admin::icon( 'check', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo esc_html( $term ? __( 'Salvar alterações', 'villa-ibit-gestor' ) : __( 'Criar', 'villa-ibit-gestor' ) ); ?></span></button>
				<?php if ( $term ) : ?><p class="vig-side-links"><a href="<?php echo esc_url( admin_url( 'admin.php?page=' . $c['page'] ) ); ?>"><?php esc_html_e( 'Cancelar e criar nova', 'villa-ibit-gestor' ); ?></a></p><?php endif; ?>
			</form>
		</aside>
		<?php
		echo '</div>';
		VIG_Admin::footer();
	}

	/**
	 * Árvore ordenada (pai, filhos…) com profundidade.
	 */
	private static function sorted_tree( $terms, $parent = 0, $depth = 0 ) {
		$out = array();
		foreach ( $terms as $t ) {
			if ( (int) $t->parent === (int) $parent ) {
				$out[] = array( $t, $depth );
				$out   = array_merge( $out, self::sorted_tree( $terms, $t->term_id, $depth + 1 ) );
			}
		}
		return $out;
	}

	public static function save() {
		VIG_Admin::check_post( 'vig_term_save' );
		$tax = isset( $_POST['tax'] ) && 'product_brand' === $_POST['tax'] ? 'product_brand' : 'product_cat';
		$c   = self::conf( $tax );
		$id  = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$url = admin_url( 'admin.php?page=' . $c['page'] );
		$args = array(
			'description' => isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : '',
			'parent'      => isset( $_POST['parent'] ) ? absint( $_POST['parent'] ) : 0,
		);
		$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		if ( '' === $name ) {
			VIG_Admin::back( $url, __( 'Informe o nome.', 'villa-ibit-gestor' ), true );
		}
		if ( $id ) {
			$args['name'] = $name;
			$r            = wp_update_term( $id, $tax, $args );
		} else {
			$r = wp_insert_term( $name, $tax, $args );
		}
		if ( is_wp_error( $r ) ) {
			VIG_Admin::back( $url, $r->get_error_message(), true );
		}
		$tid = (int) $r['term_id'];
		$img = isset( $_POST['image_id'] ) ? absint( $_POST['image_id'] ) : 0;
		if ( $img ) {
			update_term_meta( $tid, 'thumbnail_id', $img );
		} else {
			delete_term_meta( $tid, 'thumbnail_id' );
		}
		if ( isset( $_POST['order'] ) && '' !== $_POST['order'] ) {
			update_term_meta( $tid, 'order', (int) $_POST['order'] );
		}
		if ( function_exists( 'vi_cache_flush' ) ) {
			vi_cache_flush();
		}
		VIG_Admin::back( $url, $id ? __( 'Alterações salvas.', 'villa-ibit-gestor' ) : __( 'Criado com sucesso.', 'villa-ibit-gestor' ) );
	}

	public static function delete() {
		$id  = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		$tax = isset( $_GET['tax'] ) && 'product_brand' === $_GET['tax'] ? 'product_brand' : 'product_cat';
		if ( ! current_user_can( VIG_Admin::CAP ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'villa-ibit-gestor' ) );
		}
		check_admin_referer( 'vig_term_delete_' . $id );
		if ( 'product_cat' === $tax && (int) get_option( 'default_product_cat' ) === $id ) {
			VIG_Admin::back( admin_url( 'admin.php?page=vi-gestor-categorias' ), __( 'A categoria padrão não pode ser excluída.', 'villa-ibit-gestor' ), true );
		}
		wp_delete_term( $id, $tax );
		if ( function_exists( 'vi_cache_flush' ) ) {
			vi_cache_flush();
		}
		VIG_Admin::back( admin_url( 'admin.php?page=' . self::conf( $tax )['page'] ), __( 'Excluído.', 'villa-ibit-gestor' ) );
	}
}
