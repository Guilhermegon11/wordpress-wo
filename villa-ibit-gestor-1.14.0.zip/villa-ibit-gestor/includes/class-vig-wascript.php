<?php
/**
 * WhatsApp do administrador via WaScript.
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;
require_once __DIR__ . '/class-vig-integration-lock.php';

class VIG_WaScript {
	const TOKEN = 'vig_wascript_token';
	const JOB   = 'vig_wascript_deliver';
	const GROUP = 'villa-ibit';

	public static function init() {
		add_action( self::JOB, array( __CLASS__, 'deliver' ), 10, 3 );
		add_action( 'admin_post_vig_wascript_retry', array( __CLASS__, 'post_retry' ) );
		// O fluxo original ignora pedidos criados à mão. Este canal também atende o balcão.
		add_action( 'woocommerce_new_order', array( __CLASS__, 'order_created' ), 30, 2 );
		add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'order_changed' ), 30, 4 );
	}

	public static function provider() {
		$saved = vig_value( 'notify_wa_provider', '' );
		if ( in_array( $saved, array( 'wascript', 'callmebot' ), true ) ) {
			return $saved;
		}
		return vig_value( 'notify_wa_key', '' ) || vig_value( 'notify_wa', 0 ) ? 'callmebot' : 'wascript';
	}

	private static function active() {
		return 'wascript' === self::provider() && vig_value( 'notify_wa', 0 );
	}

	private static function token() {
		if ( defined( 'VIG_WASCRIPT_TOKEN' ) ) {
			return trim( (string) VIG_WASCRIPT_TOKEN );
		}
		$secret = get_option( self::TOKEN, '' );
		return $secret ? VIG_Secrets::open( $secret ) : '';
	}

	public static function fields() {
		$provider = self::provider();
		?>
		<div class="vig-grid2">
			<div class="vig-field"><label for="vig-wa-provider">Serviço de WhatsApp</label>
				<select id="vig-wa-provider" name="vig[notify_wa_provider]">
					<option value="wascript" <?php selected( $provider, 'wascript' ); ?>>WaScript</option>
					<option value="callmebot" <?php selected( $provider, 'callmebot' ); ?>>CallMeBot</option>
				</select></div>
			<div class="vig-field"><label for="vig-wa-phone">WhatsApp que recebe as vendas</label>
				<input type="tel" id="vig-wa-phone" name="vig[notify_wa_phone]" value="<?php echo esc_attr( (string) vig_value( 'notify_wa_phone', '' ) ); ?>">
				<p class="vig-help">Use o código do país, DDD e número. Exemplo: 5533991347344.</p></div>
		</div>
		<div class="vig-field"><label for="vig-wa-token">Token da WaScript</label>
			<?php if ( defined( 'VIG_WASCRIPT_TOKEN' ) ) : ?>
				<p class="vig-help">O token está definido no wp-config.php.</p>
			<?php else : ?>
				<input id="vig-wa-token" type="password" name="vig[wascript_token]" value="" autocomplete="new-password" placeholder="<?php echo get_option( self::TOKEN, '' ) ? 'Token salvo. Preencha para substituir.' : 'Cole o token fornecido pela WaScript'; ?>">
				<?php if ( get_option( self::TOKEN, '' ) ) : ?>
					<label><input type="checkbox" name="vig[wascript_remove]" value="1"> Apagar token salvo</label>
				<?php endif; ?>
			<?php endif; ?>
			<p class="vig-help">Conecte sua instância ao WhatsApp na WaScript, selecione WaScript acima e salve. Use “Enviar aviso de teste” no fim desta página. <a href="https://api-whatsapp.wascript.com.br/api-docs/" target="_blank" rel="noopener noreferrer">Documentação da WaScript</a>.</p>
		</div>
		<details class="vig-field"><summary>Credencial do CallMeBot</summary>
			<label for="vig-callmebot-key">Chave do CallMeBot</label>
			<input id="vig-callmebot-key" type="password" name="vig[notify_wa_key]" value="" autocomplete="new-password" placeholder="<?php echo vig_value( 'notify_wa_key', '' ) ? 'Chave salva. Preencha para substituir.' : 'Chave fornecida pelo CallMeBot'; ?>">
			<p class="vig-help">Usada quando CallMeBot estiver selecionado. <a href="https://www.callmebot.com/blog/free-api-whatsapp-messages/" target="_blank" rel="noopener noreferrer">Como obter a chave</a>.</p>
		</details>
		<?php
	}

	/** Chamado depois da conferência da permissão e do nonce do formulário. */
	public static function save_fields( $in, &$opts ) {
		$provider = $in['notify_wa_provider'] ?? self::provider();
		if ( ! in_array( $provider, array( 'wascript', 'callmebot' ), true ) ) {
			wp_die( 'Escolha WaScript ou CallMeBot.' );
		}
		$enabled = ! empty( $in['notify_wa'] );
		$phone   = isset( $in['notify_wa_phone'] ) && is_string( $in['notify_wa_phone'] ) ? preg_replace( '/\D+/', '', $in['notify_wa_phone'] ) : '';
		if ( $enabled && ! preg_match( '/^[1-9][0-9]{7,14}$/D', $phone ) ) {
			wp_die( 'Informe o WhatsApp de destino com o código do país, DDD e número.' );
		}
		$opts['notify_wa_provider'] = $provider;
		$opts['notify_wa_phone']    = $phone;
		if ( ! empty( $in['notify_wa_key'] ) && is_string( $in['notify_wa_key'] ) ) {
			$opts['notify_wa_key'] = preg_replace( '/[^A-Za-z0-9_\-]/', '', $in['notify_wa_key'] );
		}
		if ( $enabled && 'callmebot' === $provider && empty( $opts['notify_wa_key'] ) ) {
			wp_die( 'Preencha a chave do CallMeBot.' );
		}

		$new = isset( $in['wascript_token'] ) && is_string( $in['wascript_token'] ) ? trim( $in['wascript_token'] ) : '';
		$remove = ! empty( $in['wascript_remove'] );
		if ( ! defined( 'VIG_WASCRIPT_TOKEN' ) && '' !== $new && ( strlen( $new ) > 1024 || preg_match( '/[\x00-\x20\x7f]/', $new ) ) ) {
			wp_die( 'Cole o token da WaScript sem espaços ou quebras de linha.' );
		}
		$token = self::token();
		if ( ! defined( 'VIG_WASCRIPT_TOKEN' ) ) {
			if ( $remove ) {
				$token = '';
			} elseif ( '' !== $new ) {
				$token = $new;
			}
		}
		if ( $enabled && 'wascript' === $provider && ( is_wp_error( $token ) || '' === $token ) ) {
			wp_die( 'Preencha o token da WaScript ou desligue os avisos para apagar a credencial.' );
		}
		if ( ! defined( 'VIG_WASCRIPT_TOKEN' ) ) {
			if ( $remove ) {
				delete_option( self::TOKEN );
			} elseif ( '' !== $new ) {
				$sealed = VIG_Secrets::seal( $new );
				if ( is_wp_error( $sealed ) ) {
					wp_die( 'O servidor não conseguiu proteger o token. Você também pode defini-lo no wp-config.php com VIG_WASCRIPT_TOKEN.' );
				}
				if ( ! update_option( self::TOKEN, $sealed, false ) ) {
					wp_die( 'Não foi possível salvar o token da WaScript.' );
				}
			}
		}
		if ( $enabled && 'wascript' === $provider && ! self::active() ) {
			$opts['notify_wa_since'] = time();
		}
	}

	private static function eligible( $order, $stage ) {
		if ( ! $order instanceof WC_Order || $order instanceof WC_Order_Refund || ! self::active() ) {
			return false;
		}
		$created = $order->get_date_created();
		if ( $created && $created->getTimestamp() < (int) vig_value( 'notify_wa_since', 0 ) ) {
			return false;
		}
		if ( 'pending' === $stage ) {
			return $order->has_status( 'pending' ) && vig_value( 'notify_pending', 0 );
		}
		return 'sale' === $stage && $order->has_status( VIG_Notify::sale_statuses() );
	}

	public static function order_created( $id, $order = null ) {
		if ( ! self::active() ) {
			return;
		}
		$order = $order instanceof WC_Order ? $order : wc_get_order( $id );
		if ( $order instanceof WC_Order && self::eligible( $order, 'sale' ) ) {
			self::queue( $order, 'sale' );
		}
	}

	public static function order_changed( $id, $from, $to, $order ) {
		$statuses = VIG_Notify::sale_statuses();
		if ( in_array( $to, $statuses, true ) && ! in_array( $from, $statuses, true ) ) {
			self::order_created( $id, $order );
		}
	}

	private static function key( $stage ) {
		return '_vig_wascript_' . $stage;
	}

	private static function schedule( $id, $stage, $attempt, $delay = 0 ) {
		$args = array( (int) $id, $stage, (int) $attempt );
		if ( function_exists( 'as_schedule_single_action' ) ) {
			try {
				return as_has_scheduled_action( self::JOB, $args, self::GROUP )
					|| (bool) as_schedule_single_action( time() + $delay, self::JOB, $args, self::GROUP );
			} catch ( Exception $exception ) {
				return false;
			}
		}
		return wp_next_scheduled( self::JOB, $args ) || true === wp_schedule_single_event( time() + $delay, self::JOB, $args );
	}

	private static function record( $order, $stage, $state, $attempt, $detail ) {
		$data = array( 'state' => $state, 'attempt' => $attempt, 'time' => time(), 'detail' => $detail );
		$order->update_meta_data( self::key( $stage ), $data );
		$order->save_meta_data();
		return $data;
	}

	public static function queue( $order, $stage ) {
		if ( ! self::eligible( $order, $stage ) ) {
			return array( false, 'pedido fora das condições de envio do WaScript' );
		}
		$id = $order->get_id();
		$lease = VIG_Integration_Lock::acquire( 'wascript:' . $id . ':' . $stage, 180 );
		if ( is_wp_error( $lease ) ) {
			$order->add_order_note( 'WaScript: falha ao obter a trava de envio. Confira o banco de dados.' );
			return array( false, 'Falha ao agendar o aviso no banco de dados.', $stage, 'failed' );
		}
		if ( ! $lease ) {
			// Há outro callback cuidando deste pedido. O destino final é consultado no histórico.
			return array( true, 'Aviso em processamento.', $stage, 'waiting' );
		}
		try {
			$order = wc_get_order( $id );
			$old = $order->get_meta( self::key( $stage ), true );
			if ( isset( $old['state'] ) && 'skipped' !== $old['state'] ) {
				return self::result( $old, $stage );
			}
			$attempt = isset( $old['attempt'] ) ? (int) $old['attempt'] + 1 : 1;
			if ( ! self::schedule( $id, $stage, $attempt ) ) {
				$detail = 'Não foi possível agendar o aviso. Tente novamente em Avisos de venda.';
				$state = self::record( $order, $stage, 'failed', $attempt, $detail );
				$order->add_order_note( 'WaScript: ' . $detail );
			} else {
				$state = self::record( $order, $stage, 'waiting', $attempt, 'WaScript: na fila de envio.' );
			}
			return self::result( $state, $stage );
		} finally {
			VIG_Integration_Lock::release( $lease );
		}
	}

	private static function result( $state, $stage ) {
		return array( in_array( $state['state'], array( 'sent', 'waiting', 'sending' ), true ), $state['detail'], $stage, $state['state'] );
	}

	public static function log_result( $order_id, $result ) {
		if ( empty( $result[2] ) || ! in_array( $result[2], array( 'sale', 'pending' ), true ) ) {
			return $result;
		}
		$order = wc_get_order( $order_id );
		$state = $order ? $order->get_meta( self::key( $result[2] ), true ) : array();
		return isset( $state['state'] ) ? self::result( $state, $result[2] ) : $result;
	}

	private static function request( $message ) {
		$token = self::token();
		$phone = (string) vig_value( 'notify_wa_phone', '' );
		if ( is_wp_error( $token ) || '' === $token || ! preg_match( '/^[1-9][0-9]{7,14}$/D', $phone ) ) {
			return array( 'failed', 'Confira o token e o WhatsApp de destino em Avisos de venda.' );
		}
		$response = wp_remote_post(
			'https://api-whatsapp.wascript.com.br/api/enviar-texto/' . rawurlencode( $token ),
			array(
				'timeout' => 15,
				'redirection' => 0,
				'headers' => array( 'Content-Type' => 'application/json', 'Accept' => 'application/json' ),
				'body' => wp_json_encode( array( 'phone' => $phone, 'message' => $message ) ),
			)
		);
		if ( is_wp_error( $response ) ) {
			// O erro de transporte pode incluir a URL autenticada. Não registre a mensagem bruta.
			return array( 'uncertain', 'Sem confirmação de envio. Confira o WhatsApp antes de tentar novamente.' );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 === $code && true === ( $body['success'] ?? null ) ) {
			return array( 'sent', 'Envio confirmado pela WaScript.' );
		}
		if ( 429 === $code || ( 501 === $code && false === ( $body['success'] ?? null ) ) ) {
			return array( 'retry', 429 === $code ? 'A API pediu para aguardar.' : 'Instância desconectada. Reconecte o WhatsApp na WaScript.' );
		}
		if ( in_array( $code, array( 400, 401, 403, 404 ), true ) || false === ( $body['success'] ?? null ) ) {
			return array( 'failed', 'A WaScript recusou o envio (HTTP ' . $code . '). Confira a credencial, o número e a conexão da instância.' );
		}
		return array( 'uncertain', 'Resposta sem confirmação de envio (HTTP ' . $code . '). Confira o WhatsApp antes de tentar novamente.' );
	}

	public static function test() {
		list( $state, $detail ) = self::request( '[Teste] Villa Ibit: este número está configurado para receber os avisos de venda.' );
		return array( 'sent' === $state, $detail );
	}

	public static function deliver( $id, $stage, $attempt ) {
		if ( ! in_array( $stage, array( 'sale', 'pending' ), true ) ) {
			return;
		}
		$attempt = max( 1, (int) $attempt );
		$lease = VIG_Integration_Lock::acquire( 'wascript:' . $id . ':' . $stage, 180 );
		if ( is_wp_error( $lease ) ) {
			$order = wc_get_order( $id );
			if ( $order ) {
				$order->add_order_note( 'WaScript: falha no banco ao tentar obter a trava. Reenvie depois da correção.' );
			}
			return;
		}
		if ( ! $lease ) {
			// Outro processo possui a trava. Ao expirar, o estado persistido decide se há algo a fazer.
			$args = array( (int) $id, $stage, $attempt );
			if ( ! wp_next_scheduled( self::JOB, $args ) ) {
				wp_schedule_single_event( time() + 190, self::JOB, $args );
			}
			return;
		}
		try {
			$order = wc_get_order( $id );
			if ( ! $order ) {
				return;
			}
			$old = $order->get_meta( self::key( $stage ), true );
			if ( isset( $old['state'] ) && ( 'waiting' !== $old['state'] || $attempt !== (int) $old['attempt'] ) ) {
				return;
			}
			if ( ! self::eligible( $order, $stage ) ) {
				self::record( $order, $stage, 'skipped', $attempt, 'Aviso cancelado pelas configurações ou pelo status atual do pedido.' );
				return;
			}
			// Persistir antes do POST evita duplicatas inclusive se o processo cair após o envio.
			self::record( $order, $stage, 'sending', $attempt, 'Envio iniciado, aguardando confirmação.' );
			$msg = VIG_Notify::message( $order, $stage );
			list( $state, $detail ) = self::request( VIG_Notify::whatsapp_text( $msg ) );
			if ( 'retry' === $state && $attempt < 3 && self::schedule( $id, $stage, $attempt + 1, $attempt * 300 ) ) {
				self::record( $order, $stage, 'waiting', $attempt + 1, $detail . ' Nova tentativa agendada.' );
			} else {
				self::record( $order, $stage, 'retry' === $state ? 'failed' : $state, $attempt, $detail );
			}
			$order->add_order_note( 'WaScript: ' . $detail );
		} finally {
			VIG_Integration_Lock::release( $lease );
		}
	}

	public static function retry_box() {
		if ( ! self::active() ) {
			return;
		}
		?>
		<section class="vig-card"><h2 class="vig-card__title">Reenviar um aviso da WaScript</h2>
		<p class="vig-muted">Se houve falha, confira a nota do pedido e o WhatsApp de destino. Reenvie só se a mensagem não chegou.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'vig_wascript_retry' ); ?>
			<input type="hidden" name="action" value="vig_wascript_retry">
			<div class="vig-grid2">
				<div class="vig-field"><label for="vig-wa-id">ID do pedido</label><input id="vig-wa-id" type="number" name="order_id" min="1" required></div>
				<div class="vig-field"><label for="vig-wa-stage">Aviso</label><select id="vig-wa-stage" name="stage"><option value="sale">Venda</option><option value="pending">Pagamento pendente</option></select></div>
			</div>
			<p><label><input type="checkbox" name="checked_delivery" required value="1"> Conferi que esta mensagem não chegou.</label></p>
			<button class="vig-btn is-primary">Reenviar aviso</button>
		</form></section>
		<?php
	}

	private static function can_retry( $state, $id, $stage ) {
		if ( empty( $state['state'] ) ) {
			return true; // por exemplo, a primeira tentativa nem chegou a ser enfileirada.
		}
		if ( in_array( $state['state'], array( 'failed', 'uncertain' ), true ) ) {
			return true;
		}
		if ( 'sending' === $state['state'] ) {
			return (int) $state['time'] < time() - 180;
		}
		if ( 'waiting' !== $state['state'] || (int) $state['time'] >= time() - 600 ) {
			return false;
		}
		$args = array( $id, $stage, (int) $state['attempt'] );
		return ! wp_next_scheduled( self::JOB, $args ) &&
			( ! function_exists( 'as_has_scheduled_action' ) || ! as_has_scheduled_action( self::JOB, $args, self::GROUP ) );
	}

	public static function post_retry() {
		VIG_Admin::check_post( 'vig_wascript_retry' );
		$id = absint( $_POST['order_id'] ?? 0 );
		$stage = ( $_POST['stage'] ?? '' ) === 'pending' ? 'pending' : 'sale';
		$url = admin_url( 'admin.php?page=vi-gestor-config&tab=avisos' );
		if ( ! $id || empty( $_POST['checked_delivery'] ) ) {
			VIG_Admin::back( $url, 'Informe o pedido e confirme que a mensagem não chegou.', true );
			return;
		}
		$ok = false;
		$msg = 'Este aviso já foi enviado, está em andamento ou o pedido não atende aos critérios atuais.';
		$lease = VIG_Integration_Lock::acquire( 'wascript:' . $id . ':' . $stage, 180 );
		if ( $lease && ! is_wp_error( $lease ) ) {
			try {
				$order = wc_get_order( $id );
				$old = $order ? $order->get_meta( self::key( $stage ), true ) : array();
				if ( self::eligible( $order, $stage ) && self::can_retry( $old, $id, $stage ) ) {
					$attempt = (int) ( $old['attempt'] ?? 0 ) + 1;
					$ok = self::schedule( $id, $stage, $attempt );
					if ( $ok ) {
						self::record( $order, $stage, 'waiting', $attempt, 'Reenvio solicitado pelo administrador.' );
					}
					$msg = $ok ? 'Reenvio agendado. Acompanhe o resultado na nota do pedido.' : 'Não foi possível agendar o reenvio.';
				}
			} finally {
				VIG_Integration_Lock::release( $lease );
			}
		}
		if ( is_wp_error( $lease ) ) {
			$msg = 'Não foi possível obter a trava no banco de dados. Tente após corrigir a conexão.';
		}
		VIG_Admin::back( $url, $msg, ! $ok );
	}
}
