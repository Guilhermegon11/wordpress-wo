<?php
/**
 * Preços e estoque: edição rápida em uma tela só (produtos simples e cada sabor/cor das variações).
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;

class VIG_Products {

	public static function init() {
		add_action( 'wp_ajax_vig_save_product', array( __CLASS__, 'ajax_save' ) );
		add_action( 'wp_ajax_vig_bulk_products', array( __CLASS__, 'ajax_bulk' ) );
	}

	/**
	 * Itens (produtos simples ou variações) com estoque controlado e quantidade baixa.
	 *
	 * @return WC_Product[]
	 */
	public static function low_stock_items( $amount, $limit = 50 ) {
		$q = new WP_Query(
			array(
				'post_type'      => array( 'product', 'product_variation' ),
				'post_status'    => array( 'publish', 'private' ),
				'posts_per_page' => $limit,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'orderby'        => 'meta_value_num',
				'meta_key'       => '_stock', // phpcs:ignore WordPress.DB.SlowDBQuery
				'order'          => 'ASC',
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					array( 'key' => '_manage_stock', 'value' => 'yes' ),
					array( 'key' => '_stock', 'value' => (int) $amount, 'compare' => '<=', 'type' => 'NUMERIC' ),
				),
			)
		);
		$items = array();
		foreach ( $q->posts as $id ) {
			$p = wc_get_product( $id );
			if ( $p && ! $p->is_type( 'variable' ) ) {
				if ( $p->get_parent_id() && 'publish' !== get_post_status( $p->get_parent_id() ) ) {
					continue;
				}
				$items[] = $p;
			}
		}
		return $items;
	}

	/**
	 * Linha editável.
	 */
	/**
	 * Resumo dos sabores na linha do produto: faixa de preço, promoção, estoque total e disponibilidade.
	 */
	public static function parent_summary( WC_Product $p ) {
		$reg = array();
		$sal = array();
		$stock = 0;
		$managed = 0;
		$status  = array( 'instock' => 0, 'outofstock' => 0, 'onbackorder' => 0 );
		foreach ( $p->get_children() as $cid ) {
			$v = wc_get_product( $cid );
			if ( ! $v ) {
				continue;
			}
			if ( '' !== (string) $v->get_regular_price() ) {
				$reg[] = (float) $v->get_regular_price();
			}
			if ( '' !== (string) $v->get_sale_price() ) {
				$sal[] = (float) $v->get_sale_price();
			}
			if ( $v->get_manage_stock() ) {
				$managed++;
				$stock += (int) $v->get_stock_quantity();
			}
			$st = $v->get_stock_status();
			$status[ isset( $status[ $st ] ) ? $st : 'instock' ]++;
		}
		$range = function ( $list ) {
			if ( ! $list ) {
				return '—';
			}
			$min = min( $list );
			$max = max( $list );
			return $min === $max ? wc_price( $min ) : wc_price( $min ) . ' – ' . wc_price( $max );
		};
		$total = array_sum( $status );
		$avail = array();
		if ( $status['instock'] ) {
			$avail[] = sprintf( _n( '%d em estoque', '%d em estoque', $status['instock'], 'villa-ibit-gestor' ), $status['instock'] );
		}
		if ( $status['outofstock'] ) {
			$avail[] = sprintf( _n( '%d esgotado', '%d esgotados', $status['outofstock'], 'villa-ibit-gestor' ), $status['outofstock'] );
		}
		if ( $status['onbackorder'] ) {
			$avail[] = sprintf( __( '%d sob encomenda', 'villa-ibit-gestor' ), $status['onbackorder'] );
		}
		$cell = function ( $label, $main, $sub = '', $class = '' ) {
			return '<td class="vig-sum' . ( $class ? ' ' . esc_attr( $class ) : '' ) . '" data-label="' . esc_attr( $label ) . '"><strong>' . wp_kses_post( $main ) . '</strong>' . ( $sub ? '<span class="vig-muted">' . esc_html( $sub ) . '</span>' : '' ) . '</td>';
		};
		$out  = $cell( __( 'Preço', 'villa-ibit-gestor' ), $range( $reg ), count( $reg ) > 1 && min( $reg ) !== max( $reg ) ? __( 'varia por sabor', 'villa-ibit-gestor' ) : __( 'todos os sabores', 'villa-ibit-gestor' ) );
		$out .= $cell( __( 'Promoção', 'villa-ibit-gestor' ), $range( $sal ), $sal ? sprintf( _n( 'em %d sabor', 'em %d sabores', count( $sal ), 'villa-ibit-gestor' ), count( $sal ) ) : '', $sal ? 'is-sale' : '' );
		$out .= $cell( __( 'Estoque', 'villa-ibit-gestor' ), $managed ? (string) $stock : '∞', $managed ? __( 'no total', 'villa-ibit-gestor' ) : __( 'sem controle', 'villa-ibit-gestor' ), $managed && $stock <= (int) vig_value( 'low_stock', 3 ) ? 'is-low' : '' );
		$out .= $cell( __( 'Disponível', 'villa-ibit-gestor' ), $avail ? implode( ' · ', $avail ) : '—', sprintf( _n( '%d sabor', '%d sabores', $total, 'villa-ibit-gestor' ), $total ), $status['outofstock'] ? 'has-out' : '' );
		$out .= '<td class="vig-actions"></td>';
		return $out;
	}

	private static function row( WC_Product $p, $label, $class = '' ) {
		$managed = $p->get_manage_stock();
		$thumb   = $p->get_image_id() ? wp_get_attachment_image_url( $p->get_image_id(), 'thumbnail' ) : '';
		echo '<tr class="vig-row ' . esc_attr( $class ) . '" data-id="' . (int) $p->get_id() . '">';
		echo '<td class="vig-sel" data-vig-sel><input type="checkbox" class="vig-sel__box" value="' . (int) $p->get_id() . '" aria-label="' . esc_attr( sprintf( __( 'Selecionar %s', 'villa-ibit-gestor' ), wp_strip_all_tags( $p->get_name() ) ) ) . '"></td>';
		echo '<td class="vig-prod vig-cell-head">' . ( $thumb ? '<img src="' . esc_url( $thumb ) . '" alt="">' : '<span class="vig-noimg"></span>' ) . '<span>' . wp_kses_post( $label ) . ( $p->get_sku() ? '<br><span class="vig-muted">SKU ' . esc_html( $p->get_sku() ) . '</span>' : '' ) . '</span></td>';
		echo '<td data-label="' . esc_attr__( 'Preço', 'villa-ibit-gestor' ) . '"><label class="screen-reader-text">' . esc_html__( 'Preço', 'villa-ibit-gestor' ) . '</label><input class="vig-in" type="text" inputmode="decimal" name="regular" value="' . esc_attr( wc_format_localized_price( $p->get_regular_price() ) ) . '" placeholder="0,00"></td>';
		echo '<td data-label="' . esc_attr__( 'Promoção', 'villa-ibit-gestor' ) . '"><label class="screen-reader-text">' . esc_html__( 'Preço promocional', 'villa-ibit-gestor' ) . '</label><input class="vig-in" type="text" inputmode="decimal" name="sale" value="' . esc_attr( wc_format_localized_price( $p->get_sale_price() ) ) . '" placeholder="—"></td>';
		echo '<td data-label="' . esc_attr__( 'Estoque', 'villa-ibit-gestor' ) . '"><label class="screen-reader-text">' . esc_html__( 'Estoque', 'villa-ibit-gestor' ) . '</label><input class="vig-in vig-in--sm" type="number" step="1" name="stock" value="' . esc_attr( $managed ? (string) $p->get_stock_quantity() : '' ) . '" placeholder="∞"></td>';
		echo '<td data-label="' . esc_attr__( 'Disponível', 'villa-ibit-gestor' ) . '"><label class="screen-reader-text">' . esc_html__( 'Disponibilidade', 'villa-ibit-gestor' ) . '</label><select name="status" class="vig-in"' . ( $managed ? ' disabled' : '' ) . '>';
		foreach ( array( 'instock' => __( 'Em estoque', 'villa-ibit-gestor' ), 'outofstock' => __( 'Esgotado', 'villa-ibit-gestor' ), 'onbackorder' => __( 'Sob encomenda', 'villa-ibit-gestor' ) ) as $k => $l ) {
			echo '<option value="' . esc_attr( $k ) . '"' . selected( $p->get_stock_status(), $k, false ) . '>' . esc_html( $l ) . '</option>';
		}
		echo '</select></td>';
		echo '<td class="vig-actions"><button type="button" class="button button-primary" data-vig-save>' . esc_html__( 'Salvar', 'villa-ibit-gestor' ) . '</button><span class="vig-saved" aria-live="polite"></span></td>';
		echo '</tr>';
	}

	public static function render() {
		$search = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$cat    = isset( $_GET['cat'] ) ? sanitize_title( wp_unslash( $_GET['cat'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$low    = isset( $_GET['estoque'] ) && 'baixo' === $_GET['estoque']; // phpcs:ignore WordPress.Security.NonceVerification
		$paged  = max( 1, isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1 ); // phpcs:ignore WordPress.Security.NonceVerification

		VIG_Admin::header( 'vi-gestor-estoque', __( 'Estoque rápido', 'villa-ibit-gestor' ), VIG_Admin::btn( __( 'Novo produto', 'villa-ibit-gestor' ), admin_url( 'admin.php?page=vi-gestor-produto' ), 'is-primary', 'plus' ), __( 'Altere preço, promoção e estoque de vários produtos e sabores sem abrir cada um.', 'villa-ibit-gestor' ) );

		$cats = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => true ) );
		echo '<form method="get" class="vig-toolbar"><input type="hidden" name="page" value="vi-gestor-estoque">';
		echo '<div class="vig-search"><label class="screen-reader-text" for="vig-pq">' . esc_html__( 'Buscar produto', 'villa-ibit-gestor' ) . '</label><input id="vig-pq" type="search" name="q" value="' . esc_attr( $search ) . '" placeholder="' . esc_attr__( 'Buscar por nome ou SKU', 'villa-ibit-gestor' ) . '">';
		echo '<label class="screen-reader-text" for="vig-pc">' . esc_html__( 'Categoria', 'villa-ibit-gestor' ) . '</label><select id="vig-pc" name="cat"><option value="">' . esc_html__( 'Todas as categorias', 'villa-ibit-gestor' ) . '</option>';
		if ( ! is_wp_error( $cats ) ) {
			foreach ( $cats as $t ) {
				echo '<option value="' . esc_attr( $t->slug ) . '"' . selected( $cat, $t->slug, false ) . '>' . esc_html( $t->name ) . '</option>';
			}
		}
		echo '</select><label class="vig-check"><input type="checkbox" name="estoque" value="baixo"' . checked( $low, true, false ) . '> ' . esc_html__( 'Só estoque baixo', 'villa-ibit-gestor' ) . '</label><button class="button">' . esc_html__( 'Filtrar', 'villa-ibit-gestor' ) . '</button></div></form>';

		echo '<section class="vig-card vig-card--flush"><div class="vig-table-wrap"><table class="vig-table vig-stock"><thead><tr>';
		echo '<th class="vig-sel"><input type="checkbox" data-vig-sel-all aria-label="' . esc_attr__( 'Selecionar todos', 'villa-ibit-gestor' ) . '"></th><th>' . esc_html__( 'Produto / sabor', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Preço (R$)', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Promoção (R$)', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Estoque', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Disponível', 'villa-ibit-gestor' ) . '</th><th></th>';
		echo '</tr></thead><tbody>';

		$total_pages = 1;
		if ( $low ) {
			$items = self::low_stock_items( max( 0, (int) vig_value( 'low_stock', 3 ) ), 200 );
			foreach ( $items as $p ) {
				self::row( $p, '<a href="' . esc_url( admin_url( 'admin.php?page=vi-gestor-produto&id=' . ( $p->get_parent_id() ? $p->get_parent_id() : $p->get_id() ) ) ) . '">' . esc_html( wp_strip_all_tags( $p->get_formatted_name() ) ) . '</a>' );
			}
			if ( ! $items ) {
				echo '<tr><td colspan="7" class="vig-empty">' . esc_html__( 'Nenhum item com estoque baixo.', 'villa-ibit-gestor' ) . '</td></tr>';
			}
		} else {
			$args = array( 'limit' => 60, 'page' => $paged, 'paginate' => true, 'status' => array( 'publish', 'private', 'draft' ), 'orderby' => 'title', 'order' => 'ASC' );
			if ( $cat ) {
				$args['category'] = array( $cat );
			}
			if ( $search ) {
				$ids = wc_get_products( array( 'sku' => $search, 'return' => 'ids', 'limit' => 50 ) );
				$by_name = get_posts( array( 'post_type' => 'product', 's' => $search, 'fields' => 'ids', 'posts_per_page' => 100, 'post_status' => 'any' ) );
				$args['include'] = array_unique( array_merge( $ids, $by_name ) ) ? array_unique( array_merge( $ids, $by_name ) ) : array( 0 );
			}
			$result      = wc_get_products( $args );
			$total_pages = $result->max_num_pages;
			foreach ( $result->products as $p ) {
				$name = '<a class="vig-strong" href="' . esc_url( admin_url( 'admin.php?page=vi-gestor-produto&id=' . $p->get_id() ) ) . '">' . esc_html( $p->get_name() ) . '</a>';
				if ( 'publish' !== $p->get_status() ) {
					$name .= ' <span class="vig-badge">' . esc_html( get_post_status_object( $p->get_status() )->label ) . '</span>';
				}
				if ( $p->is_type( 'variable' ) ) {
					$children = $p->get_children();
					echo '<tr class="vig-parent vig-row" data-parent="' . (int) $p->get_id() . '" data-id="' . (int) $p->get_id() . '"><td class="vig-sel" data-vig-sel><input type="checkbox" class="vig-sel__box" value="' . (int) $p->get_id() . '" aria-label="' . esc_attr( sprintf( __( 'Selecionar %s (todos os sabores)', 'villa-ibit-gestor' ), $p->get_name() ) ) . '"></td><td class="vig-prod vig-cell-head">';
					$thumb = $p->get_image_id() ? wp_get_attachment_image_url( $p->get_image_id(), 'thumbnail' ) : '';
					echo ( $thumb ? '<img src="' . esc_url( $thumb ) . '" alt="">' : '<span class="vig-noimg"></span>' ) . '<span>' . wp_kses_post( $name ) . '<br><span class="vig-muted">' . esc_html( sprintf( _n( '%d variação', '%d variações (sabores/cores)', count( $children ), 'villa-ibit-gestor' ), count( $children ) ) ) . '</span></span>';
					echo '<span class="vig-bulk"><button type="button" class="button" data-vig-toggle aria-expanded="false">' . esc_html__( 'Editar sabores', 'villa-ibit-gestor' ) . '</button>';
					echo '<span class="vig-bulk__fields" hidden><input class="vig-in" type="text" inputmode="decimal" data-bulk="regular" placeholder="' . esc_attr__( 'Preço p/ todos', 'villa-ibit-gestor' ) . '"><input class="vig-in" type="text" inputmode="decimal" data-bulk="sale" placeholder="' . esc_attr__( 'Promo p/ todos', 'villa-ibit-gestor' ) . '"><button type="button" class="button" data-vig-apply>' . esc_html__( 'Aplicar', 'villa-ibit-gestor' ) . '</button><button type="button" class="button button-primary" data-vig-save-all>' . esc_html__( 'Salvar todos', 'villa-ibit-gestor' ) . '</button></span></span>';
					echo '</td>' . self::parent_summary( $p ) . '</tr>'; // phpcs:ignore WordPress.Security.EscapeOutput -- montado com esc_* abaixo.
					foreach ( $children as $child_id ) {
						$v = wc_get_product( $child_id );
						if ( $v ) {
							$attrs = wc_get_formatted_variation( $v, true, false, false );
							self::row( $v, '<span class="vig-var">' . esc_html( $attrs ? $attrs : '#' . $child_id ) . '</span>', 'vig-child vig-child-of-' . $p->get_id() . ' is-hidden' );
						}
					}
				} else {
					self::row( $p, $name );
				}
			}
			if ( ! $result->products ) {
				echo '<tr><td colspan="7" class="vig-empty">' . esc_html__( 'Nenhum produto encontrado.', 'villa-ibit-gestor' ) . '</td></tr>';
			}
		}
		echo '</tbody></table></div>';
		if ( $total_pages > 1 ) {
			echo '<div class="vig-pager">' . wp_kses_post( paginate_links( array( 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'current' => $paged, 'total' => $total_pages ) ) ) . '</div>';
		}
		echo '</section>';
		?>
		<div class="vig-bulkbar" data-vig-bulkbar hidden>
			<strong><span data-vig-sel-count>0</span> <?php esc_html_e( 'selecionado(s)', 'villa-ibit-gestor' ); ?></strong>
			<label><?php esc_html_e( 'Novo preço', 'villa-ibit-gestor' ); ?><input type="text" inputmode="decimal" data-bulk-field="price" placeholder="R$"></label>
			<label><?php esc_html_e( 'Promoção', 'villa-ibit-gestor' ); ?><input type="text" inputmode="decimal" data-bulk-field="sale" placeholder="<?php esc_attr_e( 'R$ ou 0 p/ tirar', 'villa-ibit-gestor' ); ?>"></label>
			<label><?php esc_html_e( 'Ajustar preço', 'villa-ibit-gestor' ); ?><input type="text" inputmode="decimal" data-bulk-field="adjust" placeholder="<?php esc_attr_e( 'ex.: -10% ou +5', 'villa-ibit-gestor' ); ?>"></label>
			<label><?php esc_html_e( 'Estoque', 'villa-ibit-gestor' ); ?><input type="number" min="0" data-bulk-field="stock" placeholder="—"></label>
			<button type="button" class="vig-btn is-primary" data-vig-bulk-apply><?php esc_html_e( 'Aplicar nos selecionados', 'villa-ibit-gestor' ); ?></button>
			<button type="button" class="vig-link-btn" data-vig-sel-clear><?php esc_html_e( 'Limpar seleção', 'villa-ibit-gestor' ); ?></button>
		</div>
		<?php
		echo '<p class="vig-help">' . esc_html__( 'Dica: clique e arraste com o mouse pela coluna da caixinha para selecionar vários de uma vez (Shift + clique seleciona um intervalo). Selecionar um produto com sabores aplica em todos os sabores dele.', 'villa-ibit-gestor' ) . '</p>';
		echo '<p class="vig-help">' . esc_html__( 'Estoque em branco = sem controle de quantidade (use “Disponível” para marcar como esgotado). Com quantidade preenchida, o WooCommerce baixa sozinho a cada venda e marca “Esgotado” ao chegar em zero.', 'villa-ibit-gestor' ) . '</p>';
		VIG_Admin::footer();
	}

	/**
	 * Alteração em massa: preço, promoção, ajuste (% ou R$) e estoque.
	 */
	public static function ajax_bulk() {
		VIG_Admin::check_ajax();
		$ids    = array_filter( array_map( 'absint', (array) ( $_POST['ids'] ?? array() ) ) );
		$price  = wc_format_decimal( sanitize_text_field( wp_unslash( $_POST['price'] ?? '' ) ) );
		$sale   = trim( sanitize_text_field( wp_unslash( $_POST['sale'] ?? '' ) ) );
		$adjust = trim( str_replace( ' ', '', sanitize_text_field( wp_unslash( $_POST['adjust'] ?? '' ) ) ) );
		$stock  = trim( sanitize_text_field( wp_unslash( $_POST['stock'] ?? '' ) ) );
		if ( ! $ids || ( '' === $price && '' === $sale && '' === $adjust && '' === $stock ) ) {
			wp_send_json_error( array( 'message' => __( 'Selecione itens e preencha ao menos um campo.', 'villa-ibit-gestor' ) ), 400 );
		}
		// Expande produtos com sabores para as variações.
		$targets = array();
		foreach ( $ids as $id ) {
			$p = wc_get_product( $id );
			if ( ! $p ) {
				continue;
			}
			if ( $p->is_type( 'variable' ) ) {
				foreach ( $p->get_children() as $child ) {
					$targets[ $child ] = true;
				}
			} elseif ( ! $p->is_type( array( 'grouped', 'external' ) ) ) {
				$targets[ $id ] = true;
			}
		}
		$parents = array();
		$done    = 0;
		foreach ( array_keys( $targets ) as $tid ) {
			$p = wc_get_product( $tid );
			if ( ! $p ) {
				continue;
			}
			$regular = (float) $p->get_regular_price();
			if ( '' !== $price ) {
				$regular = (float) $price;
			}
			if ( '' !== $adjust && preg_match( '/^([+-]?)(\d+(?:[.,]\d+)?)(%?)$/', $adjust, $m ) ) {
				$n       = (float) str_replace( ',', '.', $m[2] );
				$sign    = '-' === $m[1] ? -1 : 1;
				$regular = '%' === $m[3] ? $regular * ( 1 + $sign * $n / 100 ) : $regular + $sign * $n;
			}
			if ( '' !== $price || '' !== $adjust ) {
				$p->set_regular_price( wc_format_decimal( max( 0, round( $regular, wc_get_price_decimals() ) ) ) );
			}
			if ( '' !== $sale ) {
				$s = (float) wc_format_decimal( $sale );
				$p->set_sale_price( ( $s > 0 && $s < (float) $p->get_regular_price() ) ? wc_format_decimal( $s ) : '' );
			} elseif ( '' !== $p->get_sale_price() && (float) $p->get_sale_price() >= (float) $p->get_regular_price() ) {
				$p->set_sale_price( '' );
			}
			if ( '' !== $stock ) {
				$p->set_manage_stock( true );
				$p->set_stock_quantity( max( 0, (int) $stock ) );
			}
			$p->save();
			$done++;
			if ( $p->get_parent_id() ) {
				$parents[ $p->get_parent_id() ] = true;
			}
		}
		foreach ( array_keys( $parents ) as $pid ) {
			WC_Product_Variable::sync( $pid );
			wc_delete_product_transients( $pid );
		}
		if ( function_exists( 'vi_cache_flush' ) ) {
			vi_cache_flush();
		}
		wp_send_json_success( array( 'count' => $done, 'message' => sprintf( _n( '%d item atualizado.', '%d itens atualizados.', $done, 'villa-ibit-gestor' ), $done ) ) );
	}

	public static function ajax_save() {
		VIG_Admin::check_ajax();
		$p = wc_get_product( isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0 );
		if ( ! $p || $p->is_type( array( 'variable', 'grouped', 'external' ) ) ) {
			wp_send_json_error( array( 'message' => __( 'Produto inválido.', 'villa-ibit-gestor' ) ), 400 );
		}
		$regular = isset( $_POST['regular'] ) ? wc_format_decimal( sanitize_text_field( wp_unslash( $_POST['regular'] ) ) ) : '';
		$sale    = isset( $_POST['sale'] ) ? wc_format_decimal( sanitize_text_field( wp_unslash( $_POST['sale'] ) ) ) : '';
		$stock   = isset( $_POST['stock'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['stock'] ) ) ) : '';
		$status  = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : 'instock';

		if ( '' !== $sale && '' !== $regular && (float) $sale >= (float) $regular ) {
			wp_send_json_error( array( 'message' => __( 'A promoção precisa ser menor que o preço.', 'villa-ibit-gestor' ) ), 400 );
		}

		$p->set_regular_price( $regular );
		$p->set_sale_price( $sale );
		if ( '' === $stock ) {
			$p->set_manage_stock( false );
			$p->set_stock_status( in_array( $status, array( 'instock', 'outofstock', 'onbackorder' ), true ) ? $status : 'instock' );
		} else {
			$p->set_manage_stock( true );
			$p->set_stock_quantity( (int) $stock );
		}
		$p->save();

		if ( $p->get_parent_id() ) {
			WC_Product_Variable::sync( $p->get_parent_id() );
			wc_delete_product_transients( $p->get_parent_id() );
		}
		if ( function_exists( 'vi_cache_flush' ) ) {
			vi_cache_flush();
		}
		$out = array( 'stock_status' => $p->get_stock_status() );
		if ( $p->get_parent_id() ) {
			$parent = wc_get_product( $p->get_parent_id() );
			if ( $parent ) {
				$out['parent']  = (int) $parent->get_id();
				$out['summary'] = self::parent_summary( $parent );
			}
		}
		wp_send_json_success( $out );
	}
}
