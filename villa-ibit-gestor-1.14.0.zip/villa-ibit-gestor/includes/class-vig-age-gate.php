<?php
/**
 * Confirmação de idade na entrada da loja.
 *
 * @package VillaIbitGestor
 */
defined( 'ABSPATH' ) || exit;

class VIG_Age_Gate {
	private static $rendered = false;

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_filter( 'body_class', array( __CLASS__, 'body_class' ) );
		add_action( 'wp_body_open', array( __CLASS__, 'render' ), 0 );
		add_action( 'wp_footer', array( __CLASS__, 'render' ), 0 ); // Temas sem wp_body_open.
	}

	/** Zero pede a confirmação em cada página. Os demais valores válidos são dias inteiros. */
	public static function remember_days( $value ) {
		if ( ! is_int( $value ) && ! ( is_string( $value ) && preg_match( '/^[0-9]{1,2}$/D', $value ) ) ) {
			return 0;
		}
		$days = (int) $value;
		return $days >= 1 && $days <= 30 ? $days : 0;
	}

	private static function enabled() {
		if ( ! vig_value( 'age_gate', 1 ) || is_admin() || wp_doing_ajax() || is_feed() || is_customize_preview() ) {
			return false;
		}
		if ( is_user_logged_in() && did_action( 'elementor/loaded' ) ) {
			$elementor = \Elementor\Plugin::$instance;
			if ( $elementor && ( $elementor->editor->is_edit_mode() || $elementor->preview->is_preview_mode() ) ) {
				return false;
			}
		}
		return true;
	}

	public static function assets() {
		if ( self::enabled() ) {
			wp_enqueue_style( 'vig-age-gate', VIG_URL . 'assets/age-gate.css', array(), VIG_VER );
			wp_enqueue_script( 'vig-age-gate', VIG_URL . 'assets/age-gate.js', array(), VIG_VER, false );
			$days = self::remember_days( vig_value( 'age_remember_days', 0 ) );
			wp_add_inline_script( 'vig-age-gate', 'window.vigAgeRememberDays = ' . $days . ';', 'before' );
		}
	}

	public static function body_class( $classes ) {
		if ( self::enabled() ) {
			$classes[] = 'vig-age-page';
		}
		return $classes;
	}

	public static function render() {
		if ( self::$rendered || ! self::enabled() ) {
			return;
		}
		self::$rendered = true;
		// O HTML é o mesmo para todos. O cache de página pode compartilhá-lo com segurança.
		$title = trim( (string) vig_value( 'age_title' ) );
		$text  = trim( (string) vig_value( 'age_text' ) );
		$logo  = defined( 'VI_THEME_URI' ) ? VI_THEME_URI . '/assets/img/logo-dark.png' : wp_get_attachment_image_url( (int) get_theme_mod( 'custom_logo' ), 'full' );
		?>
		<dialog open id="vig-age" class="vig-age" role="dialog" aria-modal="true" aria-labelledby="vig-age-t" aria-describedby="vig-age-d">
			<div class="vig-age__card">
				<?php if ( $logo ) : ?>
					<img class="vig-age__logo" src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
				<?php else : ?>
					<span class="vig-age__brand"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
				<?php endif; ?>
				<span class="vig-age__badge">18+</span>
				<div id="vig-age-question">
					<h2 class="vig-age__title" id="vig-age-t" tabindex="-1"><?php echo esc_html( $title ?: __( 'Você tem 18 anos ou mais?', 'villa-ibit-gestor' ) ); ?></h2>
					<p class="vig-age__text" id="vig-age-d"><?php echo esc_html( $text ?: __( 'Confirme sua idade para acessar a loja.', 'villa-ibit-gestor' ) ); ?></p>
					<div class="vig-age__actions">
						<button type="button" class="vig-age__yes" data-vig-age-yes><?php esc_html_e( 'Sim, tenho 18+', 'villa-ibit-gestor' ); ?></button>
						<button type="button" class="vig-age__no" data-vig-age-no><?php esc_html_e( 'Sou menor de idade', 'villa-ibit-gestor' ); ?></button>
					</div>
					<noscript>
						<style>#vig-age .vig-age__actions{display:none}</style>
						<p class="vig-age__text"><?php esc_html_e( 'Ative o JavaScript no navegador para responder e acessar a loja.', 'villa-ibit-gestor' ); ?></p>
					</noscript>
				</div>
				<div id="vig-age-denied" hidden>
					<h2 class="vig-age__title" id="vig-age-denied-t" tabindex="-1"><?php esc_html_e( 'Acesso restrito a maiores de 18 anos', 'villa-ibit-gestor' ); ?></h2>
					<p class="vig-age__text" id="vig-age-denied-d"><?php esc_html_e( 'Você informou que é menor de idade. A loja ficará bloqueada nesta sessão.', 'villa-ibit-gestor' ); ?></p>
				</div>
			</div>
		</dialog>
		<?php
	}
}
