<?php
/**
 * Cupons, clientes e avaliações.
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;

/* ==================================================================== *
 * Cupons
 * ==================================================================== */
class VIG_Coupons {

	public static function init() {
		add_action( 'admin_post_vig_coupon_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_vig_coupon_delete', array( __CLASS__, 'delete' ) );
	}

	public static function render() {
		$edit_id = isset( $_GET['editar'] ) ? absint( $_GET['editar'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
		$coupon  = $edit_id ? new WC_Coupon( $edit_id ) : null;
		$coupon  = ( $coupon && $coupon->get_id() ) ? $coupon : null;
		$ids     = get_posts( array( 'post_type' => 'shop_coupon', 'post_status' => array( 'publish', 'draft' ), 'numberposts' => 100, 'fields' => 'ids' ) );

		VIG_Admin::header( 'vi-gestor-cupons', __( 'Cupons de desconto', 'villa-ibit-gestor' ), '', __( 'Crie códigos como PRIMEIRACOMPRA ou VIP10 para campanhas no Instagram e WhatsApp.', 'villa-ibit-gestor' ) );
		echo '<div class="vig-editor"><div class="vig-editor__main"><section class="vig-card vig-card--flush">';
		if ( ! $ids ) {
			VIG_Admin::empty_state( __( 'Nenhum cupom ainda', 'villa-ibit-gestor' ), __( 'Crie o primeiro no formulário ao lado.', 'villa-ibit-gestor' ) );
		} else {
			echo '<div class="vig-table-wrap"><table class="vig-table"><thead><tr><th>' . esc_html__( 'Código', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Desconto', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Usos', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Validade', 'villa-ibit-gestor' ) . '</th><th></th></tr></thead><tbody>';
			foreach ( $ids as $cid ) {
				$c       = new WC_Coupon( $cid );
				$expires = $c->get_date_expires();
				$expired = $expires && $expires->getTimestamp() < time();
				$amount  = 'percent' === $c->get_discount_type() ? wc_format_localized_decimal( $c->get_amount() ) . '%' : wp_strip_all_tags( wc_price( $c->get_amount() ) );
				echo '<tr><td class="vig-cell-head"><a class="vig-code" href="' . esc_url( add_query_arg( array( 'page' => 'vi-gestor-cupons', 'editar' => $cid ), admin_url( 'admin.php' ) ) ) . '">' . esc_html( strtoupper( $c->get_code() ) ) . '</a>' . ( $c->get_free_shipping() ? ' <span class="vig-pill is-green">' . esc_html__( 'frete grátis', 'villa-ibit-gestor' ) . '</span>' : '' ) . '</td>';
				echo '<td class="vig-strong" data-label="' . esc_attr__( 'Desconto', 'villa-ibit-gestor' ) . '">' . esc_html( $amount ) . ( (float) $c->get_minimum_amount() ? '<br><span class="vig-muted">' . esc_html( sprintf( __( 'mín. %s', 'villa-ibit-gestor' ), wp_strip_all_tags( wc_price( $c->get_minimum_amount() ) ) ) ) . '</span>' : '' ) . '</td>';
				echo '<td data-label="' . esc_attr__( 'Usos', 'villa-ibit-gestor' ) . '">' . (int) $c->get_usage_count() . ( $c->get_usage_limit() ? ' / ' . (int) $c->get_usage_limit() : '' ) . '</td>';
				echo '<td data-label="' . esc_attr__( 'Validade', 'villa-ibit-gestor' ) . '">' . ( $expires ? '<span class="vig-pill ' . ( $expired ? 'is-red' : '' ) . '">' . esc_html( ( $expired ? __( 'Expirou ', 'villa-ibit-gestor' ) : __( 'Até ', 'villa-ibit-gestor' ) ) . $expires->date_i18n( 'd/m/Y' ) ) . '</span>' : '<span class="vig-muted">' . esc_html__( 'Sem validade', 'villa-ibit-gestor' ) . '</span>' ) . '</td>';
				echo '<td class="vig-row-actions"><a class="vig-icon-btn" href="' . esc_url( add_query_arg( array( 'page' => 'vi-gestor-cupons', 'editar' => $cid ), admin_url( 'admin.php' ) ) ) . '" aria-label="' . esc_attr__( 'Editar', 'villa-ibit-gestor' ) . '">' . VIG_Admin::icon( 'edit', 16 ) . '</a><a class="vig-icon-btn is-danger" data-vig-confirm="' . esc_attr__( 'Excluir este cupom?', 'villa-ibit-gestor' ) . '" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=vig_coupon_delete&id=' . $cid ), 'vig_coupon_delete_' . $cid ) ) . '" aria-label="' . esc_attr__( 'Excluir', 'villa-ibit-gestor' ) . '">' . VIG_Admin::icon( 'trash', 16 ) . '</a></td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
			}
			echo '</tbody></table></div>';
		}
		echo '</section></div>';
		$exp = $coupon && $coupon->get_date_expires() ? $coupon->get_date_expires()->date( 'Y-m-d' ) : '';
		?>
		<aside class="vig-editor__side">
			<form class="vig-card" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'vig_coupon_save' ); ?>
				<input type="hidden" name="action" value="vig_coupon_save"><input type="hidden" name="id" value="<?php echo $coupon ? (int) $coupon->get_id() : 0; ?>">
				<h2 class="vig-card__title"><?php echo $coupon ? esc_html__( 'Editar cupom', 'villa-ibit-gestor' ) : esc_html__( 'Novo cupom', 'villa-ibit-gestor' ); ?></h2>
				<div class="vig-field"><label for="vig-ccode"><?php esc_html_e( 'Código', 'villa-ibit-gestor' ); ?> <b class="vig-req">*</b></label><input id="vig-ccode" type="text" name="code" required value="<?php echo esc_attr( $coupon ? strtoupper( $coupon->get_code() ) : '' ); ?>" placeholder="EX.: VIP10" style="text-transform:uppercase"></div>
				<div class="vig-grid2">
					<div class="vig-field"><label for="vig-ctype"><?php esc_html_e( 'Tipo', 'villa-ibit-gestor' ); ?></label><select id="vig-ctype" name="type"><option value="percent"<?php selected( $coupon ? $coupon->get_discount_type() : 'percent', 'percent' ); ?>><?php esc_html_e( 'Porcentagem (%)', 'villa-ibit-gestor' ); ?></option><option value="fixed_cart"<?php selected( $coupon ? $coupon->get_discount_type() : '', 'fixed_cart' ); ?>><?php esc_html_e( 'Valor fixo (R$)', 'villa-ibit-gestor' ); ?></option></select></div>
					<div class="vig-field"><label for="vig-camount"><?php esc_html_e( 'Valor', 'villa-ibit-gestor' ); ?></label><input id="vig-camount" type="text" inputmode="decimal" name="amount" value="<?php echo esc_attr( $coupon ? wc_format_localized_decimal( $coupon->get_amount() ) : '' ); ?>" placeholder="10"></div>
				</div>
				<div class="vig-grid2">
					<div class="vig-field"><label for="vig-cmin"><?php esc_html_e( 'Compra mínima (R$)', 'villa-ibit-gestor' ); ?></label><input id="vig-cmin" type="text" inputmode="decimal" name="minimum" value="<?php echo esc_attr( $coupon && (float) $coupon->get_minimum_amount() ? wc_format_localized_decimal( $coupon->get_minimum_amount() ) : '' ); ?>" placeholder="—"></div>
					<div class="vig-field"><label for="vig-climit"><?php esc_html_e( 'Limite de usos', 'villa-ibit-gestor' ); ?></label><input id="vig-climit" type="number" min="0" name="limit" value="<?php echo esc_attr( $coupon && $coupon->get_usage_limit() ? (string) $coupon->get_usage_limit() : '' ); ?>" placeholder="∞"></div>
				</div>
				<div class="vig-field"><label for="vig-cexp"><?php esc_html_e( 'Válido até', 'villa-ibit-gestor' ); ?></label><input id="vig-cexp" type="date" name="expires" value="<?php echo esc_attr( $exp ); ?>"></div>
				<label class="vig-check"><input type="checkbox" name="per_user" value="1"<?php checked( $coupon && 1 === (int) $coupon->get_usage_limit_per_user() ); ?>> <?php esc_html_e( 'Uma vez por cliente', 'villa-ibit-gestor' ); ?></label>
				<label class="vig-check"><input type="checkbox" name="free_shipping" value="1"<?php checked( $coupon && $coupon->get_free_shipping() ); ?>> <?php esc_html_e( 'Libera frete grátis', 'villa-ibit-gestor' ); ?></label>
				<label class="vig-check"><input type="checkbox" name="no_sale" value="1"<?php checked( $coupon && $coupon->get_exclude_sale_items() ); ?>> <?php esc_html_e( 'Não vale para produtos em oferta', 'villa-ibit-gestor' ); ?></label>
				<button class="vig-btn is-primary is-block"><?php echo VIG_Admin::icon( 'check', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput ?><span><?php echo $coupon ? esc_html__( 'Salvar cupom', 'villa-ibit-gestor' ) : esc_html__( 'Criar cupom', 'villa-ibit-gestor' ); ?></span></button>
				<p class="vig-help"><?php esc_html_e( 'Para frete grátis funcionar, o método "Frete grátis" precisa estar ativo na zona de entrega com a opção "requer cupom".', 'villa-ibit-gestor' ); ?></p>
			</form>
		</aside></div>
		<?php
		VIG_Admin::footer();
	}

	public static function save() {
		VIG_Admin::check_post( 'vig_coupon_save' );
		$url  = admin_url( 'admin.php?page=vi-gestor-cupons' );
		$id   = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$code = isset( $_POST['code'] ) ? wc_format_coupon_code( sanitize_text_field( wp_unslash( $_POST['code'] ) ) ) : '';
		if ( '' === $code ) {
			VIG_Admin::back( $url, __( 'Informe o código.', 'villa-ibit-gestor' ), true );
		}
		$existing = wc_get_coupon_id_by_code( $code, $id );
		if ( $existing ) {
			VIG_Admin::back( $url, __( 'Já existe um cupom com esse código.', 'villa-ibit-gestor' ), true );
		}
		$c = new WC_Coupon( $id );
		$c->set_code( $code );
		$c->set_discount_type( isset( $_POST['type'] ) && 'fixed_cart' === $_POST['type'] ? 'fixed_cart' : 'percent' );
		$c->set_amount( wc_format_decimal( isset( $_POST['amount'] ) ? sanitize_text_field( wp_unslash( $_POST['amount'] ) ) : 0 ) );
		$c->set_minimum_amount( wc_format_decimal( isset( $_POST['minimum'] ) ? sanitize_text_field( wp_unslash( $_POST['minimum'] ) ) : '' ) );
		$c->set_usage_limit( isset( $_POST['limit'] ) ? absint( $_POST['limit'] ) : 0 );
		$c->set_usage_limit_per_user( ! empty( $_POST['per_user'] ) ? 1 : 0 );
		$c->set_free_shipping( ! empty( $_POST['free_shipping'] ) );
		$c->set_exclude_sale_items( ! empty( $_POST['no_sale'] ) );
		$exp = isset( $_POST['expires'] ) ? sanitize_text_field( wp_unslash( $_POST['expires'] ) ) : '';
		$c->set_date_expires( $exp ? $exp . ' 23:59:59' : null );
		$c->save();
		VIG_Admin::back( $url, __( 'Cupom salvo.', 'villa-ibit-gestor' ) );
	}

	public static function delete() {
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		if ( ! current_user_can( VIG_Admin::CAP ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'villa-ibit-gestor' ) );
		}
		check_admin_referer( 'vig_coupon_delete_' . $id );
		wp_delete_post( $id, true );
		VIG_Admin::back( admin_url( 'admin.php?page=vi-gestor-cupons' ), __( 'Cupom excluído.', 'villa-ibit-gestor' ) );
	}
}

/* ==================================================================== *
 * Clientes
 * ==================================================================== */
class VIG_Customers {

	public static function init() {}

	public static function render() {
		$q     = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		$paged = max( 1, isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1 ); // phpcs:ignore WordPress.Security.NonceVerification
		$args  = array( 'role__in' => array( 'customer' ), 'number' => 25, 'paged' => $paged, 'orderby' => 'registered', 'order' => 'DESC', 'count_total' => true );
		if ( $q ) {
			$args['search']         = '*' . $q . '*';
			$args['search_columns'] = array( 'user_login', 'user_email', 'display_name' );
		}
		$users = new WP_User_Query( $args );
		$total = (int) $users->get_total();

		VIG_Admin::header( 'vi-gestor-clientes', __( 'Clientes', 'villa-ibit-gestor' ), '', sprintf( _n( '%d cliente cadastrado', '%d clientes cadastrados', $total, 'villa-ibit-gestor' ), $total ) );
		echo '<div class="vig-toolbar"><span></span><form method="get" class="vig-search"><input type="hidden" name="page" value="vi-gestor-clientes"><span class="vig-search__box">' . VIG_Admin::icon( 'search', 16 ) . '<label class="screen-reader-text" for="vig-cq">' . esc_html__( 'Buscar cliente', 'villa-ibit-gestor' ) . '</label><input id="vig-cq" type="search" name="q" value="' . esc_attr( $q ) . '" placeholder="' . esc_attr__( 'Nome ou e-mail', 'villa-ibit-gestor' ) . '"></span></form></div>'; // phpcs:ignore WordPress.Security.EscapeOutput

		if ( ! $users->get_results() ) {
			VIG_Admin::empty_state( __( 'Nenhum cliente encontrado', 'villa-ibit-gestor' ), __( 'Os clientes aparecem aqui quando criam conta na loja.', 'villa-ibit-gestor' ) );
			VIG_Admin::footer();
			return;
		}
		echo '<section class="vig-card vig-card--flush"><div class="vig-table-wrap"><table class="vig-table"><thead><tr><th>' . esc_html__( 'Cliente', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Cidade', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Pedidos', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Total gasto', 'villa-ibit-gestor' ) . '</th><th>' . esc_html__( 'Cliente desde', 'villa-ibit-gestor' ) . '</th><th></th></tr></thead><tbody>';
		foreach ( $users->get_results() as $u ) {
			$customer = new WC_Customer( $u->ID );
			$name     = trim( $customer->get_first_name() . ' ' . $customer->get_last_name() );
			$name     = $name ? $name : $u->display_name;
			$wa       = VIG_Admin::wa_number( $customer->get_billing_phone() );
			$orders   = (int) wc_get_customer_order_count( $u->ID );
			echo '<tr><td class="vig-cell-head"><span class="vig-avatar">' . esc_html( mb_strtoupper( mb_substr( $name, 0, 1 ) ) ) . '</span><strong>' . esc_html( $name ) . '</strong><br><span class="vig-muted">' . esc_html( $u->user_email ) . '</span></td>';
			echo '<td data-label="' . esc_attr__( 'Cidade', 'villa-ibit-gestor' ) . '">' . esc_html( trim( $customer->get_billing_city() . ( $customer->get_billing_state() ? ' / ' . $customer->get_billing_state() : '' ), ' /' ) ) . '</td>';
			echo '<td data-label="' . esc_attr__( 'Pedidos', 'villa-ibit-gestor' ) . '">' . ( $orders ? '<a href="' . esc_url( add_query_arg( 'cliente', $u->ID, VIG_Orders::url() ) ) . '">' . (int) $orders . '</a>' : '0' ) . '</td>';
			echo '<td class="vig-strong" data-label="' . esc_attr__( 'Total gasto', 'villa-ibit-gestor' ) . '">' . wp_kses_post( wc_price( wc_get_customer_total_spent( $u->ID ) ) ) . '</td>';
			echo '<td data-label="' . esc_attr__( 'Cliente desde', 'villa-ibit-gestor' ) . '">' . esc_html( date_i18n( 'd/m/Y', strtotime( $u->user_registered ) ) ) . '</td>';
			echo '<td class="vig-row-actions">' . ( $wa ? '<a class="vig-icon-btn is-wa" target="_blank" rel="noopener" href="' . esc_url( 'https://wa.me/' . $wa ) . '" aria-label="WhatsApp">' . VIG_Admin::icon( 'chat', 16 ) . '</a>' : '' ) . '<a class="vig-icon-btn" href="mailto:' . esc_attr( $u->user_email ) . '" aria-label="E-mail">@</a></td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput
		}
		echo '</tbody></table></div></section>';
		VIG_Admin::pager( $paged, (int) ceil( $total / 25 ) );
		VIG_Admin::footer();
	}
}

/* ==================================================================== *
 * Avaliações
 * ==================================================================== */
class VIG_Reviews {

	public static function init() {
		add_action( 'admin_post_vig_review_action', array( __CLASS__, 'action' ) );
		add_action( 'admin_post_vig_review_reply', array( __CLASS__, 'reply' ) );
	}

	public static function render() {
		$status = isset( $_GET['status'] ) && 'hold' === $_GET['status'] ? 'hold' : 'all'; // phpcs:ignore WordPress.Security.NonceVerification
		$paged  = max( 1, isset( $_GET['paged'] ) ? absint( $_GET['paged'] ) : 1 ); // phpcs:ignore WordPress.Security.NonceVerification
		$args   = array( 'type' => 'review', 'status' => $status, 'number' => 20, 'offset' => ( $paged - 1 ) * 20, 'parent' => 0 );
		$items  = get_comments( $args );
		$total  = (int) get_comments( array_merge( $args, array( 'count' => true, 'number' => 0, 'offset' => 0 ) ) );
		$hold   = (int) get_comments( array( 'type' => 'review', 'status' => 'hold', 'count' => true ) );

		VIG_Admin::header( 'vi-gestor-avaliacoes', __( 'Avaliações', 'villa-ibit-gestor' ), '', __( 'Avaliações aprovadas com 4 ou 5 estrelas aparecem na home.', 'villa-ibit-gestor' ) );
		echo '<div class="vig-toolbar"><nav class="vig-seg"><a class="' . ( 'all' === $status ? 'is-on' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=vi-gestor-avaliacoes' ) ) . '">' . esc_html__( 'Todas', 'villa-ibit-gestor' ) . '</a><a class="' . ( 'hold' === $status ? 'is-on' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=vi-gestor-avaliacoes&status=hold' ) ) . '">' . esc_html__( 'Aguardando aprovação', 'villa-ibit-gestor' ) . ' <b>' . (int) $hold . '</b></a></nav></div>';
		if ( ! $items ) {
			VIG_Admin::empty_state( __( 'Nenhuma avaliação por aqui', 'villa-ibit-gestor' ) );
			VIG_Admin::footer();
			return;
		}
		echo '<div class="vig-reviews">';
		foreach ( $items as $r ) {
			$rating   = (int) get_comment_meta( $r->comment_ID, 'rating', true );
			$approved = '1' === $r->comment_approved;
			$replies  = get_comments( array( 'parent' => $r->comment_ID, 'status' => 'approve' ) );
			echo '<article class="vig-card vig-review' . ( $approved ? '' : ' is-pending' ) . '">';
			echo '<header><span class="vig-stars" aria-label="' . esc_attr( sprintf( __( '%d de 5 estrelas', 'villa-ibit-gestor' ), $rating ) ) . '">' . esc_html( str_repeat( '★', $rating ) . str_repeat( '☆', 5 - $rating ) ) . '</span>';
			echo '<strong>' . esc_html( $r->comment_author ) . '</strong><span class="vig-muted">' . esc_html( date_i18n( 'd/m/Y', strtotime( $r->comment_date ) ) ) . ' · <a href="' . esc_url( get_permalink( $r->comment_post_ID ) ) . '" target="_blank">' . esc_html( get_the_title( $r->comment_post_ID ) ) . '</a></span>';
			if ( get_comment_meta( $r->comment_ID, 'verified', true ) ) {
				echo '<span class="vig-pill is-green">' . esc_html__( 'Compra verificada', 'villa-ibit-gestor' ) . '</span>';
			}
			if ( ! $approved ) {
				echo '<span class="vig-pill is-gold">' . esc_html__( 'Aguardando', 'villa-ibit-gestor' ) . '</span>';
			}
			echo '</header><p>' . esc_html( $r->comment_content ) . '</p>';
			foreach ( $replies as $rep ) {
				echo '<div class="vig-review__reply"><strong>' . esc_html__( 'Resposta da loja', 'villa-ibit-gestor' ) . '</strong><p>' . esc_html( $rep->comment_content ) . '</p></div>';
			}
			echo '<footer>';
			$act = function ( $do, $label, $class = 'is-ghost is-sm' ) use ( $r ) {
				return VIG_Admin::btn( $label, wp_nonce_url( admin_url( 'admin-post.php?action=vig_review_action&do=' . $do . '&id=' . $r->comment_ID ), 'vig_review_' . $r->comment_ID ), $class );
			};
			echo $approved ? $act( 'unapprove', __( 'Ocultar', 'villa-ibit-gestor' ) ) : $act( 'approve', __( 'Aprovar', 'villa-ibit-gestor' ), 'is-primary is-sm' ); // phpcs:ignore WordPress.Security.EscapeOutput
			echo $act( 'spam', __( 'Spam', 'villa-ibit-gestor' ) ) . $act( 'trash', __( 'Excluir', 'villa-ibit-gestor' ), 'is-danger is-sm' ); // phpcs:ignore WordPress.Security.EscapeOutput
			echo '<details class="vig-reply"><summary>' . esc_html__( 'Responder', 'villa-ibit-gestor' ) . '</summary><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			wp_nonce_field( 'vig_review_reply_' . $r->comment_ID );
			echo '<input type="hidden" name="action" value="vig_review_reply"><input type="hidden" name="id" value="' . (int) $r->comment_ID . '"><label class="screen-reader-text" for="vig-rep-' . (int) $r->comment_ID . '">' . esc_html__( 'Resposta', 'villa-ibit-gestor' ) . '</label><textarea id="vig-rep-' . (int) $r->comment_ID . '" name="reply" rows="2" required></textarea><button class="vig-btn is-primary is-sm">' . esc_html__( 'Publicar resposta', 'villa-ibit-gestor' ) . '</button></form></details>';
			echo '</footer></article>';
		}
		echo '</div>';
		VIG_Admin::pager( $paged, (int) ceil( $total / 20 ) );
		VIG_Admin::footer();
	}

	public static function action() {
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		$do = isset( $_GET['do'] ) ? sanitize_key( wp_unslash( $_GET['do'] ) ) : '';
		if ( ! current_user_can( VIG_Admin::CAP ) || ! current_user_can( 'moderate_comments' ) ) {
			wp_die( esc_html__( 'Sem permissão.', 'villa-ibit-gestor' ) );
		}
		check_admin_referer( 'vig_review_' . $id );
		$map = array( 'approve' => 'approve', 'unapprove' => 'hold', 'spam' => 'spam', 'trash' => 'trash' );
		if ( isset( $map[ $do ] ) ) {
			wp_set_comment_status( $id, $map[ $do ] );
			$c = get_comment( $id );
			if ( $c && class_exists( 'WC_Comments' ) ) {
				WC_Comments::clear_transients( $c->comment_post_ID );
			}
		}
		VIG_Admin::back( admin_url( 'admin.php?page=vi-gestor-avaliacoes' ), __( 'Avaliação atualizada.', 'villa-ibit-gestor' ) );
	}

	public static function reply() {
		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		VIG_Admin::check_post( 'vig_review_reply_' . $id );
		$parent = get_comment( $id );
		$text   = isset( $_POST['reply'] ) ? sanitize_textarea_field( wp_unslash( $_POST['reply'] ) ) : '';
		if ( $parent && $text ) {
			$user = wp_get_current_user();
			wp_insert_comment(
				array(
					'comment_post_ID'      => $parent->comment_post_ID,
					'comment_parent'       => $id,
					'comment_content'      => $text,
					'comment_approved'     => 1,
					'comment_type'         => 'review',
					'user_id'              => $user->ID,
					'comment_author'       => get_bloginfo( 'name' ),
					'comment_author_email' => $user->user_email,
				)
			);
			if ( '1' !== $parent->comment_approved ) {
				wp_set_comment_status( $id, 'approve' );
			}
		}
		VIG_Admin::back( admin_url( 'admin.php?page=vi-gestor-avaliacoes' ), __( 'Resposta publicada.', 'villa-ibit-gestor' ) );
	}
}
