<?php
/**
 * Guarda credenciais das integrações com autenticação do conteúdo.
 *
 * @package VillaIbitGestor
 */
defined( 'ABSPATH' ) || exit;

final class VIG_Secrets {

	private static function key() {
		return hash_hmac( 'sha256', 'villa-ibit-integrations-v1:' . get_current_blog_id(), wp_salt( 'auth' ), true );
	}

	private static function error() {
		return new WP_Error( 'vig_secret', __( 'Não foi possível acessar a credencial. Confira a extensão de criptografia do PHP e salve a credencial novamente se as chaves do WordPress mudaram.', 'villa-ibit-gestor' ) );
	}

	/** @return string|WP_Error */
	public static function seal( $plain ) {
		try {
			if ( function_exists( 'sodium_crypto_secretbox' ) ) {
				$nonce = random_bytes( 24 );
				return 's1.' . base64_encode( $nonce . sodium_crypto_secretbox( $plain, $nonce, self::key() ) );
			}
			if ( function_exists( 'openssl_encrypt' ) && in_array( 'aes-256-gcm', openssl_get_cipher_methods(), true ) ) {
				$nonce = random_bytes( 12 );
				$tag   = '';
				$data  = openssl_encrypt( $plain, 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, $nonce, $tag );
				if ( false !== $data && 16 === strlen( $tag ) ) {
					return 'g1.' . base64_encode( $nonce . $tag . $data );
				}
			}
		} catch ( Throwable $exception ) {
			return self::error();
		}
		return self::error();
	}

	/** @return string|WP_Error */
	public static function open( $sealed ) {
		if ( ! is_string( $sealed ) ) {
			return self::error();
		}
		$format = substr( $sealed, 0, 3 );
		$bytes  = base64_decode( substr( $sealed, 3 ), true );
		if ( false === $bytes ) {
			return self::error();
		}
		try {
			$result = false;
			if ( 's1.' === $format && strlen( $bytes ) >= 40 && function_exists( 'sodium_crypto_secretbox_open' ) ) {
				$result = sodium_crypto_secretbox_open( substr( $bytes, 24 ), substr( $bytes, 0, 24 ), self::key() );
			} elseif ( 'g1.' === $format && strlen( $bytes ) >= 28 && function_exists( 'openssl_decrypt' ) ) {
				$result = openssl_decrypt( substr( $bytes, 28 ), 'aes-256-gcm', self::key(), OPENSSL_RAW_DATA, substr( $bytes, 0, 12 ), substr( $bytes, 12, 16 ) );
			}
			return false === $result ? self::error() : $result;
		} catch ( Throwable $exception ) {
			return self::error();
		}
	}
}
