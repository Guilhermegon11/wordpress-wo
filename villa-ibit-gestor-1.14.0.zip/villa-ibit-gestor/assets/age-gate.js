(function () {
	'use strict';

	var root = document.documentElement;
	var cookieName = 'vi_age_ok';
	var days = window.vigAgeRememberDays || 0;
	var daySeconds = 86400;
	var temporaryChoice = '';
	var modalOpened = false;

	function cookieChoice() {
		try {
			var cookies = document.cookie.split(/;\s*/);
			if (cookies.indexOf(cookieName + '=denied') !== -1) {
				return 'denied';
			}
			var prefix = cookieName + '=';
			for (var i = 0; i < cookies.length; i++) {
				if (cookies[i].indexOf(prefix) === 0) {
					return cookies[i].slice(prefix.length);
				}
			}
		} catch (error) {
			// O navegador pode impedir o acesso a cookies.
		}
		return '';
	}

	function sessionChoice() {
		try {
			return sessionStorage.getItem(cookieName) || '';
		} catch (error) {
			return '';
		}
	}

	function writeCookie(value, seconds) {
		try {
			var duration = typeof seconds === 'number' ? '; Max-Age=' + seconds : '';
			var secure = location.protocol === 'https:' ? '; Secure' : '';
			document.cookie = cookieName + '=' + value + '; Path=/; SameSite=Lax' + duration + secure;
		} catch (error) {
			// Com cookies bloqueados, a escolha pode durar apenas nesta aba.
		}
	}

	function setSessionChoice(value) {
		try {
			if (value) {
				sessionStorage.setItem(cookieName, value);
			} else {
				sessionStorage.removeItem(cookieName);
			}
		} catch (error) {
			// Mesmo sem armazenamento, a escolha funciona na página atual.
		}
	}

	function validApproval(value) {
		// A resposta antiga "1" não traz data. A primeira confirmação na nova versão inicia o prazo.
		var parts = /^(\d{13})\.(\d{1,2})$/.exec(value);
		if (!parts || !days) {
			return false;
		}
		var age = (Date.now() - Number(parts[1])) / 1000;
		var originalDays = Number(parts[2]);
		return originalDays >= 1 && originalDays <= 30 && age >= 0 && age < Math.min(days, originalDays) * daySeconds;
	}

	function choice() {
		var cookie = cookieChoice();
		var session = sessionChoice();
		if (cookie === 'denied' || session === 'denied' || temporaryChoice === 'denied') {
			return 'denied';
		}
		if (temporaryChoice === 'page' || validApproval(cookie) || validApproval(session) || validApproval(temporaryChoice)) {
			return 'verified';
		}
		return '';
	}

	function remember(approved) {
		if (approved && !days) {
			temporaryChoice = 'page';
			return;
		}
		var value = approved ? Date.now() + '.' + days : 'denied';
		writeCookie(value, approved ? days * daySeconds : null);
		temporaryChoice = cookieChoice() === value ? '' : value;
		setSessionChoice(temporaryChoice);
	}

	function beginPage() {
		if (temporaryChoice === 'page') {
			temporaryChoice = '';
		}
		if (!days) {
			var cookie = cookieChoice();
			if (cookie && cookie !== 'denied') {
				writeCookie('', 0);
			}
			var session = sessionChoice();
			if (session && session !== 'denied') {
				setSessionChoice('');
			}
		}
		applyChoice();
	}

	function applyChoice() {
		var current = choice();
		var verified = current === 'verified';
		var denied = current === 'denied';
		root.classList.toggle('vig-age-verified', verified);
		root.classList.toggle('vig-age-open', !verified);

		var gate = document.getElementById('vig-age');
		if (!gate) {
			return;
		}
		if (verified) {
			if (modalOpened && typeof gate.close === 'function') {
				gate.close();
			}
			gate.removeAttribute('open');
			gate.removeAttribute('data-state');
			modalOpened = false;
			return;
		}

		var state = denied ? 'denied' : 'question';
		var changed = gate.getAttribute('data-state') !== state;
		var title = denied ? 'vig-age-denied-t' : 'vig-age-t';
		document.getElementById('vig-age-question').hidden = denied;
		document.getElementById('vig-age-denied').hidden = !denied;
		gate.setAttribute('data-state', state);
		gate.setAttribute('aria-labelledby', title);
		gate.setAttribute('aria-describedby', denied ? 'vig-age-denied-d' : 'vig-age-d');

		if (!modalOpened) {
			// O diálogo já aparece no HTML. No navegador, abre na camada modal e isola a loja.
			gate.removeAttribute('open');
			if (typeof gate.showModal === 'function') {
				gate.showModal();
			} else {
				gate.setAttribute('open', '');
			}
			modalOpened = true;
		}
		if (changed || !gate.contains(document.activeElement)) {
			document.getElementById(title).focus({ preventScroll: true });
		}
	}

	// No head, consulta o navegador antes da primeira pintura, inclusive com HTML em cache.
	beginPage();
	document.addEventListener('click', function (event) {
		var button = event.target.closest && event.target.closest('#vig-age [data-vig-age-yes], #vig-age [data-vig-age-no]');
		if (!button || root.classList.contains('vig-age-verified') || choice() === 'denied') {
			return;
		}
		remember(button.hasAttribute('data-vig-age-yes'));
		applyChoice();
	});

	document.addEventListener('cancel', function (event) {
		if (event.target.id === 'vig-age') {
			event.preventDefault();
		}
	}, true);

	document.addEventListener('keydown', function (event) {
		if (event.key !== 'Tab' || root.classList.contains('vig-age-verified')) {
			return;
		}
		var gate = document.getElementById('vig-age');
		if (!gate) {
			return;
		}
		if (gate.getAttribute('data-state') === 'denied') {
			event.preventDefault();
			document.getElementById('vig-age-denied-t').focus();
			return;
		}
		var first = gate.querySelector('[data-vig-age-yes]');
		var last = gate.querySelector('[data-vig-age-no]');
		var focused = document.activeElement;
		if (!gate.contains(focused) || (event.shiftKey && (focused === first || focused.id === 'vig-age-t')) || (!event.shiftKey && focused === last)) {
			event.preventDefault();
			(event.shiftKey ? last : first).focus();
		}
	});
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', applyChoice);
	}
	window.addEventListener('pageshow', function (event) {
		if (event.persisted) {
			beginPage();
		} else {
			applyChoice();
		}
	});
	document.addEventListener('visibilitychange', function () {
		if (!document.hidden) {
			applyChoice();
		}
	});
}());
