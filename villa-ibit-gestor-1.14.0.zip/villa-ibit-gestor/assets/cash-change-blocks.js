/* global wc, wp */
(function () {
	'use strict';

	var config = wc.wcSettings.getSetting('vig-cash-change_data', {});
	var create = wp.element.createElement;
	var namespace = 'villa-ibit-gestor';

	function CashChange(props) {
		var active = wp.data.useSelect(function (select) {
			var currency = select('wc/store/cart').getCartTotals().currency_code;
			return config.gateway && currency === 'BRL' &&
				select('wc/store/payment').getActivePaymentMethod() === config.gateway;
		}, []);
		var value = wp.data.useSelect(function (select) {
			var data = select('wc/store/checkout').getExtensionData();
			return (data[namespace] && data[namespace].cash_tendered) || '';
		}, []);
		var setData = props.checkoutExtensionData.setExtensionData;

		wp.element.useEffect(function () {
			if (!active && value) {
				setData(namespace, 'cash_tendered', '');
			}
		}, [active, value, setData]);

		if (!active) {
			return null;
		}
		return create('div', { className: 'vig-cash-change' },
			create('label', { htmlFor: 'vig-cash-block-tendered' }, 'Troco para quanto? (R$)'),
			create('input', {
				id: 'vig-cash-block-tendered',
				type: 'text',
				inputMode: 'decimal',
				maxLength: 30,
				autoComplete: 'off',
				placeholder: 'Ex.: 250,00',
				'aria-describedby': 'vig-cash-block-help',
				value: value,
				onChange: function (event) {
					setData(namespace, 'cash_tendered', event.target.value);
				}
			}),
			create('small', { id: 'vig-cash-block-help' }, 'Informe o valor em dinheiro que vai entregar. Se tiver o valor exato, deixe em branco.')
		);
	}

	wc.blocksCheckout.registerCheckoutBlock({
		metadata: {
			name: 'villa-ibit/checkout-cash-change',
			parent: ['woocommerce/checkout-fields-block']
		},
		component: CashChange
	});
})();
