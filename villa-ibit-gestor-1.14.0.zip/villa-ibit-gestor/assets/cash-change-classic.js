/* Mantém o valor digitado quando o WooCommerce atualiza o frete e os pagamentos por AJAX. */
(function ($) {
	'use strict';

	function syncCashField() {
		$('[data-vig-cash-change]').each(function () {
			var form = this.closest('form');
			if (!form) { return; }
			var selected = form.querySelector('input[name="payment_method"]:checked');
			var input = this.querySelector('input[name="vig_cash_tendered"]');
			var gatewayId = this.dataset.vigCashChange;
			var cashRadio = form.querySelector('input[name="payment_method"][value="' + gatewayId + '"]');
			var cashOption = cashRadio && cashRadio.closest('.wc_payment_method');
			if (cashOption && this.parentNode !== cashOption) { cashOption.appendChild(this); }
			this.hidden = !selected || selected.value !== gatewayId;
			if (Object.prototype.hasOwnProperty.call(form.dataset, 'vigCashTendered')) {
				input.value = form.dataset.vigCashTendered;
			}
		});
	}

	$(function () {
		$(document.body).on('input change', '[name="vig_cash_tendered"]', function () {
			if (this.form) { this.form.dataset.vigCashTendered = this.value; }
		});
		$(document.body).on('change', 'input[name="payment_method"]', syncCashField);
		$(document.body).on('updated_checkout payment_method_selected', syncCashField);
		syncCashField();
	});
})(jQuery);
