/* Villa Ibit Gestor — interações do painel */
jQuery(function ($) {
  'use strict';
  var t = VIG.i18n;

  function flash($el, ok, msg) {
    $el.text(msg).toggleClass('is-err', !ok);
    if (ok) { setTimeout(function () { $el.text(''); }, 2500); }
  }
  function parseMoney(v) {
    v = String(v || '').trim();
    if (!v) { return NaN; }
    if (v.indexOf(',') > -1) { v = v.replace(/\./g, '').replace(',', '.'); }
    return parseFloat(v);
  }
  function money(n) { return 'R$ ' + n.toFixed(2).replace('.', ',').replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }

  $('[data-vig-home-order]').each(function () {
    var list = this;
    var status = list.parentNode.querySelector('[data-vig-order-status]');
    function orderFields() {
      return Array.from(list.querySelectorAll('input[name="vig[home_order][]"]'));
    }
    function keys(fields) {
      return fields.map(function (field) { return field.value; }).join(',');
    }
    var initialOrder = keys(orderFields());
    $(list).on('click', '[data-vig-move]', function () {
      var button = this;
      var row = button.closest('li');
      var up = button.dataset.vigMove === 'up';
      var neighbor = up ? row.previousElementSibling : row.nextElementSibling;
      if (!neighbor) { return; }
      list.insertBefore(row, up ? neighbor : neighbor.nextElementSibling);
      var fields = orderFields();
      var changed = keys(fields) !== initialOrder;
      fields.forEach(function (field, index) {
        var item = field.closest('li');
        field.disabled = !changed;
        item.querySelector('.vig-home-order__position').textContent = index + 1;
        item.querySelector('[data-vig-move="up"]').disabled = index === 0;
        item.querySelector('[data-vig-move="down"]').disabled = index === fields.length - 1;
      });
      var position = row.querySelector('.vig-home-order__position').textContent;
      var label = row.querySelector('.vig-toggle strong').textContent;
      status.textContent = list.dataset.vigPositionMessage.replace('%1$s', function () { return label; })
        .replace('%2$d', position).replace('%3$d', fields.length);
      (button.disabled ? row.querySelector('[data-vig-move]:enabled') : button).focus();
    });
  });

  /* Confirmar ações destrutivas */
  $(document).on('click', '[data-vig-confirm]', function (e) {
    if (!window.confirm($(this).data('vig-confirm') || t.confirm)) { e.preventDefault(); }
  });

  /* Some o aviso de "salvo" depois de alguns segundos */
  setTimeout(function () { $('.vig-toast:not(.is-err)').fadeOut(400); }, 4000);

  /* Status do pedido na lista */
  $(document).on('change', '[data-vig-status]', function () {
    var $s = $(this), $tr = $s.closest('tr'), $msg = $tr.find('.vig-saved');
    $s.prop('disabled', true); $msg.text(t.saving).removeClass('is-err');
    $.post(VIG.ajax, { action: 'vig_order_status', nonce: VIG.nonce, order: $tr.data('order'), status: $s.val() })
      .done(function (r) {
        if (r && r.success) { $s.attr('class', 'vig-status is-' + r.data.status); flash($msg, true, t.saved); }
        else { flash($msg, false, (r && r.data && r.data.message) || t.error); }
      })
      .fail(function () { flash($msg, false, t.error); })
      .always(function () { $s.prop('disabled', false); });
  });

  /* Estrela de destaque na lista de produtos */
  $(document).on('click', '[data-vig-star]', function () {
    var $b = $(this);
    $b.prop('disabled', true);
    $.post(VIG.ajax, { action: 'vig_toggle_featured', nonce: VIG.nonce, id: $b.data('vig-star') })
      .done(function (r) {
        if (r && r.success) {
          $b.toggleClass('is-on', !!r.data.featured).attr('aria-pressed', r.data.featured ? 'true' : 'false');
          $b.closest('tr').find('.vig-pill.is-gold').toggle(!!r.data.featured);
        }
      })
      .always(function () { $b.prop('disabled', false); });
  });

  /* ---------- Estoque rápido ---------- */
  function saveRow($tr) {
    var $msg = $tr.find('.vig-saved'), $btn = $tr.find('[data-vig-save]');
    $btn.prop('disabled', true); $msg.text(t.saving).removeClass('is-err');
    return $.post(VIG.ajax, {
      action: 'vig_save_product', nonce: VIG.nonce, id: $tr.data('id'),
      regular: $tr.find('[name=regular]').val(), sale: $tr.find('[name=sale]').val(),
      stock: $tr.find('[name=stock]').val(), status: $tr.find('[name=status]').val()
    }).done(function (r) {
      if (r && r.success) {
        flash($msg, true, t.saved); $tr.removeClass('is-dirty'); $tr.find('[name=status]').val(r.data.stock_status);
        if (r.data.summary && r.data.parent) {
          var $p = $('tr.vig-parent[data-parent="' + r.data.parent + '"]');
          $p.find('td.vig-sum, td.vig-actions').remove();
          $p.append(r.data.summary);
        }
      }
      else { flash($msg, false, (r && r.data && r.data.message) || t.error); }
    }).fail(function (x) {
      flash($msg, false, (x.responseJSON && x.responseJSON.data && x.responseJSON.data.message) || t.error);
    }).always(function () { $btn.prop('disabled', false); });
  }
  $(document).on('click', '[data-vig-save]', function () { saveRow($(this).closest('tr')); });
  $(document).on('input change', '.vig-row .vig-in', function () { $(this).closest('tr').addClass('is-dirty'); });
  $(document).on('input', '.vig-row [name=stock]', function () { $(this).closest('tr').find('[name=status]').prop('disabled', $(this).val() !== ''); });
  $(document).on('keydown', '.vig-row .vig-in', function (e) { if (e.key === 'Enter') { e.preventDefault(); saveRow($(this).closest('tr')); } });
  $(document).on('click', '[data-vig-toggle]', function () {
    var $b = $(this), $p = $b.closest('tr'), id = $p.data('parent'), open = $b.attr('aria-expanded') !== 'true';
    $('.vig-child-of-' + id).toggleClass('is-hidden', !open);
    $p.find('.vig-bulk__fields').prop('hidden', !open);
    $b.attr('aria-expanded', open ? 'true' : 'false');
  });
  $(document).on('click', '[data-vig-apply]', function () {
    var $p = $(this).closest('tr'), id = $p.data('parent');
    ['regular', 'sale'].forEach(function (k) {
      var v = $p.find('[data-bulk=' + k + ']').val();
      if (v !== '') { $('.vig-child-of-' + id + ' [name=' + k + ']').val(v).trigger('change'); }
    });
  });
  $(document).on('click', '[data-vig-save-all]', function () {
    var id = $(this).closest('tr').data('parent'), rows = $('.vig-child-of-' + id).toArray(), i = 0;
    (function next() { if (i < rows.length) { saveRow($(rows[i++])).always(next); } })();
  });

  /* ---------- Seleção por arraste + alteração em massa ---------- */
  var $bar = $('[data-vig-bulkbar]');
  if ($bar.length) {
    var dragging = false, dragValue = true, lastIdx = -1;
    var rows = function () { return $('.vig-stock tbody tr.vig-row'); };
    var refresh = function () {
      var n = 0;
      rows().each(function () {
        var on = $(this).find('.vig-sel__box').prop('checked');
        $(this).toggleClass('is-selected', on);
        if (on) { n++; }
      });
      $bar.find('[data-vig-sel-count]').text(n);
      $bar.prop('hidden', n === 0);
      $('[data-vig-sel-all]').prop('checked', n > 0 && n === rows().length);
    };
    var setRow = function ($tr, on) { $tr.find('.vig-sel__box').prop('checked', on); };
    var interactive = 'input:not(.vig-sel__box),select,textarea,button,a,label';

    $(document).on('mousedown', '.vig-stock tbody tr.vig-row', function (e) {
      if (e.button !== 0 || $(e.target).closest(interactive).length) { return; }
      var $tr = $(this), all = rows(), idx = all.index($tr);
      var box = $tr.find('.vig-sel__box');
      e.preventDefault();
      if (e.shiftKey && lastIdx > -1) {
        var a = Math.min(lastIdx, idx), b = Math.max(lastIdx, idx);
        all.slice(a, b + 1).each(function () { setRow($(this), true); });
      } else {
        dragValue = !box.prop('checked');
        setRow($tr, dragValue);
        dragging = true;
      }
      lastIdx = idx;
      refresh();
    });
    $(document).on('mouseenter', '.vig-stock tbody tr.vig-row', function () {
      if (!dragging) { return; }
      setRow($(this), dragValue);
      lastIdx = rows().index($(this));
      refresh();
    });
    $(document).on('mouseup', function () { dragging = false; });
    $(document).on('click', '.vig-sel__box', function (e) { if (e.detail !== 0) { e.preventDefault(); } });
    $(document).on('change', '.vig-sel__box', refresh);
    $(document).on('change', '[data-vig-sel-all]', function () { var on = this.checked; rows().each(function () { setRow($(this), on); }); refresh(); });
    $(document).on('click', '[data-vig-sel-clear]', function () { rows().each(function () { setRow($(this), false); }); refresh(); });

    $(document).on('click', '[data-vig-bulk-apply]', function () {
      var ids = rows().find('.vig-sel__box:checked').map(function () { return this.value; }).get();
      var data = { action: 'vig_bulk_products', nonce: VIG.nonce, ids: ids };
      $bar.find('[data-bulk-field]').each(function () { data[$(this).data('bulk-field')] = $(this).val(); });
      if (!ids.length) { return; }
      if (!data.price && !data.sale && !data.adjust && !data.stock) { window.alert('Preencha o novo preço, a promoção, o ajuste ou o estoque.'); return; }
      var $btn = $(this).prop('disabled', true).text(t.saving);
      $.post(VIG.ajax, data).done(function (r) {
        if (r && r.success) {
          var url = new URL(window.location.href);
          url.searchParams.set('vig_msg', r.data.message);
          window.location.href = url.toString();
        } else { window.alert((r && r.data && r.data.message) || t.error); $btn.prop('disabled', false).text('Aplicar nos selecionados'); }
      }).fail(function (x) {
        window.alert((x.responseJSON && x.responseJSON.data && x.responseJSON.data.message) || t.error);
        $btn.prop('disabled', false).text('Aplicar nos selecionados');
      });
    });
    refresh();
  }

  /* ---------- Imagens (biblioteca de mídia) ---------- */
  $(document).on('click', '[data-vig-pick-image]', function (e) {
    e.preventDefault();
    var $box = $(this).closest('[data-vig-image]');
    var frame = wp.media({ title: t.pick, button: { text: t.use }, library: { type: 'image' }, multiple: false });
    frame.on('select', function () {
      var a = frame.state().get('selection').first().toJSON();
      $box.find('input[name="image_id"]').val(a.id);
      $box.find('img').attr('src', a.sizes && a.sizes.medium ? a.sizes.medium.url : a.url).prop('hidden', false);
      $box.find('.vig-photo-drop span').prop('hidden', true);
    });
    frame.open();
  });
  $(document).on('click', '[data-vig-clear-image]', function (e) {
    e.preventDefault();
    var $box = $(this).closest('[data-vig-image]');
    $box.find('input[name="image_id"]').val(0);
    $box.find('img').attr('src', '').prop('hidden', true);
    $box.find('.vig-photo-drop span').prop('hidden', false);
  });

  /* Galeria do produto */
  function syncGallery($g) {
    $g.find('input[name="gallery"]').val($g.find('li').map(function () { return $(this).data('id'); }).get().join(','));
  }
  $(document).on('click', '[data-vig-gallery-add]', function (e) {
    e.preventDefault();
    var $g = $(this).closest('[data-vig-gallery]');
    var frame = wp.media({ title: t.picks, button: { text: t.use }, library: { type: 'image' }, multiple: 'add' });
    frame.on('select', function () {
      frame.state().get('selection').each(function (m) {
        var a = m.toJSON();
        if ($g.find('li[data-id="' + a.id + '"]').length) { return; }
        var src = a.sizes && a.sizes.thumbnail ? a.sizes.thumbnail.url : a.url;
        $g.find('.vig-gallery__list').append('<li data-id="' + a.id + '"><img src="' + src + '" alt=""><button type="button" aria-label="Remover" data-vig-gallery-remove>&times;</button></li>');
      });
      syncGallery($g);
    });
    frame.open();
  });
  $(document).on('click', '[data-vig-gallery-remove]', function () {
    var $g = $(this).closest('[data-vig-gallery]');
    $(this).closest('li').remove();
    syncGallery($g);
  });
  if ($.fn.sortable) {
    $('.vig-gallery__list').sortable({ update: function () { syncGallery($(this).closest('[data-vig-gallery]')); } });
  }

  /* Banner (Configurações) */
  $(document).on('click', '[data-vig-pick]', function (e) {
    e.preventDefault();
    var $box = $(this).closest('[data-vig-media]');
    var frame = wp.media({ title: t.pick, button: { text: t.use }, library: { type: 'image' }, multiple: false });
    frame.on('select', function () {
      var a = frame.state().get('selection').first().toJSON();
      $box.find('input[name$="[image_id]"], input[data-vig-id]').val(a.id);
      $box.find('img').attr('src', a.sizes && a.sizes.medium ? a.sizes.medium.url : a.url).prop('hidden', false);
    });
    frame.open();
  });
  $(document).on('click', '[data-vig-clear]', function (e) {
    e.preventDefault();
    var $box = $(this).closest('[data-vig-media]');
    $box.find('input[name$="[image_id]"], input[data-vig-id]').val(0);
    $box.find('input[name$="[image_def]"]').val('');
    var def = $box.attr('data-vig-default');
    if (def) { $box.find('img').attr('src', def).prop('hidden', false); } else { $box.find('img').attr('src', '').prop('hidden', true); }
  });

  /* ---------- Sabores ---------- */
  var $flavorBox = $('[data-vig-flavors]');
  if ($flavorBox.length) {
    var $list = $flavorBox.find('[data-vig-flavor-list]');
    var tpl = $flavorBox.find('[data-vig-flavor-template]').html();
    var counter = $list.children().length + 1000;
    var toggleStock = function () { $('[data-vig-simple-stock]').prop('hidden', $list.children().length > 0); };
    var addFlavor = function (name) {
      var $row = $(tpl.replace(/__i__/g, counter++));
      if (name) { $row.find('.vig-flavor__name').val(name); }
      $list.append($row);
      toggleStock();
      return $row;
    };
    $(document).on('click', '[data-vig-flavor-add]', function () { addFlavor('').find('.vig-flavor__name').trigger('focus'); });
    $(document).on('click', '[data-vig-flavor-bulk-add]', function () {
      var $ta = $('[data-vig-flavor-bulk]');
      var existing = $list.find('.vig-flavor__name').map(function () { return this.value.trim().toLowerCase(); }).get();
      $ta.val().split(/\r?\n/).forEach(function (line) {
        line = line.trim();
        if (line && existing.indexOf(line.toLowerCase()) === -1) { addFlavor(line); existing.push(line.toLowerCase()); }
      });
      $ta.val('');
    });
    $list.on('keydown', '.vig-flavor__name', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); addFlavor('').find('.vig-flavor__name').trigger('focus'); }
    });
    if ($.fn.sortable) { $list.sortable({ handle: '.vig-flavor__drag', axis: 'y' }); }
  }
  $(document).on('click', '[data-vig-row-remove]', function () {
    $(this).closest('li').remove();
    $('[data-vig-simple-stock]').prop('hidden', $('[data-vig-flavor-list]').children().length > 0);
  });

  /* Especificações */
  var specTpl = $('[data-vig-spec-template]').html();
  $(document).on('click', '[data-vig-spec-add]', function () { $('[data-vig-spec-list]').append(specTpl); });

  /* Prévia do preço no PIX */
  var $pix = $('[data-vig-pix]');
  if ($pix.length) {
    var pct = parseFloat(String($pix.data('pct')).replace(',', '.')) || 0;
    var updatePix = function () {
      var p = parseMoney($('[data-vig-sale]').val());
      if (isNaN(p)) { p = parseMoney($('[data-vig-price]').val()); }
      $pix.text(isNaN(p) ? '—' : money(p * (1 - pct / 100)));
    };
    $(document).on('input', '[data-vig-price],[data-vig-sale]', updatePix);
    updatePix();
  }

  /* Aviso ao sair sem salvar o produto */
  var dirty = false;
  $('#vig-product-form').on('input change', function () { dirty = true; }).on('submit', function () { dirty = false; });
  window.addEventListener('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; } });

  /* ---------- Celular: folha "Mais" ---------- */
  var sheet = document.getElementById('vig-sheet');
  var sheetBtn = document.querySelector('[data-vig-sheet-open]');
  function openSheet() {
    if (!sheet) { return; }
    sheet.hidden = false;
    requestAnimationFrame(function () { sheet.classList.add('is-open'); });
    if (sheetBtn) { sheetBtn.setAttribute('aria-expanded', 'true'); }
    document.documentElement.classList.add('vig-lock');
    var f = sheet.querySelector('.vig-sheet__item, button'); if (f) { f.focus(); }
  }
  function closeSheet() {
    if (!sheet || sheet.hidden) { return; }
    sheet.classList.remove('is-open');
    if (sheetBtn) { sheetBtn.setAttribute('aria-expanded', 'false'); sheetBtn.focus(); }
    document.documentElement.classList.remove('vig-lock');
    setTimeout(function () { sheet.hidden = true; }, 220);
  }
  $(document).on('click', '[data-vig-sheet-open]', function (e) { e.preventDefault(); openSheet(); });
  $(document).on('click', '[data-vig-sheet-close]', function (e) { e.preventDefault(); closeSheet(); });
  $(document).on('keydown', function (e) { if (e.key === 'Escape') { closeSheet(); } });

  /* ---------- App no celular: instalar e instruções ---------- */
  var ua = navigator.userAgent || '';
  var os = /iphone|ipad|ipod/i.test(ua) || (/macintosh/i.test(ua) && 'ontouchend' in document) ? 'ios' : (/android/i.test(ua) ? 'android' : 'desktop');
  var standalone = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
  var store = { get: function (k) { try { return localStorage.getItem(k); } catch (err) { return null; } }, set: function (k, v) { try { localStorage.setItem(k, v); } catch (err) {} } };
  $('[data-vig-os]').each(function () {
    var mine = this.getAttribute('data-vig-os') === os || (os === 'desktop' && this.getAttribute('data-vig-os') === 'desktop');
    this.hidden = !mine && os !== 'desktop';
  });
  if (os === 'desktop') { $('[data-vig-os="android"],[data-vig-os="ios"]').prop('hidden', false); }
  var $card = $('[data-vig-appcard]');
  if ($card.length && (standalone || store.get('vig_app_hide') === '1')) { $card.remove(); }
  $(document).on('click', '[data-vig-appcard-close]', function () { store.set('vig_app_hide', '1'); $(this).closest('[data-vig-appcard]').slideUp(150); });
  var deferred = null;
  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    deferred = e;
    $('[data-vig-install]').prop('hidden', false);
  });
  $(document).on('click', '[data-vig-install]', function () {
    if (!deferred) { return; }
    deferred.prompt();
    deferred.userChoice.then(function (choice) {
      if (choice && choice.outcome === 'accepted') { store.set('vig_app_hide', '1'); $('[data-vig-appcard]').slideUp(150); }
      deferred = null;
      $('[data-vig-install]').prop('hidden', true);
    });
  });
  window.addEventListener('appinstalled', function () { store.set('vig_app_hide', '1'); $('[data-vig-appcard]').remove(); });
  if (standalone) { document.documentElement.classList.add('vig-standalone'); }
});

/* ---------- Avisos de venda (1.8.0) ---------- */
jQuery(function ($) {
  'use strict';
  var N = VIG.notify || {}, t = VIG.i18n || {};
  var store = { get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} } };
  var ua = navigator.userAgent || '';
  var isIos = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  var standalone = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
  var canPush = 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window && !!N.vapid;

  function deviceName() {
    var os = /Android/.test(ua) ? 'Android' : isIos ? (/iPad/.test(ua) ? 'iPad' : 'iPhone') : /Windows/.test(ua) ? 'Windows' : /Mac/.test(ua) ? 'Mac' : /Linux/.test(ua) ? 'Linux' : '';
    var br = /Edg\//.test(ua) ? 'Edge' : /SamsungBrowser/.test(ua) ? 'Samsung Internet' : /Firefox\//.test(ua) ? 'Firefox' : /Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : '';
    return [os, br].filter(Boolean).join(' · ') + (standalone ? ' (app)' : '');
  }
  function keyBytes(b64) {
    var pad = '='.repeat((4 - b64.length % 4) % 4), raw = atob((b64 + pad).replace(/-/g, '+').replace(/_/g, '/')), out = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) { out[i] = raw.charCodeAt(i); }
    return out;
  }
  function swReady() {
    return new Promise(function (resolve, reject) {
      var done = false;
      navigator.serviceWorker.ready.then(function (r) { done = true; resolve(r); });
      setTimeout(function () { if (!done) { reject(new Error('sw')); } }, 8000);
    });
  }
  function currentSub() { return swReady().then(function (reg) { return reg.pushManager.getSubscription(); }); }

  var $box = $('[data-vig-push]'), $card = $('[data-vig-pushcard]');
  function say(msg, err) { $('[data-vig-push-msg]').text(msg || '').prop('hidden', !msg).toggleClass('is-err', !!err); }
  function paint(sub) {
    var on = !!sub;
    store.set('vig_push_on', on ? '1' : '0');
    $box.toggleClass('is-on', on);
    $box.find('[data-vig-push-status]').text(on ? t.pushOn : t.pushOff);
    $('[data-vig-push-on]').prop('hidden', on);
    $box.find('[data-vig-push-off],[data-vig-push-test]').prop('hidden', !on);
    $('.vig-devices li').each(function () { $(this).find('[data-vig-this]').prop('hidden', !(sub && this.getAttribute('data-endpoint') === sub.endpoint)); });
    if ($card.length) { $card.prop('hidden', on || store.get('vig_pushcard_hide') === '1' || Notification.permission === 'denied'); }
  }
  function blocked(msg) {
    $box.find('[data-vig-push-status]').text(t.pushOff);
    $box.find('[data-vig-push-on]').prop('hidden', true);
    say(msg, true);
  }
  function send(sub, extra) {
    return $.post(VIG.ajax, $.extend({ action: 'vig_push_subscribe', nonce: VIG.nonce, sub: JSON.stringify(sub), device: deviceName() }, extra || {}));
  }

  if ($box.length || $card.length) {
    if (!canPush) {
      if (isIos && !standalone) { blocked(t.pushIos); } else if (N.vapid) { blocked(t.pushNo); }
    } else if (Notification.permission === 'denied') {
      blocked(t.pushDenied);
    } else {
      currentSub().then(function (sub) {
        paint(sub);
        if (sub) { send(sub); } // mantém o aparelho na lista (e atualiza se as chaves mudaram)
      }).catch(function () { paint(null); });
    }
  }

  $(document).on('click', '[data-vig-push-on]', function () {
    var $b = $(this).prop('disabled', true);
    if (!canPush) { say(isIos && !standalone ? t.pushIos : t.pushNo, true); $b.prop('disabled', false); return; }
    say('');
    Notification.requestPermission().then(function (perm) {
      if (perm !== 'granted') { throw new Error(perm === 'denied' ? 'denied' : 'default'); }
      return swReady();
    }).then(function (reg) {
      return reg.pushManager.getSubscription().then(function (old) {
        return old || reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: keyBytes(N.vapid) });
      });
    }).then(function (sub) {
      return send(sub, { test: 1 }).then(function (r) {
        if (!r || !r.success) { throw new Error('server'); }
        paint(sub); say(t.pushOk);
        if ($card.length) { setTimeout(function () { $card.slideUp(200); }, 2500); }
      });
    }).catch(function (e) {
      say(e && e.message === 'denied' ? t.pushDenied : t.pushErr, true);
    }).then(function () { $b.prop('disabled', false); });
  });

  $(document).on('click', '[data-vig-push-off]', function () {
    var $b = $(this).prop('disabled', true);
    currentSub().then(function (sub) {
      if (!sub) { return null; }
      return $.post(VIG.ajax, { action: 'vig_push_unsubscribe', nonce: VIG.nonce, endpoint: sub.endpoint }).then(function () { return sub.unsubscribe(); });
    }).then(function () { paint(null); say(t.pushRemoved); }).catch(function () { say(t.pushErr, true); })
      .then(function () { $b.prop('disabled', false); });
  });

  $(document).on('click', '[data-vig-push-test]', function () {
    var $b = $(this).prop('disabled', true);
    currentSub().then(function (sub) {
      if (!sub) { throw new Error('nosub'); }
      return $.post(VIG.ajax, { action: 'vig_push_test', nonce: VIG.nonce, endpoint: sub.endpoint });
    }).then(function (r) {
      if (r && r.success) { say(t.pushTestOk); } else { say((r && r.data && r.data.message) || t.pushErr, true); }
    }, function (x) {
      say((x && x.responseJSON && x.responseJSON.data && x.responseJSON.data.message) || t.pushErr, true);
    }).then(function () { $b.prop('disabled', false); });
  });

  $(document).on('click', '[data-vig-pushcard-close]', function () { store.set('vig_pushcard_hide', '1'); $card.slideUp(150); });

  /* ---------- Aviso ao vivo com o painel aberto ---------- */
  if (!N.poll) { return; }
  var since = N.since || Math.floor(Date.now() / 1000), timer = null, audio = null;
  var seen = (store.get('vig_seen') || '').split(',').filter(Boolean);
  var baseTitle = document.title, unread = 0;

  function unlock() {
    if (audio || !N.sound) { return; }
    var A = window.AudioContext || window.webkitAudioContext;
    if (A) { try { audio = new A(); } catch (e) { audio = null; } }
  }
  $(document).one('pointerdown keydown touchstart', unlock);
  function chime() {
    if (!N.sound || !audio) { return; }
    try {
      if (audio.state === 'suspended') { audio.resume(); }
      var now = audio.currentTime;
      [[880, 0], [1318.5, 0.16]].forEach(function (n) {
        var o = audio.createOscillator(), g = audio.createGain();
        o.type = 'sine'; o.frequency.value = n[0];
        g.gain.setValueAtTime(0.0001, now + n[1]);
        g.gain.exponentialRampToValueAtTime(0.35, now + n[1] + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, now + n[1] + 0.9);
        o.connect(g); g.connect(audio.destination);
        o.start(now + n[1]); o.stop(now + n[1] + 1);
      });
    } catch (e) {}
  }
  function esc(s) { return $('<div>').text(s || '').html(); }
  function $stack() {
    var $s = $('.vig-live');
    if (!$s.length) { $s = $('<div class="vig-live" role="status" aria-live="polite"></div>').appendTo(document.body); }
    return $s;
  }
  function show(it) {
    var lines = String(it.body || '').split('\n').map(esc).join('<br>');
    var onOrders = /page=vi-gestor-pedidos(&|$)/.test(location.search) && !/pedido=/.test(location.search);
    var $t = $('<div class="vig-live__item">' +
      '<span class="vig-live__icon" aria-hidden="true"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg></span>' +
      '<div class="vig-live__body"><strong>' + esc(it.title) + '</strong><p>' + lines + '</p>' +
      '<div class="vig-live__actions"><a class="vig-btn is-primary is-sm" href="' + esc(it.url) + '">' + esc(t.liveOpen) + '</a>' +
      (onOrders ? '<button type="button" class="vig-btn is-ghost is-sm" data-vig-live-reload>' + esc(t.liveReload) + '</button>' : '') + '</div></div>' +
      '<button type="button" class="vig-live__x" aria-label="' + esc(t.liveClose) + '">×</button></div>');
    $stack().prepend($t);
    setTimeout(function () { $t.addClass('is-in'); }, 20);
    setTimeout(function () { close($t); }, 30000);
  }
  function close($t) { $t.removeClass('is-in'); setTimeout(function () { $t.remove(); }, 250); }
  $(document).on('click', '.vig-live__x', function () { close($(this).closest('.vig-live__item')); });
  $(document).on('click', '[data-vig-live-reload]', function () { location.reload(); });
  function setCount(n) {
    $('a[href*="page=vi-gestor-pedidos"]').each(function () {
      var $a = $(this), cls = $a.closest('.vig-nav').length ? 'vig-nav__count' : ($a.closest('.vig-tabbar, .vig-sheet').length ? 'vig-tabbar__count' : '');
      if (!cls || /pedido=|status=/.test(this.getAttribute('href'))) { return; }
      var $b = $a.find('.' + cls);
      if (!n) { $b.remove(); return; }
      if (!$b.length) { $b = $('<b class="' + cls + '"></b>').appendTo($a); }
      $b.text(n);
    });
  }
  function osNotify(it) {
    if (!document.hidden || store.get('vig_push_on') === '1' || !('Notification' in window) || Notification.permission !== 'granted' || !('serviceWorker' in navigator)) { return; }
    navigator.serviceWorker.getRegistration().then(function (reg) {
      if (reg) { reg.showNotification(it.title, { body: it.body, icon: N.icon, tag: 'vig-live-' + it.id, data: { url: it.url } }); }
    }).catch(function () {});
  }
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden) { unread = 0; document.title = baseTitle; poll(); }
  });
  function poll() {
    clearTimeout(timer);
    $.post(VIG.ajax, { action: 'vig_sales_poll', nonce: VIG.nonce, since: since, seen: seen.slice(-30) }).done(function (r) {
      if (!r || !r.success) { return; }
      if (r.data.nonce) { VIG.nonce = r.data.nonce; }
      var items = r.data.items || [];
      items.forEach(function (it) {
        seen.push(it.id); show(it); osNotify(it);
        if (document.hidden) { unread++; }
      });
      if (items.length) {
        chime();
        seen = seen.slice(-30); store.set('vig_seen', seen.join(','));
        if (unread) { document.title = '(' + unread + ') ' + baseTitle; }
      }
      if (typeof r.data.to_ship === 'number') { setCount(r.data.to_ship); }
    }).always(function () {
      timer = setTimeout(poll, document.hidden ? 60000 : 30000);
    });
  }
  timer = setTimeout(poll, 4000);
});
