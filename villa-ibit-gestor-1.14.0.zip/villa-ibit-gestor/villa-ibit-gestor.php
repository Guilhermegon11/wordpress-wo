<?php
/**
 * Plugin Name:       Villa Ibit Gestor
 * Description:       Painel simples para administrar a loja: resumo de vendas, aviso de cada nova venda (celular, painel, e-mail e WhatsApp), pedidos com troca rápida de status e WhatsApp do cliente, avisos pelo WaScript, sincronização de produtos do Bling, edição rápida de preços e estoque (inclusive sabores), banner da home, desconto no PIX, troco para pagamentos em dinheiro e verificação de idade (18+).
 * Version:           1.14.0
 * Author:            Villa Ibit
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * WC requires at least: 9.6
 * Text Domain:       villa-ibit-gestor
 * License:           GPLv2 or later
 *
 * @package VillaIbitGestor
 */

defined( 'ABSPATH' ) || exit;

define( 'VIG_VER', '1.14.0' );
define( 'VIG_FILE', __FILE__ );
define( 'VIG_DIR', plugin_dir_path( __FILE__ ) );
define( 'VIG_URL', plugin_dir_url( __FILE__ ) );
define( 'VIG_OPTION', 'vi_gestor' );

/**
 * Lê uma configuração salva (null quando não existe — o tema usa o padrão dele).
 *
 * @param string $key Chave.
 * @return mixed|null
 */
function vi_gestor_get( $key ) {
	$opts = get_option( VIG_OPTION, array() );
	return ( is_array( $opts ) && array_key_exists( $key, $opts ) ) ? $opts[ $key ] : null;
}

/**
 * Valor efetivo: salvo › padrão do tema › padrão do plugin.
 */
function vig_value( $key, $fallback = null ) {
	$v = vi_gestor_get( $key );
	if ( null !== $v ) {
		return function_exists( 'vi_local_delivery_setting' ) ? vi_local_delivery_setting( $key, $v ) : $v;
	}
	$defaults = vig_defaults();
	return array_key_exists( $key, $defaults ) ? $defaults[ $key ] : $fallback;
}

/**
 * Padrões (usa os do tema Villa Ibit quando ativo).
 */
function vig_defaults() {
	$base = array(
		'whatsapp'       => '',
		'whatsapp_label' => '',
		'instagram'      => '',
		'pix_percent'    => 0,
		'pix_apply'      => 0,
		'pix_gateways'   => array(),
		'cash_gateway'   => 'cod',
		'age_gate'       => 1,
		'age_remember_days' => 0,
		'hero_nature'    => 0,
		'birth_required' => 0,
		'age_title'      => 'Você tem 18 anos ou mais?',
		'age_text'       => 'A venda destes produtos é proibida para menores de 18 anos. Confirme sua idade para acessar a loja.',
		'low_stock'      => 3,
		'spotlight_product' => 0,
		'spotlight_title' => 'Destaque da semana',
		'featured_title' => 'Novidades',
		'featured_text'  => '',
		// Avisos de venda (1.8.0).
		'notify_push'    => 1,
		'notify_panel'   => 1,
		'notify_sound'   => 1,
		'notify_email'   => 0,
		'notify_emails'  => '',
		'notify_wc_off'  => 0,
		'notify_pending' => 0,
		'notify_wa'      => 0,
		'notify_wa_phone' => '',
		'notify_wa_key'  => '',
	);
	if ( function_exists( 'vi_theme_defaults' ) ) {
		$base = array_merge( $base, vi_theme_defaults() );
	}
	return $base;
}

/**
 * Compatibilidade com a tabela de pedidos de alta performance (HPOS) do WooCommerce.
 */
add_action(
	'before_woocommerce_init',
	function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', VIG_FILE, true );
		}
	}
);

add_action(
	'plugins_loaded',
	function () {
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action(
				'admin_notices',
				function () {
					echo '<div class="notice notice-error"><p><strong>Villa Ibit Gestor:</strong> ' . esc_html__( 'ative o WooCommerce para usar o plugin.', 'villa-ibit-gestor' ) . '</p></div>';
				}
			);
			return;
		}
		require VIG_DIR . 'includes/class-vig-admin.php';
		require VIG_DIR . 'includes/class-vig-dashboard.php';
		require VIG_DIR . 'includes/class-vig-orders.php';
		require VIG_DIR . 'includes/class-vig-products.php';
		require VIG_DIR . 'includes/class-vig-settings.php';
		require VIG_DIR . 'includes/class-vig-pix.php';
		require VIG_DIR . 'includes/class-vig-cash-change.php';
		require VIG_DIR . 'includes/class-vig-local-delivery.php';
		require VIG_DIR . 'includes/class-vig-age-gate.php';
		require VIG_DIR . 'includes/class-vig-birthdate.php';
		require VIG_DIR . 'includes/class-vig-brands.php';
		require VIG_DIR . 'includes/class-vig-product-editor.php';
		require VIG_DIR . 'includes/class-vig-terms.php';
		require VIG_DIR . 'includes/class-vig-sales.php';
		require VIG_DIR . 'includes/class-vig-layouts.php';
		require VIG_DIR . 'includes/class-vig-visual-home-order.php';
		require VIG_DIR . 'includes/class-vig-setup.php';
		require VIG_DIR . 'includes/class-vig-secrets.php';
		require_once VIG_DIR . 'includes/class-vig-integration-lock.php';
		require VIG_DIR . 'includes/class-vig-notify.php';
		require VIG_DIR . 'includes/class-vig-wascript.php';
		require VIG_DIR . 'includes/class-vig-bling.php';

		VIG_Admin::init();
		VIG_Orders::init();
		VIG_Products::init();
		VIG_Settings::init();
		VIG_Visual_Home_Order::init();
		VIG_Pix::init();
		VIG_Cash_Change::init();
		VIG_Local_Delivery::init();
		if ( interface_exists( \Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface::class ) ) {
			require VIG_DIR . 'includes/class-vig-cash-blocks.php';
			VIG_Cash_Blocks::init();
		}
		VIG_Age_Gate::init();
		VIG_Birthdate::init();
		VIG_Brands::init();
		VIG_Setup::init();
		VIG_Product_Editor::init();
		VIG_Terms::init();
		VIG_Coupons::init();
		VIG_Reviews::init();
		VIG_Notify::init();
		VIG_WaScript::init();
		VIG_Bling::init();
	}
);

// Atualizar o gestor só registra a versão. Páginas, kit, menus e opções WC
// pertencem à instalação existente e não devem migrar por conta própria.
add_action( 'admin_init', function () {
	if ( class_exists( 'VIG_Setup' ) && get_option( 'vig_version' ) !== VIG_VER ) {
		update_option( 'vig_version', VIG_VER, false );
	}
} );

/**
 * Link "Configurações" na lista de plugins.
 */
add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	function ( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=vi-gestor' ) ) . '">' . esc_html__( 'Abrir painel', 'villa-ibit-gestor' ) . '</a>' );
		return $links;
	}
);
